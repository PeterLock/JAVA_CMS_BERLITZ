package gui.training.com;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import control.gui.TableTemplate;
import settings.UI_Settings;
import utilities.SentryModule;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class ScheduleProductTrainingPanel extends JPanel {
	
	private JButton btnGenerate = new JButton("Generate e-mail");
	private JButton btnSend = new JButton("Send request to your local manager");
	
    private JFrame controllingFrame;
    private JPasswordField passwordField;
    
	static JTabbedPane pane = new JTabbedPane();
	private UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	private TextPrompt textPrompt;
	
	private JPanel pnlCanvas;
	private JPanel pnlDetails;
	private JPanel pnlCenter;
	private JPanel pnlInformation;
	private JPanel pnlButtons;
	private JPanel pnlPassword;
	private JPanel pnlMessageContainer;
	
	private JComboBox<?> cmbEmpName = new JComboBox<Object>(UI_Settings.getEmployeeNames());
	private JComboBox<?> cmbMaterialTraining = new JComboBox<Object>(UI_Settings.getBooks());
	private JComboBox<?> cmbCompleteTrainingBy = new JComboBox<Object>(UI_Settings.getTrainingToBeCompletedBy());
	private JComboBox<?> cmbRequestFrom = new JComboBox<Object>(UI_Settings.getEmployeeNames());
	private List<JComboBox> comboboxes = new ArrayList<JComboBox>();
	
	private JTextArea txtAreaMessage = new JTextArea(9, 60);
	private JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
	private JLabel labels[] = new JLabel[8];
	
	public ScheduleProductTrainingPanel() {
		
	}
	
	public Component run(){
		JScrollPane scroller = initialize();
		return scroller;
	}

	private JScrollPane initialize() {

        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
        JLabel label = new JLabel("Enter the password: ");
        label.setLabelFor(passwordField);

		/***********************Initialize Fields******************************/
		btnGenerate.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnGenerate.setFont(UI_Settings.getComponentInputFontSize());
		btnSend.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnSend.setFont(UI_Settings.getComponentInputFontSize());
        
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage.setVisible(false);
		
 		
 
		
		pnlCanvas = new JPanel();
		pnlCanvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		
		/**********************Create the components panel***********************/
		
		pnlDetails = new JPanel();
		pnlDetails.setBackground(Color.WHITE);
		pnlDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		pnlDetails.setLayout(new GridBagLayout());
		

		/*********************************************************************************************************************************/
		/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		pnlCanvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getCanvasSize700()));
		pnlCanvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getCanvasSize700()));
		/*********************************************************************************************************************************/
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(pnlCanvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());	
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
		
		//Add the details section and table sections to the canvas.
		pnlCanvas.add(pnlDetails, BorderLayout.NORTH);
		
		return scroller;
	}

}
