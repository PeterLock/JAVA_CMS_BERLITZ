package gui.training.com;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

public class Step4ControlCenter extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
	
	private static JPanel rootpanel;
	private static JPanel panel4_1;
	private static JPanel panel4_2;
	private static JPanel panel4_3;
	
	protected JPanel cards;
	protected JPanel card1;
	protected JPanel card2;
	protected JPanel card3;
	
	final static String STEP1 = "Step1";
    final static String STEP2 = "Step2";
    final static String STEP3 = "Step3";
    
	//declare objects//
	private Step4_1 step4_1 = new Step4_1();
	private Step4_2 step4_2 = new Step4_2();
	private Step4_3 step4_3 = new Step4_3();

    
    private Step4ControlCenter sessionObject;
	protected CreateTrainingSessionPanel createSessionObject;

	
	public Step4ControlCenter(){
		
		sessionObject = this;
		
		initializeCards();
		
	}
	
	private void initializeCards() {
		
		panel4_1 = step4_1.run(createSessionObject, sessionObject);
		panel4_2 = step4_2.run(sessionObject);
		panel4_3 = step4_3.run(createSessionObject, sessionObject);
		
		card1 = panel4_1;
		card2 = panel4_2;
		card3 = panel4_3;

		
		cards = new JPanel(new CardLayout());
		cards.add(card1, STEP1);
		cards.add(card2, STEP2);
		cards.add(card3, STEP3);
		
	}
	
	public JPanel run(CreateTrainingSessionPanel createSessionObject){
		
		this.createSessionObject = createSessionObject;
		rootpanel = new JPanel();
		rootpanel.setBackground(Color.WHITE);
		rootpanel.setLayout(new BoxLayout(rootpanel, BoxLayout.Y_AXIS));
		setPanelSize(rootpanel, new Dimension(new Dimension(screenWidth, 500)));

        
		cards.setAlignmentY(Component.LEFT_ALIGNMENT);
		rootpanel.add(cards);
		
		
		return rootpanel;
	}
	

	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}

	public void resetLocatorColors() {
		CreateTrainingSessionPanel.resetLocatorColors();
	}

	public void showStep3() {
		System.out.println("Inside Step4ControlCenter - showStep3");
		 CreateTrainingSessionPanel.resetLocatorColors();
		 CreateTrainingSessionPanel.locator3.setBackground(CreateTrainingSessionPanel.LOCATOR_ACTIVE_COLOR);
		 CardLayout cl = (CardLayout)( CreateTrainingSessionPanel.cards.getLayout());
		 cl.show( CreateTrainingSessionPanel.cards, CreateTrainingSessionPanel.STEP3);
		
	}
}
