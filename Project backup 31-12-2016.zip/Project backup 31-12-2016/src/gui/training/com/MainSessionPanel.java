package gui.training.com;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.border.Border;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import settings.UI_Settings;
import utilities.JTextFieldLimit;

public class MainSessionPanel extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private GridBagConstraints gc = new GridBagConstraints();
	private int width;
	private int height;
	private JPanel container;
	private JPanel header;
	private JPanel mainSection;
	private JLabel headerLabel;
	
	private String containerFontType = "Courier";
	private int headerHeight = 50;
	
	private JTextArea txtAreaConcept1;
	private JTextArea txtAreaConcept2;
	private JTextArea txtAreaOther1;

	
	List <JLabel> labels = new ArrayList<JLabel>();
	
	private Border border = BorderFactory.createLineBorder(new Color(180,180,180));
	
	private Color fontcolor = new Color(102,102,102);
	
	public MainSessionPanel(int width, int height){
		
		this.width = width/2;
		this.height = height;
		
		initialize();
		
	}

	private void initialize() {
		
		headerLabel = new JLabel("Main session");

		
		txtAreaConcept1 = new JTextArea(7, 20);
		txtAreaConcept1.setEditable(false);
		txtAreaConcept1.setFont(new Font(containerFontType, Font.PLAIN, (int)11.0f));
		txtAreaConcept1.setWrapStyleWord(true);
		txtAreaConcept1.setLineWrap(true);
		txtAreaConcept1.setDocument(new JTextFieldLimit(80));
		txtAreaConcept1.setPreferredSize(txtAreaConcept1.getPreferredSize());
		
		txtAreaConcept1.addMouseListener(new MouseAdapter(){
			
			public void mouseEntered(MouseEvent e){
			}
			
			public void mouseExited(MouseEvent e){
			}
			
		});
		
		txtAreaConcept2 = new JTextArea(7, 20);
		txtAreaConcept2.setEditable(false);
		txtAreaConcept2.setFont(new Font(containerFontType, Font.PLAIN, (int)11.0f));
		txtAreaConcept2.setWrapStyleWord(true);
		txtAreaConcept2.setLineWrap(true);
		txtAreaConcept2.setDocument(new JTextFieldLimit(80));
		txtAreaConcept2.setPreferredSize(txtAreaConcept2.getPreferredSize());
		
		txtAreaConcept2.addMouseListener(new MouseAdapter(){
			
			public void mouseEntered(MouseEvent e){
			}
			
			public void mouseExited(MouseEvent e){
			}
			
		});
		
		txtAreaOther1 = new JTextArea(12, 20);
		txtAreaOther1.setEditable(false);
		txtAreaOther1.setFont(new Font(containerFontType, Font.PLAIN, (int)11.0f));
		txtAreaOther1.setWrapStyleWord(true);
		txtAreaOther1.setLineWrap(true);
		txtAreaOther1.setDocument(new JTextFieldLimit(80));
		txtAreaOther1.setPreferredSize(txtAreaOther1.getPreferredSize());
		
		txtAreaOther1.addMouseListener(new MouseAdapter(){
			
			public void mouseEntered(MouseEvent e){
			}
			
			public void mouseExited(MouseEvent e){
			}
			
		});
	}

	public JPanel run(){
		
		JPanel container = setUpMainContainer();
		
		return container;
	}
	
	private JPanel setUpMainContainer() {
		
		int count = 0;
		int offset = 0;
		
		//String containerFontType = headerLabel.getFont().getFontName();
		
		container = new JPanel();
		container.setLayout(new GridBagLayout());
		setPanelSize(container, new Dimension(width, height));
		container.setBackground(Color.WHITE);
		
		//Add the header//
		header = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 18));
		setPanelSize(header, new Dimension(width, headerHeight));
		header.setBackground(new Color(25,120,174));
		headerLabel.setFont(new Font(containerFontType, Font.BOLD, (int)12.0f));
		
		headerLabel.setForeground(Color.WHITE);
		header.add(headerLabel);
		
		gc.gridx = 0;
		gc.gridy = count;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.insets = new Insets(0,0,2,0);
		container.add(header, gc);
		
		offset = headerHeight+headerHeight/2;
		
		//Add the body of this container - this holds the session briefing, session notes 1, and session notes 2//
		mainSection = new JPanel();
		mainSection.setLayout(new GridBagLayout());
		mainSection.setBackground(Color.WHITE);
		setPanelSize(mainSection, new Dimension(width, this.height-offset+3));
		mainSection.setBorder(border);
		
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.fill = GridBagConstraints.NONE;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.insets = new Insets(5,10,0,0);
		
		JTextPane text = new JTextPane();
		text.setFont(new Font(containerFontType, Font.PLAIN, (int)11.0f));

		text.setForeground(UI_Settings.getComponentsFontColorDark());
		text.setBackground(Color.WHITE);
		text.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.5);
		
		text.setParagraphAttributes(set, true);
		text.setText("Run through the following \nprocesses:");
		
		mainSection.add(text, gc);
		
		JLabel label1 = new JLabel("Point 1:");
		label1.setFont(new Font(containerFontType, Font.PLAIN, (int)11.0f));
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.insets = new Insets(10,10,0,0);
		mainSection.add(label1, gc);
		
		gc.gridx = 0;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(10,10,0,10);
		mainSection.add(txtAreaConcept1, gc);
		
		JLabel label2 = new JLabel("Point 2:");
		label2.setFont(new Font(containerFontType, Font.PLAIN, (int)11.0f));
		
		gc.gridx = 0;
		gc.gridy = 3;
		gc.insets = new Insets(10,10,0,0);
		mainSection.add(label2, gc);
		
		gc.gridx = 0;
		gc.gridy = 4;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(10,10,0,10);
		mainSection.add(txtAreaConcept2, gc);
		
		JLabel label3 = new JLabel("Point 3:");
		label3.setFont(new Font(containerFontType, Font.PLAIN, (int)11.0f));
		
		gc.gridx = 0;
		gc.gridy = 5;
		gc.insets = new Insets(10,10,0,0);
		mainSection.add(label3, gc);
		
		gc.gridx = 0;
		gc.gridy = 6;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(10,10,40,10);
		mainSection.add(txtAreaOther1, gc);
		
		
		
		gc.gridy = ++count;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.fill = GridBagConstraints.NONE;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.insets = new Insets(0,0,7,0);
		container.add(mainSection, gc);
		
		return container;
	}

	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
}
