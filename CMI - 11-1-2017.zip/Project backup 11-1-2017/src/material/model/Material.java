package material.model;

import java.io.Serializable;


public class Material implements Serializable {
	
	String materialName = "";
	String publisherName = "";
	String edition = "";
	int numLevels = 0;
	int numChapters = 0;
	String hasReport = "";
	String hasDvd = "";
	String hasReader = "";
	String hasTest = "";
	String testInformation = "";
	String materialDescription = "";
	String materialComments = "";
	int id = 0;

	
	public Material(String materialName, String publisherName, String edition, int numLevels, int numChapters,
			String hasReport, String hasDvd, String hasReader, String hasTest, String testInformation, String materialDescription,
			String materialComments, int ID){
		
		this.materialName = materialName;
		this.publisherName = publisherName;
		this.edition = edition;
		this.numLevels = numLevels;
		this.numChapters = numChapters;
		this.hasReport = hasReport;
		this.hasDvd = hasDvd;
		this.hasReader = hasReader;
		this.hasTest = hasTest;
		this.testInformation = testInformation;
		this.materialDescription = materialDescription;
		this.materialComments = materialComments;
		this.id = ID;
		
		
	}


	public String getMaterialName() {
		return materialName;
	}


	public void setMaterialName(String materialName) {
		this.materialName = materialName;
	}


	public String getPublisherName() {
		return publisherName;
	}


	public void setPublisherName(String publisherName) {
		this.publisherName = publisherName;
	}


	public String getEdition() {
		return edition;
	}


	public void setEdition(String edition) {
		this.edition = edition;
	}


	public int getNumLevels() {
		return numLevels;
	}


	public void setNumLevels(int numLevels) {
		this.numLevels = numLevels;
	}


	public int getNumChapters() {
		return numChapters;
	}


	public void setNumChapters(int numChapters) {
		this.numChapters = numChapters;
	}


	public String getHasReport() {
		return hasReport;
	}


	public void setHasReport(String hasReport) {
		this.hasReport = hasReport;
	}


	public String getHasDvd() {
		return hasDvd;
	}


	public void setHasDvd(String hasDvd) {
		this.hasDvd = hasDvd;
	}


	public String getHasReader() {
		return hasReader;
	}


	public void setHasReader(String hasReader) {
		this.hasReader = hasReader;
	}


	public String getHasTest() {
		return hasTest;
	}


	public void setHasTest(String hasTest) {
		this.hasTest = hasTest;
	}


	public String getTestInformation() {
		return testInformation;
	}


	public void setTestInformation(String testInformation) {
		this.testInformation = testInformation;
	}


	public String getMaterialDescription() {
		return materialDescription;
	}


	public void setMaterialDescription(String materialDescription) {
		this.materialDescription = materialDescription;
	}


	public String getMaterialComments() {
		return materialComments;
	}


	public void setMaterialComments(String materialComments) {
		this.materialComments = materialComments;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}

}
