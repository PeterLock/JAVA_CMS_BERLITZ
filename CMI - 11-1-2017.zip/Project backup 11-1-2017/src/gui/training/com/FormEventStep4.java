package gui.training.com;

import java.util.ArrayList;
import java.util.EventObject;
import java.util.List;

public class FormEventStep4 extends EventObject {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String subTopic1Title;
	String subTopic1WhatDoEmployeesNeedToLearn;
	String subTopic1WhyImportant;
	List<String> subTopic1TrainingToolsArray = new ArrayList<String>();

	String subTopic2Title;
	String subTopic2WhatDoEmployeesNeedToLearn;
	String subTopic2WhyImportant;
	List<String> subTopic2TrainingToolsArray = new ArrayList<String>();

	public int getSubTopic1Time() {
		return subTopic1Time;
	}


	public void setSubTopic1Time(int subTopic1Time) {
		this.subTopic1Time = subTopic1Time;
	}


	public int getSubTopic2Time() {
		return subTopic2Time;
	}


	public void setSubTopic2Time(int subTopic2Time) {
		this.subTopic2Time = subTopic2Time;
	}



	int subTopic1Time;
	int subTopic2Time;
	int totalTime;

	public int getTotalTime() {
		return totalTime;
	}


	public void setTotalTime(int totalTime) {
		this.totalTime = totalTime;
	}


	public FormEventStep4(Object source, String subTopic1Title, String subTopic1WhatDoEmployeesNeedToLearn, String subTopic1WhyImportant, 
			List<String> subTopic1TrainingToolsArray, String subTopic2Title, String subTopic2WhatDoEmployeesNeedToLearn, String subTopic2WhyImportant, 
			List<String> subTopic2TrainingToolsArray, int subTopic1Time, int subTopic2Time, int totalTime) {
		super(source);
		
		this.subTopic1TrainingToolsArray.clear();
		this.subTopic2TrainingToolsArray.clear();
		
		
		this.subTopic1Title = subTopic1Title;
		this.subTopic1WhatDoEmployeesNeedToLearn = subTopic1WhatDoEmployeesNeedToLearn;
		this.subTopic1WhyImportant = subTopic1WhyImportant;
		this.subTopic1TrainingToolsArray = subTopic1TrainingToolsArray;
		
		this.subTopic2Title = subTopic2Title;
		this.subTopic2WhatDoEmployeesNeedToLearn = subTopic2WhatDoEmployeesNeedToLearn;
		this.subTopic2WhyImportant = subTopic2WhyImportant;
		this.subTopic2TrainingToolsArray = subTopic2TrainingToolsArray;
	}


	public String getSubTopic1Title() {
		return subTopic1Title;
	}



	public void setSubTopic1Title(String subTopic1Title) {
		this.subTopic1Title = subTopic1Title;
	}



	public String getSubTopic1WhatDoEmployeesNeedToLearn() {
		return subTopic1WhatDoEmployeesNeedToLearn;
	}



	public void setSubTopic1WhatDoEmployeesNeedToLearn(String subTopic1WhatDoEmployeesNeedToLearn) {
		this.subTopic1WhatDoEmployeesNeedToLearn = subTopic1WhatDoEmployeesNeedToLearn;
	}



	public String getSubTopic1WhyImportant() {
		return subTopic1WhyImportant;
	}



	public void setSubTopic1WhyImportant(String subTopic1WhyImportant) {
		this.subTopic1WhyImportant = subTopic1WhyImportant;
	}



	public List<String> getSubTopic1TrainingToolsArray() {
		return subTopic1TrainingToolsArray;
	}



	public void setSubTopic1TrainingToolsArray(List<String> subTopic1TrainingToolsArray) {
		this.subTopic1TrainingToolsArray = subTopic1TrainingToolsArray;
	}



	public String getSubTopic2Title() {
		return subTopic2Title;
	}



	public void setSubTopic2Title(String subTopic2Title) {
		this.subTopic2Title = subTopic2Title;
	}



	public String getSubTopic2WhatDoEmployeesNeedToLearn() {
		return subTopic2WhatDoEmployeesNeedToLearn;
	}



	public void setSubTopic2WhatDoEmployeesNeedToLearn(String subTopic2WhatDoEmployeesNeedToLearn) {
		this.subTopic2WhatDoEmployeesNeedToLearn = subTopic2WhatDoEmployeesNeedToLearn;
	}



	public String getSubTopic2WhyImportant() {
		return subTopic2WhyImportant;
	}



	public void setSubTopic2WhyImportant(String subTopic2WhyImportant) {
		this.subTopic2WhyImportant = subTopic2WhyImportant;
	}



	public List<String> getSubTopic2TrainingToolsArray() {
		return subTopic2TrainingToolsArray;
	}



	public void setSubTopic2TrainingToolsArray(List<String> subTopic2TrainingToolsArray) {
		this.subTopic2TrainingToolsArray = subTopic2TrainingToolsArray;
	}

}
