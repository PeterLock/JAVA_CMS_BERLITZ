package customer.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ColorUIResource;

import control.gui.FormListener;
import control.gui.PasswordListener;
import customer.controller.Controller;
import customer.model.Customer;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.SentryModule;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class CustomerControlCenter extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTabbedPane pane = new JTabbedPane();
	JPasswordField passwordField;
    JFrame controllingFrame; 
    private Controller controller;
	
	
	private ViewCustomerPanel viewCustomerPanel;
	private AddCustomerPanel addCustomerPanel;

    
    private FormListener formListener;
	
	public CustomerControlCenter(Controller controller) {
		this.controller = controller;
        initializeUI();
    }
	

    private void initializeUI() {
    	
    	viewCustomerPanel = new ViewCustomerPanel(controller);
    	addCustomerPanel = new AddCustomerPanel(controller);
    	
    	UIManager.put("Label.font", UI_Settings.getComponentsFontPlain());
    	UIManager.put("Label.foreground", UI_Settings.getComponentsFontColorDark());
    	
    	UIManager.put("OptionPane.messageFont", new Font("System", Font.PLAIN, 12));
    	UIManager.put("OptionPane.buttonFont", new Font("System", Font.PLAIN, 12));
    	
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, java.awt.Toolkit.getDefaultToolkit().getScreenSize().height));

        //OK
        UIManager.put("TabbedPane.selected", new ColorUIResource(UI_Settings.getBottomTabColor()));
        UIManager.put("TabbedPane.unselectedTabBackground", UI_Settings.getCmsGray());       
       
        //OK
        UIManager.getDefaults().put("TabbedPane.tabAreaInsets", new Insets(0,0,0,0));
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0)); 
        
        pane.setFocusable(false);
        pane.setBorder(new EmptyBorder(0, 0, 0, 0));
        
        //Sets the JPanel container to black
        setBackground(UI_Settings.getCmsTabSecondLvlGrey());
        pane.addTab("<html><body><table width='70' style='font-size:11'><td style='text-align:center'>View All</td></table></body></html>", viewCustomerPanel.run());		//0
        pane.addTab("<html><body><table width='90' style='font-size:11'><td style='text-align:center'>Add Customer</td></table></body></html>", addCustomerPanel.run());		//1
        //Set the text color for each tab
        pane.setForeground(UI_Settings.getButtonPanelColor());

        pane.setBackgroundAt(0, UI_Settings.getCmsGray());	//0
        pane.setBackgroundAt(1, UI_Settings.getCmsGray());	//1

    
        changeUI(UI_Settings.getBottomTabColor());
    }


	public void changeUI( Color bottomTabColor) {
        pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            @Override protected int calculateTabHeight(
              int tabPlacement, int tabIndex, int fontHeight) {
            	
    	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       focus = UI_Settings.getCmsTabSecondLvlGrey();
            	
              return 27;
            }
            

            @Override protected void paintTab(
              Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
              Rectangle iconRect, Rectangle textRect) {
        
               rects[tabIndex].height = 25 + 1;
               rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
              
              super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
            }
          });
        //Add the tab to the canvas
        this.add(pane, BorderLayout.CENTER);	
	}

	public static void showFrame() {
        JPanel panel = new CustomerControlCenter(null);
        JFrame frame = new JFrame("CMS Test Screen");
        frame.setLocationRelativeTo(null);
        JFrame.setDefaultLookAndFeelDecorated(false);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.setPreferredSize(UI_Settings.getMinimumScreenSize());
        frame.pack();
        frame.setVisible(true);
        frame.setBackground(UI_Settings.getButtonPanelColor());
    }
	
    public void changeTheme(Color c) {
      UIManager.put("TabbedPane.selected",new ColorUIResource(c));
		 
      pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          @Override protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
            return 27;
          }
      });
      
	pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
	    @Override protected int calculateTabHeight(
	      int tabPlacement, int tabIndex, int fontHeight) {
	    	
	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
	       focus = UI_Settings.getCmsTabSecondLvlGrey();
	    	
	      return 27;
	    }
	    
	    @Override protected void paintTab(
	      Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
	      Rectangle iconRect, Rectangle textRect) {
	
	       rects[tabIndex].height = 25 + 1;
	       rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
	      
	      super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
	    }
	  });
	}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                CustomerControlCenter.showFrame();
            }
        });
    }

	public void setFormListener(FormListener listener){
		this.formListener = listener;
		
		viewCustomerPanel.setFormListener(this.formListener);
		addCustomerPanel.setFormListener(this.formListener);

		
	}


	public void refresh() {
		viewCustomerPanel.refresh();
		addCustomerPanel.refresh();
	}

	public void resetPanels() {
		addCustomerPanel.resetPanels();
	}


	public void switchTabs() {
		pane.setSelectedIndex(1);
	}


	public void setPasswordListener(PasswordListener passwordListener) {
		viewCustomerPanel.setPasswordListener(passwordListener);
		addCustomerPanel.setPasswordListener(passwordListener);
	}
}