package control.gui;

import javax.swing.JDialog;

import customer.gui.CustomerPane;

public class GenerateDialog extends JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GenerateDialog(CustomerPane customerPane){
		super();
		
		setSize(300,650);
	}
}
