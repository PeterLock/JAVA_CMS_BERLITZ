package material.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.SentryModule;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class AddMaterialPanel extends JPanel {
	
	private UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	private TextPrompt textPrompt;

	private JPasswordField passwordField;
	private JFrame controllingFrame; 
	private Calendar c = Calendar.getInstance();
	private JLabel lblDate = new JLabel(c.getTime().toString());
	static JTabbedPane pane = new JTabbedPane();
	private Border lightBorder = BorderFactory.createLineBorder(new Color(192,192,192));
	
	private JCheckBox chkDVDYes;
	private JCheckBox chkReaderYes;
	private JCheckBox chkTestYes;
	private JCheckBox chkReportYes;

	private JCheckBox chkDVDNo;
	private	JCheckBox chkReaderNo;
	private JCheckBox chkTestNo;
	private JCheckBox chkReportNo;
	
	private JTextArea txtAreaTestInformation;
	private JTextField txtNewMaterialName;
	private JTextField txtPublisherName;
	private JTextField txtEdition;
	private JTextField txtLevels;
	private JTextField txtChapters;
	private JTextField txtNeedsReport;
	private JTextField txtDVD;
	private JTextField txtReader;
	private JTextField txtTest;
	
	List<JTextField> materialTextFields = new ArrayList<JTextField>();
	
	private List <JCheckBox> checkboxes = new ArrayList<JCheckBox>();

	
	public AddMaterialPanel(){
		
	}
	
	public Component run(){
		JScrollPane scroller = initialize();
		return scroller;
	}

	private JScrollPane initialize() {
		
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;

		JComboBox<String> cmbMaterialName = new JComboBox<String>(UI_Settings.getBooks());
		
		JTextArea txtareaMaterialDescription;
		JTextArea txtareaTeachingComments;
		
		/***********************Initialize Fields******************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage.setVisible(false);
		
		JPasswordField passwordField;
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
		
		JLabel labels[] = new JLabel[11];
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("http://www.NGL.Cennage.com");
		labels[2] = new JLabel("delete");
		labels[3] = new JLabel("edit");
		labels[4] = new JLabel("delete");
		labels[5] = new JLabel("edit");
		labels[6] = new JLabel("delete");
		labels[7] = new JLabel("edit");
		labels[8] = new JLabel("Administrator password");
		labels[9] = new JLabel("help");
		labels[10] = new JLabel("delete material");
		
		for(int i = 0; i< 11; i++ ) {
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		
		JButton btnDeleteMaterial = new JButton("Delete Material");
		btnDeleteMaterial.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnDeleteMaterial.setPreferredSize(UI_Settings.getJbuttonSize());
		btnDeleteMaterial.setFont(UI_Settings.getComponentInputFontSize());
		
		JButton btnAddCustomerToGroup = new JButton("Commit Changes");
		btnAddCustomerToGroup.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnAddCustomerToGroup.setFont(UI_Settings.getComponentInputFontSize());
		btnAddCustomerToGroup.setPreferredSize(new Dimension(180,UI_Settings.getJbuttonSize().height));
		btnAddCustomerToGroup.setMinimumSize(new Dimension(180,UI_Settings.getJbuttonSize().height));
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		int size = 12;
		txtPublisherName = new JTextField(size);
		txtPublisherName.setMinimumSize(txtPublisherName.getPreferredSize());
		txtPublisherName.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtPublisherName); 
		
		txtEdition = new JTextField(size);
		txtEdition.setMinimumSize(txtEdition.getPreferredSize());
		txtEdition.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtEdition); 
		
		txtLevels = new JTextField(size);
		txtLevels.setMinimumSize(txtLevels.getPreferredSize());
		txtLevels.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtLevels); 
		
		txtChapters = new JTextField(size);
		txtChapters.setMinimumSize(txtChapters.getPreferredSize());
		txtChapters.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtChapters); 
		
		txtNeedsReport = new JTextField(size);
		txtNeedsReport.setMinimumSize(txtNeedsReport.getPreferredSize());
		txtNeedsReport.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtNeedsReport); 
		
		txtDVD = new JTextField(size);
		txtDVD.setMinimumSize(txtDVD.getPreferredSize());
		txtDVD.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtDVD); 
		
		txtReader = new JTextField(size);
		txtReader.setMinimumSize(txtReader.getPreferredSize());
		txtReader.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtReader); 
		
		txtTest = new JTextField(size);
		txtTest.setMinimumSize(txtTest.getPreferredSize());
		txtTest.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtTest); 
		
		/***************************************************Create textAreas********************************************************************/
		txtareaMaterialDescription = new JTextArea(6, 30);
		txtareaMaterialDescription.setEditable(true);
		txtareaMaterialDescription.setBorder(UI_Settings.getBorderoutline());
		txtareaMaterialDescription.setWrapStyleWord(true);
		txtareaMaterialDescription.setLineWrap(true);
		txtareaMaterialDescription.setDocument(new JTextFieldLimit(250));
		TextPrompt textPrompt = new TextPrompt("<no material description entered>", txtareaMaterialDescription);
		
		txtareaTeachingComments = new JTextArea(6, 30);
		txtareaTeachingComments.setEditable(true);
		txtareaTeachingComments.setBorder(UI_Settings.getBorderoutline());
		txtareaTeachingComments.setWrapStyleWord(true);
		txtareaTeachingComments.setLineWrap(true);
		txtareaTeachingComments.setDocument(new JTextFieldLimit(250));
		textPrompt = new TextPrompt("no teaching comments entered", txtareaTeachingComments);

		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
			   int action = JOptionPane.showConfirmDialog(AddMaterialPanel.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		      
			   if(action == JOptionPane.OK_OPTION){
					cmbMaterialName.setSelectedIndex(0);
		       }
			}
		});
		
		
		labels[1].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(AddMaterialPanel.this, "The http://www.NGL.Cennage.com button has been pressed.", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		labels[2].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(AddMaterialPanel.this, "The delete button has been pressed.", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		//This is the Edit Material Description TextField
		labels[3].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(AddMaterialPanel.this, "The edit button has been pressed.1", "", JOptionPane.PLAIN_MESSAGE);
				
				
				
			}
			
		});
		labels[4].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(AddMaterialPanel.this, "The delete button has been pressed.", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		//This is the Edit Material Comments TextField
		labels[5].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(AddMaterialPanel.this, "The edit button has been pressed.2", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		labels[6].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(AddMaterialPanel.this, "The delete button has been pressed.", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		labels[7].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(AddMaterialPanel.this, "The edit button has been pressed.3", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		
		chkDVDYes = new JCheckBox("Yes");
		chkDVDYes.setFont(UI_Settings.getComponentsFontPlain());
		chkDVDYes.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkDVDYes);
		
		chkReaderYes = new JCheckBox("Yes");
		chkReaderYes.setFont(UI_Settings.getComponentsFontPlain());
		chkReaderYes.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkReaderYes);
		
		chkTestYes = new JCheckBox("Yes");
		chkTestYes.setFont(UI_Settings.getComponentsFontPlain());
		chkTestYes.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkTestYes);
		
		chkReportYes = new JCheckBox("Yes");
		chkReportYes.setFont(UI_Settings.getComponentsFontPlain());
		chkReportYes.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkReportYes);
		
		chkDVDNo = new JCheckBox("No");
		chkDVDNo.setSelected(true);
		chkDVDNo.setFont(UI_Settings.getComponentsFontPlain());
		chkDVDNo.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkDVDNo);
		
		chkReaderNo = new JCheckBox("No");
		chkReaderNo.setSelected(true);
		chkReaderNo.setFont(UI_Settings.getComponentsFontPlain());
		chkReaderNo.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkReaderNo);
		
		chkTestNo = new JCheckBox("No");
		chkTestNo.setSelected(true);
		chkTestNo.setFont(UI_Settings.getComponentsFontPlain());
		chkTestNo.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkTestNo);
		
		chkReportNo = new JCheckBox("No");
		chkReportNo.setSelected(true);
		chkReportNo.setFont(UI_Settings.getComponentsFontPlain());
		chkReportNo.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkReportNo);
		
		ItemListener listener = new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				
				if(e.getStateChange() == ItemEvent.SELECTED) {
				    /////////////////////////////////////////////////
				    if(e.getItem() == chkDVDYes) {
				    	chkDVDYes.setSelected(true);
				    	chkDVDNo.setSelected(false);
				    } 
				    if(e.getItem() == chkDVDNo){
				    	chkDVDNo.setSelected(true);
				    	chkDVDYes.setSelected(false);
				    }
				    /////////////////////////////////////////////////
				    if(e.getItem() == chkReaderYes){
				    	chkReaderYes.setSelected(true);
				    	chkReaderNo.setSelected(false);
				    }
				    if(e.getItem() == chkReaderNo){
				    	chkReaderNo.setEnabled(true);
				    	chkReaderYes.setSelected(false);
				    }
				    /////////////////////////////////////////////////
				    if(e.getItem() == chkTestYes){
				    	chkTestYes.setSelected(true);
				    	chkTestNo.setSelected(false);
				    }
				    if(e.getItem() == chkTestNo){
				    	chkTestNo.setSelected(true);
				    	chkTestYes.setSelected(false);
				    }
				    /////////////////////////////////////////////////
				    if(e.getItem() == chkReportYes){
				    	chkReportYes.setSelected(true);
				    	chkReportNo.setSelected(false);
				    }
				    if(e.getItem() == chkReportNo){
				    	chkReportNo.setSelected(true);
				    	chkReportYes.setSelected(false);
				    }
				}
			}
		};
		
		for(int i = 0; i < checkboxes.size(); i++){
			
			checkboxes.get(i).addItemListener(listener);
			
		}
		JButton btnSave = new JButton("Add New Material");
		btnSave.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnSave.setFont(UI_Settings.getComponentInputFontSize());
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		txtPublisherName = new JTextField(size);
		txtPublisherName.setMinimumSize(txtPublisherName.getPreferredSize());
		txtPublisherName.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtPublisherName); 
		
		txtEdition = new JTextField(size);
		txtEdition.setMinimumSize(txtEdition.getPreferredSize());
		txtEdition.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtEdition); 
		
		txtLevels = new JTextField(size);
		txtLevels.setMinimumSize(txtLevels.getPreferredSize());
		txtLevels.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtLevels); 
		
		txtChapters = new JTextField(size);
		txtChapters.setMinimumSize(txtChapters.getPreferredSize());
		txtChapters.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtChapters); 
		
		txtNeedsReport = new JTextField(size);
		txtNeedsReport.setMinimumSize(txtNeedsReport.getPreferredSize());
		txtNeedsReport.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtNeedsReport); 
		
		txtDVD = new JTextField(size);
		txtDVD.setMinimumSize(txtDVD.getPreferredSize());
		txtDVD.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtDVD); 
		
		txtReader = new JTextField(size);
		txtReader.setMinimumSize(txtReader.getPreferredSize());
		txtReader.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtReader); 
		
		txtTest = new JTextField(size);
		txtTest.setMinimumSize(txtTest.getPreferredSize());
		txtTest.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtTest); 
		
		txtNewMaterialName = new JTextField(30);
		txtNewMaterialName.setMinimumSize(txtNewMaterialName.getPreferredSize());
		txtNewMaterialName.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtNewMaterialName); 
		
		/***************************************************Create textAreas********************************************************************/
		txtareaMaterialDescription = new JTextArea(6, 30);
		txtareaMaterialDescription.setEditable(true);
		txtareaMaterialDescription.setBorder(UI_Settings.getBorderoutline());
		txtareaMaterialDescription.setWrapStyleWord(true);
		txtareaMaterialDescription.setLineWrap(true);
		txtareaMaterialDescription.setDocument(new JTextFieldLimit(250));
		textPrompt = new TextPrompt("<no material description entered>", txtareaMaterialDescription);
		
		txtareaTeachingComments = new JTextArea(6, 30);
		txtareaTeachingComments.setEditable(true);
		txtareaTeachingComments.setBorder(UI_Settings.getBorderoutline());
		txtareaTeachingComments.setWrapStyleWord(true);
		txtareaTeachingComments.setLineWrap(true);
		txtareaTeachingComments.setDocument(new JTextFieldLimit(250));
		textPrompt = new TextPrompt("no teaching comments entered", txtareaTeachingComments);
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
			   int action = JOptionPane.showConfirmDialog(AddMaterialPanel.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		      
			   if(action == JOptionPane.OK_OPTION){
					txtNewMaterialName.setText("");
		       }
			}
		});
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(UI_Settings.getButtonPanelColor());
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		GridBagConstraints gc = new GridBagConstraints();
		
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
		container.setBackground(UI_Settings.getButtonPanelColor());
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		container.add(new JLabel("Material Name:"));
		container.add(txtNewMaterialName);
		
		
		container.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(container);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(23,0,0,0);
		detailsPanel.add(firstRow, gc);
		/******************************************************Add the Buttons Panel************************************************/
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/*****************************************************Add the group details and member list panel***********************************/
		////////Initialize local fields here for convenience/////////
		txtAreaTestInformation = new JTextArea(6, 20);
		txtAreaTestInformation.setEditable(true);
		txtAreaTestInformation.setBorder(UI_Settings.getBorderoutline());
		txtAreaTestInformation.setWrapStyleWord(true);
		txtAreaTestInformation.setLineWrap(true);
		txtAreaTestInformation.setDocument(new JTextFieldLimit(150));
		
		
		txtareaMaterialDescription.setMinimumSize(txtareaMaterialDescription.getPreferredSize());
		txtareaMaterialDescription.setEditable(true);
		txtareaMaterialDescription.setBorder(UI_Settings.getBorderoutline());
		txtareaMaterialDescription.setWrapStyleWord(true);
		txtareaMaterialDescription.setLineWrap(true);
		txtareaMaterialDescription.setDocument(new JTextFieldLimit(250));
		textPrompt = new TextPrompt("<no material description entered>", txtareaMaterialDescription);
		
		txtareaTeachingComments.setMinimumSize(txtareaTeachingComments.getPreferredSize());
		txtareaTeachingComments.setEditable(true);
		txtareaTeachingComments.setBorder(UI_Settings.getBorderoutline());
		txtareaTeachingComments.setWrapStyleWord(true);
		txtareaTeachingComments.setLineWrap(true);
		txtareaTeachingComments.setDocument(new JTextFieldLimit(250));
		textPrompt = new TextPrompt("<no teaching comments entered>", txtareaTeachingComments);
		
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(5, 5, 5, 5);
		CompoundBorder border = new CompoundBorder(line, empty);
		txtAreaTestInformation.setBorder(border);
		
		txtAreaTestInformation.setPreferredSize(txtAreaTestInformation.getPreferredSize());
		textPrompt = new TextPrompt("<no test information entered>", txtAreaTestInformation);
		
		//Make the material information panel
		JPanel pnlMaterialInformation = new JPanel(new GridBagLayout());
		
		pnlMaterialInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+10));
		pnlMaterialInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+10));
		pnlMaterialInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+10));
		pnlMaterialInformation.setBackground(Color.WHITE);
		
		////////////////////DONE///////////////////
		//Make the member list panel
		JPanel pnlMaterialDetails = new JPanel(new GridBagLayout());
		
		pnlMaterialDetails.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
		pnlMaterialDetails.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
		pnlMaterialDetails.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
		
		pnlMaterialDetails.setBackground(Color.WHITE);
	
			JPanel panel2 = new JPanel(new GridBagLayout());
			panel2.setBackground(new Color(246,246,246));
			Border panel1border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);

			panel2.setBorder(panel1border);
			panel2.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
			panel2.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
			panel2.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
			
				///Add the material details contents to the panel////
				//////////////Col 1///////////
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(17,20,0,0);
				panel2.add(new JLabel("Publisher Name:"), gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Edition:"), gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Number of Levels:"), gc);
				
				gc.gridx = 0;
				gc.gridy = 3;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Number of Chapters:"), gc);
				/////////Col 2////////
				gc.gridx = 1;
				gc.gridy = 0;
				gc.insets = new Insets(10,20,0,0);
				panel2.add(txtPublisherName, gc);
				
				gc.gridx = 1;
				gc.gridy = 1;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtEdition, gc);
				
				gc.gridx = 1;
				gc.gridy = 2;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtLevels, gc);
				
				gc.gridx = 1;
				gc.gridy = 3;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtChapters, gc);
				/////////Col 3////////
				gc.gridx = 2;
				gc.gridy = 0;
				gc.insets = new Insets(17,20,0,0);
				panel2.add(new JLabel("Need Student Report:"), gc);
				
				gc.gridx = 2;
				gc.gridy = 1;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("DVD Lessons:"), gc);
				
				gc.gridx = 2;
				gc.gridy = 2;
				panel2.add(new JLabel("Has a Reader:"), gc);
				
				gc.gridx = 2;
				gc.gridy = 3;
				panel2.add(new JLabel("Has a Test:"), gc);
				////////Col 4///////
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(10,20,0,0);
				panel2.add(chkReportYes, gc);
				
				gc.gridx = 3;
				gc.gridy = 1;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(chkDVDYes, gc);
				
				gc.gridx = 3;
				gc.gridy = 2;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(chkReaderYes, gc);
				
				gc.gridx = 3;
				gc.gridy = 3;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(chkTestYes, gc);
				////////Col 5///////
				gc.gridx = 4;
				gc.gridy = 0;
				gc.insets = new Insets(10,20,0,0);
				panel2.add(chkReportNo, gc);
				
				gc.gridx = 4;
				gc.gridy = 1;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(chkDVDNo, gc);
				
				gc.gridx = 4;
				gc.gridy = 2;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(chkReaderNo, gc);
				
				gc.gridx = 4;
				gc.gridy = 3;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(chkTestNo, gc);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,5,5,5);
				pnlMaterialDetails.add(panel2,gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridwidth = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,5);
		
		pnlMaterialInformation.add(pnlMaterialDetails, gc);
		
			//Make the member list panel
			JPanel pnlTestInfo = new JPanel(new GridBagLayout());
			pnlTestInfo.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()+10));
			pnlTestInfo.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()+10));
			pnlTestInfo.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()+10));
			pnlTestInfo.setBackground(Color.WHITE);
		
				JPanel panel1 = new JPanel(new GridBagLayout());
				panel1.setBackground(Color.WHITE);
				panel1.setBorder(panel1border);
				panel1.setPreferredSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
				panel1.setMinimumSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
				panel1.setMaximumSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
				
					//Add the contents to the member list panel
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(10,13,-10,0);
					panel1.add(new JLabel("Test Information [optional]"), gc);
					
					gc.gridx = 0;
					gc.gridy = 1;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(10,10,5,10);
					panel1.add(txtAreaTestInformation, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.insets = new Insets(5,5,0,5);
				
				pnlTestInfo.add(panel1,gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		
		pnlMaterialInformation.add(pnlTestInfo, gc);
		
		/******************************************Create the Web-site and Delete buttons***************************************************/
		JPanel middleRow = new JPanel();
		middleRow.setBackground(UI_Settings.getButtonPanelColor());
		middleRow.setLayout(new BoxLayout(middleRow, BoxLayout.X_AXIS));
		
		JPanel websiteLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		websiteLeft.setBackground(Color.WHITE);
		websiteLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, 20));
		websiteLeft.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 20));
		//websiteLeft.add(new JLabel("Good Times"));
		//websiteLeft.add(labels[1]);//Web address
		
		
		JPanel deleteRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		deleteRight.setBackground(UI_Settings.getButtonPanelColor());
		deleteRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, 20));
		deleteRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 20));
		deleteRight.add(labels[7]);//Edit label
		//deleteRight.add(labels[2]);//Delete label

		websiteLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		middleRow.add(websiteLeft);
		
		deleteRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		middleRow.add(deleteRight);
		
		middleRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,20));
		middleRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 20));
		/***********************************Create the material and comments description labels**********************************************/
		JPanel textareaHeader = new JPanel();
		textareaHeader.setBackground(UI_Settings.getButtonPanelColor());
		textareaHeader.setLayout(new BoxLayout(textareaHeader, BoxLayout.X_AXIS));
		
		JPanel textAreaHeaderLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		textAreaHeaderLeft.setBackground(UI_Settings.getButtonPanelColor());
		textAreaHeaderLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, 20));
		textAreaHeaderLeft.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 20));
		textAreaHeaderLeft.add(new JLabel("Material Description:"));
		
		
		JPanel textAreaHeaderRight = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		textAreaHeaderRight.setBackground(UI_Settings.getButtonPanelColor());
		textAreaHeaderRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, 20));
		textAreaHeaderRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 20));
		textAreaHeaderRight.add(new JLabel("Material Comments:"));
		
		textAreaHeaderLeft.setAlignmentX(Component.RIGHT_ALIGNMENT);
		textareaHeader.add(textAreaHeaderLeft);
		
		textAreaHeaderRight.setAlignmentX(Component.LEFT_ALIGNMENT);
		textareaHeader.add(textAreaHeaderRight);
		

		textareaHeader.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,20));
		textareaHeader.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 20));
		/***********************************Create the material and comments description TextAreas**********************************************/
		JPanel textAreaBody = new JPanel();
		textAreaBody.setBackground(UI_Settings.getButtonPanelColor());
		textAreaBody.setLayout(new BoxLayout(textAreaBody, BoxLayout.X_AXIS));
		
		JPanel textAreaBodyLeft = new JPanel(new GridBagLayout());
		textAreaBodyLeft.setBackground(UI_Settings.getButtonPanelColor());
		textAreaBodyLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getReportCommentTextareaHeight()));
		textAreaBodyLeft.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getReportCommentTextareaHeight()));
		
		txtareaMaterialDescription.setMinimumSize(txtareaMaterialDescription.getPreferredSize());
		txtareaMaterialDescription.setEditable(true);
		txtareaMaterialDescription.setBorder(UI_Settings.getBorderoutline());
		txtareaMaterialDescription.setWrapStyleWord(true);
		txtareaMaterialDescription.setLineWrap(true);
		txtareaMaterialDescription.setDocument(new JTextFieldLimit(250));
		textPrompt = new TextPrompt("<no material description entered>", txtareaMaterialDescription);
		
		txtareaTeachingComments.setMinimumSize(txtareaTeachingComments.getPreferredSize());
		txtareaTeachingComments.setEditable(true);
		txtareaTeachingComments.setBorder(UI_Settings.getBorderoutline());
		txtareaTeachingComments.setWrapStyleWord(true);
		txtareaTeachingComments.setLineWrap(true);
		txtareaTeachingComments.setDocument(new JTextFieldLimit(250));
		textPrompt = new TextPrompt("<no teaching comments entered>", txtareaTeachingComments);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,10,0,10);
		textAreaBodyLeft.add(txtareaMaterialDescription, gc);
		
		JPanel textAreaBodyRight = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		textAreaBodyRight.setBackground(UI_Settings.getButtonPanelColor());
		textAreaBodyRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getReportCommentTextareaHeight()));
		textAreaBodyRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getReportCommentTextareaHeight()));
		textAreaBodyRight.add(txtareaTeachingComments);
		
		textAreaBodyLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		textAreaBody.add(textAreaBodyLeft);
		
		
		textAreaBodyRight = new JPanel(new GridBagLayout());
		textAreaBodyRight.setBackground(UI_Settings.getButtonPanelColor());
		textAreaBodyRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getReportCommentTextareaHeight()));
		textAreaBodyRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getReportCommentTextareaHeight()));
		
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,10,0,10);
		
		textAreaBodyRight.add(txtareaTeachingComments, gc);
		textAreaBodyRight.setAlignmentX(Component.LEFT_ALIGNMENT);
		textAreaBody.add(textAreaBodyRight);
		
		textAreaBody.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,100));
		textAreaBody.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100));

		/******************************************Create the Web-site and Delete buttons***************************************************/
		JPanel editDeletePanel = new JPanel();
		editDeletePanel.setBackground(UI_Settings.getButtonPanelColor());
		editDeletePanel.setLayout(new BoxLayout(editDeletePanel, BoxLayout.X_AXIS));
		
		JPanel editeDeleteLeft = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 7));
		editeDeleteLeft.setBackground(UI_Settings.getButtonPanelColor());
		editeDeleteLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, 20));
		editeDeleteLeft.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 20));
		editeDeleteLeft.add(labels[3]);//Edit
		//editeDeleteLeft.add(labels[4]);//Delete
		
		JPanel editDeleteRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 7));
		editDeleteRight.setBackground(UI_Settings.getButtonPanelColor());
		editDeleteRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, 20));
		editDeleteRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 20));
		editDeleteRight.add(labels[5]);//Edit
		//editDeleteRight.add(labels[6]);//Delete
		
		editeDeleteLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		editDeletePanel.add(editeDeleteLeft);
		
		editDeleteRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		editDeletePanel.add(editDeleteRight);
		
		
		editDeletePanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,20));
		editDeletePanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 20));
		///////////////////////////////////////////////////////////////////////////////////////
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlInformation = new JPanel();
		pnlInformation.setBackground(Color.WHITE);
		pnlInformation.setLayout(new GridBagLayout());
		pnlInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlSaveRow = new JPanel();
		pnlSaveRow.setBackground(Color.WHITE);
		pnlSaveRow.setLayout(new GridBagLayout());
		pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

			//Create the far left container for the group details information
			JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
			pnlSaveLeftPane.setBackground(Color.WHITE);
			pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel panel3 = new JPanel(new GridBagLayout());
				panel3.setBackground(Color.WHITE);
				panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				
				
				JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row1.setBackground(Color.WHITE);
				row1.add(new JLabel("Table updated:"));
				row1.add(lblDate);
				
				JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row2.setBackground(Color.WHITE);
				row2.add(new JLabel("Connected to: ")); //+ controller.getDBname()));
				
				JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row3.setBackground(Color.WHITE);
				row3.add(new JLabel("Connection: Secure"));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,5,0,5);
			
				panel3.add(row1, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,5);
			
				panel3.add(row2, gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,45,5);
			
				panel3.add(row3, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,20,5);
			
				pnlSaveLeftPane.add(panel3, gc);
		
		pnlSaveRow.add(pnlSaveLeftPane, gc);
			
		//////////////////////////////////////////Main Column 2 ///////////////////////////////////////////
		//Create the second panel from the left (comments panel)

		JPanel pnlSaveRight = new JPanel(new GridBagLayout());
		pnlSaveRight.setBackground(Color.WHITE);
		pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));

		

		
			//Add the nested panels to the container panel (comments panel)
			
			JPanel pblButtons = new JPanel(new GridBagLayout());
			pblButtons.setBackground(Color.WHITE);
			pblButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
			pblButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
			pblButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
			
			JPanel panel4 = new JPanel(new GridBagLayout());
			panel4.setBackground(new Color(246,246,246));
			panel4.setBorder(lightBorder);
			panel4.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
			panel4.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
			panel4.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
			
			labels[8].setCursor(UI_Settings.getJlabelCursor());
			labels[8].addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){
					JOptionPane.showMessageDialog(controllingFrame,
			                "The administrator password can be found with the \"Kids Coordinator\"\n"
			              + "or by contacting your \"Branch Manager\".", "Information Message", JOptionPane.WARNING_MESSAGE);
				}
			});
			
			JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
			adminPanel.setBackground(Color.WHITE);
			adminPanel.add(new JLabel("Administrator password:"));
			adminPanel.add(passwordField);
			adminPanel.add(labels[8]);
			adminPanel.add(btnAddCustomerToGroup);


			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,1,0,1);
			
			panel4.add(adminPanel, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHEAST;
			gc.insets = new Insets(-10,0,0,10);
			
			pblButtons.add(panel4, gc);
			
			//Add the comments panel	
			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,-5,0,0);
			
			pnlSaveRight.add(pblButtons, gc);
			
			//Add the nested panels to the container panel (information panel)
			pnlSaveRow.add(pnlSaveRight, gc);
		
		//Add the nested panels to the container panel (information panel)
		pnlInformation.add(pnlSaveRow, gc);
		
		
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());

        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
   
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        pnlMaterialInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlMaterialInformation);
        
        middleRow.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(middleRow);
        
        //centerPanel.add(Box.createVerticalStrut(25));

        textareaHeader.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(textareaHeader);
        
        textAreaBody.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(textAreaBody);
        
        editDeletePanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(editDeletePanel);
        
        centerPanel.add(Box.createVerticalStrut(10));

        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlInformation);
        
        
        /////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 400));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 400));
		/*********************************************************************************************************************************/
		//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		///////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly///////////////////
		canvas.setMaximumSize(UI_Settings.getMinimumScreenSize());
		canvas.setPreferredSize(UI_Settings.getMinimumScreenSize());

		
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		
		scroller.getVerticalScrollBar().setUnitIncrement(32);
		return scroller;
	}
}
