package group.controller;


import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

import customer.model.Customer;
import customer.model.MonthCategory;
import group.gui.FormEvent;
import group.model.Database;
import group.model.Group;

public class Controller {
	
	
	public Controller(){
	}
	
	public void showGroupControllerMessage(){
	}
	
	static Database db = new Database();
	
	public void addGroup(group.gui.FormEvent ev) {
		
		String groupName = ev.getGroupName();
		String groupMaterial = ev.getGroupMaterial();
		String level = ev.getGroupLevel();
		String day = ev.getGroupDay();
		String time = ev.getGroupTime();
		String currentClassSize = ev.getGroupClassSize();
		String maxClassSize = ev.getGroupMaxClassSize();
		int id = ev.getId();
		
		System.out.println("Group Name: " + ev.getGroupName());
		System.out.println("Group Material: " + ev.getGroupMaterial());
		System.out.println("Group Level: " + ev.getGroupLevel());
		System.out.println("Group Day: " + ev.getGroupDay());
		System.out.println("Group Time: " + ev.getGroupTime());
		System.out.println("Group Class Size: " + ev.getGroupClassSize());
		System.out.println("Group Max Class Size: " + ev.getGroupMaxClassSize());
		
		Group group = new Group(groupName, groupMaterial, level, day, time, currentClassSize, maxClassSize, id);

		db.addEmptyGroup(group);
	}

	public void save() throws SQLException {
		db.save();
	}

	public void load() throws SQLException {
		db.load();
	}

	public void connect() throws Exception {
		db.connect();
	}

	public void saveToFile(File file) throws IOException {
		//db.saveToFile(file);
	}
	
	public void loadFromFile(File file) throws IOException {
		//db.loadFromFile(file);
	}

	public void removeGroup(int row) {
		db.removeGroup(row);
		
	}

	public void setNumberOfRows(int tableRowNumber) {
		db.setAddNewRowNumber(tableRowNumber);
	}

	public static List<Group> getGroup() {
		return db.getGroup();
	}
	
	public static List<Group> getEmptyGroup() {
		return db.getEmptyGroup();
	}

	public void addEmptyGroup(FormEvent ev) {
		String groupName = ev.getGroupName();
		String groupMaterial = ev.getGroupMaterial();
		String level = ev.getGroupLevel();
		String day = ev.getGroupDay();
		String time = ev.getGroupTime();
		String currentClassSize = ev.getGroupClassSize();
		String maxClassSize = ev.getGroupMaxClassSize();
		int id = ev.getId();
		
		
		Group group = new Group(groupName, groupMaterial, level, day, time, currentClassSize, maxClassSize, id);

		db.addEmptyGroup(group);
	}

	public String getDBname() {
		return db.getName();
	}

	public static Group searchGroup(String groupName) {
		try {
			return db.searchGroup(groupName);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public void deleteGroup(JComboBox<String> cmbGroupNameListCombobox, int i, String groupName) {
		db.deleteGroup(cmbGroupNameListCombobox, i, groupName);
	}
	
	///////////////////////////////////////// Methods for adding new customers from the group panel ////////////////////////////////////////
	public void setRowNumber(int i) {
		db.setAddNewRowNumber(i);
	}
	
	public static List<Customer> getCustomer(int value){
		
		if(value == 1){
			return db.getCustomer();
		}else{
			return db.getEmpty_customer();
		}
		
	}
	
	public void addCustomer(customer.gui.FormEvent ev){

		String firstname = ev.getFirstname();
		String lastname = ev.getLastname();
		int monthId = ev.getMonth();
		String material = ev.getMaterial();
		String level = ev.getLevel();
		int id = ev.getId();
		
		MonthCategory monthCategory = null;
		
		switch(monthId){
		
		case 1:
			monthCategory = MonthCategory.January;
			break;
		case 2:
			monthCategory = MonthCategory.February;
			break;
		case 3:
			monthCategory = MonthCategory.March;
			break;
		case 4:
			monthCategory = MonthCategory.April;
			break;
		case 5:
			monthCategory = MonthCategory.May;
			break;
		case 6:
			monthCategory = MonthCategory.June;
			break;
		case 7:
			monthCategory = MonthCategory.July;
			break;
		case 8:
			monthCategory = MonthCategory.August;
			break;
		case 9:
			monthCategory = MonthCategory.September;
			break;
		case 10:
			monthCategory = MonthCategory.October;
			break;
		case 11:
			monthCategory = MonthCategory.November;
			break;
		case 12:
			monthCategory = MonthCategory.December;
			break;
		default:
		
		}
		
		 int listen = ev.getListen();
		 int speak = ev.getSpeak();
		 int read = ev.getRead();
		 int par = ev.getParticipation();
		 int coop = ev.getCooperation();
		 String age = ev.getAge();
		 String interests = ev.getInterests();
		 String comments = ev.getComments();
		 
		
		Customer customer = new Customer(firstname, lastname, monthCategory, material,
			 level, id, listen, speak, read, par, coop, age, interests,
			 	comments);
		
		
		db.addCustomer(customer);
	}
	
	///////////////////////////////////////////////////////////////////////
	public void addEmptyCustomer(customer.gui.FormEvent ev){
			
	
			String firstname = ev.getFirstname();
			String lastname = ev.getLastname();
			int monthId = ev.getMonth();
			String material = ev.getMaterial();
			String level = ev.getLevel();
			int id = ev.getId();
			
			MonthCategory monthCategory = null;
			
			switch(monthId){
			
			case 1:
				monthCategory = MonthCategory.January;
				break;
			case 2:
				monthCategory = MonthCategory.February;
				break;
			case 3:
				monthCategory = MonthCategory.March;
				break;
			case 4:
				monthCategory = MonthCategory.April;
				break;
			case 5:
				monthCategory = MonthCategory.May;
				break;
			case 6:
				monthCategory = MonthCategory.June;
				break;
			case 7:
				monthCategory = MonthCategory.July;
				break;
			case 8:
				monthCategory = MonthCategory.August;
				break;
			case 9:
				monthCategory = MonthCategory.September;
				break;
			case 10:
				monthCategory = MonthCategory.October;
				break;
			case 11:
				monthCategory = MonthCategory.November;
				break;
			case 12:
				monthCategory = MonthCategory.December;
				break;
			default:
			
			}
			
			 int listen = ev.getListen();
			 int speak = ev.getSpeak();
			 int read = ev.getRead();
			 int par = ev.getParticipation();
			 int coop = ev.getCooperation();
			 String age = ev.getAge();
			 String interests = ev.getInterests();
			 String comments = ev.getComments();
			 
			
			Customer customer = new Customer(firstname, lastname, monthCategory, material,
				 level, id, listen, speak, read, par, coop, age, interests,
				 	comments);
			
			
			db.addCustomerViewAllTable(customer);
		}
	
	public void removeCustomer(int index, int i){
		db.removeCustomer(index, i);
	}
	
	public void saveNewCustomer() throws SQLException {
		db.saveNewCustomer();
	}

	public void setCustomerRowNumber(int value) {
		db.setAddNewCustomerRowNumber(value);
	}

	public void search(String firstname, String lastname, String month, String material, String level) {
		try {
			db.search(firstname, lastname, month, material, level);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void clearAddNewTable() {
		db.clearAddNewTable();
	}

}
