package gui.reports.com;



import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_ReportsModel extends AbstractTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static int CATEGORY = 0;
	public static int EXCELLENT = 1;
	public static int VERY_GOOD = 2;
	public static int GOOD = 3;
	public static int PLEASE_REVIEW = 4;
	
	public final static String[] COLUMN_NAMES = {"Category", "Excellent", "Very Good", "Good", "Please Review"};

	public TD_ReportsModel(){
		
	}
	
	public Object[][] values =
		{
				{ "Overall Progress", Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE},
				{ "Comprehension for Listening", Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE},
				{ "Comprehension for Reading",  Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE},
				{ "Speaking Fluency",  Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE},
				{ "Speaking Accuracy",  Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE},
				{ "Writing", Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE},
				{ "Grammar",  Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE},
				{ "Vocabulary",  Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE},
				{ "Pronunciation",  Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE},
				{ "Classroom Participation",  Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE},
				{ "Classroom Confidence",  Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE},
				{ "Classroom Homework",  Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE},
				{ "Classroom Attendance",  Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE}
		};
	
	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	public boolean isCellEditable(int rowIndex, int col) {
		
		if(col == 0) return false;
		else return true;

	}

	@Override
	public int getRowCount() {
		return values.length;
	}
	

	@Override
	public void setValueAt(Object value, int row, int col) {
		
		
		values[row][col] = value;
		
        super.setValueAt(value, row, col);

/*		System.out.println("value: " + value.toString() + ", row: " + row + ", col: " + col);

		for(int i = 0; i < this.getColumnCount(); i++){
			
			System.out.println(values[row][i] + ", ");
			
		}*/
		
	}//End setValueAt

	@Override
	public Class<?> getColumnClass(int col) {
		
		if(col == 0) return String.class;
		else return Boolean.class;

	}

	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	
	
	
	
	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}

	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList( 40, 15, 15, 15, 15));

}
