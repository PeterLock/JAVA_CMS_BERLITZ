package gui.reports.com;

import java.util.EventObject;

public class FormEventVR extends EventObject {
	private static final long serialVersionUID = 1L;
	
	private String firstname;
	private String lastname;
	private String groupname;
	private String material;
	private String reporttype;

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getGroupname() {
		return groupname;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getReporttype() {
		return reporttype;
	}

	public void setReporttype(String reporttype) {
		this.reporttype = reporttype;
	}

	public FormEventVR(Object source, String firstname, String lastname, String groupname, String material, String reporttype) {
		super(source);
		
		this.firstname = firstname;
		this.lastname = lastname;
		this.groupname = groupname;
		this.material = material;
		this.reporttype = reporttype;
	}

}
