package gui.events.com;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_EGroupMembers extends AbstractTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int CUSTOMER_NAME = 0;
	public final static int KC_COMMENTS = 2;
	
	
	public Object[][]values =
		{
				{"Karen Miller", "Strongest, solid speaking and expands well. Not shy in class. An excellent student overall"},
				{"Susie Miller", "A little shy at times. Well behaved usually, doesnt do her HW. Cant do her abcs."},
				{"Ally Jup", "Good student. Picks up new words quickly and is well behaved. Doesnt like Susie much."},
				{"", ""},
				{"", ""},
				{"", ""}
		};
	
	public final static String[] COLUMN_NAMES = {"Customer Name", "KC Comments on Group Members Abilities"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	
	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}

	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList(15,85));

}
