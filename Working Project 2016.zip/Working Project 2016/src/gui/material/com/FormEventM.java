package gui.material.com;

import java.util.EventObject;

public class FormEventM extends EventObject {
	
	private static final long serialVersionUID = 1L;
	private String materialName;
	private String publisher;
	private String website;
	private String materialDescript;
	private String materialComments;
	private Integer levels;
	private String edition;
	private boolean hasDVD;
	private boolean hasReader;
	private boolean hasReport;
	private boolean hasTest;
	private Integer materialID;
	

	public String getMaterialName() {
		return materialName;
	}


	public void setMaterialName(String materialName) {
		this.materialName = materialName;
	}


	public String getPublisher() {
		return publisher;
	}


	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}


	public String getWebsite() {
		return website;
	}


	public void setWebsite(String website) {
		this.website = website;
	}


	public String getMaterialDescript() {
		return materialDescript;
	}


	public void setMaterialDescript(String materialDescript) {
		this.materialDescript = materialDescript;
	}


	public String getMaterialComments() {
		return materialComments;
	}


	public void setMaterialComments(String materialComments) {
		this.materialComments = materialComments;
	}


	public Integer getLevels() {
		return levels;
	}


	public void setLevels(Integer levels) {
		this.levels = levels;
	}


	public String getEdition() {
		return edition;
	}


	public void setEdition(String edition) {
		this.edition = edition;
	}


	public boolean isHasDVD() {
		return hasDVD;
	}


	public void setHasDVD(boolean hasDVD) {
		this.hasDVD = hasDVD;
	}


	public boolean isHasReader() {
		return hasReader;
	}


	public void setHasReader(boolean hasReader) {
		this.hasReader = hasReader;
	}


	public boolean isHasReport() {
		return hasReport;
	}


	public void setHasReport(boolean hasReport) {
		this.hasReport = hasReport;
	}


	public boolean isHasTest() {
		return hasTest;
	}


	public void setHasTest(boolean hasTest) {
		this.hasTest = hasTest;
	}


	public Integer getMaterialID() {
		return materialID;
	}


	public void setMaterialID(Integer materialID) {
		this.materialID = materialID;
	}


	public FormEventM(Object source, String materialName, String publisher, String website, String materialDescript, String materialComments, 
			Integer levels, String edition, boolean hasDVD, boolean hasReader, boolean hasReport, boolean hasTest, Integer materialID) {
		super(source);
		
		this.materialName = materialName;
		this.publisher = publisher;
		this.website = website;
		this.materialDescript = materialDescript;
		this.materialComments = materialComments;
		this.levels = levels;
		this.edition = edition;
		this.hasDVD = hasDVD;
		this.hasReader = hasReader;
		this.hasReport = hasReport;
		this.hasTest = hasTest;
		this.materialID = materialID;
	}
	
	

}
