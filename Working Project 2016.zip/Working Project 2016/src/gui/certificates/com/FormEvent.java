package gui.certificates.com;

import java.util.EventObject;

public class FormEvent extends EventObject {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String firstname;
	private String lastname; 
	private String material;
	private String monthstarted;
	private String certificate;

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getMonthstarted() {
		return monthstarted;
	}

	public void setMonthstarted(String monthstarted) {
		this.monthstarted = monthstarted;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getCertificate() {
		return certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}

	public FormEvent(Object source, String firstname, String lastname, String material, String monthstarted, String certificate) {
		super(source);

		this.firstname = firstname;
		this.lastname = lastname;
		this.material = material;
		this.monthstarted = monthstarted;
		this.certificate = certificate;
		
	}

}
