package gui.alerts.com;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_PaneAlerts extends AbstractTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int ALERT_ID = 0;
	public final static int ALERT_DESCRIPTION = 1;
	public final static int ALERT_DATE = 2;
	public final static int ALERT_IMPORTANCE = 3;

	
	
	public Object[][]values =
		{
				{new Integer(12343), "Group [Koala] will need a final test soon", "February 22nd 2016", new Integer(3)},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},

		};
	
	public final static String[] COLUMN_NAMES = {"Alert ID", "Alert Description", "Alert Date", "Alert Level"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}
	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList( 10,60,20, 10));

}
