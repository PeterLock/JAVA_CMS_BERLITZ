package control.gui;

import java.util.EventListener;

import customer.gui.FormEvent;

public interface FormListener extends EventListener{
	
	public void formEventOccurred(customer.gui.FormEvent e);
	public void formEventOccurred(group.gui.FormEvent e);
	public void formEventOccurred(group.gui.FormEventMemberList e);
	public void formEventOccurred(material.gui.FormEvent ev);
	
}
