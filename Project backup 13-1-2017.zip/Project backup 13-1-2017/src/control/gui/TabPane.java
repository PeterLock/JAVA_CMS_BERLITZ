package control.gui;
/* File name: CMSTabPane.java
 * ----------------------
 * This class builds a custom looking tab pane. The tab colors and borders
 * have their own look and feel which must look the same on every system.
 * 
 * Date: May 19th 2016
 * Programmer: Peter Lock
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.ColorUIResource;

import customer.controller.Controller;
import customer.gui.CustomerControlCenter;
import group.gui.FormEventMemberList;
import gui.administrative.com.AdministrativePane;
import gui.alerts.com.AlertsPane;
import gui.events.com.EventsPane;
import gui.training.com.TrainingControlCenter;
import settings.UI_Settings;

/* Class name: CMSTabPane
 * ----------------------
 */

public class TabPane extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private static List<Object> object_list = new ArrayList<Object>();
    static JTabbedPane pane = new JTabbedPane();
    
    private customer.controller.Controller customer_controller;
    private group.controller.Controller group_controller;
    private material.controller.Controller material_controller;
	
	//Needed to update all of the Group ComboBoxes across the program when adding or deleting groups//
    private DefaultComboBoxModel model = new DefaultComboBoxModel();
	public TabPane(List<Object> object_list, DefaultComboBoxModel model) {
		
		TabPane.object_list = object_list;
		initializeObjects(object_list);
		
		initializeUI();		
    }
	
    private void initializeObjects(List<Object> object_list) {
    	
    	TabPane.object_list = object_list;
    	
	}

	private void initializeUI() {
		
		setFormListeners();
    	
    	setLayout(new BorderLayout());

        changeUI(UI_Settings.getCmsTopTabColor(), UI_Settings.getBottomTabColor());

        pane.setForeground(Color.WHITE);
        pane.setFocusable(false);
        pane.setBorder(new EmptyBorder(0, 0, 0, 0));
        
      

        UIManager.getDefaults().put("TabbedPane.tabAreaInsets", new Insets(0,0,0,0));
        UIManager.put("TabbedPane.unselectedTabBackground", UI_Settings.getCmsGray());
        
        setBackground(Color.BLACK);
        
        pane.addTab("<html><body><table width='70' style='font-size:11'><td style='text-align:center'>Customer</td></table></body></html>",(CustomerControlCenter)object_list.get(0) );	
        pane.addTab("<html><body><table width='70' style='font-size:11'><td style='text-align:center'>Group</td></table></body></html>", (group.gui.GroupControlCenter)object_list.get(1));	
        pane.addTab("<html><body><table width='70' style='font-size:11'><td style='text-align:center'>Products</td></table></body></html>", (material.gui.MaterialControlCenter)object_list.get(2) );	
        pane.addTab("<html><body><table width='120' style='font-size:11'><td style='text-align:center'>Training Session</td></table></body></html>", (TrainingControlCenter)object_list.get(3) );	
        pane.addTab("<html><body><table width='60' style='font-size:11'><td style='text-align:center'>Events</td></table></body></html>", (EventsPane)object_list.get(4) );	
        pane.addTab("<html><body><table width='70' style='font-size:11'><td style='text-align:center'>Administrative</td></table></body></html>", (AdministrativePane)object_list.get(5) );	
        pane.addTab("<html><body><table width='70' style='font-size:11'><td style='text-align:center'>Alerts</td></table></body></html>", (AlertsPane)object_list.get(6) );	

        
        //Set the text color for each tab
        pane.setForeground(Color.WHITE);
        //Set the background color for each tab
        for(int i = 0; i <= 6; i++){
            pane.setBackgroundAt(i, UI_Settings.getCmsGray());	//0

        }
        
        pane.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                //System.out.println("Tab: " + pane.getSelectedIndex());
                
            	
            	//CreateTrainingSessionPanel position 0,0 scroll bar workaround - were not positioning 0,0 with nested objects in CardLayout//
                if(pane.getSelectedIndex() == 3){
                	
            		TrainingControlCenter trainingControl;
            		trainingControl = (TrainingControlCenter) object_list.get(3);
            		
            		trainingControl.resetScrollBars();
                	
                }
                
            }
        });

        //Add the tab to the canvas
        this.add(pane, BorderLayout.CENTER);
    }
    
    private void setFormListeners() {
    	
    	((customer.gui.CustomerControlCenter) object_list.get(0)).setFormListener(new FormListener(){
    		
    		public void formEventOccurred(customer.gui.FormEvent ev){
    			customer_controller.addCustomer(ev);
    		}

			@Override
			public void formEventOccurred(group.gui.FormEvent ev) {
    			group_controller.addGroup(ev);
			}

			@Override
			public void formEventOccurred(material.gui.FormEvent ev) {
    			material_controller.addMaterial(ev);
			}

			@Override
			public void formEventOccurred(FormEventMemberList ev) {
				group_controller.addMemberList(ev);
			}
    		
    	});
    	
    	((group.gui.GroupControlCenter) object_list.get(1)).setFormListener(new FormListener(){
    		
    		public void formEventOccurred(customer.gui.FormEvent ev){
    			customer_controller.addCustomer(ev);
    		}

			@Override
			public void formEventOccurred(group.gui.FormEvent ev) {
    			group_controller.addGroup(ev);
			}

			@Override
			public void formEventOccurred(material.gui.FormEvent ev) {
    			material_controller.addMaterial(ev);
			}

			@Override
			public void formEventOccurred(FormEventMemberList e) {
				// TODO Auto-generated method stub
				
			}
    		
    	});
    	
    	((material.gui.MaterialControlCenter) object_list.get(2)).setFormListener(new FormListener(){

    		public void formEventOccurred(customer.gui.FormEvent ev){
    			customer_controller.addCustomer(ev);
    		}

			@Override
			public void formEventOccurred(group.gui.FormEvent ev) {
    			group_controller.addGroup(ev);
    			System.out.println("FormListener set in group");

			}
			
			@Override
			public void formEventOccurred(material.gui.FormEvent ev) {
    			material_controller.addMaterial(ev);
			}

			@Override
			public void formEventOccurred(FormEventMemberList e) {
				// TODO Auto-generated method stub
				
			}
    		
    	});
		
	}

	public static void changeUI(Color topColor, Color bottomColor){
    	UIManager.put("TabbedPane.selected",new ColorUIResource(topColor));
    	
        pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            @Override protected int calculateTabHeight(
              int tabPlacement, int tabIndex, int fontHeight) {
            	
    	       highlight = Color.black;
    	       lightHighlight = Color.black;
    	       shadow = Color.black;
    	       darkShadow = Color.black;
    	       focus = Color.black;
            	
            	
              return 45;
            }
            
            
            
            @Override protected void paintTab(
              Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
              Rectangle iconRect, Rectangle textRect) {
        
               rects[tabIndex].height = 23 + 1;
               rects[tabIndex].y = 20 - rects[tabIndex].height + 25;
              
              super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
            }
          });
        
        ((CustomerControlCenter) object_list.get(0)).changeTheme(bottomColor);
        ((group.gui.GroupControlCenter) object_list.get(1)).changeTheme(bottomColor); 
        ((material.gui.MaterialControlCenter) object_list.get(2)).changeTheme(bottomColor);
        ((TrainingControlCenter) object_list.get(3)).changeTheme(bottomColor); 
        ((EventsPane) object_list.get(4)).changeTheme(bottomColor); 
        ((AdministrativePane) object_list.get(5)).changeTheme(bottomColor); 
        ((AlertsPane) object_list.get(6)).changeTheme(bottomColor); 
        
    }

    public static void showFrame() {
        JPanel panel = new TabPane(object_list, null);
        JFrame frame = new JFrame("Customer Interaction System");
        frame.setLocationRelativeTo(null);
        JFrame.setDefaultLookAndFeelDecorated(false);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.setPreferredSize(UI_Settings.getMinimumScreenSize());
        frame.pack();
        frame.setVisible(true);
        frame.setBackground(UI_Settings.getButtonPanelColor());
    }
   

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                TabPane.showFrame();
            }
        });
    }

	public void switchTabs(int i) {
		/////Programmed for only one case////////
		pane.setSelectedIndex(0);
		CustomerControlCenter customer;
		customer = (CustomerControlCenter) object_list.get(0);
		
		customer.switchTabs();
		
	}

	public void setCustomerController(Controller customer_controller) {
		this.customer_controller = customer_controller;
	}

	public void setGroupController(group.controller.Controller group_controller) {
		this.group_controller = group_controller;
	}
	
	public void setMaterialController(material.controller.Controller material_controller) {
		this.material_controller = material_controller;
	}
}