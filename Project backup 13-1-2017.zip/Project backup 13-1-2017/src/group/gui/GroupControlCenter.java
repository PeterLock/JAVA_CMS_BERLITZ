package group.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ColorUIResource;

import control.gui.FormListener;
import control.gui.GroupComboListener;
import control.gui.PasswordListener;
import group.controller.Controller;
import settings.UI_Settings;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class GroupControlCenter extends JPanel {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	static JTabbedPane pane = new JTabbedPane();
	
	private group.controller.Controller controller;
	private ViewGroupsPanel viewAllPanel;
	private AddCustomerToGroupPanel addStudentPanel;
	private MoveCustomerPanel moveStudentPanel;

	private DefaultComboBoxModel model = new DefaultComboBoxModel();
	private UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	private TextPrompt textPrompt;
	private Boolean ignoreEvents = false;
	private FormListener formListener;
	
    
	public GroupControlCenter(Controller controller, DefaultComboBoxModel<?> model) {
		this.controller = controller;
		this.model = model;
        initializeUI();
    }
	
    private void initializeUI() {
    	
    	
    	try {
			viewAllPanel = new ViewGroupsPanel(controller, model);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
    	addStudentPanel = new AddCustomerToGroupPanel(controller);
    	moveStudentPanel = new MoveCustomerPanel();
    	
      	UIManager.put("Label.font", UI_Settings.getComponentsFontPlain());
    	UIManager.put("Label.foreground", UI_Settings.getComponentsFontColorDark());
    	
    	UIManager.put("OptionPane.messageFont", new Font("System", Font.PLAIN, 12));
    	UIManager.put("OptionPane.buttonFont", new Font("System", Font.PLAIN, 12));
    	
    	
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, java.awt.Toolkit.getDefaultToolkit().getScreenSize().height));

        //OK
        UIManager.put("TabbedPane.selected", new ColorUIResource(UI_Settings.getBottomTabColor()));
        UIManager.put("TabbedPane.unselectedTabBackground", UI_Settings.getCmsGray());       
        
        pane.setForeground(UI_Settings.getButtonPanelColor());
        pane.setFocusable(false);
        pane.setBorder(new EmptyBorder(0, 0, 0, 0));

        UIManager.getDefaults().put("TabbedPane.tabAreaInsets", new Insets(0,0,0,0));
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0)); 
        
        //Sets the JPanel container to black
        setBackground(UI_Settings.getCmsTabSecondLvlGrey());
        
        
        try {
			pane.addTab("<html><body><table width='110' style='font-size:11'><td style='text-align:center'>View/Add Group</td></table></body></html>", viewAllPanel.run());
		} catch (Exception e) {
			e.printStackTrace();
		}
        pane.addTab("<html><body><table width='150' style='font-size:11'><td style='text-align:center'>Add Customer To Group</td></table></body></html>", addStudentPanel.run());
        pane.addTab("<html><body><table width='200' style='font-size:11'><td style='text-align:center'>Move Customer To Another Group</td></table></body></html>", moveStudentPanel.run());

        //Set the text color for each tab
        pane.setForeground(UI_Settings.getButtonPanelColor());

        pane.setBackgroundAt(0, UI_Settings.getCmsGray());	//0
        pane.setBackgroundAt(1, UI_Settings.getCmsGray());	//1
        pane.setBackgroundAt(2, UI_Settings.getCmsGray());	//2
    
        changeUI(UI_Settings.getBottomTabColor());
    }

	public void changeUI( Color bottomTabColor) {
        pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            @Override protected int calculateTabHeight(
              int tabPlacement, int tabIndex, int fontHeight) {
            	
    	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       focus = UI_Settings.getCmsTabSecondLvlGrey();
            	
              return 27;
            }
            
            
            @Override protected void paintTab(
              Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
              Rectangle iconRect, Rectangle textRect) {
        
               rects[tabIndex].height = 25 + 1;
               rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
              
              super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
            }
          });
        
        //Add the tab to the canvas
        this.add(pane, BorderLayout.CENTER);		
	}

	public static void showFrame() {
        JPanel panel = new GroupControlCenter(null, null);
        panel.setOpaque(true);

        JFrame frame = new JFrame("CMS Test Screen");
        JFrame.setDefaultLookAndFeelDecorated(false);
        frame.setPreferredSize(UI_Settings.getMinimumScreenSize());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }
    
    public void changeTheme(Color c) {
      UIManager.put("TabbedPane.selected",new ColorUIResource(c));
		 
      pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          @Override protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
            return 27;
          }
      });
      
	pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
	    @Override protected int calculateTabHeight(
	      int tabPlacement, int tabIndex, int fontHeight) {
	    	
	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
	       focus = UI_Settings.getCmsTabSecondLvlGrey();
	    	
	      return 27;
	    }
	    
	    
	    @Override protected void paintTab(
	      Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
	      Rectangle iconRect, Rectangle textRect) {
	
	       rects[tabIndex].height = 25 + 1;
	       rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
	      
	      super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
	    }
	  });
	}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                GroupControlCenter.showFrame();
            }
        });
    }

	public void resetPanels() {
		viewAllPanel.resetPanels();
		
	}

	public void setFormListener(FormListener listener) {
		this.formListener = listener;
	}

	public void setPasswordListener(PasswordListener passwordListener) {
		viewAllPanel.setPasswordListener(passwordListener);
		addStudentPanel.setPasswordListener(passwordListener);;
		moveStudentPanel.setPasswordListener(passwordListener);;
		
	}

	public void setComboModelListener(GroupComboListener groupComboListener) {
		viewAllPanel.setComboBoxListener(groupComboListener);
	}
}