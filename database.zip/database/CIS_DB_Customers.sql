-- MySQL dump 10.13  Distrib 5.7.9, for osx10.9 (x86_64)
--
-- Host: 127.0.0.1    Database: CIS_DB
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Customers`
--

DROP TABLE IF EXISTS `Customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Customers` (
  `id` int(11) NOT NULL DEFAULT '0',
  `firstName` varchar(45) DEFAULT '0',
  `lastName` varchar(45) DEFAULT '0',
  `month` varchar(45) DEFAULT '0',
  `material` varchar(45) DEFAULT '0',
  `level` varchar(45) DEFAULT '0',
  `age` varchar(45) DEFAULT '0',
  `listening` int(11) DEFAULT '0',
  `speaking` int(11) DEFAULT '0',
  `reading` int(11) DEFAULT '0',
  `participation` int(11) DEFAULT '0',
  `cooperation` int(11) DEFAULT '0',
  `interests` varchar(45) DEFAULT '0',
  `comments` varchar(45) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customers`
--

LOCK TABLES `Customers` WRITE;
/*!40000 ALTER TABLE `Customers` DISABLE KEYS */;
INSERT INTO `Customers` VALUES (2730,'Kate','Hopps','February','Book 2','NBE-1','12-16',2,3,3,3,4,'',''),(3962,'Peter','Lock','February','Book 4','NBE-3','12-16',3,3,3,3,3,'Tennis','Football'),(4271,'Peter','Lock','March','Book 4','NBE-4','16-24',2,2,2,2,2,'Reading and such','No comments available'),(7549,'Kim','Chong','January','Book 6','NBE-7','24 >',5,5,5,5,5,'',''),(8011,'Kim','Chong','January','Book 6','NBE-7','24 >',0,0,0,0,0,'',''),(8831,'Peter','Lock','January','Book 5','NBE-3','12-16',3,4,5,6,4,'','');
/*!40000 ALTER TABLE `Customers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-11 23:31:15
