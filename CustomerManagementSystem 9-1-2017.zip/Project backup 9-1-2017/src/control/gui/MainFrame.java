package control.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import customer.controller.Controller;
import customer.gui.CustomerControlCenter;
import group.gui.GroupControlCenter;
import gui.administrative.com.AdministrativePane;
import gui.alerts.com.AlertsPane;
import gui.employee.com.EmployeePane;
import gui.events.com.EventsPane;
import gui.footer.com.Footer;
import gui.training.com.TrainingControlCenter;
import settings.UI_Settings;


public class MainFrame extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Toolbar toolBar;
	private TabPane tabPane;
	private MenuBar menuBar;
	private Footer footer;
	
    private DefaultComboBoxModel model = new DefaultComboBoxModel();
	
	private customer.controller.Controller customer_controller = new customer.controller.Controller();
	private group.controller.Controller group_controller = new group.controller.Controller();
	private material.controller.Controller material_controller = new material.controller.Controller();
	
	
	customer.gui.CustomerControlCenter customerPane = new customer.gui.CustomerControlCenter(customer_controller);
	group.gui.GroupControlCenter groupPane = new group.gui.GroupControlCenter(group_controller, model);
	material.gui.MaterialControlCenter materialPane = new material.gui.MaterialControlCenter(material_controller);
	
	TrainingControlCenter trainingPane = new TrainingControlCenter();
	EventsPane openHousePane = new EventsPane();
	AdministrativePane administrativePane = new AdministrativePane();
	EmployeePane employeePane = new EmployeePane();
	AlertsPane alertsPane = new AlertsPane();
	
	private JFileChooser fileChooser;
	
	
	//Needed to update all of the Group ComboBoxes across the program when adding or deleting groups//
	private List<Object> object_list = new ArrayList<Object>();
	
	public MainFrame(){
		
		super("");
		
		fillObjectList();
	
		toolBar = new Toolbar();
		
		menuBar = new MenuBar(toolBar, object_list);
		tabPane = new TabPane(object_list, model);
		footer = new Footer();
		
		setControllers();

		fileChooser = new JFileChooser();
		fileChooser.addChoosableFileFilter(new CustomerFileFilter());
		
		
		toolBar.setToolbarListener(new ToolbarListener(){
			public void saveEventOccurred(){
				
			connect();
				System.out.println("save event occured");
				try {
					customer_controller.save();
					group_controller.save();
					material_controller.save();
				} catch (SQLException e) {
					JOptionPane.showMessageDialog(MainFrame.this, "Unable to save to database", "Database Connection Problem", JOptionPane.ERROR_MESSAGE);
				}
			}

			public void refreshEventOccurred() {
				connect();
				
				try {
					customer_controller.load();
					group_controller.load();
					material_controller.load();
				} catch (SQLException e) {
					JOptionPane.showMessageDialog(MainFrame.this, "Unable to load from database", "Database Connection Problem", JOptionPane.ERROR_MESSAGE);
				}

				customerPane.refresh();
				groupPane.resetPanels();
				materialPane.resetPanels();
			}

			@Override
			public void refreshWindowsEventOccurred() {
				customerPane.resetPanels();
				groupPane.resetPanels();
				materialPane.resetPanels();
			}

			@Override
			public void importEventOccurred() {
				
				if(fileChooser.showOpenDialog(MainFrame.this) == JFileChooser.APPROVE_OPTION){
					try {
						customer_controller.loadFromFile(fileChooser.getSelectedFile());
						
						///////////Refresh Customer Screen Tables/////////////
						CustomerControlCenter customerPane;
						customerPane = (CustomerControlCenter) object_list.get(0);
						customerPane.refresh();
						
						
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(MainFrame.this, "Could not load data from file", "Load Error", JOptionPane.ERROR_MESSAGE);
					}
				};
				
			}

			@Override
			public void addStudent() {
				tabPane.switchTabs(0);
			}
		});
		
		
		setJMenuBar(menuBar.addMenu());

		setLayout(new BorderLayout());

		add(toolBar, BorderLayout.NORTH);
		add(tabPane, BorderLayout.CENTER);
		add(footer, BorderLayout.SOUTH);
				
		
		setPreferredSize(Toolkit.getDefaultToolkit().getScreenSize());
		setMinimumSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()/4*3+80, (int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().getHeight()/4*3+40));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);				
		
	}
	
	private void setControllers() {
		tabPane.setCustomerController(customer_controller);
		tabPane.setGroupController(group_controller);
		tabPane.setMaterialController(material_controller);
		
		menuBar.setCustomerController(customer_controller);
		menuBar.setGroupController(group_controller);
		menuBar.setMaterialController(material_controller);
	}

	private void connect(){
		try {
			customer_controller.connect();
			group_controller.connect();
			material_controller.connect();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(MainFrame.this, "Cannot connect to database", "Database Connection Problem", JOptionPane.ERROR_MESSAGE);
			customer_controller.buildEmptyTable();
		}
	}
	
	private void fillObjectList(){
		
		object_list.add(customerPane);
		object_list.add(groupPane);
		object_list.add(materialPane);
		object_list.add(trainingPane);
		object_list.add(openHousePane);
		object_list.add(administrativePane);
		object_list.add(alertsPane);

	}

}
