package group.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import group.controller.Controller;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.SentryModule;
import utilities.TextPrompt;

public class MoveCustomerPanel extends JPanel {
	
	private Calendar c = Calendar.getInstance();
	private JLabel lblDate = new JLabel(c.getTime().toString());
	
	private Controller controller;
	
	public void MoveStudent(){
	}
	
	public Component run(){
		JScrollPane scroller = initialize();
		return scroller;
	}

	private JScrollPane initialize() {
		
		controller = new Controller();
		
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		
		JButton btnMoveStudent;
		
		//Center Panel fields
		JTextField txtTopPanelStudentName;
		JTextField txtTopPanelAge;
		
		JTextField txtTopGroupName;
		JTextField txtTopGroupID;
		JTextField txtTopGroupPos;
		JTextField txtTopGroupLev;
		JTextField txtTopGroupDay;
		JTextField txtTopGroupTime;
		JTextField txtTopGroupMax;
		JTextField txtTopGroupMat;
		
		JTextField txtBottomGroupName;
		JTextField txtBottomGroupID;
		JTextField txtBottomGroupPos;
		JTextField txtBottomGroupLev;
		JTextField txtBottomGroupDay;
		JTextField txtBottomGroupTime;
		JTextField txtBottomGroupMax;
		JTextField txtBottomGroupMat;
		
	    JFrame controllingFrame = new JFrame();
	    
	    
		JPasswordField passwordField;
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
        
        JTextArea txtMoveFromNameContainer;
        JTextArea txtMoveToNameContainer;
		/***************************************************Create labels***********************************************************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage.setVisible(false);
		
		JLabel labels[] = new JLabel[8];
		labels[0] = new JLabel("reset move from data");
		labels[1] = new JLabel("undo move");
		labels[2] = new JLabel("help");
		labels[3] = new JLabel("help");
		labels[4] = new JLabel("move");
		labels[5] = new JLabel("view interests");
		labels[6] = new JLabel("view comments");
		labels[7] = new JLabel("reset move to data");
		
		labels[1].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(MoveCustomerPanel.this, "The undo move comment for group member button has been pressed.", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		
		for(int i = 0; i < 8; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());	
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		////////Initialize local fields here for convenience/////////
		txtMoveFromNameContainer = new JTextArea(7, 20);
		txtMoveFromNameContainer.setEditable(true);
		txtMoveFromNameContainer.setBorder(UI_Settings.getBorderoutline());
		txtMoveFromNameContainer.setWrapStyleWord(true);
		txtMoveFromNameContainer.setLineWrap(true);
		txtMoveFromNameContainer.setDocument(new JTextFieldLimit(150));
		
		txtMoveFromNameContainer.setPreferredSize(txtMoveFromNameContainer.getPreferredSize());
		TextPrompt textPrompt = new TextPrompt("<no customer names found>", txtMoveFromNameContainer);
		
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(5, 5, 5, 5);
		CompoundBorder border = new CompoundBorder(line, empty);
		txtMoveFromNameContainer.setBorder(border);
		////////Initialize local fields here for convenience/////////
		txtMoveToNameContainer = new JTextArea(6, 20);
		txtMoveToNameContainer.setEditable(true);
		txtMoveToNameContainer.setBorder(UI_Settings.getBorderoutline());
		txtMoveToNameContainer.setWrapStyleWord(true);
		txtMoveToNameContainer.setLineWrap(true);
		txtMoveToNameContainer.setDocument(new JTextFieldLimit(150));
		txtMoveToNameContainer.setBorder(border);
		
		txtMoveToNameContainer.setPreferredSize(txtMoveToNameContainer.getPreferredSize());
		textPrompt = new TextPrompt("<no customer names found>", txtMoveToNameContainer);
		/*************************************Listeners*****************************************/
		btnMoveStudent = new JButton("Commit Changes");
		btnMoveStudent.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnMoveStudent.setFont(UI_Settings.getComponentInputFontSize());
		btnMoveStudent.setPreferredSize(new Dimension(180,UI_Settings.getJbuttonSize().height));
		btnMoveStudent.setMinimumSize(new Dimension(180,UI_Settings.getJbuttonSize().height));
		/*********************************************Add the Bottom Panel TextFields***********************/
		int size = 13;
		
		List <JTextField> textfieldsGroupDetailsTop = new ArrayList<JTextField>();
		List <JTextField> textfieldsGroupDetailsBottom = new ArrayList<JTextField>();

		
		txtTopGroupName = new JTextField(size);
		txtTopGroupName.setMinimumSize(txtTopGroupName.getPreferredSize());
		txtTopGroupName.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupName); 
		
		txtTopGroupID = new JTextField(size);
		txtTopGroupID.setMinimumSize(txtTopGroupID.getPreferredSize());
		txtTopGroupID.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupID); 

		
		txtTopGroupPos = new JTextField(size);
		txtTopGroupPos.setMinimumSize(txtTopGroupPos.getPreferredSize());
		txtTopGroupPos.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupPos); 

		
		txtTopGroupLev = new JTextField(size);
		txtTopGroupLev.setMinimumSize(txtTopGroupLev.getPreferredSize());
		txtTopGroupLev.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupLev); 
		
		txtTopGroupDay = new JTextField(size);
		txtTopGroupDay.setMinimumSize(txtTopGroupDay.getPreferredSize());
		txtTopGroupDay.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupDay); 

		
		txtTopGroupTime = new JTextField(size);
		txtTopGroupTime.setMinimumSize(txtTopGroupTime.getPreferredSize());
		txtTopGroupTime.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupTime); 

		
		txtTopGroupMax = new JTextField(size);
		txtTopGroupMax.setMinimumSize(txtTopGroupMax.getPreferredSize());
		txtTopGroupMax.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupMax); 

		
		txtTopGroupMat = new JTextField(size);
		txtTopGroupMat.setMinimumSize(txtTopGroupMat.getPreferredSize());
		txtTopGroupMat.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupMat); 
		
		
		txtBottomGroupName = new JTextField(size);
		txtBottomGroupName.setMinimumSize(txtBottomGroupName.getPreferredSize());
		txtBottomGroupName.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupName); 
		
		txtBottomGroupID = new JTextField(size);
		txtBottomGroupID.setMinimumSize(txtBottomGroupID.getPreferredSize());
		txtBottomGroupID.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupID); 

		
		txtBottomGroupPos = new JTextField(size);
		txtBottomGroupPos.setMinimumSize(txtBottomGroupPos.getPreferredSize());
		txtBottomGroupPos.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupPos); 

		
		txtBottomGroupLev = new JTextField(size);
		txtBottomGroupLev.setMinimumSize(txtBottomGroupLev.getPreferredSize());
		txtBottomGroupLev.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupLev); 
		
		txtBottomGroupDay = new JTextField(size);
		txtBottomGroupDay.setMinimumSize(txtBottomGroupDay.getPreferredSize());
		txtBottomGroupDay.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupDay); 

		
		txtBottomGroupTime = new JTextField(size);
		txtBottomGroupTime.setMinimumSize(txtBottomGroupTime.getPreferredSize());
		txtBottomGroupTime.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupTime); 

		
		txtBottomGroupMax = new JTextField(size);
		txtBottomGroupMax.setMinimumSize(txtBottomGroupMax.getPreferredSize());
		txtBottomGroupMax.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupMax); 

		
		txtBottomGroupMat = new JTextField(size);
		txtBottomGroupMat.setMinimumSize(txtBottomGroupMat.getPreferredSize());
		txtBottomGroupMat.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupMat); 

		txtTopPanelStudentName = new JTextField(10);
		txtTopPanelStudentName.setEditable(true);
		txtTopPanelStudentName.setMinimumSize(txtTopPanelStudentName.getPreferredSize());
		textPrompt = new TextPrompt("-", txtTopPanelStudentName);
		txtTopPanelStudentName.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetailsTop.add(txtTopPanelStudentName);
		
		txtTopPanelAge = new JTextField(5);
		txtTopPanelAge.setEditable(true);
		txtTopPanelAge.setMinimumSize(txtTopPanelAge.getPreferredSize());
		textPrompt = new TextPrompt("-", txtTopPanelAge);
		txtTopPanelAge.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetailsTop.add(txtTopPanelAge);
		
		
		/*********************************************************Create Combo Boxes*********************************************************/
		JComboBox<String> cmbMoveFromGroupName = new JComboBox<String>(UI_Settings.getGroups());
		cmbMoveFromGroupName.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbMoveFromGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbMoveFromGroupName.setMinimumSize(cmbMoveFromGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbMoveFromGroupName, 180, UI_Settings.getComboBoxHeight());

		JComboBox<String> cmbMoveToGroupName = new JComboBox<String>(UI_Settings.getGroups());
		cmbMoveToGroupName.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbMoveToGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbMoveToGroupName.setMinimumSize(cmbMoveToGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbMoveToGroupName, 180, UI_Settings.getComboBoxHeight());
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		//Reset move to button//
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
				failedMessage.setVisible(false);
				
				for(int i = 0; i < textfieldsGroupDetailsTop.size(); i++){
					textfieldsGroupDetailsTop.get(i).setText("");
				}
				
				txtMoveFromNameContainer.setText("");
				
				cmbMoveFromGroupName.setSelectedIndex(0);
				
				passwordField.setText("");
				   
			}
		});
		//Reset move to button//
		labels[7].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
				for(int i = 0; i < textfieldsGroupDetailsBottom.size(); i++){
					textfieldsGroupDetailsBottom.get(i).setText("");
				}
				
				txtMoveToNameContainer.setText("");
				
				cmbMoveToGroupName.setSelectedIndex(0);
				
				passwordField.setText("");
				   
			}
		});
		/*****************************************************************************************************************************/
	
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) );
		/**********************Create the messages panel***********************/
		GridBagConstraints gc = new GridBagConstraints();

		JPanel heading = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		JLabel lblHeading = new JLabel("Swapping out customers");
		heading.setBackground(Color.WHITE);
		lblHeading.setFont(lblHeading.getFont().deriveFont(16.0f));
		heading.add(lblHeading);
		
		JPanel headingMessage = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		headingMessage.setBackground(Color.WHITE);
		JLabel lblHeadingMessage = new JLabel("Swapping out customers is simple. Choose the group to swap from, select the customer and\n"
				+ "choose which group to add the customer to.");
		
		headingMessage.add(lblHeadingMessage);

		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		JPanel header = new JPanel(new GridBagLayout());
		setPanelSize(header, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100));
		header.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		header.add(heading,gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(-15,0,0,0);
		header.add(headingMessage, gc);
	
		gc.gridy = 2;
		gc.insets = new Insets(-30,0,0,0);
		header.add(detailsPanel, gc);
		
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		container.setBackground(Color.WHITE);
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		container.add(new JLabel("Select the group you want to move the customer from:"));
		container.add(cmbMoveFromGroupName);
		
		container.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(container);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(17,0,0,0);
		detailsPanel.add(firstRow, gc);
		/******************************************************Add the Buttons Panel************************************************/
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 25));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 25));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 25));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 7));
		rightPanel.setBackground(Color.WHITE);
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 25));
		rightPanel.add(labels[0]);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		
		
		/*************************************************Add Student to Group Buttons Panel***********************************************/
		JPanel middleComponents = new JPanel(new GridBagLayout());
		middleComponents.setBackground(Color.WHITE);

		middleComponents.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		middleComponents.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		
		
		/******************************************************Add the Buttons Panel************************************************/

		int size2 = 80;
		JPanel moveToButtonsPanel = new JPanel();
		moveToButtonsPanel.setBackground(UI_Settings.getButtonPanelColor());
		moveToButtonsPanel.setLayout(new BoxLayout(moveToButtonsPanel, BoxLayout.X_AXIS));
		moveToButtonsPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, size2));
		moveToButtonsPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, size2));
		moveToButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, size2));

		
		JPanel leftPanel2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 10,30));
		leftPanel2.setBackground(Color.WHITE);
		leftPanel2.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, size2));
		leftPanel2.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, size2));
		leftPanel2.add(new JLabel("Select the group you want to add the student to:"));
		leftPanel2.add(cmbMoveToGroupName);
		
		
		JPanel rightPanel2 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 35));
		rightPanel2.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel2.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, size2));
		rightPanel2.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, size2));
		rightPanel2.add(labels[7]);//Reset Move To data
		
		leftPanel2.setAlignmentX(Component.LEFT_ALIGNMENT);
		moveToButtonsPanel.add(leftPanel2);
		
		rightPanel2.setAlignmentX(Component.RIGHT_ALIGNMENT);
		moveToButtonsPanel.add(rightPanel2);
		///////////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////Start the center panels///////////////////////////////////	
		int topFrameHeight = 210;
		
		JPanel pnlCenterTopPanel = new JPanel(new GridBagLayout());
		pnlCenterTopPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		pnlCenterTopPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		pnlCenterTopPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		
		JPanel pnlCenterTopLeft = new JPanel(new GridBagLayout());
		pnlCenterTopLeft.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		pnlCenterTopLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		pnlCenterTopLeft.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		
		Border darkBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
			//add components to the left panel
			pnlCenterTopLeft.setBorder(darkBorder);
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(10,10,0,0);
			pnlCenterTopLeft.add(new JLabel("Click on the students name to select:"), gc);
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.BOTH;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,10,10,10);
			pnlCenterTopLeft.add(txtMoveFromNameContainer, gc);
			
		JPanel pnlCenterTopRight = new JPanel(new GridBagLayout());
		pnlCenterTopRight.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setBackground(Color.WHITE);

			int centerTopHeight = 50;
			JPanel pnlCenterTopRightTop = new JPanel(new GridBagLayout());
			pnlCenterTopRightTop.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setBackground(Color.WHITE);

				//Add the contents of this panel - the student name and the student age plus buttons
				//Add the student name panel//
				JPanel pnlStudentName = new JPanel(new GridBagLayout());
				pnlStudentName.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				pnlStudentName.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				pnlStudentName.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				pnlStudentName.setBorder(darkBorder);
				pnlStudentName.setBackground(Color.WHITE);
					//Add student name fields//
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 0.2;
					gc.weighty = 0.2;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,10,0,0);
					pnlStudentName.add(new JLabel("Student Name:"),gc);
					gc.gridx = 1;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 0.2;
					gc.weighty = 0.2;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,10,0,0);
					pnlStudentName.add(txtTopPanelStudentName,gc);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 0.2;
				gc.weighty = 0.2;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,0,0);
				pnlCenterTopRightTop.add(pnlStudentName,gc);
				
				JPanel pnlStudentButtons = new JPanel(new GridBagLayout());
				pnlStudentButtons.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				pnlStudentButtons.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				pnlStudentButtons.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				pnlStudentButtons.setBorder(darkBorder);
				pnlStudentButtons.setBackground(Color.WHITE);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,1);
				pnlStudentButtons.add(new JLabel("Age:"), gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,-20,0,0);
				pnlStudentButtons.add(txtTopPanelAge, gc);
				
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,0);
				pnlStudentButtons.add(labels[5], gc);
				
				gc.gridx = 3;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,0);
				pnlStudentButtons.add(labels[6], gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,1);
				pnlCenterTopRightTop.add(pnlStudentButtons, gc);

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		pnlCenterTopRight.add(pnlCenterTopRightTop, gc);
		
				//Add the contents of the bottom panel, the group details
				//Add the group details (toprightbottom)
				JPanel pnlTopGroupDetails = new JPanel(new GridBagLayout());
				pnlTopGroupDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
				pnlTopGroupDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
				pnlTopGroupDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
				pnlTopGroupDetails.setBackground(Color.WHITE);
				pnlTopGroupDetails.setBorder(darkBorder);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(20,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Name:"),gc);
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group ID:"),gc);
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Positions Available:"),gc);
				gc.gridx = 0;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Level:"),gc);
				gc.gridx = 1;
				gc.gridy = 0;
				gc.insets = new Insets(15,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupName,gc);
				gc.gridx = 1;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupID,gc);
				gc.gridx = 1;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupPos,gc);
				gc.gridx = 1;
				gc.gridy = 3;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupLev,gc);
				gc.gridx = 2;
				gc.gridy = 0;
				gc.insets = new Insets(20,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Day:"),gc);
				gc.gridx = 2;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Time:"),gc);
				gc.gridx = 2;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Size:"),gc);
				gc.gridx = 2;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Material:"),gc);
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(15,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupDay,gc);
				gc.gridx = 3;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupTime,gc);
				gc.gridx = 3;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupMax,gc);
				gc.gridx = 3;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupMat,gc);
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,0,1,0);
		pnlCenterTopRight.add(pnlTopGroupDetails, gc);
		
				
		pnlCenterTopLeft.setBackground(new Color(246,246,246));
		

		
		//This is the main container panel for the North most components on the central stage - namely pnlCenterTopLeftPanel and pnlCenterTopRight//
		pnlCenterTopPanel.setBackground(Color.WHITE);
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,5,0,5);
			pnlCenterTopPanel.add(pnlCenterTopLeft, gc);
			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,5,0,10);
			pnlCenterTopPanel.add(pnlCenterTopRight, gc);
		////////////////////////////END OF THE TOP LEVEL COMPONENTS////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////
		////////////////////////BEGINNING OF THE BOTTOM LEVEL COMPONENTS///////////////////////
		///////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////
			
			JPanel pnlCenterBottomPanel = new JPanel(new GridBagLayout());
			pnlCenterBottomPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight-centerTopHeight));
			pnlCenterBottomPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight-centerTopHeight));
			pnlCenterBottomPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight-centerTopHeight));
			
			JPanel pnlCenterBottomLeft = new JPanel(new GridBagLayout());
			pnlCenterBottomLeft.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight-centerTopHeight));
			pnlCenterBottomLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight-centerTopHeight));
			pnlCenterBottomLeft.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight-centerTopHeight));
			

				//add components to the left panel
				pnlCenterBottomLeft.setBorder(darkBorder);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 0.2;
				gc.weighty = 0.2;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(10,10,0,0);
				pnlCenterBottomLeft.add(new JLabel("Click on the customers name to select:"), gc);
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.weightx = 0.2;
				gc.weighty = 0.2;
				gc.fill = GridBagConstraints.BOTH;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,10,10,10);
				pnlCenterBottomLeft.add(txtMoveToNameContainer, gc);
				
			JPanel pnlCenterBottomRight = new JPanel(new GridBagLayout());
			pnlCenterBottomRight.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
			pnlCenterBottomRight.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
			pnlCenterBottomRight.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
			pnlCenterBottomRight.setBackground(new Color(246,246,246));

					//Add the contents of the bottom panel, the group details
					//Add the group details (pnlBottomGroupDetails)
					JPanel pnlBottomGroupDetails = new JPanel(new GridBagLayout());
					pnlBottomGroupDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
					pnlBottomGroupDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
					pnlBottomGroupDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
					pnlBottomGroupDetails.setBackground(new Color(246,246,246));
					pnlBottomGroupDetails.setBorder(darkBorder);
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridwidth = 1;
					gc.gridheight = 1;
					gc.weightx = 0.5;
					gc.weighty = 0.5;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(20,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Group Name:"),gc);
					gc.gridx = 0;
					gc.gridy = 1;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Group ID:"),gc);
					gc.gridx = 0;
					gc.gridy = 2;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Positions Available:"),gc);
					gc.gridx = 0;
					gc.gridy = 3;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Group Level:"),gc);
					gc.gridx = 1;
					gc.gridy = 0;
					gc.insets = new Insets(15,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupName,gc);
					gc.gridx = 1;
					gc.gridy = 1;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupID,gc);
					gc.gridx = 1;
					gc.gridy = 2;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupPos,gc);
					gc.gridx = 1;
					gc.gridy = 3;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupLev,gc);
					gc.gridx = 2;
					gc.gridy = 0;
					gc.insets = new Insets(20,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Group Day:"),gc);
					gc.gridx = 2;
					gc.gridy = 1;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Group Time:"),gc);
					gc.gridx = 2;
					gc.gridy = 2;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Group Size:"),gc);
					gc.gridx = 2;
					gc.gridy = 3;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Material:"),gc);
					gc.gridx = 3;
					gc.gridy = 0;
					gc.insets = new Insets(15,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupDay,gc);
					gc.gridx = 3;
					gc.gridy = 1;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupTime,gc);
					gc.gridx = 3;
					gc.gridy = 2;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupMax,gc);
					gc.gridx = 3;
					gc.gridy = 3;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupMat,gc);
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,1,0);
			pnlCenterBottomRight.add(pnlBottomGroupDetails, gc);
			
					
			pnlCenterBottomLeft.setBackground(Color.WHITE);
			

			
			//This is the main container panel for the North most components on the central stage - namely pnlCenterTopLeftPanel and pnlCenterTopRight//
			pnlCenterBottomPanel.setBackground(Color.WHITE);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 0.2;
				gc.weighty = 0.2;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,5);
				pnlCenterBottomPanel.add(pnlCenterBottomLeft, gc);
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,10);
				pnlCenterBottomPanel.add(pnlCenterBottomRight, gc);
		
		///////////////////////////////////////////////////////////////////////////////////////
				//Begin Nested Details Panels (lowest panel on screen)
				JPanel pnlInformation = new JPanel();
				pnlInformation.setBackground(Color.WHITE);
				pnlInformation.setLayout(new GridBagLayout());
				pnlInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
				pnlInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
				pnlInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
				
				//Begin Nested Details Panels (lowest panel on screen)
				JPanel pnlSaveRow = new JPanel();
				pnlSaveRow.setBackground(Color.WHITE);
				pnlSaveRow.setLayout(new GridBagLayout());
				pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
				pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
				pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

					//Create the far left container for the group details information
					JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
					pnlSaveLeftPane.setBackground(Color.WHITE);
					pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
					pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
					pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
					
					//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,0,0,0);
					
						//Add the nested panels to the container panel (information panel)
					
						JPanel panel3 = new JPanel(new GridBagLayout());
						panel3.setBackground(Color.WHITE);
						panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
						panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
						panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
						
						
						JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
						row1.setBackground(Color.WHITE);
						row1.add(new JLabel("Table updated:"));
						row1.add(lblDate);
						
						JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
						row2.setBackground(Color.WHITE);
						row2.add(new JLabel("Connected to: " + controller.getDBname()));
						
						JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
						row3.setBackground(Color.WHITE);
						row3.add(new JLabel("Connection: Secure"));
						
						gc.gridx = 0;
						gc.gridy = 0;
						gc.gridheight = 1;
						gc.gridwidth = 1;
						gc.weightx = 1;
						gc.weighty = 1;
						gc.fill = GridBagConstraints.NONE;
						gc.anchor = GridBagConstraints.NORTHWEST;
						gc.insets = new Insets(5,5,0,5);
					
						panel3.add(row1, gc);
						
						gc.gridx = 0;
						gc.gridy = 1;
						gc.gridheight = 1;
						gc.gridwidth = 1;
						gc.weightx = 1;
						gc.weighty = 1;
						gc.fill = GridBagConstraints.NONE;
						gc.anchor = GridBagConstraints.NORTHWEST;
						gc.insets = new Insets(0,5,0,5);
					
						panel3.add(row2, gc);
						
						gc.gridx = 0;
						gc.gridy = 2;
						gc.gridheight = 1;
						gc.gridwidth = 1;
						gc.weightx = 1;
						gc.weighty = 1;
						gc.fill = GridBagConstraints.NONE;
						gc.anchor = GridBagConstraints.NORTHWEST;
						gc.insets = new Insets(0,5,45,5);
					
						panel3.add(row3, gc);
						
						gc.gridx = 0;
						gc.gridy = 0;
						gc.gridheight = 1;
						gc.gridwidth = 1;
						gc.weightx = 1;
						gc.weighty = 1;
						gc.fill = GridBagConstraints.NONE;
						gc.anchor = GridBagConstraints.NORTHWEST;
						gc.insets = new Insets(0,5,20,5);
					
						pnlSaveLeftPane.add(panel3, gc);
				
				pnlSaveRow.add(pnlSaveLeftPane, gc);
					
				//////////////////////////////////////////Main Column 2 ///////////////////////////////////////////
				//Create the second panel from the left (comments panel)

				JPanel pnlSaveRight = new JPanel(new GridBagLayout());
				pnlSaveRight.setBackground(Color.WHITE);
				pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
				pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
				pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));

				

				
					//Add the nested panels to the container panel (comments panel)
					
					JPanel pblButtons = new JPanel(new GridBagLayout());
					pblButtons.setBackground(Color.WHITE);
					pblButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
					pblButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
					pblButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
					
					JPanel panel4 = new JPanel(new GridBagLayout());
					panel4.setBackground(Color.WHITE);
					panel4.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
					panel4.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
					panel4.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
					
					labels[3].setCursor(UI_Settings.getJlabelCursor());
					labels[3].addMouseListener(new MouseAdapter(){
						public void mouseClicked(MouseEvent e){
							JOptionPane.showMessageDialog(controllingFrame,
					                "The administrator password can be found with the \"Kids Coordinator\"\n"
					              + "or by contacting your \"Branch Manager\".", "Information Message", JOptionPane.WARNING_MESSAGE);
						}
					});
					
					JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
					adminPanel.setBackground(Color.WHITE);
					adminPanel.add(new JLabel("Administrator password:"));
					adminPanel.add(passwordField);
					adminPanel.add(labels[3]);
					adminPanel.add(btnMoveStudent);


					
					gc.gridx = 0;
					gc.gridy = 1;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,1,0,1);
					
					panel4.add(adminPanel, gc);
					
					gc.gridx = 0;
					gc.gridy = 1;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.NORTHEAST;
					gc.insets = new Insets(-10,0,0,10);
					
					pblButtons.add(panel4, gc);
					
					//Add the comments panel	
					gc.gridx = 1;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,-5,0,0);
					
					pnlSaveRight.add(pblButtons, gc);
					
					//Add the nested panels to the container panel (information panel)
					pnlSaveRow.add(pnlSaveRight, gc);
				
				//Add the nested panels to the container panel (information panel)
				pnlInformation.add(pnlSaveRow, gc);
	
		
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        pnlCenterTopPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlCenterTopPanel);
        
        moveToButtonsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(moveToButtonsPanel);
        
        pnlCenterBottomPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlCenterBottomPanel);
        
        centerPanel.add(Box.createVerticalStrut(5));

        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlInformation);

		/*********************************************************************************************************************************/
		///////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly///////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());		
		//Add the details section and table sections to the canvas.
		canvas.add(header, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return scroller;
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
}
