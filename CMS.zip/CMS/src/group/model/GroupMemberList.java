package group.model;

import java.io.Serializable;

public class GroupMemberList implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String getGroupName() {
		return groupName;
	}


	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}


	public int getGroupID() {
		return groupID;
	}


	public void setGroupID(int groupID) {
		this.groupID = groupID;
	}


	public int getMember1ID() {
		return member1ID;
	}


	public void setMember1ID(int member1id) {
		member1ID = member1id;
	}


	public int getMember2ID() {
		return member2ID;
	}


	public void setMember2ID(int member2id) {
		member2ID = member2id;
	}


	public int getMember3ID() {
		return member3ID;
	}


	public void setMember3ID(int member3id) {
		member3ID = member3id;
	}


	public int getMember4ID() {
		return member4ID;
	}


	public void setMember4ID(int member4id) {
		member4ID = member4id;
	}


	public int getMember5ID() {
		return member5ID;
	}


	public void setMember5ID(int member5id) {
		member5ID = member5id;
	}


	public int getMember6ID() {
		return member6ID;
	}


	public void setMember6ID(int member6id) {
		member6ID = member6id;
	}


	String groupName = "";
	int groupID = 0;
	
	int member1ID = 0;
	int member2ID = 0;
	int member3ID = 0;
	int member4ID = 0;
	int member5ID = 0;
	int member6ID = 0;
	

	public GroupMemberList(String groupName, int groupID, int member1id, int member2id,
			int member3id, int member4id, int member5id, int member6id) {
		
		this.groupName = groupName;
		this.groupID = groupID;
		
		this.member1ID = member1id;
		this.member2ID = member2id;
		this.member3ID = member3id;
		this.member4ID = member4id;
		this.member5ID = member5id;
		this.member6ID = member6id;
		
		
	}
	
	

}
