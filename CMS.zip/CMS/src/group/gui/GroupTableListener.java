package group.gui;

public interface GroupTableListener {
	public void rowDeleted(int row);
}
