package group.gui;

import java.util.EventObject;

public class FormEventMemberList extends EventObject {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String groupName = "";
	int groupID = 0;
	
	int member1ID = 0;
	int member2ID = 0;
	int member3ID = 0;
	int member4ID = 0;
	int member5ID = 0;
	int member6ID = 0;

	public FormEventMemberList(Object source, String groupName, int groupID, int member1ID, int member2ID, int member3ID, int member4ID, int member5ID, int member6ID) {
		super(source);
		
		this.groupName = groupName;
		this.groupID = groupID;
		this.member1ID = member1ID;
		this.member2ID = member2ID;
		this.member3ID = member3ID;
		this.member4ID = member4ID;
		this.member5ID = member5ID;
		this.member6ID = member6ID;
		
	}
	
	
	public String getGroupName() {
		return groupName;
	}


	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}


	public int getGroupID() {
		return groupID;
	}


	public void setGroupID(int groupID) {
		this.groupID = groupID;
	}


	public int getMember1ID() {
		return member1ID;
	}


	public void setMember1ID(int member1id) {
		member1ID = member1id;
	}


	public int getMember2ID() {
		return member2ID;
	}


	public void setMember2ID(int member2id) {
		member2ID = member2id;
	}


	public int getMember3ID() {
		return member3ID;
	}


	public void setMember3ID(int member3id) {
		member3ID = member3id;
	}


	public int getMember4ID() {
		return member4ID;
	}


	public void setMember4ID(int member4id) {
		member4ID = member4id;
	}


	public int getMember5ID() {
		return member5ID;
	}


	public void setMember5ID(int member5id) {
		member5ID = member5id;
	}


	public int getMember6ID() {
		return member6ID;
	}


	public void setMember6ID(int member6id) {
		member6ID = member6id;
	}

}
