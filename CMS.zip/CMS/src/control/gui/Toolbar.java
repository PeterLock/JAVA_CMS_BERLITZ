package control.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JToolBar;

import settings.UI_Settings;
import utilities.SentryModule;

public class Toolbar extends JToolBar implements ActionListener {


	private static final long serialVersionUID = 1L;
	private JButton refreshButton;
	private JButton saveButton;
	private JButton addButton;
	private JButton openButton;
	private JButton searchButton;
	private JButton databaseErrorButton;
	private JButton openExcelButton;
	private JButton openWordButton;
	private JButton lockButton;
	private JButton printButton;
	private JButton mailButton;
	private JButton resetButton;
	
	private ToolbarListener listener;
	private JFrame frame;
	
	private Color toolBarColor;
	private boolean unlocked = false;

	
	private UI_Settings UI = new UI_Settings();

	
	public Toolbar(){
		setFloatable(false);
		
		toolBarColor = UI.getToolBarColor();
		
		
		this.setBackground(UI.getToolBarColor());
		this.setPreferredSize(new Dimension(700, UI_Settings.getToolbarHeight()));

		refreshButton = new JButton();
		refreshButton.setIcon(createIcon("/icons_c/database_plus.png"));
		refreshButton.setBackground(toolBarColor);
		refreshButton.setMargin(new Insets(5,0,0,0));
		refreshButton.setOpaque(true);
		refreshButton.setBorderPainted(false);
		refreshButton.setToolTipText("Load database");
		refreshButton.addActionListener(this);
		
		saveButton = new JButton();
		saveButton.setIcon(createIcon("/icons_c/database_insert.png"));
		saveButton.setBackground(toolBarColor);
		saveButton.setMargin(new Insets(5,0,0,0));
		saveButton.setOpaque(true);
		saveButton.setBorderPainted(false);
		saveButton.setToolTipText("Save database");
		saveButton.addActionListener(this);
		
		
		addButton = new JButton();
		addButton.setIcon(createIcon("/icons_c/butterfly.png"));
		addButton.setBackground(toolBarColor);
		addButton.setMargin(new Insets(5,2,0,0));
		addButton.setOpaque(true);
		addButton.setBorderPainted(false);
		addButton.setToolTipText("Add customer");
		addButton.addActionListener(this);

		resetButton = new JButton();
		resetButton.setIcon(createIcon("/icons_c/c_reorder.png"));
		resetButton.setBackground(toolBarColor);
		resetButton.setMargin(new Insets(5,0,0,0));
		resetButton.setOpaque(true);
		resetButton.setBorderPainted(false);
		resetButton.setToolTipText("Reset perspectives");
		resetButton.addActionListener(this);	

		
		openButton = new JButton();
		openButton.setIcon(createIcon("/icons_g/folder_horizontal_open.png"));
		openButton.setBackground(toolBarColor);
		openButton.setMargin(new Insets(5,25,0,0));
		openButton.setOpaque(true);
		openButton.setBorderPainted(false);
		openButton.setToolTipText("Open file");
		openButton.addActionListener(this);

		
		searchButton = new JButton();
		searchButton.setIcon(createIcon("/icons_c/find.png"));
		searchButton.setBackground(toolBarColor);
		searchButton.setMargin(new Insets(5,0,0,0));
		searchButton.setOpaque(true);
		searchButton.setBorderPainted(false);
		searchButton.setToolTipText("Find");
		searchButton.addActionListener(this);

		
		databaseErrorButton = new JButton();
		databaseErrorButton.setIcon(createIcon("/icons_g/database_exclamation.png"));
		databaseErrorButton.setBackground(toolBarColor);
		databaseErrorButton.setMargin(new Insets(5,0,0,0));
		databaseErrorButton.setOpaque(true);
		databaseErrorButton.setBorderPainted(false);
		databaseErrorButton.setToolTipText("Database state");
		databaseErrorButton.addActionListener(this);

		
		openExcelButton = new JButton();
		openExcelButton.setIcon(createIcon("/icons_c/document-table.png"));
		openExcelButton.setBackground(toolBarColor);
		openExcelButton.setMargin(new Insets(5,25,0,0));
		openExcelButton.setOpaque(true);
		openExcelButton.setBorderPainted(false);
		openExcelButton.setToolTipText("Create new spreadsheet");
		openExcelButton.addActionListener(this);

		
		openWordButton = new JButton();
		openWordButton.setIcon(createIcon("/icons_c/document.png"));
		openWordButton.setBackground(toolBarColor);
		openWordButton.setMargin(new Insets(7,0,2,0));
		openWordButton.setOpaque(true);
		openWordButton.setBorderPainted(false);
		openWordButton.setToolTipText("Create new document");
		openWordButton.addActionListener(this);
		
		/******************************************************Right side menu items*****************************************************/
		lockButton = new JButton();
		lockButton.setIcon(createIcon("/icons_g/lock_grey.png"));
		lockButton.setBackground(toolBarColor);
		lockButton.setMargin(new Insets(7,0,2,0));
		lockButton.setOpaque(true);
		lockButton.setBorderPainted(false);
		lockButton.setToolTipText("Lock");
		lockButton.addActionListener(this);

		
		printButton = new JButton();
		printButton.setIcon(createIcon("/icons_c/printer.png"));
		printButton.setBackground(toolBarColor);
		printButton.setMargin(new Insets(7,0,2,0));
		printButton.setOpaque(true);
		printButton.setBorderPainted(false);
		printButton.setToolTipText("Print");
		printButton.addActionListener(this);

		
		mailButton = new JButton();
		mailButton.setIcon(createIcon("/icons_c/emails.png"));
		mailButton.setBackground(toolBarColor);
		mailButton.setMargin(new Insets(7,0,2,0));
		mailButton.setOpaque(true);
		mailButton.setBorderPainted(false);
		mailButton.setToolTipText("Mail");
		mailButton.addActionListener(this);

		
		
		add(refreshButton);
		add(saveButton);
		add(databaseErrorButton);
		add(addButton);
		add(resetButton);
		add(openButton);
		add(searchButton);
        add(Box.createHorizontalGlue());
        add(lockButton);
		add(printButton);
		add(mailButton);

	}

	
	private ImageIcon createIcon(String path){
		URL url = getClass().getResource(path);
		
		if(url == null){
			System.out.println("Unable to load image: " + path);
		}
		
		ImageIcon icon = new ImageIcon(url);
		
		Image img = icon.getImage();
		Image newimg = img.getScaledInstance(16, 16, java.awt.Image.SCALE_SMOOTH);
		
		icon=new ImageIcon(newimg);
		

		return icon;
	}
	
	public void setToolbarListener(ToolbarListener listener){
		this.listener = listener;
	}


	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		JButton clicked = new JButton();
		clicked = (JButton)e.getSource();
		
		
		if(clicked == refreshButton){
			if(listener != null){
				try {
					listener.refreshEventOccurred();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		if(clicked == saveButton){
			if(listener != null){
				listener.saveEventOccurred();
			}
		}
		if(clicked == addButton){
			if(listener != null){
				listener.addStudent();
			}
		}		
		
		if(clicked == resetButton){
			if(listener != null){
				listener.refreshWindowsEventOccurred();
			}
		}	
		if(clicked == openButton){
			if(listener != null){
				listener.importEventOccurred();
			}
		}
		if(clicked == searchButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}	
	
		if(clicked == databaseErrorButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}	
		if(clicked == openExcelButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}	
		if(clicked == openWordButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}		

		
		if(clicked == lockButton){
			
			Boolean validated = false;
			
			JPanel panel = new JPanel();
			JLabel label = new JLabel("Enter your password:");
			JPasswordField pass = new JPasswordField(20);
			panel.add(label);
			panel.add(pass);
			String[] options = new String[]{"OK", "Cancel"};

			
			if(listener != null){
				
				if(!unlocked){
					int option = JOptionPane.showOptionDialog(null, panel, "Secure Login",
	                         JOptionPane.NO_OPTION, JOptionPane.PLAIN_MESSAGE,
	                         null, options, options[1]);
					
					if(option == 0) // pressing OK button
					{
					    char[] password = pass.getPassword();
						SentryModule sentry = new SentryModule();
						validated = sentry.takeInput(password);
						
						if(!validated){
							JOptionPane.showMessageDialog(frame, 
									"Unable to login. Incorrect password.", 
									"Secure settings", 
									JOptionPane.ERROR_MESSAGE);
						}else{
							this.lockButton.setIcon(createIcon("/icons_c/lock_unlock.png"));
							unlocked = true;
							this.listener.acceptPassword();
						}
					}
					return;
				} 
			}
			
			if(unlocked){
				this.lockButton.setIcon(createIcon("/icons_g/lock_grey.png"));
				unlocked = false;
				validated = false;
				this.listener.declinePassword();
				return;
			}
			
		}	
		if(clicked == printButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}			
		if(clicked == mailButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}		
	}
	
	public void setToolBarColor(Color c){
		
		this.setBackground(c);
		this.toolBarColor = c;
		
		refreshButton.setBackground(c);
		saveButton.setBackground(c);
		addButton.setBackground(c);
		resetButton.setBackground(c);
		openButton.setBackground(c);
		searchButton.setBackground(c);
		databaseErrorButton.setBackground(c);
		openExcelButton.setBackground(c);
		openWordButton.setBackground(c);
		lockButton.setBackground(c);
		printButton.setBackground(c);
		mailButton.setBackground(c);

		repaint();
	}
}
