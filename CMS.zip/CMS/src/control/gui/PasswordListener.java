package control.gui;

public interface PasswordListener {
	public boolean getPasswordState();
}
