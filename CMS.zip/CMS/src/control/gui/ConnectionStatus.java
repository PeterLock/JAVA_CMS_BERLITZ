package control.gui;

import com.mysql.jdbc.Connection;

public interface ConnectionStatus {
	public java.sql.Connection getConnection();
}
