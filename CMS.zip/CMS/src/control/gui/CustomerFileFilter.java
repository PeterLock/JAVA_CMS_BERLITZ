package control.gui;

import java.io.File;

import javax.swing.filechooser.FileFilter;

public class CustomerFileFilter extends FileFilter {

	@Override
	public boolean accept(File file) {
		
		String name = file.getName();
		
		String extenstion = Utils.getFileExtension(name);
		
		if(extenstion == null){
			return false;
		}
		
		if(extenstion.equals("cis")){
			return true;
		}
		
		return false;
	}

	@Override
	public String getDescription() {
		return "CIS Files (*.cis)";
	}

}
