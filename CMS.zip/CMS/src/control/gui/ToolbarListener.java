package control.gui;

public interface ToolbarListener {
	public void saveEventOccurred();
	public void refreshEventOccurred() throws Exception;
	public void refreshWindowsEventOccurred();
	public void importEventOccurred();
	public void addStudent();
	public void acceptPassword();
	public void declinePassword();
	public boolean getPasswordState();
}
