package customer.gui;

import java.util.EventObject;

public class FormEvent extends EventObject {
	

	private static final long serialVersionUID = 1L;
	private String firstname;
	private String lastname;
	private Integer month;
	private String material;
	private String level;
	private int id;
	private int listen;
	private int speak;
	private int read;
	private int participation;
	private int cooperation;
	private String age;
	private String interests;
	private String comments;

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getListen() {
		return listen;
	}

	public void setListen(int listen) {
		this.listen = listen;
	}

	public int getSpeak() {
		return speak;
	}

	public void setSpeak(int speak) {
		this.speak = speak;
	}

	public int getRead() {
		return read;
	}

	public void setRead(int read) {
		this.read = read;
	}

	public int getParticipation() {
		return participation;
	}

	public void setParticipation(int participation) {
		this.participation = participation;
	}

	public int getCooperation() {
		return cooperation;
	}

	public void setCooperation(int cooperation) {
		this.cooperation = cooperation;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getInterests() {
		return interests;
	}

	public void setInterests(String interests) {
		this.interests = interests;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public String getFirstname() {
		return firstname;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public FormEvent(Object source) {
		super(source);
	}
	
	//Extra parameter ID for saving new students
	public FormEvent(Object source, String firstname, String lastname, Integer month, String material, String level, Integer ID) {
		super(source);
		
		this.firstname = firstname;
		this.lastname = lastname;
		this.month = month;
		this.material = material;
		this.level = level;
		this.id = ID;
	}
	
	//Doesn't have the ID parameter - this constructor is used for searching
	public FormEvent(Object source, String firstname, String lastname, int month, String material, String level) {
		super(source);
		
		this.firstname = firstname;
		this.lastname = lastname;
		this.month = month;
		this.material = material;
		this.level = level;
	}

	public FormEvent(Object source, String firstname, String lastname, int month, String material,
			String level, Integer ID, int listen, int speak, int read, int par, int coop, String age, String interests,
			String comments) {
		super(source);
		
		this.firstname = firstname;
		this.lastname = lastname;
		this.month = month;
		this.material = material;
		this.level = level;
		this.id = ID;
		this.listen = listen;
		this.speak = speak;
		this.read = read;
		this.participation = par;
		this.cooperation = coop;
		this.age = age;
		this.interests = interests;
		this.comments = comments;
		
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}
}
