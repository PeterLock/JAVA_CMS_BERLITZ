package gui.administrative.com;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ColorUIResource;

import control.gui.TableTemplate;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.SentryModule;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class AdministrativePane extends JPanel {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		static JTabbedPane pane = new JTabbedPane();
		TextPrompt textPrompt;
		UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	    JPasswordField passwordField;
	    JPasswordField passwordField2;
	    JPasswordField passwordField3;
	    JPasswordField passwordField4;

	    JFrame controllingFrame; //needed for dialogs
		
		/**********************************************************************************************************************************/
		////////////Add Student Waiting to Join Table////////////////////
		TD_Waiting TD_AddStudentWaiting = new TD_Waiting();
		TableTemplate waitingTable = new TableTemplate(TD_AddStudentWaiting, TD_AddStudentWaiting.getCOLUMN_PERCENTAGES(), "");
		
		/**********************************************************************************************************************************/

		public AdministrativePane() {
	        initializeUI();
	    }
	
	    private void initializeUI() {
	    	
	    	UIManager.put("Label.font", UI_Settings.getComponentsFontPlain());
	    	UIManager.put("Label.foreground", UI_Settings.getComponentsFontColorDark());
	    	
	        setLayout(new BorderLayout());
	        setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, java.awt.Toolkit.getDefaultToolkit().getScreenSize().height));
	
	        //OK
	        UIManager.put("TabbedPane.selected", new ColorUIResource(UI_Settings.getBottomTabColor()));
	        UIManager.put("TabbedPane.unselectedTabBackground", UI_Settings.getCmsGray());       
	        
	        pane.setForeground(Color.WHITE);
	        pane.setFocusable(false);
	        pane.setBorder(new EmptyBorder(0, 0, 0, 0));
	
	
	        //OK
	        UIManager.getDefaults().put("TabbedPane.tabAreaInsets", new Insets(0,0,0,0));
	        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0)); 
	        
	
	        //Sets the JPanel container to black
	        setBackground(UI_Settings.getCmsTabSecondLvlGrey());
	        pane.addTab("<html><body><table width='120' style='font-size:11'><td style='text-align:center'>Possible Classes</td></table></body></html>", possibleClasses());//0
	        pane.addTab("<html><body><table width='160' style='font-size:11'><td style='text-align:center'>Add Waiting</td></table></body></html>",addWaiting());//1

	        //Set the text color for each tab
	        pane.setForeground(Color.WHITE);
	
	        pane.setBackgroundAt(0, UI_Settings.getCmsGray());	//0
	        pane.setBackgroundAt(1, UI_Settings.getCmsGray());	//1
	    
	        changeUI(UI_Settings.getBottomTabColor());
	
	    }
	
	    public void changeUI( Color bottomTabColor) {
	        pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
	            @Override protected int calculateTabHeight(
	              int tabPlacement, int tabIndex, int fontHeight) {
	            	
	    	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
	    	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
	    	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
	    	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
	    	       focus = UI_Settings.getCmsTabSecondLvlGrey();
	            	
	              return 27;
	            }
	            
	            
	            @Override protected void paintTab(
	              Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
	              Rectangle iconRect, Rectangle textRect) {
	        
	               rects[tabIndex].height = 25 + 1;
	               rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
	              
	              super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
	            }
	          });
	        
	        //Add the tab to the canvas
	        this.add(pane, BorderLayout.CENTER);		
		}
	
		public static void showFrame() {
	        JPanel panel = new AdministrativePane();
	        panel.setOpaque(true);
	
	        JFrame frame = new JFrame("CMS Test Screen");
	        JFrame.setDefaultLookAndFeelDecorated(false);
	        frame.setPreferredSize(UI_Settings.getMinimumScreenSize());
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setContentPane(panel);
	        frame.pack();
	        frame.setVisible(true);
	    }
	    
	    public void changeTheme(Color c) {
	      UIManager.put("TabbedPane.selected",new ColorUIResource(c));
			 
	      pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
	          @Override protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
	            return 27;
	          }
	      });
	      
		pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
		    @Override protected int calculateTabHeight(
		      int tabPlacement, int tabIndex, int fontHeight) {
		    	
		       highlight = UI_Settings.getCmsTabSecondLvlGrey();
		       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
		       shadow = UI_Settings.getCmsTabSecondLvlGrey();
		       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
		       focus = UI_Settings.getCmsTabSecondLvlGrey();
		    	
		      return 27;
		    }
		    
		    
		    @Override protected void paintTab(
		      Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
		      Rectangle iconRect, Rectangle textRect) {
		
		       rects[tabIndex].height = 25 + 1;
		       rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
		      
		      super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
		    }
		  });
		}
	
	    public static void main(String[] args) {
	        SwingUtilities.invokeLater(new Runnable() {
	            public void run() {
	                AdministrativePane.showFrame();
	            }
	        });
	    }

		public Component possibleClasses()
		{
			JPanel canvas;
			JPanel detailsPanel;
			JPanel centerPanel;
			
			JButton btnDeleteEvent;
			
			JTextArea txtAreaComments;
			JTextArea txtAreaEventList;
			JTextArea txtAreaEmail;
			
	        passwordField2 = new JPasswordField(10);
	        passwordField2.setActionCommand(UI_Settings.getOk());
	
			btnDeleteEvent = new JButton("Perform Action");
			btnDeleteEvent.setPreferredSize(new Dimension(200,UI_Settings.getJbuttonSize().height));
			btnDeleteEvent.setMinimumSize(new Dimension(200,UI_Settings.getJbuttonSize().height));
	
			btnDeleteEvent.setFont(UI_Settings.getComponentInputFontSize());
			
			JCheckBox chkMatchRequest = new JCheckBox("send match alert");
			JCheckBox chkDeleteCustomer = new JCheckBox("delete waiting customer");
			
			chkMatchRequest.setFont(UI_Settings.getComponentsFontPlain());
			chkMatchRequest.setForeground(UI_Settings.getComponentsFontColorLight());
			
			chkDeleteCustomer.setFont(UI_Settings.getComponentsFontPlain());
			chkDeleteCustomer.setForeground(UI_Settings.getComponentsFontColorLight());
			
			/***************************************************Create textAreas********************************************************************/
			Border line = BorderFactory.createLineBorder(new Color(224,224,224));
			Border empty = new EmptyBorder(5, 5, 5, 5);
			CompoundBorder border = new CompoundBorder(line, empty);
			
			txtAreaComments = new JTextArea(4, 40);
			txtAreaComments.setPreferredSize(txtAreaComments.getPreferredSize());
			txtAreaComments.setMinimumSize(txtAreaComments.getPreferredSize());
			txtAreaComments.setEditable(true);
			txtAreaComments.setBorder(border);
			txtAreaComments.setWrapStyleWord(true);
			txtAreaComments.setLineWrap(true);
			textPrompt = new TextPrompt("<no comments found>", txtAreaComments);
			txtAreaComments.setFont(UI_Settings.getComponentInputFontSize());
			txtAreaComments.setMargin( new Insets(2,2,2,2) );
			
			
			txtAreaEventList = new JTextArea(5, 35);
			txtAreaEventList.setMinimumSize(txtAreaEventList.getPreferredSize());
			txtAreaEventList.setEditable(true);
			txtAreaEventList.setBorder(border);
			txtAreaEventList.setWrapStyleWord(true);
			txtAreaEventList.setLineWrap(true);
			textPrompt = new TextPrompt("<no events found>", txtAreaEventList);
			txtAreaEventList.setFont(UI_Settings.getComponentInputFontSize());
			txtAreaEventList.setMargin( new Insets(5,5,5,5) );
			
			txtAreaEmail = new JTextArea(5, 35);
			txtAreaEmail.setMinimumSize(txtAreaEventList.getPreferredSize());
			txtAreaEmail.setEditable(true);
			txtAreaEmail.setBorder(border);
			txtAreaEmail.setWrapStyleWord(true);
			txtAreaEmail.setLineWrap(true);
			textPrompt = new TextPrompt("<notfiy staff of a possible class for this customer>", txtAreaEmail);
			txtAreaEmail.setFont(UI_Settings.getComponentInputFontSize());
			txtAreaEmail.setMargin( new Insets(5,5,5,5) );
			
			/***********************Initialize Fields******************************/
			JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
			failedMessage.setForeground(UI_Settings.getFailedMessageColor());
	
			failedMessage.setVisible(false);
			
			JLabel failedMessage1 = new JLabel(UI_Settings.getFailedMessage());
			failedMessage1.setForeground(UI_Settings.getFailedMessageColor());
	
			failedMessage1.setVisible(false);
			
			JLabel labels[] = new JLabel[10];
			
			labels[0] = new JLabel("reset fields");
			labels[1] = new JLabel("delete");
			labels[2] = new JLabel("edit email");
			labels[3] = new JLabel("reset calendar");
			labels[4] = new JLabel("hint");
			labels[5] = new JLabel("edit event description");
			labels[6] = new JLabel("refresh event list");
			labels[7] = new JLabel("generate");
			labels[8] = new JLabel("view details");
			labels[9] = new JLabel("possible match found");
	
	
			for( int i = 0; i < 10; i++){
				labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
				labels[i].setCursor(UI_Settings.getJlabelCursor());
			}
			
	        passwordField = new JPasswordField(10);
	        passwordField.setActionCommand(UI_Settings.getOk());
			
			
	        List<JTextField> textfields = new ArrayList<JTextField>();
	        @SuppressWarnings("rawtypes")
			List<JComboBox> comboboxes = new ArrayList<JComboBox>();
			
	        
			JTextField txtPrefDay = new JTextField(8);
			JTextField txtRecomDay = new JTextField(8);
			JTextField txtStartDate = new JTextField(12);
			JTextField txtStudentName = new JTextField(7);

	        textfields.add(txtPrefDay);
	        textfields.add(txtRecomDay);
	        textfields.add(txtStartDate);
	        textfields.add(txtStudentName);

			//textPrompt = new TextPrompt("0 / 5", txtListen);

	        for(int i = 0; i < textfields.size(); i++){
	        	
	        	textfields.get(i).setEditable(true);
	        	textfields.get(i).setMinimumSize(textfields.get(i).getPreferredSize());
	        	textfields.get(i).setHorizontalAlignment(JTextField.LEFT);
	        	
	    		textPrompt = new TextPrompt("<empty>", textfields.get(i));

	        }
	        
	        
	        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			List<JTextField> textfieldsGroupDetails = new ArrayList<JTextField>();
			List<TextPrompt> textprompts = new ArrayList<TextPrompt>();
	
	        
	        int size = 13;
			
			JTextField txtGroupName = new JTextField(size);
			JTextField txtGroupID = new JTextField(size);
			JTextField txtGroupPos = new JTextField(size);
			JTextField txtGroupLev = new JTextField(size);
			JTextField txtGroupDay = new JTextField(size);
			JTextField txtGroupTime = new JTextField(size);
			JTextField txtGroupMax = new JTextField(size);
			JTextField txtGroupMat = new JTextField(size);

			
			textfieldsGroupDetails.add(txtGroupName); 
			textfieldsGroupDetails.add(txtGroupID); 
			textfieldsGroupDetails.add(txtGroupPos); 
			textfieldsGroupDetails.add(txtGroupLev); 
			textfieldsGroupDetails.add(txtGroupDay); 
			textfieldsGroupDetails.add(txtGroupTime); 
			textfieldsGroupDetails.add(txtGroupMax); 
			textfieldsGroupDetails.add(txtGroupMat); 

			
			for(int i = 0; i < textfieldsGroupDetails.size(); i++){
				
				textfieldsGroupDetails.get(i).setMinimumSize(textfieldsGroupDetails.get(i).getPreferredSize());
				textfieldsGroupDetails.get(i).setHorizontalAlignment(JTextField.LEFT);
				
				textPrompt = new TextPrompt("-", textfieldsGroupDetails.get(i));

			}
	
	        
			/*********************************************************Create Combo Boxes*********************************************************/
			JComboBox cmbGroupName = new JComboBox(UI_Settings.getGroups());
			JComboBox cmbRequestBy = new JComboBox(UI_Settings.getEmployeeNames());
			JComboBox cmbEventMonth = new JComboBox(UI_Settings.getMonths());
			JComboBox cmbWeeks = new JComboBox(UI_Settings.getWaitingFrom());
	
			cmbWeeks.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
			cmbWeeks.setFont(UI_Settings.getComponentInputFontSize());
			cmbWeeks.setMinimumSize(cmbWeeks.getPreferredSize());
			//AutoCompletion.enable(cmbPreferredEmp_1, 150, UI_Settings.getComboBoxHeight());
			comboboxes.add(cmbWeeks);
	
			cmbRequestBy.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
			cmbRequestBy.setFont(UI_Settings.getComponentInputFontSize());
			cmbRequestBy.setMinimumSize(cmbRequestBy.getPreferredSize());
			//AutoCompletion.enable(cmbPreferredEmp_1, 150, UI_Settings.getComboBoxHeight());
			comboboxes.add(cmbRequestBy);
			
			cmbEventMonth.setPreferredSize(new Dimension(120, 27));
			cmbEventMonth.setFont(UI_Settings.getComponentInputFontSize());
			cmbEventMonth.getEditor().getEditorComponent().setBackground(Color.WHITE);
			//AutoCompletion.enable(cmbStartMonth, 120, 28);
			
			cmbGroupName.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
			cmbGroupName.setFont(UI_Settings.getComponentInputFontSize());
			cmbGroupName.setMinimumSize(cmbGroupName.getPreferredSize());
			//AutoCompletion.enable(cmbGroupName, 150, UI_Settings.getComboBoxHeight());
			comboboxes.add(cmbGroupName);
			
			/****************************Create the canvas**************************/
			canvas = new JPanel();
			canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
			/**********************Create the components panel***********************/
			detailsPanel = new JPanel();
			detailsPanel.setBackground(Color.WHITE);
			detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 120));
			detailsPanel.setLayout(new GridBagLayout());
			/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
			labels[0].addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){
					
			       int action = JOptionPane.showConfirmDialog(AdministrativePane.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
			       
			       if(action == JOptionPane.OK_OPTION){
			    	   
			    	   cmbGroupName.setSelectedIndex(0);
					   failedMessage.setVisible(false);
					   failedMessage1.setVisible(false);
					   
					   txtAreaComments.setText("");
					   
					   txtStartDate.setText("");
					   txtPrefDay.setText("");
					   txtRecomDay.setText("");
					   passwordField.setText("");
					   
			       }
				}
			});
			GridBagConstraints gc = new GridBagConstraints();
			
			/****************************Create the canvas**************************/
			canvas = new JPanel();
			canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
			/**********************Create the components panel***********************/
			detailsPanel = new JPanel();
			detailsPanel.setBackground(UI_Settings.getButtonPanelColor());
			detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.X_AXIS));
			detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
			/******************************************************Add the Header Panel************************************************/
			
			JPanel dpLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 30));
			dpLeft.setBackground(Color.WHITE);
			dpLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			dpLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
	
			dpLeft.add(new JLabel("Select how far back you would like to view waiting customers:"));
			dpLeft.add(cmbWeeks);
			
			
			JPanel dpRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 2));
			dpRight.setBackground(Color.WHITE);
			setPanelSize(dpRight, new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			
			dpLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
			detailsPanel.add(dpLeft);
			
			dpRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
			detailsPanel.add(dpRight);
			
			/******************************************************Add the Reset Panel************************************************/
			JPanel buttonPanel = new JPanel();
			buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
			buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
			
			buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
			buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
			buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
	
			
			JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
			leftPanel.setBackground(Color.WHITE);
			leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			leftPanel.add(failedMessage);
			
			JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
			rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
			rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			rightPanel.add(labels[0]);//Reset label
			
			leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
			buttonPanel.add(leftPanel);
			
			rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
			buttonPanel.add(rightPanel);
			/******************************************************Add The Central Components************************************************/
			int containerHght = (int) (java.awt.Toolkit.getDefaultToolkit().getScreenSize().getHeight()/3*1.5);
			
			JPanel container = new JPanel(new GridBagLayout());
			setPanelSize(container, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, containerHght));
			container.setBackground(Color.WHITE);
	
				JPanel containerLeft = new JPanel(new GridBagLayout());
				setPanelSize(containerLeft, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, containerHght));
				containerLeft.setBackground(new Color(246,246,246));
				containerLeft.setBorder(border);
				
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(20,10,0,0);
					containerLeft.add(new JLabel("Click on the customers name to select:"),gc);
				
					gc.gridx = 0;
					gc.gridy = 0;
					gc.fill = GridBagConstraints.BOTH;
					gc.insets = new Insets(50,10,10,10);
					containerLeft.add(txtAreaEventList,gc);
				
					JPanel containerRight = new JPanel(new GridBagLayout());
					setPanelSize(containerRight, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, containerHght));
					containerRight.setBackground(Color.WHITE);
						
						int datesoffset = 20;
						
						int conRightWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2;
						
	
						JPanel scheduleDatesContainer = new JPanel(new GridBagLayout());
						setPanelSize(scheduleDatesContainer, new Dimension(conRightWidth, UI_Settings.getSmallPanelHeight()-datesoffset));
						scheduleDatesContainer.setBackground(Color.WHITE);
						
	
						JPanel datesLeft = new JPanel(new GridBagLayout());
						setPanelSize(datesLeft, new Dimension(conRightWidth/3, UI_Settings.getSmallPanelHeight()-datesoffset));
						datesLeft.setBackground(Color.WHITE);
						datesLeft.setBorder(border);
					
						gc.gridx = 0;
						gc.gridy = 0;
						gc.gridheight = 1;
						gc.gridwidth = 1;
						gc.weightx = 0.1;
						gc.weighty = 0.1;
						gc.fill = GridBagConstraints.NONE;
						gc.anchor = GridBagConstraints.WEST;
						gc.insets = new Insets(0,5,0,5);
						datesLeft.add(new JLabel("Customer Name:"), gc);
						
						gc.gridx = 1;
						gc.fill = GridBagConstraints.HORIZONTAL;
						gc.insets = new Insets(0,-5,0,5);
						datesLeft.add(txtStudentName, gc);
	
						JPanel datesRight = new JPanel(new GridBagLayout());
						setPanelSize(datesRight, new Dimension(conRightWidth/3*2, UI_Settings.getSmallPanelHeight()-datesoffset));
						datesRight.setBackground(new Color(246,246,246));
						datesRight.setBorder(border);
					
						gc.gridx = 0;
						gc.gridy = 0;
						gc.weightx = 0.1;
						gc.weighty = 0.1;
						gc.fill = GridBagConstraints.HORIZONTAL;
						gc.anchor = GridBagConstraints.WEST;
						gc.insets = new Insets(0,2,0,20);
						datesRight.add(new JLabel("Preferred Day:"), gc);
						
						gc.gridx = 1;
						gc.weightx = 0.6;
						gc.weighty = 0.6;
						gc.insets = new Insets(0,-20,0,10);
						datesRight.add(txtPrefDay, gc);
	
						gc.gridx = 2;
						gc.weightx = 0.1;
						gc.weighty = 0.1;
						gc.insets = new Insets(0,0,0,15);
						datesRight.add(new JLabel("Recommended Level:"), gc);
						gc.gridx = 3;
						
						gc.weightx = 0.8;
						gc.weighty = 0.8;
						gc.fill = GridBagConstraints.HORIZONTAL;
						gc.insets = new Insets(0,0,0,3);
						datesRight.add(txtRecomDay, gc);
						
				
						gc.gridx = 0;
						gc.gridy = 0;
						gc.fill = GridBagConstraints.HORIZONTAL;
						gc.anchor = GridBagConstraints.WEST;
						gc.insets = new Insets(0,5,5,5);
						container.add(containerLeft, gc);
						
						gc.gridx = 0;
						scheduleDatesContainer.add(datesLeft, gc);
						
						gc.gridx = 1;
						gc.weightx = 1;
						gc.weighty = 1;
						gc.insets = new Insets(0,5,5,10);
						scheduleDatesContainer.add(datesRight, gc);
						
						gc.gridx = 0;
						gc.gridy = 0;
						gc.gridwidth = 2;
						gc.fill = GridBagConstraints.NONE;
						gc.anchor = GridBagConstraints.NORTHWEST;
						gc.insets = new Insets(0,0,0,0);
						containerRight.add(scheduleDatesContainer, gc);
						
						//Add the lower components to containerRight - comments, possible match found, and find another match button//
						
						JPanel comments = new JPanel(new GridBagLayout());
						
						int commentsheight = UI_Settings.getSmallPanelHeight()-(datesoffset+10);
						
						setPanelSize(comments, new Dimension(conRightWidth, UI_Settings.getSmallPanelHeight()-(datesoffset)));
						comments.setBackground(new Color(246,246,246));
						comments.setBorder(border);
						
						gc.gridx = 0;
						gc.gridy = 0;
						gc.gridheight = 1;
						gc.gridwidth = 1;
						gc.weightx = 0.5;
						gc.weighty = 0.5;
						gc.fill = GridBagConstraints.HORIZONTAL;
						gc.anchor = GridBagConstraints.WEST;
						gc.insets = new Insets(5,5,5,5);
						comments.add(new JLabel("Comments:"),gc);
						
						gc.gridx = 1;
						gc.gridy = 0;
						gc.gridheight = 1;
						gc.gridwidth = 1;
						gc.weightx = 1;
						gc.weighty = 1;
						gc.fill = GridBagConstraints.HORIZONTAL;
						gc.anchor = GridBagConstraints.NORTHWEST;
						gc.insets = new Insets(0,-10,0,2);
						comments.add(txtAreaComments, gc);
						
						int firstPanelHeight = UI_Settings.getSmallPanelHeight()-datesoffset;
	
						gc.insets = new Insets(firstPanelHeight,5,0,10);
						gc.gridwidth = 1;
						containerRight.add(comments, gc);
						
						JPanel showdetailsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
						setPanelSize(showdetailsPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getDetailsButtonPanelHeight()-5));
						showdetailsPanel.setBackground(Color.WHITE);
						showdetailsPanel.add(labels[8]);
						
						int detailsButtonOffset = (commentsheight*2)+10;
						
						gc.gridx = 1;
						gc.gridy = 0;
						gc.gridheight = 1;
						gc.gridwidth = 1;
						gc.weightx = 1;
						gc.weighty = 1;
						gc.fill = GridBagConstraints.HORIZONTAL;
						gc.anchor = GridBagConstraints.NORTHWEST;
						gc.insets = new Insets(detailsButtonOffset+5,0,0,0);
						containerRight.add(showdetailsPanel, gc);
						
						
						////////////////////////////////////////////////////Add the group details panel////////////////////////////////////////////////////
						
						int topFrameHeight = 210;
						int centerTopHeight = 50;
	
	
						
						JPanel pnlCenterBottomRight = new JPanel(new GridBagLayout());
						
						setPanelSize(pnlCenterBottomRight, new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), topFrameHeight));
						pnlCenterBottomRight.setBackground(Color.WHITE);
						
								JPanel groupDetailsInfoTopButtons = new JPanel(new GridBagLayout());
								groupDetailsInfoTopButtons.setBackground(UI_Settings.getButtonPanelColor());
								setPanelSize(groupDetailsInfoTopButtons, new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
								
								groupDetailsInfoTopButtons.setBackground(Color.WHITE);
	
									JPanel lft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10,15));
									
									setPanelSize(lft, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getDetailsButtonPanelHeight()));
									
									lft.setBackground(Color.WHITE);
									lft.add(new JLabel("Possible Match Found:"));
									
									JPanel rght = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10,15));
									
									setPanelSize(rght, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getDetailsButtonPanelHeight()));
									rght.setBackground(Color.WHITE);
									rght.add(labels[9]);
									
								gc.gridx = 0;
								gc.gridy = 0;
								gc.gridheight = 1;
								gc.gridwidth = 1;
								gc.weightx = 1;
								gc.weighty = 1;
								gc.fill = GridBagConstraints.NONE;
								gc.anchor = GridBagConstraints.NORTHWEST;
								gc.insets = new Insets(0,0,0,0);	
	
								groupDetailsInfoTopButtons.add(lft, gc);	
								
								gc.gridx = 2;
								gc.gridy = 0;
								gc.gridheight = 1;
								gc.gridwidth = 1;
								gc.weightx = 1;
								gc.weighty = 1;
								gc.fill = GridBagConstraints.NONE;
								gc.anchor = GridBagConstraints.NORTHWEST;
								gc.insets = new Insets(0,0,0,0);	
								groupDetailsInfoTopButtons.add(rght, gc);	
	
	
								//Add the contents of the bottom panel, the group details
								//Add the group details (pnlBottomGroupDetails)
								JPanel pnlBottomGroupDetails = new JPanel(new GridBagLayout());
								
								setPanelSize(pnlBottomGroupDetails, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
								
								pnlBottomGroupDetails.setBackground(new Color(246,246,246));
								pnlBottomGroupDetails.setBorder(border);
								gc.gridx = 0;
								gc.gridy = 0;
								gc.gridwidth = 1;
								gc.gridheight = 1;
								gc.weightx = 0.5;
								gc.weighty = 0.5;
								gc.fill = GridBagConstraints.HORIZONTAL;
								gc.anchor = GridBagConstraints.NORTHWEST;
								gc.insets = new Insets(20,10,0,0);
								pnlBottomGroupDetails.add(new JLabel("Group Name:"),gc);
								gc.gridx = 0;
								gc.gridy = 1;
								gc.insets = new Insets(0,10,0,0);
								pnlBottomGroupDetails.add(new JLabel("Group ID:"),gc);
								gc.gridx = 0;
								gc.gridy = 2;
								gc.insets = new Insets(0,10,0,0);
								pnlBottomGroupDetails.add(new JLabel("Positions Available:"),gc);
								gc.gridx = 0;
								gc.gridy = 3;
								gc.insets = new Insets(0,10,0,0);
								pnlBottomGroupDetails.add(new JLabel("Group Level:"),gc);
								gc.gridx = 1;
								gc.gridy = 0;
								gc.insets = new Insets(15,10,0,0);
								pnlBottomGroupDetails.add(txtGroupName,gc);
								gc.gridx = 1;
								gc.gridy = 1;
								gc.insets = new Insets(0,10,0,0);
								pnlBottomGroupDetails.add(txtGroupID,gc);
								gc.gridx = 1;
								gc.gridy = 2;
								gc.insets = new Insets(0,10,0,0);
								pnlBottomGroupDetails.add(txtGroupPos,gc);
								gc.gridx = 1;
								gc.gridy = 3;
								gc.insets = new Insets(0,10,0,0);
								pnlBottomGroupDetails.add(txtGroupLev,gc);
								gc.gridx = 2;
								gc.gridy = 0;
								gc.insets = new Insets(20,10,0,0);
								pnlBottomGroupDetails.add(new JLabel("Group Day:"),gc);
								gc.gridx = 2;
								gc.gridy = 1;
								gc.insets = new Insets(0,10,0,0);
								pnlBottomGroupDetails.add(new JLabel("Group Time:"),gc);
								gc.gridx = 2;
								gc.gridy = 2;
								gc.insets = new Insets(0,10,0,0);
								pnlBottomGroupDetails.add(new JLabel("Max Class #:"),gc);
								gc.gridx = 2;
								gc.gridy = 3;
								gc.insets = new Insets(0,10,0,0);
								pnlBottomGroupDetails.add(new JLabel("Material:"),gc);
								gc.gridx = 3;
								gc.gridy = 0;
								gc.insets = new Insets(15,10,0,0);
								pnlBottomGroupDetails.add(txtGroupDay,gc);
								gc.gridx = 3;
								gc.gridy = 1;
								gc.insets = new Insets(0,10,0,0);
								pnlBottomGroupDetails.add(txtGroupTime,gc);
								gc.gridx = 3;
								gc.gridy = 2;
								gc.insets = new Insets(0,10,0,0);
								pnlBottomGroupDetails.add(txtGroupMax,gc);
								gc.gridx = 3;
								gc.gridy = 3;
								gc.insets = new Insets(0,10,0,0);
								pnlBottomGroupDetails.add(txtGroupMat,gc);
								
								
							gc.gridx = 0;
							gc.gridy = 1;
							gc.gridheight = 1;
							gc.gridwidth = 1;
							gc.weightx = 1;
							gc.weighty = 1;
							gc.fill = GridBagConstraints.HORIZONTAL;
							gc.anchor = GridBagConstraints.SOUTHWEST;
							gc.insets = new Insets(10,0,1,0);
							pnlCenterBottomRight.add(groupDetailsInfoTopButtons, gc);		
						
								
						gc.gridx = 0;
						gc.gridy = 2;
						gc.gridheight = 1;
						gc.weightx = 0.2;
						gc.weighty = 0.2;
						gc.fill = GridBagConstraints.HORIZONTAL;
						gc.anchor = GridBagConstraints.SOUTHWEST;
						gc.insets = new Insets(0,0,0,0);
						pnlCenterBottomRight.add(pnlBottomGroupDetails, gc);
						
						gc.gridx = 1;
						gc.gridy = 0;
						gc.gridheight = 1;
						gc.gridwidth = 1;
						gc.weightx = 1;
						gc.weighty = 1;
						gc.fill = GridBagConstraints.HORIZONTAL;
						gc.anchor = GridBagConstraints.SOUTHWEST;
						gc.insets = new Insets(detailsButtonOffset,5,0,10);
						containerRight.add(pnlCenterBottomRight, gc);
						
	
	
			gc.gridx = 0;
			gc.gridy = 0;
			gc.weightx = 0.4;
			gc.weighty = 0.4;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,2,0,2);
			container.add(containerLeft,gc);
			
			gc.gridx = 1;
			gc.gridy = 0;
			gc.weightx = 1;
			gc.weighty = 1;
			container.add(containerRight,gc);
			
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			/******************************************Generate request panel***************************************/
			
			JPanel trainingRequestsSavedPanel = new JPanel();
			trainingRequestsSavedPanel.setBackground(Color.WHITE);
			trainingRequestsSavedPanel.setLayout(new BoxLayout(trainingRequestsSavedPanel, BoxLayout.X_AXIS));
			
			trainingRequestsSavedPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
			trainingRequestsSavedPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
			trainingRequestsSavedPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
	
			
			JPanel pnlGenLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
			pnlGenLeft.setBackground(Color.WHITE);
			pnlGenLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3*2, UI_Settings.getTableButtonsPanelHeight()));
			pnlGenLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getTableButtonsPanelHeight()));
			pnlGenLeft.add(new JLabel("Request made for: "));
			pnlGenLeft.add(cmbRequestBy);
			pnlGenLeft.add(labels[7]);
	
			
			JPanel pnlGenRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
			pnlGenRight.setBackground(Color.WHITE);
			pnlGenRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
			pnlGenRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
			pnlGenRight.add(chkMatchRequest);
			pnlGenRight.add(chkDeleteCustomer);
	
			
			pnlGenLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
			trainingRequestsSavedPanel.add(pnlGenLeft);
			
			pnlGenRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
			trainingRequestsSavedPanel.add(pnlGenRight);
			
			/*******************************************Message panel*************************************************************/
			//Begin Nested Details Panels (lowest panel on screen)
			JPanel pnlInformation = new JPanel();
			pnlInformation.setBackground(Color.WHITE);
			pnlInformation.setLayout(new GridBagLayout());
			
			setPanelSize(pnlInformation, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
			
	
				//Create the far left container for the group details information
				JPanel pnlMessageContainer = new JPanel(new GridBagLayout());
				pnlMessageContainer.setBackground(Color.WHITE);
				
				setPanelSize(pnlMessageContainer, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-20));
				
				//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,0);
				
					//Add the nested panels to the container panel (information panel)
				
					JPanel pnlMessageArea = new JPanel(new GridBagLayout());
					pnlMessageArea.setBackground(Color.WHITE);
					Border informationBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
					//pnlMessageArea.setBorder(informationBorder);
					
					setPanelSize(pnlMessageArea, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-20));
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.weightx = 0.1;
					gc.weighty = 0.1;
					gc.fill = GridBagConstraints.BOTH;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,0,0,0);
					
					pnlMessageArea.add(txtAreaEmail, gc);
					
						int offset = 10;
					
						JPanel messageButtons = new JPanel();
						messageButtons.setBackground(UI_Settings.getButtonPanelColor());
						messageButtons.setLayout(new BoxLayout(messageButtons, BoxLayout.X_AXIS));
						
						setPanelSize(messageButtons, new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-offset));
						
						JPanel messageText = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 10));
						messageText.setBackground(Color.WHITE);
						messageText.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
						messageText.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
						messageText.add(new JLabel("Match Alert Requests are automatically saved"));
						
						JPanel editButton = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
						editButton.setBackground(Color.WHITE);
						editButton.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
						editButton.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
						editButton.add(labels[2]);
		
						
						messageText.setAlignmentX(Component.LEFT_ALIGNMENT);
						messageButtons.add(messageText);
						
						editButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
						messageButtons.add(editButton);
						
					gc.gridx = 0;
					gc.gridy = 1;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 0.1;
					gc.weighty = 0.1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(-10,0,0,0);
					
					pnlMessageArea.add(messageButtons, gc);
					
					/////////////////////////////////////////
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,5,17,5);
				
					pnlMessageContainer.add(pnlMessageArea, gc);
					
			
			pnlInformation.add(pnlMessageContainer, gc);
			
			/////////////////////////////////////////
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(0,5,0,5);
		
			pnlMessageContainer.add(pnlMessageArea, gc);
			//////////////////////////////////////////Main Column 3 ///////////////////////////////////////////
			JPanel pnlButtons = new JPanel(new GridBagLayout());
			pnlButtons.setBackground(Color.WHITE);
			
			setPanelSize(pnlButtons, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3+10, UI_Settings.getRegularPanelHeight()));
			
				JPanel pnlPassword = new JPanel(new GridBagLayout());
				pnlPassword.setBackground(new Color(246,246,246));
				pnlPassword.setBorder(informationBorder);
				
				setPanelSize(pnlPassword, new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)+10, UI_Settings.getRegularPanelHeight()-50));
				
				btnDeleteEvent.addMouseListener(new MouseAdapter(){
					public void mouseReleased(MouseEvent e){
	
						
						
						
						
						
						SentryModule module = new SentryModule();
						
				           char[] input = passwordField.getPassword();
				            if (module.takeInput(input)) {
				                JOptionPane.showMessageDialog(controllingFrame,
				                    "Welcome administrator. The office time request has been sent.");
				            } else {
				                JOptionPane.showMessageDialog(controllingFrame,
				                    "To send an office time request please enter the correct password.",
				                    "Error Message",
				                    JOptionPane.ERROR_MESSAGE);
				            }
		
				            //Zero out the possible password, for security.
				            Arrays.fill(input, '0');
		
				            passwordField.selectAll();
						
					}
				});
				
				labels[4].setCursor(UI_Settings.getJlabelCursor());
				labels[4].addMouseListener(new MouseAdapter(){
					public void mouseClicked(MouseEvent e){
						
						JOptionPane.showMessageDialog(controllingFrame,
				                "The administrator password can be found with the \"Kids Coordinator\"\n"
				              + "or by contacting your \"Branch Manager\".");
						
					}
				});
				JPanel adminPanel = new JPanel(new GridBagLayout());
				adminPanel.setBackground(Color.WHITE);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				
				adminPanel.add(new JLabel("Administrator password:"), gc);
				
				gc.gridx = 1;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,0);
				
				adminPanel.add(passwordField, gc);
				
				gc.gridx = 2;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.2;
				gc.weighty = 0.2;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,5);
				adminPanel.add(labels[4], gc);
				
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTH;
				gc.insets = new Insets(15,0,0,0);
				
				pnlPassword.add(adminPanel, gc);
				
	
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(-5,5,10,0);
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHEAST;
				pnlPassword.add(btnDeleteEvent, gc);//Send request button
				
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.anchor = GridBagConstraints.NORTH;
				gc.insets = new Insets(0,0,0,0);
				
				pnlButtons.add(pnlPassword, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.anchor = GridBagConstraints.NORTHEAST;
				gc.insets = new Insets(-15,0,0,5);
				
				
				pnlButtons.add(new JLabel("This action cannot be undone"), gc);
			
			gc.gridx = 2;
			gc.gridy = 0;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,0,10);
			
			//Add the nested panels to the container panel (information panel)
			pnlInformation.add(pnlButtons, gc);
					
			/******************************************************Create the Table Data Panel*******************************************/
			centerPanel = new JPanel();
			centerPanel.setBackground(UI_Settings.getButtonPanelColor());
	        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
	        
	        detailsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	        centerPanel.add(detailsPanel);
	
	        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	        centerPanel.add(buttonPanel);
	        
	        container.setAlignmentY(Component.LEFT_ALIGNMENT);
	        centerPanel.add(container);
	        
	        trainingRequestsSavedPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	        centerPanel.add(trainingRequestsSavedPanel);
	        
	        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
	        centerPanel.add(pnlInformation);
	        
	        
			/*********************************************************************************************************************************/
	    	/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
			canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 700));
			canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 700));
	
			//Add the details section and table sections to the canvas.
			canvas.add(detailsPanel, BorderLayout.NORTH);
			canvas.add(centerPanel, BorderLayout.CENTER);
		
			
			//Create the scroll-bar, add the canvas to it and return the scroll-bar.
			JScrollPane scroller = new JScrollPane(canvas);
			//Change the width of the scroll-bar
			scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
			scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
			//Change the visibility of the scroll-bar
			scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			scroller.setBorder(BorderFactory.createEmptyBorder());
			
			scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
	
			return scroller;
		} //END possible Classes

	

	public Component addWaiting()
	{
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		JPanel trainingRequestsSavedPanel;
		JPanel pnlGenLeft;
		JPanel pnlGenRight;
		JPanel pnlButtons;
		JPanel pnlPassword;
		
		JButton btnAddWaitingCustomer = new JButton("Add Waiting Customer");
		btnAddWaitingCustomer.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnAddWaitingCustomer.setFont(UI_Settings.getComponentInputFontSize());

		/***********************Initialize Fields******************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		
        passwordField2 = new JPasswordField(10);
        passwordField2.setActionCommand(UI_Settings.getOk());
	
		failedMessage.setVisible(false);
		
		JLabel[] labels = new JLabel[3];
		
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("delete customer waiting");
		labels[2] = new JLabel("hint");
	
		for(int i = 0; i < 3; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
	
		JButton btnSave = new JButton("Save");
		btnSave.setPreferredSize(UI_Settings.getJbuttonSize());
		btnSave.setFont(UI_Settings.getComponentInputFontSize());
		
		/******************************************************Create TextFields*************************************************************/
		JTextField txtFirstName = new JTextField(10);
		JTextField txtLastName = new JTextField(10);
		
		JTextField txtWaitingID = new JTextField(10);
		JTextField dateTextField = new JTextField(10);
		
		txtFirstName.setEnabled(true);
		txtFirstName.setMinimumSize(txtFirstName.getPreferredSize());
		txtFirstName.setHorizontalAlignment(JTextField.CENTER);
		//textPrompt = new TextPrompt("<first name>", txtFirstName);

		txtLastName.setEnabled(true);
		txtLastName.setMinimumSize(txtLastName.getPreferredSize());
		txtLastName.setHorizontalAlignment(JTextField.CENTER);
		//textPrompt = new TextPrompt("<last name>", txtLastName);
		
		Border border = BorderFactory.createLineBorder(new Color(224,224,224));
		/******************************************************Create TextAreas*************************************************************/
	
		
		JTextArea txtAreaComments = new JTextArea(4, 33);
		txtAreaComments.setMinimumSize(txtAreaComments.getPreferredSize());
		txtAreaComments.setEditable(true);
		txtAreaComments.setBorder(border);
		txtAreaComments.setWrapStyleWord(true);
		txtAreaComments.setLineWrap(true);
		txtAreaComments.setDocument(new JTextFieldLimit(150));

		
		/****************************************************Create ComboBoxes**************************************************************/
		JComboBox cmbAge = new JComboBox(UI_Settings.getStudentAge());
		JComboBox cmbPrefDay1 = new JComboBox(UI_Settings.getDays());
		JComboBox cmbRecommendLvl = new JComboBox(UI_Settings.getBooks());
		JComboBox cmbUpperLvl = new JComboBox(UI_Settings.getBooks());
		
		
		
		JComboBox cmbMonth1 = new JComboBox(UI_Settings.getMonths());
		JComboBox cmbMonth2 = new JComboBox(UI_Settings.getMonths());
		JComboBox cmbDate1 = new JComboBox(UI_Settings.getDates());
		JComboBox cmbDate2 = new JComboBox(UI_Settings.getDates());

		
		cmbAge.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		cmbAge.setFont(UI_Settings.getComponentInputFontSize());
		cmbAge.setMinimumSize(cmbAge.getPreferredSize());
		//AutoCompletion.enable(cmbAge, 120, UI_Settings.getComboBoxHeight());
	
		cmbPrefDay1.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		cmbPrefDay1.setFont(UI_Settings.getComponentInputFontSize());
		cmbPrefDay1.setMinimumSize(cmbPrefDay1.getPreferredSize());
		//AutoCompletion.enable(cmbPrefDay1, 120, UI_Settings.getComboBoxHeight());
	
		cmbRecommendLvl.setFont(UI_Settings.getComponentInputFontSize());
		cmbRecommendLvl.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		cmbRecommendLvl.setMinimumSize(cmbRecommendLvl.getPreferredSize());
		//AutoCompletion.enable(cmbRecommendLvl, 120, UI_Settings.getComboBoxHeight());
		
		cmbUpperLvl.setFont(UI_Settings.getComponentInputFontSize());
		cmbUpperLvl.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		cmbUpperLvl.setMinimumSize(cmbUpperLvl.getPreferredSize());
		//AutoCompletion.enable(cmbUpperLvl, 120, UI_Settings.getComboBoxHeight());
		
		/***********************************************************************************************************************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		GridBagConstraints gc = new GridBagConstraints();
		
		int offset = 25;

		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+offset*2));
		detailsPanel.setLayout(new GridBagLayout());
		
			JPanel leftTopPanel = new JPanel(new GridBagLayout());
			setPanelSize(leftTopPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()));
			leftTopPanel.setBackground(Color.WHITE);
			
			
			JPanel custInfo = new JPanel(new GridBagLayout());
			setPanelSize(custInfo, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getSmallPanelHeight()-offset));
			custInfo.setBorder(border);
			custInfo.setBackground(new Color(246,246,246));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				custInfo.add(new JLabel("First Name:"),gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.insets = new Insets(0,0,0,0);
				custInfo.add(txtFirstName,gc);
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.insets = new Insets(0,10,0,0);
				custInfo.add(new JLabel("Last Name:"),gc);
				
				gc.gridx = 3;
				gc.gridy = 0;
				custInfo.add(txtLastName,gc);
				
				gc.gridx = 4;
				gc.gridy = 0;
				gc.insets = new Insets(0,10,0,0);
				custInfo.add(new JLabel("Preferred Day 1:"),gc);
				
				gc.gridx = 5;
				gc.gridy = 0;
				gc.insets = new Insets(0,0,0,5);
				custInfo.add(cmbPrefDay1,gc);
			
			
			JPanel waitLeft = new JPanel(new GridBagLayout());
			setPanelSize(waitLeft, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()-offset));
			waitLeft.setBorder(border);
			waitLeft.setBackground(Color.WHITE);
			
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				waitLeft.add(new JLabel("Waiting From:"),gc);
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,0);
				waitLeft.add(cmbMonth1,gc);
				
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(0,0,0,0);
				waitLeft.add(cmbDate1,gc);
				
			
			JPanel waitRight = new JPanel(new GridBagLayout());
			setPanelSize(waitRight, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()-offset));
			waitRight.setBorder(border);
			waitRight.setBackground(Color.WHITE);
			
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				waitRight.add(new JLabel("Waiting Until:"),gc);
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,0);
				waitRight.add(cmbMonth2,gc);
				
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(0,0,0,0);
				waitRight.add(cmbDate2,gc);

			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 2;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,0,0);
			
			leftTopPanel.add(custInfo, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,0,0,5);
			leftTopPanel.add(waitLeft, gc);
			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,0,0,5);
			leftTopPanel.add(waitRight, gc);
			
			
			
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(10,5,5,5);
		detailsPanel.add(leftTopPanel, gc);
		
		
		
		JPanel rightTopPanel = new JPanel(new GridBagLayout());
		setPanelSize(rightTopPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
		rightTopPanel.setBackground(Color.WHITE);
		
				JPanel resetPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10,12));
				setPanelSize(resetPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getDetailsButtonPanelHeight()));
				resetPanel.setBackground(Color.WHITE);
				resetPanel.add(labels[0]);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.SOUTHWEST;
				gc.insets = new Insets(40,10,0,0);
				rightTopPanel.add(resetPanel,gc);
		
			JPanel materialPanel = new JPanel(new GridBagLayout());
			setPanelSize(materialPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()-offset));
			materialPanel.setBorder(border);
			materialPanel.setBackground(Color.WHITE);
			
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				materialPanel.add(new JLabel("Upper Level:"),gc);
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,20);
				materialPanel.add(cmbUpperLvl,gc);
			
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.SOUTHWEST;
			gc.insets = new Insets(-8,0,8,0);
			rightTopPanel.add(materialPanel, gc);
		
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(5,5,5,10);
		detailsPanel.add(rightTopPanel, gc);
		/***********************************************************************************************************************************/
		////////////Add the text under the customer name panel//////////
		JPanel studentInfoTxt = new JPanel();
		studentInfoTxt.setBackground(UI_Settings.getButtonPanelColor());
		studentInfoTxt.setLayout(new BoxLayout(studentInfoTxt, BoxLayout.X_AXIS));
		studentInfoTxt.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-10));
		studentInfoTxt.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-10));
		studentInfoTxt.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-10));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 5));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
		rightPanel.setBackground(Color.WHITE);
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(new JLabel("Customers waiting for more than 29 days will be automatically removed from the system"));
		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		studentInfoTxt.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		studentInfoTxt.add(rightPanel);
		/***********************************************************************************************************************************/
		///////////////Add the comments panel/////////////////
		JPanel commentsPanel = new JPanel(new GridBagLayout());
		setPanelSize(commentsPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		commentsPanel.setBackground(Color.WHITE);
		
			JPanel comments = new JPanel(new GridBagLayout());
			setPanelSize(comments, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getSmallPanelHeight()-offset));
			comments.setBackground(new Color(246,246,246));
			comments.setBorder(border);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				comments.add(new JLabel("Comments:"), gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(10,10,10,10);
				comments.add(txtAreaComments, gc);
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				comments.add(new JLabel("Age:"), gc);
				
				gc.gridx = 3;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,5);
				comments.add(cmbAge, gc);
		
		
		
			JPanel recLvl = new JPanel(new GridBagLayout());
			setPanelSize(recLvl, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()-offset));
			recLvl.setBackground(Color.WHITE);
			recLvl.setBorder(border);
			
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				recLvl.add(new JLabel("Recommended Level:"),gc);
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,20);
				recLvl.add(cmbRecommendLvl,gc);
		
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,5,5,5);
			commentsPanel.add(comments, gc);
			
			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,5,5,10);
			commentsPanel.add(recLvl, gc);
		
			/***********************************************************************************************************************************/
			//Add the password panel
			
			trainingRequestsSavedPanel = new JPanel();
			trainingRequestsSavedPanel.setBackground(UI_Settings.getButtonPanelColor());
			trainingRequestsSavedPanel.setLayout(new BoxLayout(trainingRequestsSavedPanel, BoxLayout.X_AXIS));
			trainingRequestsSavedPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
			trainingRequestsSavedPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
			trainingRequestsSavedPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

			pnlGenLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10,10));
			pnlGenLeft.setBackground(Color.WHITE);
			pnlGenLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			pnlGenLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			//pnlGenLeft.add(new JLabel("something goes here"));
			
			pnlGenRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10,10));
			pnlGenRight.setBackground(Color.WHITE);
			pnlGenRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			pnlGenRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			//pnlGenRight.add(new JLabel("and here"));
			
			pnlGenLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
			trainingRequestsSavedPanel.add(pnlGenLeft);
			
			pnlGenRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
			trainingRequestsSavedPanel.add(pnlGenRight);
			
			/*******************************************Message panel*************************************************************/
			//Begin Nested Details Panels (lowest panel on screen)
			JPanel pnlInformation = new JPanel();
			pnlInformation.setBackground(Color.WHITE);
			pnlInformation.setLayout(new GridBagLayout());
			
			setPanelSize(pnlInformation, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
			
	
				//Create the far left container for the group details information
				JPanel pnlMessageContainer = new JPanel(new GridBagLayout());
				pnlMessageContainer.setBackground(Color.WHITE);
				
				setPanelSize(pnlMessageContainer, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-20));
				
				//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,0);
				
					//Add the nested panels to the container panel (information panel)
				
					JPanel pnlMessageArea = new JPanel(new GridBagLayout());
					pnlMessageArea.setBackground(Color.WHITE);
					Border informationBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
					//pnlMessageArea.setBorder(informationBorder);
					
					setPanelSize(pnlMessageArea, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-20));
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.weightx = 0.1;
					gc.weighty = 0.1;
					gc.fill = GridBagConstraints.BOTH;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,0,0,0);
					
					//pnlMessageArea.add(txtAreaEmail, gc);
					
						int offset2 = 10;
					
						JPanel messageButtons = new JPanel();
						messageButtons.setBackground(UI_Settings.getButtonPanelColor());
						messageButtons.setLayout(new BoxLayout(messageButtons, BoxLayout.X_AXIS));
						
						setPanelSize(messageButtons, new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-offset2));
						
						JPanel messageText = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 10));
						messageText.setBackground(Color.WHITE);
						messageText.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
						messageText.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
						//messageText.add(new JLabel("Match Alert Requests are automatically saved"));
						
						JPanel editButton = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
						editButton.setBackground(Color.WHITE);
						editButton.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
						editButton.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
						editButton.add(labels[2]);
		
						
						messageText.setAlignmentX(Component.LEFT_ALIGNMENT);
						messageButtons.add(messageText);
						
						editButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
						messageButtons.add(editButton);
						
					gc.gridx = 0;
					gc.gridy = 1;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 0.1;
					gc.weighty = 0.1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(-10,0,0,0);
					
					pnlMessageArea.add(messageButtons, gc);
					
					/////////////////////////////////////////
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,5,17,5);
				
					pnlMessageContainer.add(pnlMessageArea, gc);
					
			
			pnlInformation.add(pnlMessageContainer, gc);
			
			/////////////////////////////////////////
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(0,5,0,5);
		
			pnlMessageContainer.add(pnlMessageArea, gc);
			//////////////////////////////////////////Main Column 3 ///////////////////////////////////////////
			JPanel pnlButtons2 = new JPanel(new GridBagLayout());
			pnlButtons2.setBackground(Color.WHITE);
			
			setPanelSize(pnlButtons2, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3+10, UI_Settings.getRegularPanelHeight()));
			
				JPanel pnlPassword2 = new JPanel(new GridBagLayout());
				pnlPassword2.setBackground(new Color(246,246,246));
				pnlPassword2.setBorder(informationBorder);
				
				setPanelSize(pnlPassword2, new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)+10, UI_Settings.getRegularPanelHeight()-50));
				
				btnAddWaitingCustomer.addMouseListener(new MouseAdapter(){
					public void mouseReleased(MouseEvent e){
	
						
						
						
						
						
						SentryModule module = new SentryModule();
						
				           char[] input = passwordField2.getPassword();
				            if (module.takeInput(input)) {
				                JOptionPane.showMessageDialog(controllingFrame,
				                    "Welcome administrator. The office time request has been sent.");
				            } else {
				                JOptionPane.showMessageDialog(controllingFrame,
				                    "To send an office time request please enter the correct password.",
				                    "Error Message",
				                    JOptionPane.ERROR_MESSAGE);
				            }
		
				            //Zero out the possible password, for security.
				            Arrays.fill(input, '0');
		
				            passwordField2.selectAll();
						
					}
				});
				
				labels[2].setCursor(UI_Settings.getJlabelCursor());
				labels[2].addMouseListener(new MouseAdapter(){
					public void mouseClicked(MouseEvent e){
						
						JOptionPane.showMessageDialog(controllingFrame,
				                "The administrator password can be found with the \"Kids Coordinator\"\n"
				              + "or by contacting your \"Branch Manager\".");
						
					}
				});
				JPanel adminPanel = new JPanel(new GridBagLayout());
				adminPanel.setBackground(Color.WHITE);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				
				adminPanel.add(new JLabel("Administrator password:"), gc);
				
				gc.gridx = 1;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,0);
				
				adminPanel.add(passwordField2, gc);
				
				gc.gridx = 2;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.2;
				gc.weighty = 0.2;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,5);
				adminPanel.add(labels[2], gc);
				
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTH;
				gc.insets = new Insets(15,0,0,0);
				
				pnlPassword2.add(adminPanel, gc);
				
	
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(-5,5,10,0);
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHEAST;
				pnlPassword2.add(btnAddWaitingCustomer, gc);//Add waiting customer button
				
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.anchor = GridBagConstraints.NORTH;
				gc.insets = new Insets(0,0,0,0);
				
				pnlButtons2.add(pnlPassword2, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.anchor = GridBagConstraints.NORTHEAST;
				gc.insets = new Insets(-15,0,0,5);
				
				
				pnlButtons2.add(new JLabel("This action cannot be undone"), gc);
			
			gc.gridx = 2;
			gc.gridy = 0;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,0,10);
			
			//Add the nested panels to the container panel (information panel)
			pnlInformation.add(pnlButtons2, gc);
			
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(AdministrativePane.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		   		txtFirstName.setText("");
				txtWaitingID.setText("");
				txtLastName.setText("");
				txtWaitingID.setText("");
				dateTextField.setText("");
				txtAreaComments.setText(""); 
				cmbAge.setSelectedIndex(0);
				cmbPrefDay1.setSelectedIndex(0);
				cmbRecommendLvl.setSelectedIndex(0);
				cmbUpperLvl.setSelectedIndex(0);
				
		       }
			}
		});
	
		/********************************************************Set the Table Objects Sizes**************************************************/
	
		waitingTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*2)));
		waitingTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*2)));
		
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
	    centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
    
	    studentInfoTxt.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(studentInfoTxt);  
	    
	    commentsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(commentsPanel);  
	    
	    waitingTable.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(waitingTable);
	    
	    trainingRequestsSavedPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(trainingRequestsSavedPanel);
	
	    pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(pnlInformation);
	    

		/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 650));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 650));
		
		
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());		
		
		//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
	
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
		
		return scroller;
	}//END addWaiting
	
		
	private void setPanelSize(JPanel container, Dimension dimension) {
		
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
		
	}
}