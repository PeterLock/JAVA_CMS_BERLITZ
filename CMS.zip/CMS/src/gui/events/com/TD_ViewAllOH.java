package gui.events.com;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_ViewAllOH extends AbstractTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int GROUP_NAME = 0;
	public final static int PREFERRED_INSTRUCTOR_1 = 1;
	public final static int PREFERRED_INSTRUCTOR_2 = 2;
	public final static int MATERIAL = 3;
	public final static int SCHEDULED_FROM = 4;
	
	
	public Object[][]values =
		{
				{"Duffy", "Nanny McKenny", "Paul Young", "Timezones 2","2016-12 - 22nd ~ 29th" },
				{"Mickey", "Nanny McKenny", "Renee Jones", "Timeszones 3", "2016-12 - 22nd ~ 29th"},
				{"Pluto", "Renee Jones", "Nanny McKenny", "Timezones 1", "2016-12 - 22nd ~ 29th"},
				{"Carrot", "Renee Jones", "Paul Young", "Reading Explorer 1", "2016-12 - 22nd ~ 29th"},
				{"Pineapple", "Paul Young", "Nanny McKenny", "Reading Explorer 2", "2016-12 - 22nd ~ 29th"},
				{"", "", "", "", "", ""}
		};
	
	public final static String[] COLUMN_NAMES = {"Group Name", "Preferred Instructor 1",
			"Preferred Instructor 2", "Material", "Scheduled From"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	


	public static ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}



	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList(10,15,15,15,15));

}
