package material.gui;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import material.model.Material;

public class MaterialTableModel extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<Material>db;
	
	private String[] colNames = {"Material Name", "Publisher", "Edition", "Levels", "Chapters"};

	@Override
	public int getRowCount() {
		return db.size();
	}

	@Override
	public int getColumnCount() {
		return 5;
	}
	
	@Override
	public String getColumnName(int column) {
		return colNames[column];
	}

	@Override
	public Object getValueAt(int row, int col) {
		
		Material material = db.get(row);
		
		switch(col){
		case 0: 
			return material.getMaterialName();
		case 1:
			return material.getPublisherName();
		case 2:
			return material.getEdition();
		case 3:{
			if(material.getNumLevels() == 0){
				return null;
			}else{
				return material.getNumLevels();
			}
		}
		case 4:
			if(material.getNumChapters() == 0){
				return null;
			}else{
				return material.getNumChapters();
			}
		}
		return null;
	}

	public void setData(List<Material> db) {
		this.db = db;
	}
}
