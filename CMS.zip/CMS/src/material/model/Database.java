package material.model;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import customer.model.Customer;
import group.model.Group;

public class Database {
	
	private JFrame controllingFrame;
	
	private List<Material> material_list = new ArrayList<Material>();
	private List<Material> loaded_material_list = new ArrayList<Material>();
	private int flag = 0;

	private List<Material> addnew_material;
	private List<Material> viewall_material;

	private int setNumberOfRows = 0;
	private int setViewAllRowNumber = 0;
	
	private int setAddMaterialRowNumber = 4;
	private int setViewAllMaterialRowNumber = 0;
	
	private int count = 0;
	private Connection con;
	
	public Database(){
		material_list = new ArrayList<Material>();
		loaded_material_list = new ArrayList<Material>();
	}
	
	public void connect() throws Exception{
		
		if(con != null)return;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new Exception("Driver not found");
		}
		

		String url = "jdbc:mysql://localhost:3306/CMS_DB?autoReconnect=true&useSSL=false";
		
		con = DriverManager.getConnection(url, "root", "password");
		
		//System.out.println("Connected: " + con.getCatalog());
		
	}
	
	public void disconnect(){
		if(con != null){
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println("Can't close the connection");
			}
		}
	}
	
	public void save() throws SQLException{
		
		String checkSql = "select count(*) as count from MaterialList where ID=?";
		PreparedStatement checkStmt = con.prepareStatement(checkSql);
		
		String insertSql = "insert into MaterialList (id, materialName, publisherName, edition, numberLevels, numberChapters, hasReport, hasDVD, hasReader, hasTest, testInformation, comments, description) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement insertStatement = con.prepareStatement(insertSql);
		

		String updateSql = "update MaterialList set materialName=?, publisherName=?, edition=?, numberLevels=?, numberChapters=?, hasReports=?, hasDVD=?, hasReader=?, hasTest=?, testInformation=?, comments=?, description=? where id=?";
		PreparedStatement updateStatement = con.prepareStatement(updateSql);
		
		for(Material material : material_list){
			
			int t = material.getId();
			if(t > 0){
				
				int id = material.getId();
				String materialName = material.getMaterialName();
				String publisherName = material.getPublisherName();
				String edition = material.getEdition();
				int numberLevels = material.getNumLevels();
				int numberChapters = material.getNumChapters();
				String hasReport = material.getHasReport();
				String hasDVD = material.getHasDvd();
				String hasReader = material.getHasReader();
				String hasTest = material.getHasTest();
				String testInformation = material.getTestInformation();
				String comments = material.getMaterialComments();
				String description = material.getMaterialDescription();
				
				checkStmt.setInt(1, id);
				
				ResultSet checkResult = checkStmt.executeQuery();
				checkResult.next();
				
				int count = checkResult.getInt(1);
				
				
				if(count == 0){
					System.out.println("Inserting material with ID " + id);
					
					int col = 1;

					insertStatement.setInt(col++, id);
					insertStatement.setString(col++, materialName);
					insertStatement.setString(col++, publisherName);
					insertStatement.setString(col++, edition);
					insertStatement.setInt(col++, numberLevels);
					insertStatement.setInt(col++, numberChapters);
					insertStatement.setString(col++, hasReport);
					insertStatement.setString(col++, hasDVD);
					insertStatement.setString(col++, hasReader);
					insertStatement.setString(col++, hasTest);
					insertStatement.setString(col++, testInformation);
					insertStatement.setString(col++, comments);
					insertStatement.setString(col++, description);


					insertStatement.executeUpdate();

				}
				else{
					System.out.println("Updating customer with ID " + id);
					
					int col = 1;
					
					updateStatement.setString(col++, materialName);
					updateStatement.setString(col++, publisherName);
					updateStatement.setString(col++, edition);
					updateStatement.setInt(col++, numberLevels);
					updateStatement.setInt(col++, numberChapters);
					updateStatement.setString(col++, hasReport);
					updateStatement.setString(col++, hasDVD);
					updateStatement.setString(col++, hasReader);
					updateStatement.setString(col++, hasTest);
					updateStatement.setString(col++, testInformation);
					updateStatement.setString(col++, comments);
					updateStatement.setString(col++, description);
					
					updateStatement.setInt(col++, id);
					
					updateStatement.executeUpdate();
				}
			}
		}
		updateStatement.close();
		insertStatement.close();
		checkStmt.close();
		
	}
	
	public void load(){
		
	}
	
	public void addNewMaterial(Material material){
		
		if(this.material_list.size()==setNumberOfRows){
			this.material_list.add(0, material);
			this.material_list.remove(this.material_list.get(this.getEmptyMaterial().size()-1));
		}else{
			if(count >setNumberOfRows){
				this.material_list.add(0, material);
			}else{
				this.material_list.add(0, material);
				count++;	
			}
		}
		
		try {
			this.save();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void addEmptyMaterial(Material material){
		
	}
	
	public void printMaterial(){
		
	}
	
	public void saveToFile(File file) throws IOException{
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		Material[] material = this.material_list.toArray(new Material[this.material_list.size()]);
		
		oos.writeObject(material);
		
		fos.close();
		oos.close();
		
	}
	
	public void loadFromFile(File file) throws IOException {
		
	}
	
	public void removeMaterial(int index, int i){
		if(index <0){
			return;
		}else{
			if( i == 1){
				int remove_id = viewall_material.get(index).getId();
				
				viewall_material.remove(index);

				populateRemainingMaterialRows(viewall_material, setViewAllRowNumber);
				
				delete(remove_id);
				
				try {
					this.save();
				} catch (SQLException e) {
					System.err.println("Unable to save database");
				}

			}
			if( i == 2){
				addnew_material.remove(index);
				populateRemainingMaterialRows(addnew_material, setNumberOfRows);			
			}
		}
	}
	
	
	public void populateRemainingMaterialRows(List<Material> data, int j) {
       	for(int i = data.size()+1; i <=j; i++){
       		data.add(new Material("","","",0,0,"","","","","","","",0));
    	}
	}
	
	public void delete(int remove_id){
		
	}
	
	public void setAddNewRowNumber(int i) {
		setNumberOfRows = i;
	}

	public List<Material> getMaterial() {
		return loaded_material_list;
	}
	
	public List<Material> getEmptyMaterial() {
		return material_list;
	}
	
	public void populateRemainingRows(List<Material> data, int j) {
		
       	for(int i = data.size()+1; i <=j; i++){
       		data.add(new Material("", "", "", 0, 0, "", "", "", "", "", "", "", 0));
    	}
	}

	public String getName() {
		return "CIS_DB";
	}
	
	public Material searchMaterial(String materialName){
		return null;
	}
	
	public void deleteMaterial(JComboBox<String> cmbMaterialNameListCombobox, int i, String materialName) {
		
		if(materialName == null || materialName == "" || materialName.isEmpty()){
			return;
		}else{
			 try 
			 {  
				PreparedStatement statement = con.prepareStatement("DELETE FROM Material WHERE name = ?");
				statement.setString(1,materialName);
				statement.executeUpdate(); 
				
				JOptionPane.showMessageDialog(controllingFrame,
					    "Material Deleted",
					    "Deletion complete",
					    JOptionPane.INFORMATION_MESSAGE);	
			 }
			 catch(Exception e)
			 {
					JOptionPane.showMessageDialog(controllingFrame,
						    "Error deleting material",
						    "An error deleting this material has occurred. No information available",
						    JOptionPane.ERROR_MESSAGE);	
			 }
		}
	}

	public void addNewMaterialRowNumber(int rows) {
		setAddMaterialRowNumber = rows;
	}
}
