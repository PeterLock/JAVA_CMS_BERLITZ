package gui.training.com;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DragSourceDragEvent;
import java.awt.dnd.DragSourceMotionListener;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.Box;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.TransferHandler;


public class DragAndDrop extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static int width = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2;
    protected final static int HEIGHT = 600,  WIDTH = width,  PANEL_INSETS = 10;
    private final List<DragAndDropPanel> panels;
    private final RootPanel rootPanel;
    
    private List<String> panelList = new ArrayList<String>();
    

    private static DataFlavor dragAndDropPanelDataFlavor = null;

    public DragAndDrop() throws Exception {

        this.setBackground(Color.WHITE);
        
        this.setPreferredSize(new Dimension(DragAndDrop.WIDTH, DragAndDrop.HEIGHT-100));
        this.setMinimumSize(new Dimension(DragAndDrop.WIDTH, DragAndDrop.HEIGHT-100));
        this.setMaximumSize(new Dimension(DragAndDrop.WIDTH, DragAndDrop.HEIGHT-100));

        this.setLayout(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        
        rootPanel = new RootPanel(DragAndDrop.this);
        rootPanel.setLayout(new GridBagLayout());
        rootPanel.setBackground(Color.WHITE);
        
        
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,5,5,5);
		
        this.add(rootPanel, gc);

        panels = new ArrayList<DragAndDropPanel>();

        DragAndDropPanel panel1 = new DragAndDropPanel(1);
        DragAndDropPanel panel2 = new DragAndDropPanel(2);
        DragAndDropPanel panel3 = new DragAndDropPanel(3);

        getDragAndDropPanels().add(panel1);
        getDragAndDropPanels().add(panel2);     
        getDragAndDropPanels().add(panel3);

        relayout();
    }

    protected void relayout() {

        // Create the constraints, and go ahead and set those
        // that don't change for components
        final GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.weighty = 0.0;
        gbc.fill = GridBagConstraints.NONE;

        int row = 0;

        // Clear out all previously added items
        rootPanel.removeAll();

        // Add the panels, if any
        panelList.clear();
        for (DragAndDropPanel p : getDragAndDropPanels()) {
        	
        	gbc.gridx = 0;
            gbc.gridy = row++;
        	gbc.gridheight = 1;
        	gbc.gridwidth = 1;
        	gbc.weightx = 1;
        	gbc.weighty = 1;
        	gbc.fill = GridBagConstraints.HORIZONTAL;
        	gbc.anchor = GridBagConstraints.NORTHWEST;
        	gbc.insets = new Insets(PANEL_INSETS,PANEL_INSETS,PANEL_INSETS,PANEL_INSETS);
        	
            rootPanel.add(p, gbc);
            System.out.println(p.getComponent(0).getName());
            panelList.add(p.getComponent(0).getName());

        }

        // Add a vertical strut to push content to top.
        gbc.weighty = 1.0;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.gridy = row++;
        Component strut = Box.createVerticalStrut(1);
        rootPanel.add(strut, gbc);
        
        /**
         * Print out the order in which the panels are currently in by name
         */
        System.out.println("\n\nMeanwhile....");
        for(int i = 0; i < panelList.size(); i++){
        	System.out.println("#" + i + " is: " + panelList.get(i));
        }

        this.validate();
        this.repaint();

    }

    /**
     * <p>Returns (creating, if necessary) the DataFlavor representing DragAndDropPanel</p>
     * @return
     */
    public static DataFlavor getDragAndDropPanelDataFlavor() throws Exception {
        // Lazy load/create the flavor
        if (dragAndDropPanelDataFlavor == null) {
            dragAndDropPanelDataFlavor = new DataFlavor(DataFlavor.javaJVMLocalObjectMimeType + ";findClass=RandomDragAndDropPanel");
        }

        return dragAndDropPanelDataFlavor;
    }


    /**
     * <p>Returns the List of user-added panels.</p>
     * <p>Note that for drag and drop, these will be cleared, and the panels will be added back in the correct order!</p>
     * @return
     */
    protected List<DragAndDropPanel> getDragAndDropPanels() {
        return panels;
    }
}


class RootPanel extends JPanel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final DragAndDrop dragandDrop;
    RootPanel(DragAndDrop dragandDrop) {
        super();
        
        // Need to keep reference so can later communicate with drop listener
        this.dragandDrop = dragandDrop;
        
        // Again, needs to negotiate with the draggable object
        this.setTransferHandler(new DragAndDropTransferHandler());
        
        // Create the listener to do the work when dropping on this object!
        this.setDropTarget(new DropTarget(RootPanel.this, new PanelDropTargetListener(RootPanel.this)));
    }

    public DragAndDrop getDragAndDropPanels() {
        return dragandDrop;
    }
}


class DragAndDropPanel extends JPanel implements Transferable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtConceptOne = new JTextField();
	private JTextField txtConceptTwo = new JTextField();
	private JTextField txtConceptThree = new JTextField();
	private JTextField txtConOneThemeOne = new JTextField();
	private JTextField txtConOneThemeTwo = new JTextField();
	private JTextField txtConTwoThemeOne = new JTextField();
	private JTextField txtConTwoThemeTwo = new JTextField();
	private JTextField txtConThreeThemeOne = new JTextField();
	private JTextField txtConThreeThemeTwo = new JTextField();
	
	private List<JTextField> textfieldListConcept1 = new ArrayList<JTextField>();
	private List<JTextField> textfieldListConcept2 = new ArrayList<JTextField>();
	private List<JTextField> textfieldListConcept3 = new ArrayList<JTextField>();
    
	private void intializeTextBoxes() {
		//////////////////////////////////////////////////////
		initializeConceptTextField(txtConceptOne);
		initializeConceptTextField(txtConceptTwo);
		initializeConceptTextField(txtConceptThree);
		
		initializeThemeTextFields(txtConOneThemeOne);
		initializeThemeTextFields(txtConOneThemeTwo);

		initializeThemeTextFields(txtConTwoThemeOne);
		initializeThemeTextFields(txtConTwoThemeTwo);

		initializeThemeTextFields(txtConThreeThemeOne);
		initializeThemeTextFields(txtConThreeThemeTwo);
		//////////////////////////////////////////////////////
		textfieldListConcept1.add(txtConceptOne);
		textfieldListConcept1.add(txtConOneThemeOne);
		textfieldListConcept1.add(txtConOneThemeTwo);
		
		textfieldListConcept2.add(txtConceptTwo);
		textfieldListConcept2.add(txtConTwoThemeOne);
		textfieldListConcept2.add(txtConTwoThemeTwo);
		
		textfieldListConcept3.add(txtConceptThree);
		textfieldListConcept3.add(txtConThreeThemeOne);
		textfieldListConcept3.add(txtConThreeThemeTwo);
		//////////////////////////////////////////////////////
		
	}


    private void initializeConceptTextField(JTextField textfield) {
    		textfield = new JTextField(30);
    		textfield.setMinimumSize(textfield.getPreferredSize());
    		textfield.setHorizontalAlignment(JTextField.CENTER);
	}
    
	private void initializeThemeTextFields(JTextField textfield) {
		textfield = new JTextField(20);
		textfield.setMinimumSize(textfield.getPreferredSize());
		textfield.setHorizontalAlignment(JTextField.CENTER);		
	}


	public DragAndDropPanel(int index) {
		int containerheight = 500/3;
		
		intializeTextBoxes();
    	JPanel topContainer = new JPanel(new GridBagLayout());
    	topContainer.setPreferredSize(new Dimension(DragAndDrop.WIDTH, containerheight));
    	topContainer.setMinimumSize(new Dimension(DragAndDrop.WIDTH, containerheight));
    	topContainer.setMaximumSize(new Dimension(DragAndDrop.WIDTH, containerheight));
    	
    	JPanel middleContainer = new JPanel(new GridBagLayout());
    	middleContainer.setPreferredSize(new Dimension(DragAndDrop.WIDTH, containerheight));
    	middleContainer.setMinimumSize(new Dimension(DragAndDrop.WIDTH, containerheight));
    	middleContainer.setMaximumSize(new Dimension(DragAndDrop.WIDTH, containerheight));
    	
    	JPanel lowerContainer = new JPanel(new GridBagLayout());
    	lowerContainer.setPreferredSize(new Dimension(DragAndDrop.WIDTH, containerheight));
    	lowerContainer.setMinimumSize(new Dimension(DragAndDrop.WIDTH, containerheight));
    	lowerContainer.setMaximumSize(new Dimension(DragAndDrop.WIDTH, containerheight));

    	
        // Add the listener which will export this panel for dragging
        this.addMouseListener(new DraggableMouseListener());
        this.setTransferHandler(new DragAndDropTransferHandler());

        // Style it a bit to set apart from container
        //this.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        this.setPreferredSize(new Dimension(DragAndDrop.WIDTH, containerheight));
        this.setMinimumSize(new Dimension(DragAndDrop.WIDTH, containerheight));
        this.setMaximumSize(new Dimension(DragAndDrop.WIDTH, containerheight));
        
        
        this.setBackground(Color.WHITE);
        this.setLayout(new GridBagLayout());

        GridBagConstraints gc = new GridBagConstraints();
        
        switch(index){
        
        case 1:{
        	topContainer.setName("topContainer");
        	topContainer.setBackground(new Color(231,247,255));
        	topContainer = getInputContentOne(topContainer, gc);
    		gc.gridx = 0;
    		gc.gridy = 0;
    		gc.gridheight = 1;
    		gc.gridwidth = 1;
    		gc.weightx = 0.1;
    		gc.weighty = 0.1;
    		gc.fill = GridBagConstraints.HORIZONTAL;
    		gc.anchor = GridBagConstraints.WEST;
    		gc.insets = new Insets(0,0,0,0);
        	this.add(topContainer,gc);
        	break;
        }
        
        case 2: {
        	middleContainer.setName("middleContainer");
        	middleContainer.setBackground(new Color(254,191,63));
        	middleContainer = getInputContentTwo(middleContainer, gc);

    		gc.gridx = 0;
    		gc.gridy = 0;
    		gc.gridheight = 1;
    		gc.gridwidth = 1;
    		gc.weightx = 0.1;
    		gc.weighty = 0.1;
    		gc.fill = GridBagConstraints.HORIZONTAL;
    		gc.anchor = GridBagConstraints.WEST;
    		gc.insets = new Insets(0,0,0,0);
        	this.add(middleContainer,gc);
            break;
        }
        
        case 3: {
        	lowerContainer.setName("lowerContainer");
        	lowerContainer.setBackground(new Color(217,240,251));
        	lowerContainer = getInputContentThree(lowerContainer, gc);

    		gc.gridx = 0;
    		gc.gridy = 0;
    		gc.gridheight = 1;
    		gc.gridwidth = 1;
    		gc.weightx = 0.1;
    		gc.weighty = 0.1;
    		gc.fill = GridBagConstraints.HORIZONTAL;
    		gc.anchor = GridBagConstraints.WEST;
    		gc.insets = new Insets(0,0,0,0);
        	this.add(lowerContainer,gc);
            break;
        }
        default:break;
        }
    }

    private JPanel getInputContentThree(JPanel container, GridBagConstraints gc) {
    	
    	
		JLabel heading = new JLabel("Moveable:");
		heading.setFont(heading.getFont().deriveFont(11.0f));

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(15,20,0,0);
		container.add(heading, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(10,5,0,100);
		container.add(this.txtConceptThree, gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("Theme 1"),gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("1."),gc);
		
		gc.gridx = 1;
		gc.gridy = 3;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("2."),gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,20,5,100);
		container.add(txtConThreeThemeOne,gc);
		
		gc.gridx = 1;
		gc.gridy = 3;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,20,5,100);
		container.add(txtConThreeThemeTwo,gc);
		
		return container;
	}


	private JPanel getInputContentTwo(JPanel container, GridBagConstraints gc) {
    	
    	JLabel heading = new JLabel("Moveable:");
		heading.setFont(heading.getFont().deriveFont(11.0f));

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(15,20,0,0);
		container.add(heading, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(10,5,0,100);
		container.add(this.txtConceptTwo, gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("Theme 1"),gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("1."),gc);
		
		gc.gridx = 1;
		gc.gridy = 3;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("2."),gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		gc.insets = new Insets(5,20,5,100);
		container.add(txtConTwoThemeOne,gc);
		
		gc.gridx = 1;
		gc.gridy = 3;
		gc.insets = new Insets(5,20,5,100);
		container.add(txtConTwoThemeTwo,gc);
		
		return container;
	}


	private JPanel getInputContentOne(JPanel container, GridBagConstraints gc) {
    	
		JLabel heading = new JLabel("Moveable:");
		heading.setFont(heading.getFont().deriveFont(11.0f));
		
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(15,20,0,0);
		container.add(heading, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(10,5,0,100);
		container.add(this.txtConceptOne, gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("Theme 1"),gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("1."),gc);
		
		gc.gridx = 1;
		gc.gridy = 3;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("2."),gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,20,5,100);
		container.add(txtConOneThemeOne,gc);
		
		gc.gridx = 1;
		gc.gridy = 3;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,20,5,100);
		container.add(txtConOneThemeTwo,gc);
		
		return container;
	}

	/**
     * <p>One of three methods defined by the Transferable interface.</p>
     * <p>If multiple DataFlavor's are supported, can choose what Object to return.</p>
     * <p>In this case, we only support one: the actual JPanel.</p>
     * <p>Note we could easily support more than one. For example, if supports text and drops to a JTextField, could return the label's text or any arbitrary text.</p>
     * @param flavor
     * @return
     */
    public Object getTransferData(DataFlavor flavor) {

        DataFlavor thisFlavor = null;

        try {
            thisFlavor = DragAndDrop.getDragAndDropPanelDataFlavor();
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
            return null;
        }

        // For now, assume wants this class... see loadDnD
        if (thisFlavor != null && flavor.equals(thisFlavor)) {
            return DragAndDropPanel.this;
        }

        return null;
    }

    /**
     * <p>One of three methods defined by the Transferable interface.</p>
     * <p>Returns supported DataFlavor. Again, we're only supporting this actual Object within the JVM.</p>
     * <p>For more information, see the JavaDoc for DataFlavor.</p>
     * @return
     */
    public DataFlavor[] getTransferDataFlavors() {

        DataFlavor[] flavors = {null};
        
        try {
            flavors[0] = DragAndDrop.getDragAndDropPanelDataFlavor();
        } catch (Exception ex) {
            System.err.println("Problem lazy loading: " + ex.getMessage());
            ex.printStackTrace(System.err);
            return null;
        }

        return flavors;
    }

    /**
     * <p>One of three methods defined by the Transferable interface.</p>
     * <p>Determines whether this object supports the DataFlavor. In this case, only one is supported: for this object itself.</p>
     * @param flavor
     * @return True if DataFlavor is supported, otherwise false.
     */
    public boolean isDataFlavorSupported(DataFlavor flavor) {

        DataFlavor[] flavors = {null};
        try {
            flavors[0] = DragAndDrop.getDragAndDropPanelDataFlavor();
        } catch (Exception ex) {
            System.err.println("Problem lazy loading: " + ex.getMessage());
            ex.printStackTrace(System.err);
            return false;
        }

        for (DataFlavor f : flavors) {
            if (f.equals(flavor)) {
                return true;
            }
        }

        return false;
    }
} // DragAndDropPanels

/**
 * <p>Listener that make source draggable.</p>
 */
class DraggableMouseListener extends MouseAdapter {

    @Override()
    public void mousePressed(MouseEvent e) {
        JComponent c = (JComponent) e.getSource();
        TransferHandler handler = c.getTransferHandler();
        handler.exportAsDrag(c, e, TransferHandler.COPY);
    }
} // DraggableMouseListener

/**
 * <p>Used by both the draggable class and the target for negotiating data.</p>
 * <p>Note that this should be set for both the draggable object and the drop target.</p>
 */
class DragAndDropTransferHandler extends TransferHandler implements DragSourceMotionListener {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DragAndDropTransferHandler() {
        super();
    }

    /**
     * <p>This creates the Transferable object. In our case, DragAndDropPanel implements Transferable, so this requires only a type cast.</p>
     * @param c
     * @return
     */
    @Override()
    public Transferable createTransferable(JComponent c) {

        // TaskInstancePanel implements Transferable
        if (c instanceof DragAndDropPanel) {
            Transferable tip = (DragAndDropPanel) c;
            return tip;
        }

        // Not found
        return null;
    }

    public void dragMouseMoved(DragSourceDragEvent dsde) {}

    /**
     * <p>This is queried to see whether the component can be copied, moved, both or neither. We are only concerned with copying.</p>
     * @param c
     * @return
     */
    @Override()
    public int getSourceActions(JComponent c) {
        
        if (c instanceof DragAndDropPanel) {
            return TransferHandler.COPY;
        }
        
        return TransferHandler.NONE;
    }
} // DragAndDropTransferHandler

/**
 * <p>Listens for drops and performs the updates.</p>
 * <p>The real magic behind the drop!</p>
 */
class PanelDropTargetListener implements DropTargetListener {

    private final RootPanel rootPanel;
    
    /**
     * <p>Two cursors with which we are primarily interested while dragging:</p>
     * <ul>
     *   <li>Cursor for droppable condition</li>
     *   <li>Cursor for non-droppable consition</li>
     * </ul>
     * <p>After drop, we manually change the cursor back to default, though does this anyhow -- just to be complete.</p>
     */
    private static final Cursor droppableCursor = Cursor.getPredefinedCursor(Cursor.HAND_CURSOR),
            notDroppableCursor = Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR);

    public PanelDropTargetListener(RootPanel sheet) {
        this.rootPanel = sheet;
    }

    // Could easily find uses for these, like cursor changes, etc.
    public void dragEnter(DropTargetDragEvent dtde) {}
    public void dragOver(DropTargetDragEvent dtde) {
        if (!this.rootPanel.getCursor().equals(droppableCursor)) {
            this.rootPanel.setCursor(droppableCursor);
        }
    }
    public void dropActionChanged(DropTargetDragEvent dtde) {}
    public void dragExit(DropTargetEvent dte) {
        this.rootPanel.setCursor(notDroppableCursor);
    }

    /**
     * <p>The user drops the item. Performs the drag and drop calculations and layout.</p>
     * @param dtde
     */
    public void drop(DropTargetDropEvent dtde) {
        
        // Done with cursors, dropping
        this.rootPanel.setCursor(Cursor.getDefaultCursor());
        
        // Just going to grab the expected DataFlavor to make sure
        // we know what is being dropped
        DataFlavor dragAndDropPanelFlavor = null;
        
        Object transferableObj = null;
        Transferable transferable = null;
        
        try {
            // Grab expected flavor
            dragAndDropPanelFlavor = DragAndDrop.getDragAndDropPanelDataFlavor();
            
            transferable = dtde.getTransferable();
            
            // What does the Transferable support
            if (transferable.isDataFlavorSupported(dragAndDropPanelFlavor)) {
                transferableObj = dtde.getTransferable().getTransferData(dragAndDropPanelFlavor);
            } 
            
        } catch (Exception ex) { /* nope, not the place */ }
        
        // If didn't find an item, bail
        if (transferableObj == null) {
            return;
        }
        
        // Cast it to the panel. By this point, we have verified it is 
        // a RandomDragAndDropPanel.
        DragAndDropPanel droppedPanel = (DragAndDropPanel)transferableObj;
        
        // Get the y offset from the top of the WorkFlowSheetPanel
        // for the drop option (the cursor on the drop)
        final int dropYLoc = dtde.getLocation().y;

        // We need to map the Y axis values of drop as well as other
        // DragAndDropPanel so can sort by location.
        Map<Integer, DragAndDropPanel> yLocMapForPanels = new HashMap<Integer, DragAndDropPanel>();
        yLocMapForPanels.put(dropYLoc, droppedPanel);

        // Iterate through the existing panels. Going to find their locations.
        for (DragAndDropPanel nextPanel : rootPanel.getDragAndDropPanels().getDragAndDropPanels()) {

            // Grab the y value
            int y = nextPanel.getY();

            // If the dropped panel, skip
            if (!nextPanel.equals(droppedPanel)) {
                yLocMapForPanels.put(y, nextPanel);
            }
        }

        // Grab the Y values and sort them
        List<Integer> sortableYValues = new ArrayList<Integer>();
        sortableYValues.addAll(yLocMapForPanels.keySet());
        Collections.sort(sortableYValues);

        // Put the panels in list in order of appearance
        List<DragAndDropPanel> orderedPanels = new ArrayList<DragAndDropPanel>();
        for (Integer i : sortableYValues) {
            orderedPanels.add(yLocMapForPanels.get(i));
        }
        
        // Grab the in-memory list and re-add panels in order.
        List<DragAndDropPanel> inMemoryPanelList = this.rootPanel.getDragAndDropPanels().getDragAndDropPanels();
        inMemoryPanelList.clear();
        inMemoryPanelList.addAll(orderedPanels);
    
        // Request relayout contents, or else won't update GUI following drop.
        // Will add back in the order to which we just sorted
        this.rootPanel.getDragAndDropPanels().relayout();
    }
} // PanelDropTargetListener