package gui.training.com;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.border.Border;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import settings.UI_Settings;
import utilities.JTextFieldLimit;

public class IntroductionTrainingAidPanel extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private GridBagConstraints gc = new GridBagConstraints();
	private int width;
	private int height;
	private JLabel headerLabel;
	private JLabel keyPointsLabel;
	private JLabel trainingAidToolsLabel;
	
	private String containerFontType = "Courier";
	private int headerHeight = 50;
	
	private JTextArea txtAreaSessionOne;
	private JTextArea txtAreaSessionTwo;
	
	List <JLabel> labels = new ArrayList<JLabel>();
	
	JLabel lblIntroduction = new JLabel("Introduction");
	JLabel lblOutline = new JLabel("Outline Structure");
	JLabel lblBackground = new JLabel("Background Information");
	JLabel session1 = new JLabel("Session notes 1:");
	JLabel session2 = new JLabel("Session notes 2:");

	
	
	private Border border = BorderFactory.createLineBorder(new Color(180,180,180));
	private Color fontcolor = new Color(102,102,102);
	private Color headercolor = new Color(25,120,174);
	
	public IntroductionTrainingAidPanel(int width, int height){
		
		this.width = width/2;
		this.height = height;
		
		initialize();
		
	}

	private void initialize() {
		headerLabel = new JLabel("Introduction");
		headerLabel.setFont(new Font(containerFontType, Font.BOLD, (int)12.0f));
		
		keyPointsLabel = new JLabel("Key Points");
		keyPointsLabel.setFont(new Font(containerFontType, Font.BOLD, (int)12.0f));
		
		trainingAidToolsLabel = new JLabel("Training Aids/Tools");
		trainingAidToolsLabel.setFont(new Font(containerFontType, Font.BOLD, (int)12.0f));
		

		headerLabel.setForeground(Color.WHITE);
		keyPointsLabel.setForeground(Color.WHITE);
		trainingAidToolsLabel.setForeground(Color.WHITE);

		
		labels.add(lblIntroduction);
		labels.add(lblOutline);
		labels.add(lblBackground);
		labels.add(session1);
		labels.add(session2);

		
		for(int i = 0; i < labels.size(); i++){
			labels.get(i).setForeground(fontcolor);
			labels.get(i).setFont(new Font(containerFontType, Font.PLAIN, (int)11.0f));
		}
		
		txtAreaSessionOne = new JTextArea(8, 20);
		txtAreaSessionOne.setEditable(true);
		txtAreaSessionOne.setBorder(UI_Settings.getBorderoutline());
		txtAreaSessionOne.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaSessionOne.setWrapStyleWord(true);
		txtAreaSessionOne.setLineWrap(true);
		txtAreaSessionOne.setDocument(new JTextFieldLimit(80));
		txtAreaSessionOne.setBorder(border);
		txtAreaSessionOne.setPreferredSize(txtAreaSessionOne.getPreferredSize());
		
		txtAreaSessionTwo = new JTextArea(6, 20);
		txtAreaSessionTwo.setEditable(true);
		txtAreaSessionTwo.setBorder(UI_Settings.getBorderoutline());
		txtAreaSessionTwo.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaSessionTwo.setWrapStyleWord(true);
		txtAreaSessionTwo.setLineWrap(true);
		txtAreaSessionTwo.setDocument(new JTextFieldLimit(80));
		txtAreaSessionTwo.setBorder(border);
		txtAreaSessionTwo.setPreferredSize(txtAreaSessionTwo.getPreferredSize());
	}

	public JPanel run(){
		
		JPanel container = setUpMainContainer();
		
		return container;
	}
	
	private JPanel setUpMainContainer() {
		
		JPanel container = new JPanel();
		container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
		setPanelSize(container, new Dimension(width, height-50));
		container.setBackground(Color.WHITE);
		
		container.add(getHeaderComponent());
		
		
		
		
		container.add(Box.createVerticalStrut(3));
		container.add(getAgendaComponent());
		container.add(Box.createVerticalStrut(3));
		container.add(getMainComponent());

		return container;
	}

	private Component getMainComponent() {
		
		int containerheight = 420;
		
		JPanel maincontainer = new JPanel(new GridBagLayout());
		setPanelSize(maincontainer, new Dimension(width, containerheight));
		maincontainer.setBackground(Color.WHITE);
		
		JPanel container1 = new JPanel(new GridBagLayout());
		setPanelSize(container1, new Dimension(width/2, containerheight));
		container1.setBackground(Color.WHITE);
		container1.setBorder(border);
		
		JPanel container2 = new JPanel(new GridBagLayout());
		setPanelSize(container2, new Dimension(width/2, containerheight));
		container2.setBackground(Color.WHITE);
		container2.setBorder(border);
		
		JPanel northSectionLeft = new JPanel(new GridBagLayout());
		setPanelSize(northSectionLeft, new Dimension(width/2, 120));
		northSectionLeft.setBackground(Color.WHITE);
		northSectionLeft.setBorder(border);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(10,25,5,5);
			northSectionLeft.add(lblIntroduction, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			northSectionLeft.add(lblOutline, gc);
			
			gc.gridx = 0;
			gc.gridy = 2;
			northSectionLeft.add(lblBackground, gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(10,5,5,5);
		container1.add(northSectionLeft, gc);
		
		JPanel southSectionLeft = new JPanel(new GridBagLayout());
		setPanelSize(southSectionLeft, new Dimension(width/2, 280));
		southSectionLeft.setBackground(Color.WHITE);
		
		JPanel southSectionRight = new JPanel(new GridBagLayout());
		setPanelSize(southSectionRight, new Dimension(width/2, 280));
		southSectionRight.setBackground(Color.WHITE);

		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(5,25,5,5);
			southSectionLeft.add(session1, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.insets = new Insets(5,5,5,5);
			southSectionLeft.add(txtAreaSessionOne, gc);
			
			gc.gridx = 0;
			gc.gridy = 2;
			gc.insets = new Insets(5,25,5,5);
			southSectionLeft.add(session2, gc);
			
			gc.gridx = 0;
			gc.gridy = 3;
			gc.insets = new Insets(5,5,5,5);
			southSectionLeft.add(txtAreaSessionTwo, gc);
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.insets = new Insets(10,5,10,5);
		container1.add(southSectionLeft, gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		gc.insets = new Insets(10,5,10,5);
		container2.add(southSectionRight, gc);
		
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,0,0,2);
		maincontainer.add(container1, gc);
		
		gc.gridx = 1;
		gc.insets = new Insets(0,0,0,1);
		maincontainer.add(container2, gc);		
		
		
		return maincontainer;
	}

	private Component getAgendaComponent() {
		
		double height = (int)headerHeight * 1.5;
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(width, (int)height));
		container.setBackground(Color.WHITE);
		
		JPanel leftContainer = new JPanel(new GridBagLayout());
		setPanelSize(leftContainer, new Dimension(width/2, (int)height));
		leftContainer.setBackground(new Color(242,242,242));
		leftContainer.setBorder(border);
		
		JPanel rightContainer = new JPanel(new GridBagLayout());
		setPanelSize(rightContainer, new Dimension(width/2, (int)height));
		rightContainer.setBackground(new Color(242,242,242));
		rightContainer.setBorder(border);
		
		JTextPane text = new JTextPane();
		text.setFont(new Font(containerFontType, Font.PLAIN, (int)11.0f));

		text.setForeground(UI_Settings.getComponentsFontColorDark());
		text.setBackground(new Color(242,242,242));
		text.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.5);
		
		text.setParagraphAttributes(set, true);
		text.setText("Open training session: Introduce tutor, outline structure and provide background information");
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,3,0,3);
		leftContainer.add(text, gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(3,0,3,2);
		container.add(leftContainer, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(3,0,3,0);
		container.add(rightContainer, gc);

		return container;
	}

	private Component getHeaderComponent() {
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(width*2, headerHeight*2));
		container.setBackground(Color.WHITE);
		
		JPanel keyPointsContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 15));
		setPanelSize(keyPointsContainer, new Dimension(width, headerHeight));
		keyPointsContainer.setBackground(headercolor);
		keyPointsContainer.add(keyPointsLabel);

		
		JPanel trainingAidToolsContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 15));
		setPanelSize(trainingAidToolsContainer, new Dimension(width, headerHeight));
		trainingAidToolsContainer.setBackground(headercolor);
		trainingAidToolsContainer.add(trainingAidToolsLabel);

		
		JPanel introductionContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 15));
		setPanelSize(introductionContainer, new Dimension(width*2, headerHeight));
		introductionContainer.setBackground(headercolor);
		introductionContainer.add(headerLabel);
			
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(3,0,3,0);
		container.add(keyPointsContainer, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.insets = new Insets(3,3,3,0);
		container.add(trainingAidToolsContainer, gc);
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 2;
		gc.insets = new Insets(0,0,0,0);
		container.add(introductionContainer, gc);

		
		return container;
	}

	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
}
