package gui.training.com;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import settings.UI_Settings;

public class Step4_1 extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel nextStepTextButton = new JLabel(">>");
	private JLabel previousStepTextButton = new JLabel("<<");
	private int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
	
	private JPanel rootpanel;
	private CreateTrainingSessionPanel createTrainingCenter;
	private Step4ControlCenter step4ControlCenter;
	
	private JCheckBox lectures = new JCheckBox("Lectures");
	private JCheckBox demonstrations = new JCheckBox("Demonstrations");
	private JCheckBox discussions = new JCheckBox("Discussions");
	private JCheckBox onlineLearning = new JCheckBox("Online Learning");
	private JCheckBox rolePlay = new JCheckBox("Role Play");
	private JCheckBox groupTeach = new JCheckBox("Small Group Teaching");
	private JCheckBox caseStudies = new JCheckBox("Case Studies");
	private JCheckBox other = new JCheckBox("Other");
	
	private List<String> selections = new ArrayList<String>();

	
	private JFrame messageFrame;
	
	private List<JCheckBox> checkboxes = new ArrayList<JCheckBox>();
	private GridBagConstraints gc = new GridBagConstraints();

	
	public Step4_1(){
	}
	
	private void initialize(){
		
		
		checkboxes.add(caseStudies);
		checkboxes.add(demonstrations);
		checkboxes.add(groupTeach);
		checkboxes.add(lectures);
		checkboxes.add(onlineLearning);
		checkboxes.add(other);
		checkboxes.add(discussions);
		checkboxes.add(rolePlay);
		
		caseStudies.setName("case");
		demonstrations.setName("demo");
		groupTeach.setName("group");
		lectures.setName("lecture");
		onlineLearning.setName("online");
		other.setName("other");
		discussions.setName("discuss");
		rolePlay.setName("role");
		
		
	   ActionListener listener = new ActionListener() {
		   
				int counter;

		    	public void actionPerformed(ActionEvent actionEvent) {
		    		
		    	JCheckBox checkbox = (JCheckBox) actionEvent.getSource();
		    	  
		        AbstractButton abstractButton = (AbstractButton) actionEvent.getSource();
		        boolean selected = abstractButton.getModel().isSelected();
		        String name = abstractButton.getName();
		    	  
		        if(counter > 4){
		        	
		        	if(selected){
		        		checkbox.setSelected(false);
		        		counter--;
		        		removeFromArray(name);
			        	JOptionPane.showMessageDialog(messageFrame, "You have seleceted the maximum number of methods!", "", JOptionPane.WARNING_MESSAGE);
			        	return;
		        	}
		        }
		    	  
		        
		        if(selected){
		        	counter++;
		        	selections.add(name);
		        	System.out.println("Adding:" + name);
		        }else{
		        	counter--;
	        		removeFromArray(name);
		        }
		        
		        if(counter > 4){
		        	
		        	if(selected){
		        		checkbox.setSelected(false);
		        		counter--;
		        		removeFromArray(name);
			        	JOptionPane.showMessageDialog(messageFrame, "You have seleceted the maximum number of methods!", "", JOptionPane.WARNING_MESSAGE);
			        	return;
		        	}
		        }
		      }

				private void removeFromArray(String name) {
		        	//Iterate through the array to find and remove the CheckBox name
		        	for(int i = 0; i < selections.size(); i++){
		        		if(selections.get(i).equals(name)){
		        			selections.remove(i);
		        		}
		        	}
		        	System.out.println("Removing:" + name);
				}
	   };
		
		for(int i = 0; i < checkboxes.size(); i++){
			checkboxes.get(i).setForeground(UI_Settings.getComponentsFontColorLight());
			checkboxes.get(i).setFont(checkboxes.get(i).getFont().deriveFont(11.0f));
			
			checkboxes.get(i).addActionListener(listener);
			
		}
		initializeListeners();
	}
	
	public JPanel run(CreateTrainingSessionPanel createTrainingCenter, Step4ControlCenter step4ControlCenter){
		
		this.createTrainingCenter = createTrainingCenter;
		this.step4ControlCenter = step4ControlCenter;
		
		rootpanel = new JPanel();
		rootpanel.setLayout(new BoxLayout(rootpanel, BoxLayout.Y_AXIS));
		rootpanel.setBackground(Color.WHITE);
		setPanelSize(rootpanel, new Dimension(new Dimension(screenWidth, 800)));
		
		initialize();
		addNextStepRow();
		addHeadingAndSubText();
		addTextBodyHeader();
		addTextBody();
		addCheckBoxDescription();
		addCheckBoxes();
		
		return rootpanel;
	}
	
	private void addCheckBoxes() {
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(screenWidth, 50));
		container.setBackground(Color.WHITE);
		
		int count = 0;
		
		gc.gridx = count;
		gc.gridy = 0;
		gc.gridwidth = 1;
		gc.gridheight = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(10,20,0,0);
		container.add(lectures, gc);
		
		gc.gridx = ++count;
		gc.gridy = 0;
		gc.insets = new Insets(10,5,0,0);
		container.add(demonstrations, gc);
		
		gc.gridx = ++count;
		gc.gridy = 0;
		container.add(discussions, gc);
		
		gc.gridx = ++count;
		gc.gridy = 0;
		container.add(onlineLearning, gc);
		
		gc.gridx = ++count;
		gc.gridy = 0;
		container.add(rolePlay, gc);
		
		gc.gridx = ++count;
		gc.gridy = 0;
		container.add(groupTeach, gc);
		
		gc.gridx = ++count;
		gc.gridy = 0;
		container.add(caseStudies, gc);
		
		gc.gridx = ++count;
		gc.gridy = 0;
		gc.insets = new Insets(10,0,0,20);
		container.add(other, gc);
		
		rootpanel.add(container);
	}

	private void addCheckBoxDescription() {
		
		JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		setPanelSize(container, new Dimension(this.screenWidth, 20));
		container.setBackground(Color.WHITE);
		
		JTextPane row1Text = new JTextPane();
		row1Text.setFont(row1Text.getFont().deriveFont(11.0f));
		row1Text.setForeground(UI_Settings.getComponentsFontColorDark());
		row1Text.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(row1Text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0);
		
		row1Text.setParagraphAttributes(set, true);
		row1Text.setText("Once you've decided which training methods to use, select them from the list below and we "
				+ "will start adding them to your template. Max 4/7");
		container.add(row1Text);
		
		this.rootpanel.add(Box.createVerticalStrut(10));
		this.rootpanel.add(container);		
	}

	private void addTextBodyHeader() {
	
		JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		setPanelSize(container, new Dimension(this.screenWidth, 20));
		container.setBackground(Color.WHITE);
		
		JTextPane row1Text = new JTextPane();
		row1Text.setFont(row1Text.getFont().deriveFont(11.0f));
		row1Text.setForeground(UI_Settings.getComponentsFontColorDark());
		row1Text.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(row1Text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0);
		
		row1Text.setParagraphAttributes(set, true);
		row1Text.setText("Consider using these activities during your training session:");
		container.add(row1Text);
		
		this.rootpanel.add(Box.createVerticalStrut(10));
		this.rootpanel.add(container);
	}

	private void addTextBody() {
	
	JPanel container = new JPanel(new GridBagLayout());
	setPanelSize(container, new Dimension(screenWidth, 500));
	container.setBackground(Color.WHITE);
	
	JLabel lblLectures = new JLabel("Lectures");
	JLabel lblDemonstrations = new JLabel("Demonstrations");
	JLabel lblDiscussions = new JLabel("Discussions");
	JLabel lblOnlineLearning = new JLabel("Online learning");
	JLabel lblRolePlay = new JLabel("Role play");
	JLabel lblSmallGroupTeaching = new JLabel("Small group teaching");
	JLabel lblCaseStudies = new JLabel("Case studies");

	int count = 0;
	
	gc.gridx = 0;
	gc.gridy = count;
	gc.gridheight = 1;
	gc.gridwidth = 1;
	gc.weightx = 0.1;
	gc.weighty = 1;
	gc.fill = GridBagConstraints.NONE;
	gc.anchor = GridBagConstraints.NORTHWEST;
	gc.insets = new Insets(20,60,0,0);
	container.add(lblLectures, gc);
	
	gc.gridy = ++count;
	gc.insets = new Insets(10,60,0,0);
	container.add(lblDemonstrations, gc);
	
	gc.gridy = ++count;
	container.add(lblDiscussions, gc);
	
	gc.gridy = ++count;
	container.add(lblOnlineLearning, gc);
	
	gc.gridy = ++count;
	container.add(lblRolePlay, gc);
	
	gc.gridy = ++count;
	container.add(lblSmallGroupTeaching, gc);
	
	gc.gridy = ++count;
	container.add(lblCaseStudies, gc);
	
	count = 0;
	
	gc.gridx = 1;
	gc.gridy = 0;
	gc.gridheight = 1;
	gc.gridwidth = 1;
	gc.weightx = 0.1;
	gc.weighty = 1;
	gc.fill = GridBagConstraints.NONE;
	gc.anchor = GridBagConstraints.NORTHWEST;
	gc.insets = new Insets(10,20,0,20);
	container.add(getLecturesText(), this.gc);
		
	this.rootpanel.add(container);
	}

	private Component getLecturesText() {
		
		GridBagConstraints gc = new GridBagConstraints();
		
		JPanel container = new JPanel();
		container.setLayout(new GridBagLayout());
		
		String text = "Lectures are ideal for introducing a topic. Keep lectures to 30 minutes or less, and summarize "
				+ "the important points at the beginning and end. You may want to use a guest speaker if the topic is "
				+ "highly specialized.";
		
		String text2 = "Demonstrations work best when you need to show the steps in a process or task. Learners can try the "
				+ "task out for themselves, or you can demonstrate it in front of the group.";
		
		String text3 = "Discussions and debates are useful after a lecture, because they allow trainees to ask questions "
				+ "about the concepts that they have just learned. Consider handing out a list of questions or topics to "
				+ "prompt a discussion.";
		
		String text4 = "Online learning is helpful when trainees need to gain practical experience of IT skills, if they "
				+ "need to access video or audio material, or if quizzes and self-test activities will be useful.";
		/////
		String text5 = "Role play involves trainees acting out a new skill in a simulated environment, and learning from "
				+ "feedback from other participants";

		
		String text6 = "Small group teaching helps learners clarify their understanding of the new information. They can explain"
				+ " it to one another in their own words, and answer questions.";
		
		String text7 = "Case studies can help learners put new information into context. As they process the information and relate"
				+ " it to a situation that's relevant to them, they create mental connections that will help them recall the "
				+ "information later.";
		
		JPanel panel1 = getTextPanel(text);
		JPanel panel2 = getTextPanel(text2);
		JPanel panel3 = getTextPanel(text3);
		JPanel panel4 = getTextPanel(text4);
		JPanel panel5 = getTextPanel(text5);
		JPanel panel6 = getTextPanel(text6);
		JPanel panel7 = getTextPanel(text7);

		int count = 0;
		
		gc.gridx = 0;
		gc.gridy = count;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(10,20,0,60);
		container.add(panel1, gc);
		
		gc.gridx = 0;
		gc.gridy = ++count;
		gc.insets = new Insets(10,20,0,60);
		container.add(panel2, gc);
		
		gc.gridx = 0;
		gc.gridy = ++count;
		gc.insets = new Insets(10,20,0,60);
		container.add(panel3, gc);
		
		gc.gridx = 0;
		gc.gridy = ++count;
		gc.insets = new Insets(10,20,0,60);
		container.add(panel4, gc);
		
		gc.gridx = 0;
		gc.gridy = ++count;
		gc.insets = new Insets(10,20,0,60);
		container.add(panel5, gc);
		
		gc.gridx = 0;
		gc.gridy = ++count;
		gc.insets = new Insets(10,20,0,60);
		container.add(panel6, gc);
		
		gc.gridx = 0;
		gc.gridy = ++count;
		gc.insets = new Insets(10,20,0,60);
		container.add(panel7, gc);
		
		return container;
	}

	private void addHeadingAndSubText() {
		
		JPanel content = new JPanel(new GridBagLayout());
		setPanelSize(content, new Dimension(screenWidth, 100));
		content.setBackground(Color.WHITE);
		
		JLabel pageTitle = new JLabel("Step 4.1: Plan Presentation Techniques");
		pageTitle.setFont(pageTitle.getFont().deriveFont(16.0f));
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(15,20,0,0);
		content.add(pageTitle, gc);
		
		
		JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
		setPanelSize(row1, new Dimension(screenWidth, 20));
		row1.setBackground(Color.WHITE);
		
		JTextPane row1Text = new JTextPane();
		row1Text.setFont(row1Text.getFont().deriveFont(11.0f));
		row1Text.setForeground(UI_Settings.getComponentsFontColorDark());
		row1Text.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(row1Text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0);
		
		row1Text.setParagraphAttributes(set, true);

		row1Text.setText("Now think about how you will teach this material to your students. It's best to use"
				+ " several different presentation approaches to keep students engaged, and to appeal to people"
				+ " with different learning styles.");

		row1.add(row1Text);
		row1.setAlignmentY(Component.LEFT_ALIGNMENT);
		gc.gridx = 0;
		gc.gridy = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(0,0,0,0);
		content.add(row1, gc);
		
		//////////////////////////
		JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 40, 0));
		setPanelSize(row2, new Dimension(screenWidth, 20));
		row2.setBackground(Color.WHITE);
		
		JTextPane row2Text = new JTextPane();
		row2Text.setFont(row2Text.getFont().deriveFont(11.0f));
		row2Text.setForeground(UI_Settings.getComponentsFontColorDark());
		row2Text.setEditable(false);
		
		set = new SimpleAttributeSet(row2Text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0);
		
		row2Text.setParagraphAttributes(set, true);

		row2Text.setText("What are the most important concepts or skills that "
				+ "trainees need to understand by the end of the class?");
		
		row2.add(row2Text);
		gc.gridx = 0;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(0,20,0,0);
		content.add(row2,gc);
		content.setAlignmentY(Component.LEFT_ALIGNMENT);
		this.rootpanel.add(content);
	}

	private void initializeListeners() {
		
		previousStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		previousStepTextButton.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				CreateTrainingSessionPanel.resetLocatorColors();
				CreateTrainingSessionPanel.locator3.setBackground(CreateTrainingSessionPanel.LOCATOR_ACTIVE_COLOR);
				
				CardLayout cl = (CardLayout)(CreateTrainingSessionPanel.cards.getLayout());
				cl.show(CreateTrainingSessionPanel.cards, Step4ControlCenter.STEP3);
			}
		});
		
		nextStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		nextStepTextButton.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				step4ControlCenter.setSelectedCheckBoxes(selections);
				
				CardLayout cl = (CardLayout)(step4ControlCenter.cards.getLayout());
				cl.show(step4ControlCenter.cards, Step4ControlCenter.STEP2);
			}
		});
	}
	
	private void addNextStepRow() {
		
		nextStepTextButton.setFont(nextStepTextButton.getFont().deriveFont(12.0f));
		previousStepTextButton.setFont(previousStepTextButton.getFont().deriveFont(12.0f));

		nextStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());
		previousStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());

		JPanel container = new JPanel();
		container.setBackground(Color.WHITE);
		container.setLayout(new BoxLayout(container, BoxLayout.X_AXIS));
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(previousStepTextButton);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(nextStepTextButton);
		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		container.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		container.add(rightPanel);
		
		this.rootpanel.add(container);
	}
	
	private JPanel getTextPanel(String text) {
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension((screenWidth/5*3), 450 ));
		container.setBackground(new Color(238,238,238));
		
		JTextPane textpane = new JTextPane();
		textpane.setFont(textpane.getFont().deriveFont(11.0f));
		textpane.setBackground(new Color(238,238,238));
		textpane.setForeground(UI_Settings.getComponentsFontColorDark());
		textpane.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(textpane.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0);
		
		textpane.setParagraphAttributes(set, true);

		textpane.setText(text);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 7;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		container.add(textpane, gc);
		
		return container;
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}

}
