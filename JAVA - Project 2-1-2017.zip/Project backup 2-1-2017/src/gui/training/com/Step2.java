package gui.training.com;

import java.awt.BasicStroke;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import settings.UI_Settings;

public class Step2 extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	CreateTrainingSessionPanel sessionObject;
	
	private String containerFontType = "Courier";

	private JPanel panel;
    private JTextPane tipOneContent = new JTextPane();
    private JTextPane affinity0ne = new JTextPane();
    private JTextPane affinityTwo = new JTextPane();
	
	private GridBagConstraints gc = new GridBagConstraints();
	private int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
	
	private JLabel nextStepTextButton = new JLabel(">>");
	private JLabel previousStepTextButton = new JLabel("<<");
	
	private JTextField txtConceptOne = new JTextField();
	private JTextField txtConceptTwo = new JTextField();
	private JTextField txtConceptThree = new JTextField();
	
	private JTextField txtConOneThemeOne = new JTextField();
	private JTextField txtConOneThemeTwo = new JTextField();
	
	private JTextField txtConTwoThemeOne = new JTextField();
	private JTextField txtConTwoThemeTwo = new JTextField();
	
	private JTextField txtConThreeThemeOne = new JTextField();
	private JTextField txtConThreeThemeTwo = new JTextField();
	
	private JLabel clearData1 = new JLabel("clear theme data");
	private JLabel clearData2= new JLabel("clear theme data");
	private JLabel clearData3 = new JLabel("clear theme data");
	
	private List<JTextField> textfields = new ArrayList<JTextField>();
	
	private JLabel tipOneHeader;
	private JPanel tipsContainer;
	private JPanel minimizeTips = new JPanel();

	private JLabel closeTips = new JLabel("close tips [x]");
	private JLabel threeDots = new JLabel("...");

	private FormEventSBuilder ev;


	public Step2(FormEventSBuilder ev){
		
		this.ev = ev;
		intialize();

	}
	

	private void intialize() {
		
		initializeListeners();
		
		addTextFieldsToArrayList();
		
		
		initializeConceptTextField(txtConceptOne);
		initializeConceptTextField(txtConceptTwo);
		initializeConceptTextField(txtConceptThree);
		
		initializeThemeTextFields(txtConOneThemeOne);
		initializeThemeTextFields(txtConOneThemeTwo);

		initializeThemeTextFields(txtConTwoThemeOne);
		initializeThemeTextFields(txtConTwoThemeTwo);

		initializeThemeTextFields(txtConThreeThemeOne);
		initializeThemeTextFields(txtConThreeThemeTwo);
		
		initializeLabels(clearData1);
		initializeLabels(clearData2);
		initializeLabels(clearData3);
		
		initializeTextPanes(tipOneContent);
		initializeAffinityHeaderPanes(affinity0ne);
		initializeAffinityHeaderPanes(affinityTwo);

		
		initializeMinimizePanes();
		initializeListeners();
		
		initializeTextFieldFont();
		
	}
	
	private void initializeTextFieldFont() {
	}


	private void addTextFieldsToArrayList() {
		textfields.add(txtConceptOne);
		textfields.add(txtConceptTwo);
		textfields.add(txtConceptThree);
		
		textfields.add(txtConOneThemeOne);
		textfields.add(txtConOneThemeTwo);
		
		textfields.add(txtConTwoThemeOne);
		textfields.add(txtConTwoThemeTwo);
		
		textfields.add(txtConThreeThemeOne);
		textfields.add(txtConThreeThemeTwo);
	}


	public JPanel run(CreateTrainingSessionPanel sessionObject){
		
		this.sessionObject = sessionObject;
		
		panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.setBackground(Color.WHITE);
		setPanelSize(panel, new Dimension(new Dimension(screenWidth, 800)));
		/////////////////////////////////////////////////////////////////////////////////

		addNextStepRow();
		addHeadingAndSubText();
		addThemeInputRowBody();
		addTipContainers();
		addMinimizeTipsContainer();
		
		/////////////////////////////////////////////////////////////////////////////////
		return panel;
	}

	public void addFormEventDataToFields() {
		
		txtConceptOne.setText(ev.getConcept1());
		txtConceptTwo.setText(ev.getConcept2());
		txtConceptThree.setText(ev.getOtherConcept());
		
	}


	private void initializeListeners() {
		
		minimizeTips.setCursor(new Cursor(Cursor.HAND_CURSOR));
		minimizeTips.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				minimizeTips.setVisible(false);
				tipsContainer.setVisible(true);
			}
		});
		
		
		nextStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		nextStepTextButton.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				JScrollPane scroller = sessionObject.getScroller();
				
				
				 System.out.println("Next step 2 has been pressed");
				
				 if(scroller != null){
					 scroller.getViewport().setViewPosition(new Point(0,0));
				 }
				
				 CreateTrainingSessionPanel.resetLocatorColors();
				 CreateTrainingSessionPanel.locator3.setBackground(CreateTrainingSessionPanel.LOCATOR_ACTIVE_COLOR);
				 CardLayout cl = (CardLayout)(CreateTrainingSessionPanel.cards.getLayout());
				 cl.show(CreateTrainingSessionPanel.cards, CreateTrainingSessionPanel.STEP3);
			}
		});
		
		
		previousStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		previousStepTextButton.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				JScrollPane scroller = sessionObject.getScroller();
				
				 if(scroller != null){
					 scroller.getViewport().setViewPosition(new Point(0,0));
				 }
				
				 CreateTrainingSessionPanel.resetLocatorColors();
				 sessionObject.locator1.setBackground(CreateTrainingSessionPanel.LOCATOR_ACTIVE_COLOR);
				 CardLayout cl = (CardLayout)(CreateTrainingSessionPanel.cards.getLayout());
				 cl.show(CreateTrainingSessionPanel.cards, CreateTrainingSessionPanel.STEP1);
			}
		});
		
		clearData1.addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				txtConOneThemeOne.setText("");
				txtConOneThemeTwo.setText("");
				
			}
			
		});
		
		clearData2.addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				txtConTwoThemeOne.setText("");
				txtConTwoThemeTwo.setText("");
				
			}
			
		});
		
		clearData3.addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				txtConThreeThemeOne.setText("");
				txtConThreeThemeTwo.setText("");
				
			}
			
		});
		
		closeTips.setCursor(new Cursor(Cursor.HAND_CURSOR));
		closeTips.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				tipsContainer.setVisible(false);
				minimizeTips.setVisible(true);
			}
		});
		
	}

	private void addMinimizeTipsContainer() {
		threeDots.setForeground(UI_Settings.getComponentsFontColorLight());
		threeDots.setFont(threeDots.getFont().deriveFont(16.0f));
		panel.add(minimizeTips);
	}
	
	private void initializeMinimizePanes() {
		minimizeTips = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		setPanelSize(minimizeTips, new Dimension(screenWidth, 20));
		minimizeTips.setBackground(Color.WHITE);
		minimizeTips.add(threeDots);
		
		minimizeTips.setAlignmentY(Component.LEFT_ALIGNMENT);
		minimizeTips.setVisible(false);		
	}
	
	private void addThemeInputRowBody() {
		
		int containerHeight = 450;
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(screenWidth, containerHeight));
		container.setBackground(Color.RED);
		

		JPanel left = new JPanel();
		left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
		setPanelSize(left, new Dimension(screenWidth/2, containerHeight));
		left.setBackground(Color.WHITE);
		
		left.add(conceptOneInputDisplay(containerHeight));
		left.add(conceptTwoInputDisplay(containerHeight));
		left.add(conceptThreeInputDisplay(containerHeight));
		
		JPanel right = new JPanel();
		right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
		setPanelSize(right, new Dimension(screenWidth/2, containerHeight));
		right.setBackground(Color.PINK);
		right.add(unorderAffinityDiagram(containerHeight));
		right.add(orderedAffinityDiagram(containerHeight));
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		container.add(left, gc);
		
		gc.gridx = 1;
		container.add(right, gc);
		
		panel.add(container);
	}

	private JPanel unorderAffinityDiagram(int containerHeight) {

		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(screenWidth/2, containerHeight/2));
		container.setBackground(Color.WHITE);
		
		affinity0ne.setText("Unorganized\nideas example");
		
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(15,20,0,0);
		container.add(affinity0ne, gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		gc.fill = GridBagConstraints.NONE;
		gc.insets = new Insets(5,5,5,5);
		container.add(new AffinitySquares(), gc);
		
		gc.gridx = 2;
		gc.insets = new Insets(5,5,5,5);
		container.add(new AffinitySquares(), gc);
		
		gc.gridx = 4;
		gc.insets = new Insets(5,5,5,15);
		container.add(new AffinitySquares(), gc);
		
		///////////2nd Row//////////
		gc.gridx = 2;
		gc.gridy = 2;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,5,10,0);
		container.add(new AffinitySquares(), gc);

		gc.gridx = 3;
		gc.gridy = 2;
		container.add(new AffinitySquares(), gc);
		
		gc.gridx = 4;
		gc.gridy = 2;
		container.add(new AffinitySquares(), gc);
		
		return container;
	}

	private JPanel orderedAffinityDiagram(int containerHeight) {
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(screenWidth/2, containerHeight/2));
		container.setBackground(Color.WHITE);
		
		affinityTwo.setText("Affinity diagram\nexample");
		
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(15,20,0,0);
		container.add(affinityTwo, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(15,25,0,0);
		container.add(new JLabel("Theme 1"), gc);
		
		gc.gridx = 2;
		gc.gridy = 0;
		container.add(new JLabel("Theme 2"), gc);
		
		gc.gridx = 3;
		gc.gridy = 0;
		container.add(new JLabel("Theme 3"), gc);
		
		
		gc.gridx = 1;
		gc.gridy = 1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,5,5,5);
		container.add(new AffinityDiagram(), gc);
		
		gc.gridx = 2;
		gc.insets = new Insets(5,5,5,5);
		container.add(new AffinityDiagram(), gc);
		
		gc.gridx = 3;
		gc.insets = new Insets(5,5,5,15);
		container.add(new AffinityDiagram(), gc);
		
		
		return container;
	}

	private JPanel conceptThreeInputDisplay(int containerHeight) {
		
		JLabel heading = new JLabel("Concept 3:");
		heading.setFont(heading.getFont().deriveFont(11.0f));

		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(screenWidth/2, containerHeight/3));
		container.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(15,20,0,0);
		container.add(heading, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(10,5,0,5);
		container.add(this.txtConceptThree, gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("Theme 1"),gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("1."),gc);
		
		gc.gridx = 1;
		gc.gridy = 3;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("2."),gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		gc.insets = new Insets(5,20,5,5);
		container.add(txtConThreeThemeOne,gc);
		
		gc.gridx = 1;
		gc.gridy = 3;
		gc.insets = new Insets(5,20,5,5);
		container.add(txtConThreeThemeTwo,gc);
		
		gc.gridx = 2;
		gc.gridy = 2;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.NONE;
		gc.insets = new Insets(5,0,5,5);
		container.add(clearData3,gc);
		
		return container;
	}


	private Component conceptTwoInputDisplay(int containerHeight) {
		
		JLabel heading = new JLabel("Concept 2:");
		heading.setFont(heading.getFont().deriveFont(11.0f));

		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(screenWidth/2, containerHeight/3));
		container.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(15,20,0,0);
		container.add(heading, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(10,5,0,5);
		container.add(this.txtConceptTwo, gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("Theme 1"),gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("1."),gc);
		
		gc.gridx = 1;
		gc.gridy = 3;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("2."),gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		gc.insets = new Insets(5,20,5,5);
		container.add(txtConTwoThemeOne,gc);
		
		gc.gridx = 1;
		gc.gridy = 3;
		gc.insets = new Insets(5,20,5,5);
		container.add(txtConTwoThemeTwo,gc);
		
		gc.gridx = 2;
		gc.gridy = 2;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.NONE;
		gc.insets = new Insets(5,0,5,5);
		container.add(clearData2,gc);
		
		return container;
	}


	private Component conceptOneInputDisplay(int containerHeight) {
		
		JLabel heading = new JLabel("Concept 1:");
		heading.setFont(heading.getFont().deriveFont(11.0f));
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(screenWidth/2, containerHeight/3));
		container.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(15,20,0,0);
		container.add(heading, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(10,5,0,5);
		container.add(this.txtConceptOne, gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("Theme 1"),gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("1."),gc);
		
		gc.gridx = 1;
		gc.gridy = 3;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,5,5,5);
		container.add(new JLabel("2."),gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,20,5,5);
		container.add(txtConOneThemeOne,gc);
		
		gc.gridx = 1;
		gc.gridy = 3;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,20,5,5);
		container.add(txtConOneThemeTwo,gc);
		
		gc.gridx = 2;
		gc.gridy = 2;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.NONE;
		gc.insets = new Insets(5,0,5,5);
		container.add(clearData1,gc);
		
		return container;
	}


	private void addNextStepRow() {
		nextStepTextButton.setFont(nextStepTextButton.getFont().deriveFont(12.0f));
		previousStepTextButton.setFont(previousStepTextButton.getFont().deriveFont(12.0f));
		
		nextStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());
		previousStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());


		JPanel container = new JPanel();
		container.setBackground(Color.WHITE);
		container.setLayout(new BoxLayout(container, BoxLayout.X_AXIS));
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(previousStepTextButton);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(nextStepTextButton);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		container.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		container.add(rightPanel);
		
		panel.add(container);
	}



	private void addHeadingAndSubText() {
		
		JPanel content = new JPanel(new GridBagLayout());
		setPanelSize(content, new Dimension(screenWidth, 100));
		content.setBackground(Color.WHITE);
		
		JLabel pageTitle = new JLabel("Step 2: Clarify Key Topics and Related Concepts");
		pageTitle.setFont(pageTitle.getFont().deriveFont(16.0f));
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(18,20,0,0);
		content.add(pageTitle, gc);
		
		
		JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20,5));
		setPanelSize(row1, new Dimension(screenWidth, 20));
		row1.setBackground(Color.WHITE);
		
		JTextPane row1Text = new JTextPane();
		row1Text.setFont(row1Text.getFont().deriveFont(11.0f));
		row1Text.setForeground(UI_Settings.getComponentsFontColorDark());
		row1Text.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(row1Text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.5);
		
		row1Text.setParagraphAttributes(set, true);

		row1Text.setText("Your class will focus on a few central ideas or skills, but you'll"
				+ " need to explain related concepts to reach your learning objectives.");
		

		row1.add(row1Text);
		row1.setAlignmentY(Component.LEFT_ALIGNMENT);
		gc.gridx = 0;
		gc.gridy = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(5,0,0,0);
		content.add(row1, gc);
		
		//////////////////////////
		JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 40, 0));
		setPanelSize(row2, new Dimension(screenWidth, 40));
		row2.setBackground(Color.WHITE);
		
		JTextPane row2Text = new JTextPane();
		row2Text.setFont(row2Text.getFont().deriveFont(11.0f));
		row2Text.setForeground(UI_Settings.getComponentsFontColorDark());
		row2Text.setEditable(false);
		
		set = new SimpleAttributeSet(row2Text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.5);
		
		row2Text.setParagraphAttributes(set, true);

		row2Text.setText("List your key topics and their related concepts, and then group them"
				+ " together using an Affinity diagram to show that they are connected.\n"
				+ "Each theme should correspond to the concepts you decided upon in Step 1.");
		

		row2.add(row2Text);
		gc.gridx = 0;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(10,20,0,0);
		content.add(row2,gc);
		content.setAlignmentY(Component.LEFT_ALIGNMENT);
		this.panel.add(content);
	}
	
	private void addTipContainers() {
		
		int containerHeight = 180;
		int tipOnecontainerHeight = 80;

		int count = 0;
		
		tipOneHeader = new JLabel("Tip 3:");
		tipOneHeader.setFont(tipOneHeader.getFont().deriveFont(14.0f));
		
		tipOneContent.setText("Transfer your ideas onto sticky notes. Write down every piece of information that you need"
				+ " to organize onto a separate sticky note. This helps to understand your Audience, define the Behavior "
				+ "needed at the end of the session, specify the Conditions under which the knowledge will be used, and "
				+ "Determine  the degree of knowledge needed.");
		
		tipsContainer = new JPanel(new GridBagLayout());
		setPanelSize(tipsContainer, new Dimension(screenWidth, containerHeight));
		tipsContainer.setBackground(Color.WHITE);
		
		
		JPanel left = new JPanel(new GridBagLayout());
		setPanelSize(left, new Dimension(screenWidth/3*2, containerHeight));
		left.setBackground(Color.WHITE);
		
			JPanel containerOne = new JPanel(new GridBagLayout());
			setPanelSize(containerOne, new Dimension(screenWidth/3*2, tipOnecontainerHeight));
			containerOne.setBackground(new Color(242,242,242));
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(5,20,0,0);
			containerOne.add(tipOneHeader, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.insets = new Insets(0,20,0,0);
			containerOne.add(tipOneContent,gc);
			
			gc.gridx = 0;
			gc.gridy = count;
			gc.insets = new Insets(10,20,0,20);
			left.add(containerOne, gc);
			
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,0,0,0);
		tipsContainer.add(left,gc);
		
		
		JPanel right = new JPanel(new GridBagLayout());
		setPanelSize(right, new Dimension(screenWidth/3, containerHeight));
		right.setBackground(Color.WHITE);
		
			JPanel hideTips = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20,5));
			setPanelSize(hideTips, new Dimension(screenWidth/3, 20));
			hideTips.setBackground(Color.WHITE);
			hideTips.add(closeTips);
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,0,0,0);
			right.add(hideTips,gc);
		
		gc.gridx = 1;
		tipsContainer.add(right, gc);
		
		tipsContainer.setAlignmentY(Component.LEFT_ALIGNMENT);
		panel.add(tipsContainer);
	}

	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
	
	private void initializeLabels(JLabel label) {
		label.setCursor(new Cursor(Cursor.HAND_CURSOR));
		label.setForeground(UI_Settings.getComponentsFontColorLight());
	}

	private void initializeThemeTextFields(JTextField textfield) {
		textfield = new JTextField(20);
		textfield.setMinimumSize(textfield.getPreferredSize());
		textfield.setHorizontalAlignment(JTextField.CENTER);		
	}

	private void initializeConceptTextField(JTextField textfield) {
		textfield = new JTextField(30);
		textfield.setMinimumSize(textfield.getPreferredSize());
		textfield.setHorizontalAlignment(JTextField.CENTER);
	}
	
	private void initializeTextPanes(JTextPane textpane) {
		textpane.setFont(textpane.getFont().deriveFont(11.0f));
		textpane.setForeground(UI_Settings.getComponentsFontColorDark());
		textpane.setEditable(false);	
		textpane.setBackground(new Color(242,242,242));
		
		MutableAttributeSet set = new SimpleAttributeSet(textpane.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.3);
		
		textpane.setParagraphAttributes(set, true);
	}
	
	private void initializeAffinityHeaderPanes(JTextPane textpane) {
		textpane.setFont(textpane.getFont().deriveFont(11.0f));
		textpane.setForeground(UI_Settings.getComponentsFontColorDark());
		textpane.setEditable(false);	
		textpane.setBackground(Color.WHITE);
		
		MutableAttributeSet set = new SimpleAttributeSet(textpane.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.2);
		
		textpane.setParagraphAttributes(set, true);
	}

}

class AffinitySquares extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AffinitySquares(){
		this.setBackground(Color.WHITE);
	}
	
	  protected void paintComponent(Graphics g) {
	    super.paintComponent(g); 
	    
	    Graphics2D g2 = (Graphics2D) g;
	    
	    int thickness = 1;
	    
	    g2.setStroke(new BasicStroke(thickness));
	    g2.setColor(new Color(180,180,180));
	    g2.drawRect(2,2,66,66);  
	    
	  }

	  public Dimension getPreferredSize() {
		  
	    return new Dimension(PREF_W, PREF_H);
	    
	  }
	  
	  private static final int PREF_W = 70;
	  private static final int PREF_H = 70;

	  
}

class AffinityDiagram extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AffinityDiagram(){
		this.setBackground(Color.WHITE);
	}
	
	  protected void paintComponent(Graphics g) {
	    super.paintComponent(g); 
	    
	    Graphics2D g2 = (Graphics2D) g;
	    
	    int thickness = 1;
	    
	    g2.setStroke(new BasicStroke(thickness));
	    g2.setColor(new Color(180,180,180));
	    g2.drawRect(2,2,86,162); 
	    
	    g2.drawRect(12,12,66,66);  
	    g2.drawRect(12,88,66,66);

	    
	  }

	  public Dimension getPreferredSize() {
		  
	    return new Dimension(PREF_W, PREF_H);
	    
	  }
	  
	  private static final int PREF_W = 90;
	  private static final int PREF_H = 166;

	  
}
