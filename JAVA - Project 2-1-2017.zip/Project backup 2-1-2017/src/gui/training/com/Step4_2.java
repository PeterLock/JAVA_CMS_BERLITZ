package gui.training.com;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import settings.UI_Settings;

public class Step4_2 extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private TrainingMethodPanels trainingMethodPanels;
	private IntroductionTrainingAidPanel trainingAidObject;
	
	private JLabel nextStepTextButton = new JLabel(">>");
	private JLabel previousStepTextButton = new JLabel("<<");

	private GridBagConstraints gc = new GridBagConstraints();
	
	private int height = 800;
	private int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
	
	private JPanel rootpanel;
	private JPanel containerLeft;
	private JPanel containerRight;
	private Step4ControlCenter sessionObject;
	
	private JLabel tipOneHeader;
    private JTextPane tipOneContent = new JTextPane();
	private JPanel tipsContainer;

	private List<String> selections;

	
	public Step4_2(){
		
	}
	
	private void initialize(){
		
		trainingAidObject = new IntroductionTrainingAidPanel(screenWidth, height);
		trainingMethodPanels = new TrainingMethodPanels();
		
		addNextStepRow();
		initializeListeners();
		initializeTextPanes(tipOneContent);

	}
	
	public JPanel run(Step4ControlCenter sessionObject){
		this.sessionObject = sessionObject;
		
		
		rootpanel = new JPanel();
		rootpanel.setLayout(new BoxLayout(rootpanel, BoxLayout.Y_AXIS));
		rootpanel.setBackground(Color.BLUE);
		setPanelSize(rootpanel, new Dimension(new Dimension(screenWidth, 600)));
		
		
		initialize();
		addHeadingAndSubText();
		addTrainingAidBody();
		
		return rootpanel;
		
	}
	
	private void addTrainingAidBody() {
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(screenWidth, height));
		container.setBackground(Color.PINK);
		
		//Add the left section of the main container//
		containerLeft = new JPanel(new GridBagLayout());
		setPanelSize(containerLeft, new Dimension(screenWidth/3+150, height));
		containerLeft.setBackground(Color.WHITE);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(5,40,150,20);
			containerLeft.add(trainingAidObject.run(), gc);
		
		//Add the right section of the main container//
		containerRight = new JPanel(new GridBagLayout());
		setPanelSize(containerRight, new Dimension(screenWidth/3, height));
		containerRight.setBackground(Color.WHITE);
		
			JPanel tipsPanel = addTipContainers();
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(20,0,0,10);
			containerRight.add(tipsPanel, gc);
			/////////////////////////////////////////////////
			FormEvent ev = null;
			JPanel trainingMethodPanel = trainingMethodPanels.run(ev);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.fill = GridBagConstraints.BOTH;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(5,0,10,0);
			containerRight.add(trainingMethodPanel, gc);
			/////////////////////////////////////////////////
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,0,0,0);
		container.add(containerLeft, gc);
		
		gc.gridx = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,0,0,0);
		container.add(containerRight, gc);
		
		rootpanel.add(container);
	}

	private void addHeadingAndSubText() {
		
		JPanel content = new JPanel(new GridBagLayout());
		setPanelSize(content, new Dimension(screenWidth, 100));
		content.setBackground(Color.WHITE);
		
		JLabel pageTitle = new JLabel("Step 4.2: Add the training activities to your template. Lets start with the introduction.");
		pageTitle.setFont(pageTitle.getFont().deriveFont(16.0f));
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(15,20,0,0);
		content.add(pageTitle, gc);
		
		
		JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
		setPanelSize(row1, new Dimension(screenWidth, 20));
		row1.setBackground(Color.WHITE);
		
		JTextPane row1Text = new JTextPane();
		row1Text.setFont(row1Text.getFont().deriveFont(11.0f));
		row1Text.setForeground(UI_Settings.getComponentsFontColorDark());
		row1Text.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(row1Text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0);
		
		row1Text.setParagraphAttributes(set, true);

		row1Text.setText("Once you have a general idea of what you need to cover, draft a "
				+ "lesson outline. List all of the points that you need to cover, in the order in which you'll cover them.");

		row1.add(row1Text);
		row1.setAlignmentY(Component.LEFT_ALIGNMENT);
		gc.gridx = 0;
		gc.gridy = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(0,0,0,0);
		content.add(row1, gc);
		
		//////////////////////////
		JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
		setPanelSize(row2, new Dimension(screenWidth, 20));
		row2.setBackground(Color.WHITE);
		
		JTextPane row2Text = new JTextPane();
		row2Text.setFont(row2Text.getFont().deriveFont(11.0f));
		row2Text.setForeground(UI_Settings.getComponentsFontColorDark());
		row2Text.setEditable(false);
		
		set = new SimpleAttributeSet(row2Text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0);
		
		row2Text.setParagraphAttributes(set, true);

		row2Text.setText("Use the 5 E Learning Cycle to link information to trainees existing skills and knowledge. This will help"
				+ " them put it into a personal context, which, in turn, will help them retain it better.");
		
		row2.add(row2Text);
		gc.gridx = 0;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(0,20,0,0);
		content.add(row2,gc);
		content.setAlignmentY(Component.LEFT_ALIGNMENT);
		this.rootpanel.add(content);
	}

	
	private void initializeListeners() {
		
		nextStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		nextStepTextButton.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				 CardLayout cl = (CardLayout)(sessionObject.cards.getLayout());
				 cl.show(sessionObject.cards, Step4ControlCenter.STEP3);
			}
		});
		
		
		previousStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		previousStepTextButton.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				 CardLayout cl = (CardLayout)(sessionObject.cards.getLayout());
				 cl.show(sessionObject.cards, Step4ControlCenter.STEP1);
			}
		});
	}
	
	private void addNextStepRow() {
		
		nextStepTextButton.setFont(nextStepTextButton.getFont().deriveFont(12.0f));
		previousStepTextButton.setFont(previousStepTextButton.getFont().deriveFont(12.0f));

		nextStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());
		previousStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());


		JPanel container = new JPanel();
		container.setBackground(Color.WHITE);
		container.setLayout(new BoxLayout(container, BoxLayout.X_AXIS));
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(previousStepTextButton);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(nextStepTextButton);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		container.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		container.add(rightPanel);
		
		this.rootpanel.add(container);
	}
	
	private JPanel addTipContainers() {
		
		int containerHeight = 170;
		int tipOnecontainerHeight = 170;

		tipOneHeader = new JLabel("Tip 5:");
		tipOneHeader.setFont(tipOneHeader.getFont().deriveFont(14.0f));
		
		tipOneContent.setText("You can use the same tool multiple times throughout the training session. "
				+ "\n\nFor example, if you want to do four case studies just drag and drop the case studies box "
				+ "four times onto the left panel.\n\nRemember though, its important to have a logically flow to "
				+ "your plan - if the activities don’t connect the audience may lose assurance in you as a "
				+ "session trainer and leader");
		
		tipsContainer = new JPanel(new GridBagLayout());
		setPanelSize(tipsContainer, new Dimension(screenWidth/2, containerHeight));
		tipsContainer.setBackground(Color.WHITE);
		
		
		JPanel tipContainer = new JPanel(new GridBagLayout());
		setPanelSize(tipContainer, new Dimension(screenWidth/2, tipOnecontainerHeight));
		tipContainer.setBackground(new Color(242,242,242));
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,15,5,10);
		tipContainer.add(tipOneHeader, gc);
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.insets = new Insets(5,15,5,10);
		tipContainer.add(tipOneContent,gc);
		////////////////////////////////////////////////OK UP/////////////////////////////////////////
		
		return tipContainer;
	}
	
	private void initializeTextPanes(JTextPane textpane) {
		textpane.setFont(textpane.getFont().deriveFont(11.0f));
		textpane.setForeground(UI_Settings.getComponentsFontColorDark());
		textpane.setEditable(false);	
		textpane.setBackground(new Color(242,242,242));
		
		MutableAttributeSet set = new SimpleAttributeSet(textpane.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.3);
		
		textpane.setParagraphAttributes(set, true);
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}

	public void setSelectedCheckBoxes(List<String> selections) {
		this.selections = selections;
		
		//Print the array
        if(selections.isEmpty()){
        	System.out.println("CheckBox array is empty!");
        }else{
        	System.out.println("\n--------------------------------------------------");
        	System.out.println("Recieved populated array. Printing contents ...");
        	System.out.println("--------------------------------------------------\n");

        	trainingMethodPanels.setSelectedCheckBoxes(selections);
        }
	}

}
