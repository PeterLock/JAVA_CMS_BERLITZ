package gui.training.com;

import java.awt.Color;
import java.awt.Dimension;
import java.util.List;

import javax.swing.JPanel;

public class TrainingMethodPanels extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private int height = 800;
	private int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;


	private List<String> selections;

	public TrainingMethodPanels(){
		
	}
	
	private void initialize(){
		
	}
	
	public JPanel run(FormEvent ev){
		initialize();
		
		JPanel container = getPanels();
		setPanelSize(container, new Dimension(screenWidth/3, 570));
		container.setBackground(Color.YELLOW);

		
		return container;
	}

	private JPanel getPanels() {
		
		JPanel container = new JPanel();
		setPanelSize(container, new Dimension());
		
		return container;
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}

	public void setSelectedCheckBoxes(List<String> selections) {
		this.selections = selections;
        for(int i = 0; i < selections.size(); i++){
        	System.out.println("Contains: " + this.selections.get(i));
       }
	}

}
