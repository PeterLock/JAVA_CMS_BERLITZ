package gui.training.com;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.border.Border;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import settings.UI_Settings;
import utilities.JTextFieldLimit;

public class IntroductionPanel extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private GridBagConstraints gc = new GridBagConstraints();
	private int width;
	private int height;
	private JLabel headerLabel;
	
	private String containerFontType = "Courier";
	private int headerHeight = 50;
	
	private JTextArea txtAreaSessionOne;
	private JTextArea txtAreaSessionTwo;
	
	List <JLabel> labels = new ArrayList<JLabel>();
	
	JLabel lblIntroduction = new JLabel("Introduction");
	JLabel lblOutline = new JLabel("Outline Structure");
	JLabel lblBackground = new JLabel("Background Information");
	JLabel session1 = new JLabel("Session notes 1:");
	JLabel session2 = new JLabel("Session notes 2:");

	
	
	private Border border = BorderFactory.createLineBorder(new Color(180,180,180));
	private Color fontcolor = new Color(102,102,102);
	private Color headercolor = new Color(25,120,174);
	
	public IntroductionPanel(int width, int height){
		
		this.width = width/2;
		this.height = height;
		
		initialize();
		
	}

	private void initialize() {
		headerLabel = new JLabel("Introduction");
		headerLabel.setFont(new Font(containerFontType, Font.BOLD, (int)12.0f));

		headerLabel.setForeground(Color.WHITE);
		
		labels.add(lblIntroduction);
		labels.add(lblOutline);
		labels.add(lblBackground);
		labels.add(session1);
		labels.add(session2);

		
		for(int i = 0; i < labels.size(); i++){
			labels.get(i).setForeground(fontcolor);
			labels.get(i).setFont(new Font(containerFontType, Font.PLAIN, (int)11.0f));
		}
		
		txtAreaSessionOne = new JTextArea(8, 20);
		txtAreaSessionOne.setEditable(true);
		txtAreaSessionOne.setBorder(UI_Settings.getBorderoutline());
		txtAreaSessionOne.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaSessionOne.setWrapStyleWord(true);
		txtAreaSessionOne.setLineWrap(true);
		txtAreaSessionOne.setDocument(new JTextFieldLimit(80));
		txtAreaSessionOne.setBorder(border);
		txtAreaSessionOne.setPreferredSize(txtAreaSessionOne.getPreferredSize());
		
		txtAreaSessionTwo = new JTextArea(6, 20);
		txtAreaSessionTwo.setEditable(true);
		txtAreaSessionTwo.setBorder(UI_Settings.getBorderoutline());
		txtAreaSessionTwo.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaSessionTwo.setWrapStyleWord(true);
		txtAreaSessionTwo.setLineWrap(true);
		txtAreaSessionTwo.setDocument(new JTextFieldLimit(80));
		txtAreaSessionTwo.setBorder(border);
		txtAreaSessionTwo.setPreferredSize(txtAreaSessionTwo.getPreferredSize());
	}

	public JPanel run(){
		
		JPanel container = setUpMainContainer();
		
		return container;
	}
	
	private JPanel setUpMainContainer() {
		
		JPanel container = new JPanel();
		container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
		setPanelSize(container, new Dimension(width, height));
		container.setBackground(Color.WHITE);
		
		container.add(getHeaderComponent());
		container.add(Box.createVerticalStrut(3));
		container.add(getAgendaComponent());
		container.add(Box.createVerticalStrut(3));
		container.add(getMainComponent());
		

		return container;
	}

	private Component getMainComponent() {
		
		int containerheight = 450;
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(width, containerheight));
		container.setBackground(Color.WHITE);
		container.setBorder(border);
		
		JPanel northSection = new JPanel(new GridBagLayout());
		setPanelSize(northSection, new Dimension(width, 120));
		northSection.setBackground(Color.WHITE);
		northSection.setBorder(border);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(10,25,5,5);
			northSection.add(lblIntroduction, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			northSection.add(lblOutline, gc);
			
			gc.gridx = 0;
			gc.gridy = 2;
			northSection.add(lblBackground, gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(10,5,5,5);
		container.add(northSection, gc);
		
		JPanel southSection = new JPanel(new GridBagLayout());
		setPanelSize(southSection, new Dimension(width, 300));
		southSection.setBackground(Color.WHITE);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(5,25,5,5);
			southSection.add(session1, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.insets = new Insets(5,5,5,5);
			southSection.add(txtAreaSessionOne, gc);
			
			gc.gridx = 0;
			gc.gridy = 2;
			gc.insets = new Insets(5,25,5,5);
			southSection.add(session2, gc);
			
			gc.gridx = 0;
			gc.gridy = 3;
			gc.insets = new Insets(5,5,5,5);
			southSection.add(txtAreaSessionTwo, gc);
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.insets = new Insets(10,5,5,5);
		container.add(southSection, gc);
		
		
		
		return container;
	}

	private Component getAgendaComponent() {
		
		double height = (int)headerHeight * 1.5;
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(width, (int)height));
		container.setBackground(new Color(242,242,242));
		container.setBorder(border);
		
		JTextPane text = new JTextPane();
		text.setFont(new Font(containerFontType, Font.PLAIN, (int)11.0f));

		text.setForeground(UI_Settings.getComponentsFontColorDark());
		text.setBackground(new Color(242,242,242));
		text.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.5);
		
		text.setParagraphAttributes(set, true);
		text.setText("Open training session: Introduce tutor, outline structure and provide background information");
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(10,5,5,5);
		container.add(text, gc);

		return container;
	}

	private Component getHeaderComponent() {
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(width, headerHeight));
		container.setBackground(headercolor);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,20,0,0);
		container.add(headerLabel, gc);

		
		return container;
	}

	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
}
