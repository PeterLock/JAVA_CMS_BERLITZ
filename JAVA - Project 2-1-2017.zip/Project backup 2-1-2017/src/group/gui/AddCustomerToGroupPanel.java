package group.gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerListModel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import customer.gui.CustomerTableListener;
import customer.gui.FormEvent;
import customer.gui.TablePanel;
import group.controller.Controller;
import group.model.Group;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class AddCustomerToGroupPanel extends JPanel {
	/**
	 * 
	 */
    private group.controller.Controller controller;

	private static final long serialVersionUID = 1L;
	UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	TextPrompt textPrompt;
	Boolean ignoreEvents = false;
	
    private TablePanel addnew_table_panel = new TablePanel();
    private TablePanel viewAllCustomersTable = new TablePanel();

	private JPasswordField passwordField;
    private JFrame controllingFrame; 
	
    private JPanel threeDotsPanel;
    private JPanel containerPanel;
    private JPanel container;
	private JPanel container_left;
	private JPanel container_right;
	private JPanel groupAddingToDetailsPanel;
	private JPanel pnlTopGroupDetails;
	private JPanel canvas;
	private JPanel detailsPanel;
	private JPanel centerPanel;
	private JPanel cards; 
	private JPanel card1;
	private JPanel card2;
	
	private JPanel cardsButtons;
	private JPanel cardsNCButtonsPanel;
	private JPanel cardsECButtonsPanel;
	
	private JTextField txtLastName;
	private JTextField txtFirstName;
	private JTextField txtMaterial;
	private JTextField txtPositionsAvailable;
	private JTextField txtListen;
	private JTextField txtSpeak;
	private JTextField txtRead;
	private JTextField txtParticipate;
	private JTextField txtCooperate;
	private JTextField txtViewFirstName;
	private JTextField txtViewLastName;
	private JTextField txtViewCustomerID;
	private JTextField txtViewGroupName;
	private JTextField txtViewGroupID;
	private JTextField txtViewGroupPos;
	private JTextField txtViewGroupLevel;
	private JTextField txtViewGroupDay;
	private JTextField txtViewGroupTime;
	private JTextField txtViewGroupMaterial;
	private JTextField txtViewGroupMinimumClassSize;
	private JTextField txtViewGroupCurrentClassSize;
	private JTextField txtViewGroupMaximumClassSize;
	
	private SpinnerListModel listeningModel;
	private SpinnerListModel speakingModel;
	private SpinnerListModel readingModel;
	private SpinnerListModel rarticipationModel;
	private SpinnerListModel cooperationModel;

	private JButton btnAddCustomerToGroup;
	private JButton btnSearch;
	
	private JTextArea txtStudentListDisplayArea;
	private JTextArea txtAreaMemberNames;
	
	private final String NEW_CUSTOMER_PANEL = "New Customer";
	private final String EXISTING_CUSTOMER_PANEL = "Existing Customer";
	private final String NEW_CUSTOMER_PANEL_BUTTONS = "New Customer Buttons";
	private final String EXISTING_CUSTOMER_PANEL_BUTTONS = "Existing Customer Buttons";
	
	private JCheckBox chkNewStudent;
	private JCheckBox chkExistingStudent;
	
	private List <JTextField> textfieldsViewGroupDetails = new ArrayList<JTextField>();
	private List <JTextField> regular_textfields = new ArrayList<JTextField>();
	private List<JCheckBox> checkboxes = new ArrayList<JCheckBox>();
	@SuppressWarnings("rawtypes")
	private List<JComboBox> comboboxes = new ArrayList<JComboBox>();
	
	private JTextArea txtAreaComments;
	private JTextArea txtAreaInterests;
	
	private Calendar c = Calendar.getInstance();
	private JLabel lblDate = new JLabel(c.getTime().toString());
	
	private JComboBox<String> cmbMaterial = new JComboBox<String>(UI_Settings.getBooks());
	private JComboBox<String> cmbLevel = new JComboBox<String>(UI_Settings.getLevels());
	private JComboBox<String> cmbMonths = new JComboBox<String>(UI_Settings.getMonths());
	
	private Border lightBorder = BorderFactory.createLineBorder(new Color(192,192,192));

    @SuppressWarnings("rawtypes")
	private DefaultComboBoxModel model = new DefaultComboBoxModel();
	private JComboBox<String> cmbGroupNameListCombobox = new JComboBox<String>();
	
	
	public AddCustomerToGroupPanel(group.controller.Controller controller, DefaultComboBoxModel model){
		
		this.model = model;
		
		try {
			populateComboBoxes();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		int tableWindowHeight = 0;
		int tableRowNumber = 0;
		
		this.controller = controller;
		
		tableWindowHeight = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height/9;
		tableRowNumber = tableWindowHeight/UI_Settings.getTableRowHeight();
		
		controller.setCustomerRowNumber(tableRowNumber);
		addnew_table_panel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		addnew_table_panel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		addnew_table_panel.setData(group.controller.Controller.getCustomer(GET_ADDNEW_TABLE_CUSTOMER_LIST));
		
    	for(int i = 0; i < 6; i++){
    		FormEvent ev = new FormEvent(this, "", "", 13, "", "", 0);
    		if(controller != null){
        		this.controller.addCustomer(ev);
    		}
    	}
    	
		addnew_table_panel.setCustomerTableListener(new CustomerTableListener() {
			
			@Override
			public void rowDeleted(int row) {
				controller.removeCustomer(row, 2);
			}
		});
		
		
		viewAllCustomersTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		viewAllCustomersTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		viewAllCustomersTable.setData(group.controller.Controller.getCustomer(GET_VIEWALL_TABLE_CUSTOMER_LIST));
		
    	for(int i = 0; i < 6; i++){
    		FormEvent ev = new FormEvent(this, "", "", 13, "", "", 0);
    		if(controller != null){
        		this.controller.addEmptyCustomer(ev);
    		}
    	}
    	
    	viewAllCustomersTable.setCustomerTableListener(new CustomerTableListener() {
			
			@Override
			public void rowDeleted(int row) {
				controller.removeCustomer(row, 2);
			}
		});
	}

	public Component run(){
		JScrollPane scroller = initialize();
		return scroller;
	}

	@SuppressWarnings("unused")
	private JScrollPane initialize() {
		
		int topFrameHeight = 210;
		int centerTopHeight = 50;
		int bottomFrameHeight = 200;
		int view_textfield_size = 13;
		
		//////////////Initialize View Group Fields///////////////
		btnAddCustomerToGroup = new JButton("Commit Changes");
		btnAddCustomerToGroup.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnAddCustomerToGroup.setFont(UI_Settings.getComponentInputFontSize());
		btnAddCustomerToGroup.setPreferredSize(new Dimension(180,UI_Settings.getJbuttonSize().height));
		btnAddCustomerToGroup.setMinimumSize(new Dimension(180,UI_Settings.getJbuttonSize().height));
						
		int marker;

		btnAddCustomerToGroup.addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
			//On mouse press check for and if needed add a new customer to the database//
				if(chkNewStudent.isSelected()){
					
					FormEvent ev = addNewCustomer();
					if(ev !=null){
						txtViewFirstName.setText(ev.getFirstname());
						txtViewLastName.setText(ev.getLastname());
						txtViewCustomerID.setText(String.valueOf(ev.getId()));
					}
				}
				
				if(chkExistingStudent.isSelected()){
					searchCustomers();
				}
			}
			
			public void mouseReleased(MouseEvent e){
				
			}
		});
		
		
		JPasswordField passwordField;
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
        addFocus(passwordField);
		
		JLabel lblCloseWindow = new JLabel("close panel group [x]");
		lblCloseWindow.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
		JLabel lblCloseWindow2 = new JLabel("close panel group [x]");
		lblCloseWindow2.setForeground(Color.BLACK);
		lblCloseWindow2.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
		JCheckBox under_eight = new JCheckBox("4-8");
		JCheckBox eight_twelve = new JCheckBox("8-12");
		JCheckBox twelve_sixteen = new JCheckBox("12-16");
		JCheckBox sixteen_twentyfour = new JCheckBox("16-24");
		JCheckBox twentyfour_up = new JCheckBox("24 >");
		
		checkboxes.add(under_eight);
		checkboxes.add(eight_twelve);
		checkboxes.add(twelve_sixteen);
		checkboxes.add(sixteen_twentyfour);
		checkboxes.add(twentyfour_up);
		
		configure_checkboxes_age();

		
		for(int i = 0; i < checkboxes.size(); i++){
			checkboxes.get(i).setFont(UI_Settings.getComponentsFontPlain());
			checkboxes.get(i).setForeground(UI_Settings.getComponentsFontColorLight());
			checkboxes.get(i).setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		}
		
		
		cards = new JPanel(new CardLayout());
		cardsButtons = new JPanel(new CardLayout());
		
		btnSearch = new JButton("Search");
		btnSearch.setCursor(UI_Settings.getJlabelCursor());
		btnSearch.setPreferredSize(UI_Settings.getJbuttonSize());
		btnSearch.setFont(UI_Settings.getComponentInputFontSize());
		
		
		txtStudentListDisplayArea = new JTextArea(7, 20);
		txtStudentListDisplayArea.setEditable(true);
		txtStudentListDisplayArea.setBorder(UI_Settings.getBorderoutline());
		txtStudentListDisplayArea.setWrapStyleWord(true);
		txtStudentListDisplayArea.setLineWrap(true);
		txtStudentListDisplayArea.setDocument(new JTextFieldLimit(150));
		txtStudentListDisplayArea.setPreferredSize(txtStudentListDisplayArea.getPreferredSize());
		/***************************************************Create labels***********************************************************************/
		JLabel failedMessage1 = new JLabel(UI_Settings.getFailedMessage());
		failedMessage1.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage1.setVisible(false);
		
		JLabel failedMessage2 = new JLabel(UI_Settings.getFailedMessage());
		failedMessage2.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage2.setVisible(false);
		
		JLabel labels[] = new JLabel[11];
		
		labels[0] = new JLabel("generate");
		labels[1] = new JLabel("reset fields");
		labels[2] = new JLabel("...");
		labels[3] = new JLabel("show assessment details");
		labels[4] = new JLabel("Assessment details (optional)");
		labels[5] = new JLabel("edit");
		labels[6] = new JLabel("clear table");
		labels[7] = new JLabel("reset local fields");
		labels[8] = new JLabel("hint");
		labels[9] = new JLabel("edit");
		labels[10] = new JLabel("clear table");
		
		
		for(int i = 0; i < 11; i++) {
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());	
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		
		labels[2].setFont(labels[1].getFont().deriveFont(18.0f));
		labels[2].setVisible(true);
		labels[2].addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				threeDotsPanel.setVisible(false);
				containerPanel.setVisible(true);
				container_left.setVisible(true);
				container_right.setVisible(true);
			}
		});
		
		/********************************************************Text Areas*************************************************************/
		txtAreaComments = new JTextArea(3, 42);
		txtAreaComments.setEditable(true);
		txtAreaComments.setBorder(UI_Settings.getBorderoutline());
		txtAreaComments.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaComments.setWrapStyleWord(true);
		txtAreaComments.setLineWrap(true);
		txtAreaComments.setDocument(new JTextFieldLimit(150));
		txtAreaComments.setBorder(lightBorder);
		txtAreaComments.setPreferredSize(txtAreaComments.getPreferredSize());
		TextPrompt prompt = new TextPrompt("<no comments added>", txtAreaComments);
		
		
		txtAreaInterests = new JTextArea(3, 42);
		txtAreaInterests.setEditable(true);
		txtAreaInterests.setBorder(UI_Settings.getBorderoutline());
		txtAreaInterests.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaInterests.setWrapStyleWord(true);
		txtAreaInterests.setLineWrap(true);
		txtAreaInterests.setDocument(new JTextFieldLimit(150));
		txtAreaInterests.setBorder(lightBorder);
		txtAreaInterests.setPreferredSize(txtAreaInterests.getPreferredSize());
		prompt = new TextPrompt("<no interests added>", txtAreaInterests);
		
		/*********************************************Add the Bottom Panel TextFields***********************/
		int size = 13;
		
		txtViewFirstName = new JTextField(size);
		txtViewLastName = new JTextField(size);
		txtViewGroupName = new JTextField(size);
		txtViewGroupID = new JTextField(size);
		txtViewGroupPos = new JTextField(size);
		txtViewGroupLevel = new JTextField(size);
		txtViewGroupDay = new JTextField(size);
		txtViewGroupTime = new JTextField(size);
		txtViewGroupMaterial = new JTextField(size);
		
		txtViewGroupMaximumClassSize = new JTextField(size);
		txtViewGroupCurrentClassSize = new JTextField(size);
		txtViewGroupMinimumClassSize = new JTextField(size);
		
		txtFirstName = new JTextField(10);
		txtLastName = new JTextField(10);
		txtPositionsAvailable = new JTextField(5);
		txtMaterial = new JTextField(15);
		txtViewCustomerID = new JTextField(5);

		
		initializeViewGroupTextFields(txtViewFirstName);
		initializeViewGroupTextFields(txtViewLastName);
		initializeViewGroupTextFields(txtViewGroupName);
		initializeViewGroupTextFields(txtViewGroupID);
		initializeViewGroupTextFields(txtViewGroupPos);
		initializeViewGroupTextFields(txtViewGroupLevel);
		initializeViewGroupTextFields(txtViewGroupDay);
		initializeViewGroupTextFields(txtViewGroupTime);
		initializeViewGroupTextFields(txtViewGroupMaximumClassSize);
		initializeViewGroupTextFields(txtViewGroupMaterial);
		
		initializeViewGroupTextFields(txtViewGroupMaximumClassSize);
		initializeViewGroupTextFields(txtViewGroupCurrentClassSize);
		initializeViewGroupTextFields(txtViewGroupMinimumClassSize);
		
		initializeViewGroupTextFields(txtFirstName);
		initializeViewGroupTextFields(txtLastName);
		initializeViewGroupTextFields(txtPositionsAvailable);
		initializeViewGroupTextFields(txtMaterial);
		initializeViewGroupTextFields(txtViewCustomerID);

		
		txtViewFirstName.setEditable(false);
		txtViewLastName.setEditable(false);
		
		
		//TextPrompt textPrompt8 = new TextPrompt(prompt2, txtViewGroupMat);
		//textprompts.add(textPrompt8);
		/////////////////////////////////////////////////////////////
		txtListen = new JTextField(8);
		txtSpeak = new JTextField(8);
		txtRead = new JTextField(8);
		txtParticipate = new JTextField(8);
		txtCooperate = new JTextField(8);
		
		initializeRegularTextFields(txtListen);
		initializeRegularTextFields(txtSpeak);
		initializeRegularTextFields(txtRead);
		initializeRegularTextFields(txtParticipate);
		initializeRegularTextFields(txtCooperate);
		
		
		//Add the focus listener for this field//
		txtFirstName.addFocusListener(new FocusListener(){

			@Override
			public void focusGained(FocusEvent e) {
				txtViewFirstName.setText("");
			}

			@Override
			public void focusLost(FocusEvent e) {
				txtViewFirstName.setText(txtFirstName.getText());
				
				if(txtViewCustomerID.getText().isEmpty()){
					int temp = idGenerator.getUniqueCustomerID();
					txtViewCustomerID.setText(String.valueOf(temp));
				}
				
				if(txtViewFirstName.getText().isEmpty() && txtViewLastName.getText().isEmpty()){
					txtViewCustomerID.setText("");
				}
				
			}
		});
		
		txtLastName.addFocusListener(new FocusListener(){

			@Override
			public void focusGained(FocusEvent e) {
				txtViewLastName.setText("");
				txtViewCustomerID.setText("");
			}

			@Override
			public void focusLost(FocusEvent e) {
				txtViewLastName.setText(txtLastName.getText());
				
				if(txtViewCustomerID.getText().isEmpty()){
					int temp = idGenerator.getUniqueCustomerID();
					txtViewCustomerID.setText(String.valueOf(temp));
				}
				
				if(txtViewFirstName.getText().isEmpty() && txtViewLastName.getText().isEmpty()){
					txtViewCustomerID.setText("");
				}
				
			}
		});
		/*********************************************************Create the Combo Boxes*********************************************************/
		
		initializeComboBoxes(cmbMaterial);
		initializeComboBoxes(cmbLevel);
		initializeComboBoxes(cmbMonths);
		initializeComboBoxes(cmbGroupNameListCombobox);

		cmbGroupNameListCombobox.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	        	
	        	
	        	if(cmbGroupNameListCombobox.getSelectedIndex()==-1){
	        		System.out.println("Selected combo index is -1, returning"); 
	        		return;
	        	}
	        	
				Group group = Controller.searchGroup(cmbGroupNameListCombobox.getSelectedItem().toString());
				
				//Populate group form with the returned group data//
				txtViewGroupName.setText(group.getGroupName());
				txtViewGroupID.setText(String.valueOf(group.getId()));
				
				//Convert currentClassSize and maxClassSize to number format//
				int current = Integer.parseInt(group.getCurrentClassSize());
				int maximum = Integer.parseInt(group.getMaxClassSize());
				int positions_available = maximum - current;
				
				txtViewGroupPos.setText(String.valueOf(positions_available));
				txtViewGroupLevel.setText(group.getLevel());
				txtViewGroupDay.setText(getDayString(group));
				txtViewGroupTime.setText(group.getTime());
				txtViewGroupCurrentClassSize.setText(group.getCurrentClassSize());
				txtViewGroupMaterial.setText(group.getGroupMaterial());
						
	        }

			private String getDayString(Group group) {
				
				if(group.getDay().equals("Mon"))return "Monday";
				if(group.getDay().equals("Tue"))return "Tuesday";
				if(group.getDay().equals("Wed"))return "Wednesday";
				if(group.getDay().equals("Thu"))return "Thursday";
				if(group.getDay().equals("Fri"))return "Friday";
				if(group.getDay().equals("Sat"))return "Saturday";
				if(group.getDay().equals("Sun"))return "Sunday";

				
				return "Unknown data format";
			}
	    });
		
		comboboxes.add(cmbGroupNameListCombobox);
		comboboxes.add(cmbLevel);
		comboboxes.add(cmbMaterial);
		comboboxes.add(cmbMonths);
		
		/**********************************Create CheckBoxes***********************************/
		chkExistingStudent = new JCheckBox("Existing Customer");
		chkNewStudent = new JCheckBox("New Customer");
		
		chkNewStudent.setFont(UI_Settings.getComponentsFontPlain());
		chkNewStudent.setForeground(UI_Settings.getComponentsFontColorLight());
		chkNewStudent.setSelected(true);
		chkNewStudent.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e) {
				if(chkNewStudent.isSelected()==true){
					chkExistingStudent.setSelected(false);
					containerPanel.setVisible(true);
					threeDotsPanel.setVisible(false);

					
					CardLayout cl = (CardLayout)(cards.getLayout());
					cl.show(cards, NEW_CUSTOMER_PANEL);
					
					CardLayout cl2 = (CardLayout)(cardsButtons.getLayout());
					cl2.show(cardsButtons, NEW_CUSTOMER_PANEL_BUTTONS);
					
				}
			}
		});
		
		chkExistingStudent.setFont(UI_Settings.getComponentsFontPlain());
		chkExistingStudent.setForeground(UI_Settings.getComponentsFontColorLight());
		chkExistingStudent.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				if(chkExistingStudent.isSelected()==true){
					chkNewStudent.setSelected(false);
					threeDotsPanel.setVisible(true);
					
					containerPanel.setVisible(false);
					
					CardLayout cl = (CardLayout)(cards.getLayout());
					cl.show(cards, EXISTING_CUSTOMER_PANEL);
					
					CardLayout cl2 = (CardLayout)(cardsButtons.getLayout());
					cl2.show(cardsButtons, EXISTING_CUSTOMER_PANEL_BUTTONS);
					
				}				
			}
		});
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		////////////////Reset button  on card layout 2/////////////
		labels[1].addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){

				for(int i = 0; i < textfieldsViewGroupDetails.size(); i++){
					textfieldsViewGroupDetails.get(i).setText("");
				}
				
				for(int i = 0; i < comboboxes.size(); i++){
					comboboxes.get(i).setSelectedIndex(-1);
				}
				
				for(int i = 0; i < regular_textfields.size(); i++){
					regular_textfields.get(i).setText("");
				}
				
				clearTableData();
		       
			}
		});
		////////////////Reset button  on card layout 2/////////////
		labels[2].addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				container.setVisible(true);
				
			}
		});
		
		/******************************************************Add the Buttons Panel************************************************/
		cardsNCButtonsPanel = new JPanel();
		
		cardsNCButtonsPanel.setLayout(new BoxLayout(cardsNCButtonsPanel, BoxLayout.X_AXIS));
		cardsNCButtonsPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		cardsNCButtonsPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		cardsNCButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel ncLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		ncLeftPanel.setBackground(Color.WHITE);
		ncLeftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ncLeftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ncLeftPanel.add(failedMessage1);
		
		
		JPanel ncRightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		ncRightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		ncRightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ncRightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ncRightPanel.add(labels[1]);
		
		ncLeftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		cardsNCButtonsPanel.add(ncLeftPanel);
		
		ncRightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		cardsNCButtonsPanel.add(ncRightPanel);
		
		
		cardsECButtonsPanel = new JPanel();
		cardsECButtonsPanel.setBackground(UI_Settings.getButtonPanelColor());
		cardsECButtonsPanel.setLayout(new BoxLayout(cardsECButtonsPanel, BoxLayout.X_AXIS));
		cardsECButtonsPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		cardsECButtonsPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		cardsECButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel ecLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		ecLeftPanel.setBackground(Color.WHITE);
		ecLeftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ecLeftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ecLeftPanel.add(failedMessage2);
		//leftPanel.add();
		
		JPanel ecRightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 2));
		ecRightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		ecRightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ecRightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ecRightPanel.add(labels[2]);
		ecRightPanel.add(btnSearch);

		
		ecLeftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		cardsECButtonsPanel.add(ecLeftPanel);
		
		ecRightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		cardsECButtonsPanel.add(ecRightPanel);
		

		
		cardsNCButtonsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsECButtonsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsNCButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsECButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
	
		cardsButtons.add(cardsNCButtonsPanel, NEW_CUSTOMER_PANEL_BUTTONS);
		cardsButtons.add(cardsECButtonsPanel, EXISTING_CUSTOMER_PANEL_BUTTONS );
		
		
		
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/***********************************     **Create edit, delete, table header and print panels***************************************/
		JPanel addGroupTableButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		addGroupTableButtonPanel.add(new JLabel("Positions Available"));//Positions available label
		addGroupTableButtonPanel.setBackground(UI_Settings.getButtonPanelColor());
		addGroupTableButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		addGroupTableButtonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		
		JPanel showAllCustomersButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		showAllCustomersButtonPanel.add(labels[3]);//Show assessment details label
		showAllCustomersButtonPanel.setBackground(UI_Settings.getButtonPanelColor());
		showAllCustomersButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		showAllCustomersButtonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		
		
		/**********************Create the messages panel***********************/

		JPanel headingTitle = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		JLabel lblHeading = new JLabel("Adding customers to a group");
		lblHeading.setFont(lblHeading.getFont().deriveFont(16.0f));

		headingTitle.setBackground(Color.WHITE);
		headingTitle.add(lblHeading);
		
		JPanel headingMessage = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		headingMessage.setBackground(Color.WHITE);
		JLabel lblHeadingMessage = new JLabel("Adding customers to a group is simple. To add a customer select new or existing, enter the necesary\n"
				+ "informtion, choose a group and hit commit. ");
		
		headingMessage.add(lblHeadingMessage);
		
		/****************************Create the canvas**************************/
		
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) );
		
		GridBagConstraints gc = new GridBagConstraints();

		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(UI_Settings.getButtonPanelColor());
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		detailsPanel.setLayout(new GridBagLayout());
		
		/****************************Create the header**************************/
		JPanel messageHeader = new JPanel(new GridBagLayout());
		setPanelSize(messageHeader, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 160));
		messageHeader.setBackground(Color.WHITE);
		messageHeader.add(headingTitle);
		messageHeader.add(headingMessage);
		messageHeader.add(detailsPanel);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(1,0,0,0);
		messageHeader.add(headingTitle,gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(-10,0,0,0);
		messageHeader.add(headingMessage, gc);
	
		gc.gridy = 2;
		gc.insets = new Insets(0,0,0,0);
		messageHeader.add(detailsPanel, gc);
		/**********************************************************Card layout for the details panel********************************************************/
		//Contains the Add New Student and Existing Student CheckBoxes
		JPanel checkBoxesPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		checkBoxesPanel.setBackground(Color.WHITE);
		checkBoxesPanel.add(chkNewStudent);
		checkBoxesPanel.add(chkExistingStudent);
		checkBoxesPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableButtonsPanelHeight()+10));
		checkBoxesPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableButtonsPanelHeight()+10));

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 10;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,15,0);
		
		detailsPanel.add(checkBoxesPanel, gc);
		/////////////////////////////////////////////////////Card 1 - New Customer//////////////////////////////////////////////
		
		gc.gridx = 0;
		gc.gridy = 2;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-16,10,16,10);
		detailsPanel.add(new JLabel("Customer Name:"), gc); //Customer name label
		
		//////////////////////////////////////////Begin Column 2 ///////////////////////////////////////////
		gc.gridx = 1;
		gc.gridy = 1;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(-12,12,12,-12);
		detailsPanel.add(new JLabel("First Name"), gc); //FirstName Label

		gc.gridx = 1;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-12,5,12,5);
		detailsPanel.add(txtFirstName, gc); //FirstName TextField
		
		//////////////////////////////////////////Begin Column 3 ///////////////////////////////////////////
		gc.gridx = 2;
		gc.gridy = 1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(-12,5,12,5);
		detailsPanel.add(new JLabel("Last Name"), gc); //Last Name Label

		gc.gridx = 2;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-12,5,12,5);
		detailsPanel.add(txtLastName, gc); //Last Name TextField
		//////////////////////////////////////////Begin Column 4///////////////////////////////////////////	
		gc.gridx = 3;
		gc.gridy = 2;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-16,5,16,5);
		detailsPanel.add(new JLabel("Month Started:"), gc); //Month started label
		//////////////////////////////////////////Begin Column 5///////////////////////////////////////////	

		gc.gridx = 4;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-13,5,13,5);
		detailsPanel.add(cmbMonths, gc); //Month started combo
		//////////////////////////////////////////Begin Column 6///////////////////////////////////////////		

		
		gc.gridx = 5;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-16,5,16,5);
		detailsPanel.add(new JLabel("Material:"), gc); //Material label
		//////////////////////////////////////////Begin Column 7///////////////////////////////////////////		

		gc.gridx = 7;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,5,13,5);
		detailsPanel.add(cmbMaterial, gc); //Materials Title ComboBox
		//////////////////////////////////////////Begin Column 8///////////////////////////////////////////	

		gc.gridx = 8;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-16,5,16,5);
		detailsPanel.add(new JLabel("Level:"), gc); //Level label
		//////////////////////////////////////////Begin Column 9///////////////////////////////////////////	
		gc.gridx = 9;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-14,5,14,5);
		detailsPanel.add(cmbLevel, gc); //Level combo
		

		////////////////////////////////////////////////////////Create the Card Layout for the details panel/////////////////////////////////////////////////////////////////////////////////////
		card1 = new JPanel(new GridBagLayout());
		card2 = new JPanel(new GridBagLayout());
		
		int cardsHeight = 6;
		card1.setBackground(Color.PINK);
		
		card1.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		card2.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		cards.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		
		card1.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		card2.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		cards.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		
		////////////////////////////////////////////////////CARDS 1/////////////////////////////////////////////////////////////
		gc.gridx = 0;
		gc.gridy = 6;
		gc.gridheight = 5;
		gc.gridwidth = 10;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(2,0,-2,0);
		gc.fill = GridBagConstraints.BOTH;
		card1.add(addnew_table_panel, gc); //View all customers table list	
		////////////////////////////////////////////////////CARDS 2/////////////////////////////////////////////////////////////
		btnSearch.addMouseListener(new MouseAdapter(){
			
			private String firstname;
			private String lastname;
			private String month;
			private String material;
			private String level;
			
			public void mousePressed(MouseEvent e) {

				firstname = txtFirstName.getText();
				lastname = txtLastName.getText();
				month = (String) cmbMonths.getSelectedItem();
				material = (String) cmbMaterial.getSelectedItem();
				level = (String)cmbLevel.getSelectedItem();
				
				
				controller.search(firstname, lastname, month, material, level);
				viewAllCustomersTable.refresh();
				
				}
			
			public void mouseReleased(MouseEvent e){
				
				if(checkValues()){
					
					
					
					for(int i = 0; i < comboboxes.size(); i++){
						comboboxes.get(i).getEditor().getEditorComponent().setBackground(Color.WHITE);
					}
					
					
				}
			}

			private boolean checkValues() {
				
				if(firstname.isEmpty() && lastname.isEmpty() && month.isEmpty() && material.isEmpty() && level == null){
					
					failedMessage2.setVisible(true);
					
					for(int i = 0; i < comboboxes.size()-1; i++){
						comboboxes.get(i).getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
					}
					
					
					JOptionPane.showMessageDialog(AddCustomerToGroupPanel.this, UI_Settings.getDlgSearchExistingStudentFail(), "", JOptionPane.WARNING_MESSAGE);
					return false;
				}
				failedMessage2.setVisible(false);
				return true;
			}
	
		});
		gc.gridx = 0;
		gc.gridy = 6;
		gc.gridheight = 5;
		gc.gridwidth = 10;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(2,0,-2,0);
		gc.fill = GridBagConstraints.BOTH;
		card2.add(viewAllCustomersTable, gc); //View all customers table list
		/////////////////////////////////////////////Add the Cards to the details panel///////////////////////////////////////
		card1.setBackground(Color.WHITE);
		card2.setBackground(Color.WHITE);
		
		cards.add(card1, NEW_CUSTOMER_PANEL);
		cards.add(card2, EXISTING_CUSTOMER_PANEL);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 10;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(30,0,-30,0);
		
		/*
		 * Add the edit and delete text buttons on a split screen - for future use
		 * 
		 */
		
		JPanel editdeletePanel = new JPanel();
		editdeletePanel.setBackground(UI_Settings.getButtonPanelColor());
		editdeletePanel.setLayout(new BoxLayout(editdeletePanel, BoxLayout.X_AXIS));
		editdeletePanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-10));
		editdeletePanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-10));
		editdeletePanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-10));

		
		JPanel edLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		edLeft.setBackground(Color.WHITE);
		edLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		edLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		
		JPanel edRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
		edRight.setBackground(Color.WHITE);
		edRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		edRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		edRight.add(labels[10]);

		
		edLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		editdeletePanel.add(edLeft);
		
		edRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		editdeletePanel.add(edRight);

		
		int container_height = 200;
		container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, container_height-10));
		container.setBackground(Color.WHITE);
		
		container_left = new JPanel(new GridBagLayout());
		container_left.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, container_height-20));
		container_left.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, container_height-20));
		container_left.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, container_height-20));
		container_left.setBorder(lightBorder);

		
		container_left.setBackground(Color.WHITE);
		lblCloseWindow.addMouseListener(new MouseAdapter(){
			
			public void mouseReleased(MouseEvent e){
				containerPanel.setVisible(false);
				threeDotsPanel.setVisible(true);
			}
			
		});
		Dimension dimension = new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getPopupHeaderHeight());
		JPanel header = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
		header.setBorder(new EmptyBorder(0,0,0,0));
		header.setBackground(new Color(191,210,236));
		setPanelSize(header, dimension);
		header.add(lblCloseWindow);
			
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		container_left.add(header, gc);
		
		JPanel container_left_body = new JPanel(new GridBagLayout());
		setPanelSize(container_left_body, new Dimension(dimension.width, container_height-50-UI_Settings.getPopupHeaderHeight()));
		container_left_body.setBackground(Color.WHITE);
		
			////////////////////////////CONTAINER LEFT BODY/////////////////////////
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.1;
			gc.weighty = 0.1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(5,20,0,20);
			container_left_body.add(new JLabel("Listening:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(5,10,0,20);
			container_left_body.add(txtListen, gc);
			
			gc.gridx = 0;
			gc.gridy = 2;
			gc.fill = GridBagConstraints.NONE;
			gc.insets = new Insets(2,20,0,20);
			container_left_body.add(new JLabel("Speaking:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 2;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(2,10,0,20);
			container_left_body.add(txtSpeak, gc);
		
			gc.gridx = 0;
			gc.gridy = 3;
			gc.fill = GridBagConstraints.NONE;
			gc.insets = new Insets(2,20,0,20);
			container_left_body.add(new JLabel("Reading:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 3;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(2,10,0,20);
			container_left_body.add(txtRead, gc);
			
			gc.gridx = 0;
			gc.gridy = 4;
			gc.fill = GridBagConstraints.NONE;
			gc.insets = new Insets(2,20,0,20);
			container_left_body.add(new JLabel("Participation:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 4;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(2,10,0,20);
			container_left_body.add(txtParticipate, gc);
			
			gc.gridx = 0;
			gc.gridy = 5;
			gc.fill = GridBagConstraints.NONE;
			gc.insets = new Insets(2,20,5,20);
			container_left_body.add(new JLabel("Cooperation:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(2,10,5,20);
			container_left_body.add(txtCooperate, gc);
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		container_left.add(container_left_body, gc);
		
		
		
		container_right = new JPanel(new GridBagLayout());
		setPanelSize(container_right, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, container_height-20));
		container_right.setBackground(Color.WHITE);
		container_right.setBorder(lightBorder);

		
		lblCloseWindow2.addMouseListener(new MouseAdapter(){
			
			public void mouseReleased(MouseEvent e){
				
				containerPanel.setVisible(false);
				threeDotsPanel.setVisible(true);
			}
			
		});
		
		JPanel header2 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
		header2.setBorder(new EmptyBorder(0,0,0,0));
		header2.setBackground(new Color(191,210,236));
		setPanelSize(header2, dimension);
		header2.add(lblCloseWindow2);
			
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		container_right.add(header2, gc);
		
		
		////////////////////////////CONTAINER RIGHT BODY/////////////////////////
		
		JPanel customerAgePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 30, 0));
		customerAgePanel.setBackground(Color.WHITE);
		customerAgePanel.add(new JLabel("Age:"));

		customerAgePanel.add(checkboxes.get(0));//age 4-8
		customerAgePanel.add(checkboxes.get(1));//age 8-12
		customerAgePanel.add(checkboxes.get(2));//age 12-16
		customerAgePanel.add(checkboxes.get(3));//age 16-24
		customerAgePanel.add(checkboxes.get(4));//age 24>
	
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 2;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,5,0,5);
		container_right.add(customerAgePanel, gc);
		
		
		JPanel container_right_body = new JPanel(new GridBagLayout());
		setPanelSize(container_right_body, new Dimension(dimension.width, container_height-50-UI_Settings.getPopupHeaderHeight()));
		container_right_body.setBackground(Color.WHITE);
		
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(-15,30,5,5);
			container_right_body.add(new JLabel("Interests:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(10,5,5,15);
			container_right_body.add(txtAreaInterests, gc);
			
			gc.gridx = 0;
			gc.gridy = 2;
			gc.gridheight = 1;
			gc.gridwidth = 2;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.CENTER;
			gc.insets = new Insets(-25,30,5,5);
			container_right_body.add(new JLabel("Comments:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 2;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(-5,5,5,15);
			container_right_body.add(txtAreaComments, gc);
			
			
		gc.gridx = 0;
		gc.gridy = 2;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		container_right.add(container_right_body, gc);

		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(3,5,0,0);
		container.add(container_left, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(3,10,0,10);
		container.add(container_right, gc);
		
		//Add the contents of the bottom panel, the group details
		pnlTopGroupDetails = new JPanel(new GridBagLayout());
		setPanelSize(pnlTopGroupDetails, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
		pnlTopGroupDetails.addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				if(e.getButton() == MouseEvent.BUTTON3){
					
					System.err.println("Popup selected");

				}
				
			}
			
		});
		
		/******************************************************Add the Buttons Panel************************************************/
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 2));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
	
		leftPanel.add(new JLabel("Select the group you want to add the student to:"));
		leftPanel.add(cmbGroupNameListCombobox);
		
		
		threeDotsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 3));
		threeDotsPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		threeDotsPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		threeDotsPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		threeDotsPanel.add(labels[2]);
		threeDotsPanel.setVisible(false);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		threeDotsPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(threeDotsPanel);
		
		/*****************************************************Add the group details and member list panel***********************************/
		//////////////////////////////////////////////////////////////////////////////////////
		groupAddingToDetailsPanel = new JPanel(new GridBagLayout());
		setPanelSize(groupAddingToDetailsPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		
		JPanel pnlCenterTopLeft = new JPanel(new GridBagLayout());
		setPanelSize(pnlCenterTopLeft, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		
		Border darkBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY);

			//add components to the left panel
			pnlCenterTopLeft.setBorder(darkBorder);
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(30,10,0,0);
			pnlCenterTopLeft.add(new JLabel("Click on the students name to select:"), gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,10,20,10);
			pnlCenterTopLeft.add(txtStudentListDisplayArea, gc);
			
		JPanel pnlCenterTopRight = new JPanel(new GridBagLayout());
		setPanelSize(pnlCenterTopRight, new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setBackground(Color.WHITE);

			JPanel pnlCenterTopRightTop = new JPanel(new GridBagLayout());
			setPanelSize(pnlCenterTopRightTop, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setBackground(Color.WHITE);

				//Add the contents of this panel - the student name and the student age plus buttons
				//Add the student name panel//
			
				Color moveCustomerColor = Color.WHITE;
				Color moveCustomerColor2 = new Color(246,246,246);

				JPanel studentDetailsPanel = new JPanel(new GridBagLayout());
				setPanelSize(studentDetailsPanel, new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				studentDetailsPanel.setBorder(darkBorder);
				studentDetailsPanel.setBackground(moveCustomerColor2);
					//Add student name fields//
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 0.2;
					gc.weighty = 0.2;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,10,0,0);
					studentDetailsPanel.add(new JLabel("Customer ID:"),gc);
					
					gc.gridx = 1;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 0.2;
					gc.weighty = 0.2;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,5,0,20);
					studentDetailsPanel.add(txtViewCustomerID,gc);
					
				
				JPanel studentNamePanel = new JPanel(new GridBagLayout());
				setPanelSize(studentNamePanel, new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				studentNamePanel.setBorder(darkBorder);
				studentNamePanel.setBackground(moveCustomerColor);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,25);
				studentNamePanel.add(new JLabel("First Name:"), gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.insets = new Insets(0,5,0,10);
				studentNamePanel.add(txtViewFirstName,gc);
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.insets = new Insets(0,10,0,25);
				studentNamePanel.add(new JLabel("Last Name:"),gc);
				
				gc.gridx = 3;
				gc.gridy = 0;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.insets = new Insets(0,5,0,10);
				studentNamePanel.add(txtViewLastName,gc);
				
				
				////////////////////////////////////////////////////////////
				gc.gridx = 0;
				gc.gridy = 0;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,0,0);
				pnlCenterTopRightTop.add(studentNamePanel, gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,1);
				pnlCenterTopRightTop.add(studentDetailsPanel,gc);
				////////////////////////////////////////////////////////////

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		pnlCenterTopRight.add(pnlCenterTopRightTop, gc);

				pnlTopGroupDetails.setBackground(Color.WHITE);
				pnlTopGroupDetails.setBorder(darkBorder);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(20,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Name:"),gc);
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group ID:"),gc);
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Positions Available:"),gc);
				gc.gridx = 0;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Level:"),gc);
				gc.gridx = 1;
				gc.gridy = 0;
				gc.insets = new Insets(15,10,0,0);
				pnlTopGroupDetails.add(txtViewGroupName,gc);
				gc.gridx = 1;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtViewGroupID,gc);
				gc.gridx = 1;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtViewGroupPos,gc);
				gc.gridx = 1;
				gc.gridy = 3;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtViewGroupLevel,gc);
				gc.gridx = 2;
				gc.gridy = 0;
				gc.insets = new Insets(20,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Day:"),gc);
				gc.gridx = 2;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Time:"),gc);
				gc.gridx = 2;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Current Group Size:"),gc);
				gc.gridx = 2;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Material:"),gc);
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(15,10,0,0);
				pnlTopGroupDetails.add(txtViewGroupDay,gc);
				gc.gridx = 3;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtViewGroupTime,gc);
				gc.gridx = 3;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtViewGroupCurrentClassSize,gc);
				gc.gridx = 3;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtViewGroupMaterial,gc);
				
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,0,1,0);
		pnlCenterTopRight.add(pnlTopGroupDetails, gc);
		pnlCenterTopLeft.setBackground(new Color(246,246,246));
		
		//This is the main container panel for the North most components on the central stage - namely pnlCenterTopLeftPanel and pnlCenterTopRight//
		groupAddingToDetailsPanel.setBackground(Color.WHITE);
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,5,0,5);
			groupAddingToDetailsPanel.add(pnlCenterTopLeft, gc);
			
			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,5,0,10);
			groupAddingToDetailsPanel.add(pnlCenterTopRight, gc);
		//////////////////////////////////////Container for the lower components - these components can be toggled/////////////////////////////////////
		containerPanel = new JPanel(new GridBagLayout());
		setPanelSize(containerPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, container_height));
		containerPanel.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		containerPanel.add(container, gc);

		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlInformation = new JPanel();
		pnlInformation.setBackground(Color.WHITE);
		pnlInformation.setLayout(new GridBagLayout());
		pnlInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlSaveRow = new JPanel();
		pnlSaveRow.setBackground(Color.WHITE);
		pnlSaveRow.setLayout(new GridBagLayout());
		pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

			//Create the far left container for the group details information
			JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
			pnlSaveLeftPane.setBackground(Color.WHITE);
			pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel panel3 = new JPanel(new GridBagLayout());
				panel3.setBackground(Color.WHITE);
				panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				
				
				JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row1.setBackground(Color.WHITE);
				row1.add(new JLabel("Table updated:"));
				row1.add(lblDate);
				
				JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row2.setBackground(Color.WHITE);
				row2.add(new JLabel("Connected to: " + controller.getDBname()));
				
				JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row3.setBackground(Color.WHITE);
				row3.add(new JLabel("Connection: Secure"));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,5,0,5);
			
				panel3.add(row1, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,5);
			
				panel3.add(row2, gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,45,5);
			
				panel3.add(row3, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,20,5);
			
				pnlSaveLeftPane.add(panel3, gc);
		
		pnlSaveRow.add(pnlSaveLeftPane, gc);
			
		//////////////////////////////////////////Main Column 2 ///////////////////////////////////////////
		//Create the second panel from the left (comments panel)

		JPanel pnlSaveRight = new JPanel(new GridBagLayout());
		pnlSaveRight.setBackground(Color.WHITE);
		pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));

		

		
			//Add the nested panels to the container panel (comments panel)
			
			JPanel pblButtons = new JPanel(new GridBagLayout());
			pblButtons.setBackground(Color.WHITE);
			pblButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
			pblButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
			pblButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
			
			JPanel panel4 = new JPanel(new GridBagLayout());
			panel4.setBackground(Color.WHITE);
			panel4.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
			panel4.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
			panel4.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
			
			labels[8].setCursor(UI_Settings.getJlabelCursor());
			labels[8].addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){
					JOptionPane.showMessageDialog(controllingFrame,
			                "The administrator password can be found with the \"Kids Coordinator\"\n"
			              + "or by contacting your \"Branch Manager\".", "Information Message", JOptionPane.WARNING_MESSAGE);
				}
			});
			
			JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
			adminPanel.setBackground(Color.WHITE);
			adminPanel.add(new JLabel("Administrator password:"));
			adminPanel.add(passwordField);
			adminPanel.add(labels[8]);
			adminPanel.add(btnAddCustomerToGroup);


			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,1,0,1);
			
			panel4.add(adminPanel, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHEAST;
			gc.insets = new Insets(-10,0,0,10);
			
			pblButtons.add(panel4, gc);
			
			//Add the comments panel	
			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,-5,0,0);
			
			pnlSaveRight.add(pblButtons, gc);
			
			//Add the nested panels to the container panel (information panel)
			pnlSaveRow.add(pnlSaveRight, gc);
		
		//Add the nested panels to the container panel (information panel)
		pnlInformation.add(pnlSaveRow, gc);

		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        centerPanel.add(cardsButtons);
        
        centerPanel.add(cards);
        
        editdeletePanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(editdeletePanel);
        
        containerPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(containerPanel);

        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        centerPanel.add(Box.createVerticalStrut(10));

	    groupAddingToDetailsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(groupAddingToDetailsPanel);
	    
        centerPanel.add(Box.createVerticalStrut(10));
        
        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlInformation);
        
        /*********************************************************************************************************************************/
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 1000));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 1000));

		//////////////////////////////Search, save, reset button row///////////////////
		//Add the details section and table sections to the canvas.
		canvas.add(messageHeader, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		
		/*********************************************************************************************************************************/
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());	
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
		
		return scroller;
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
	
	private void configure_checkboxes_age() {
		
		ItemListener listener = new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				
				if(e.getStateChange() == ItemEvent.SELECTED){
					
					if(e.getItem() == checkboxes.get(0)){
						resetCheckBoxDays(0);
					}
					
					if(e.getItem() == checkboxes.get(1)){
						resetCheckBoxDays(1);
					}
					
					if(e.getItem() == checkboxes.get(2)){
						resetCheckBoxDays(2);
					}
					
					if(e.getItem() == checkboxes.get(3)){
						resetCheckBoxDays(3);
					}
					if(e.getItem() == checkboxes.get(4)){
						resetCheckBoxDays(4);
					}
				}
			}

			private void resetCheckBoxDays(int j) {
				
				for(int i = 0; i < checkboxes.size(); i++){
					if(j != i){
						checkboxes.get(i).setSelected(false);
					}
				}
				
			}
		};
		
		for(int i = 0; i < checkboxes.size(); i++){
			checkboxes.get(i).addItemListener(listener);
		}
	}
	public void resetPanels() {
		container.setVisible(true);
		container_left.setVisible(true);
		container_right.setVisible(true);
		threeDotsPanel.setVisible(false);
	}
	private void addFocus(JTextField jTextField) {
		jTextField.addFocusListener(new FocusListener() {
		      public void focusGained(FocusEvent e) {
		        jTextField.setText("");
		      }

		      public void focusLost(FocusEvent e) {
		    	  
		      }
		    });
	}
	
	protected FormEvent addNewCustomer() {
		
		String firstName;
		String lastName;
		int month;
		String material;
		String level;
		int id;
		int listen;
		int speak;
		int read;
		int par;
		int coop;
		String ag = "";
		String interests;
		String comments;
		
		firstName = txtFirstName.getText();
		lastName = txtLastName.getText();
		month = cmbMonths.getSelectedIndex();
		material = (String)cmbMaterial.getSelectedItem();
		level = (String)cmbLevel.getSelectedItem();
		interests = txtAreaInterests.getText();
		comments = txtAreaComments.getText();		
		
		
		try{
			final int listentemp = Integer.parseInt(txtListen.getText());
			listen = listentemp;
			txtListen.setText(listen + "/5");
		} catch(NumberFormatException ec){
			txtListen.setText("0/5");
			listen = 0;
		}
		
		try{
			final int speaktemp = Integer.parseInt(txtSpeak.getText());
			speak = speaktemp;
			txtSpeak.setText(speak + "/5");
		} catch(NumberFormatException ec){
			txtSpeak.setText("0/5");
			speak = 0;
		}
		
		try{
			final int readtemp = Integer.parseInt(txtRead.getText());
			read = readtemp;
			txtRead.setText(read + "/5");
		} catch(NumberFormatException ec){
			txtRead.setText("0/5");
			read = 0;
		}
		
		try{
			final int partemp = Integer.parseInt(txtParticipate.getText());
			par = partemp;
			txtParticipate.setText(par + "/5");
		} catch(NumberFormatException ec){
			txtParticipate.setText("0/5");
			par = 0;
		}
		
		try{
			final int cooptemp = Integer.parseInt(txtCooperate.getText());
			coop = cooptemp;
			txtCooperate.setText(coop + "/5");
		} catch(NumberFormatException ec){
			txtCooperate.setText("0/5");
			coop = 0;
		}
		
		if(checkboxes.get(0).isSelected()){
			ag = "4-8";
		}
		
		if(checkboxes.get(1).isSelected()){
			ag = "8-12";
		}
		
		if(checkboxes.get(2).isSelected()){
			ag = "12-16";
		}
		
		if(checkboxes.get(3).isSelected()){
			ag = "16-24";
		}
		
		if(checkboxes.get(4).isSelected()){
			ag = "24 >";
		}
		
		id= Integer.parseInt(txtViewCustomerID.getText());
		
		FormEvent ev = new FormEvent(this, firstName, lastName, month, material, level, id, listen, speak, read, par, coop, ag, interests, comments);

		System.out.println("First Name: " + ev.getFirstname());
		System.out.println("Last Name:" + ev.getLastname());
		System.out.println("Month:" + ev.getMonth());
		System.out.println("Material:" + ev.getMaterial());
		System.out.println("Level:" + ev.getLevel());
		System.out.println("ID:" + ev.getId());
		System.out.println("Listen:" + ev.getListen());
		System.out.println("Speak:" + ev.getSpeak());
		System.out.println("Read:" + ev.getRead());
		System.out.println("Participation:" + ev.getParticipation());
		System.out.println("Cooperation:" + ev.getCooperation());
		System.out.println("Age: " + ev.getAge());
		System.out.println("Interests: " + ev.getInterests());
		System.out.println("Comments: " + ev.getComments());
		
		if(ev != null){
			controller = new group.controller.Controller();
			controller.addCustomer(ev);
			try {
				controller.saveNewCustomer();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return ev;
	}
	
	protected void searchCustomers() {
		System.out.println("Searching for a customer");
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void populateComboBoxes() throws Exception {
		cmbGroupNameListCombobox = new JComboBox(UI_Settings.getGroups());
		cmbGroupNameListCombobox.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbGroupNameListCombobox.setFont(UI_Settings.getComponentInputFontSize());
		cmbGroupNameListCombobox.setMinimumSize(cmbGroupNameListCombobox.getPreferredSize());
		
		//Add model to ComboBox - model is updated in the AddGroups class//
		cmbGroupNameListCombobox.setModel(model);
	}
	
	private void initializeViewGroupTextFields(JTextField textfield) {
		
		textfield.setHorizontalAlignment(JTextField.LEFT);
		textfield.setBackground(Color.WHITE);
		textfieldsViewGroupDetails.add(textfield);
		
	}
	
	private void initializeRegularTextFields(JTextField textfield) {
		
		textfield.setEditable(true);
		textfield.setMinimumSize(textfield.getPreferredSize());
		textPrompt = new TextPrompt("0 / 5", textfield);
		textfield.setHorizontalAlignment(JTextField.CENTER);
		regular_textfields.add(textfield); 
		
	}
	
	private void initializeComboBoxes(JComboBox<String> comboboxes) {
		
		comboboxes.setFont(UI_Settings.getComponentInputFontSize());
		comboboxes.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		comboboxes.setMinimumSize(comboboxes.getPreferredSize());
		
		this.comboboxes.add(comboboxes);		
	}
	
	protected void clearTableData() {
		
		System.out.println("clearTableData method called");
/*		
    	for(int i = 0; i < 6; i++){
    		FormEvent ev = new FormEvent(this, "", "", 13, "", "", 0);
    		if(controller != null){
        		this.controller.addEmptyCustomer(ev);
    		}
    	}
    	
    	viewAllCustomersTable.refresh();*/
		
		
	}

	private final static int GET_VIEWALL_TABLE_CUSTOMER_LIST = 1;
	private final static int GET_ADDNEW_TABLE_CUSTOMER_LIST = 2;
}
