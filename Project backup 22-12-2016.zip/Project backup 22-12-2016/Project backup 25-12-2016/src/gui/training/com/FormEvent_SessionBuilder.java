package gui.training.com;

import java.util.EventObject;

public class FormEvent_SessionBuilder extends EventObject {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//Step 1//
	String concept1 = "";
	String concept2 = "";
	String otherConcept = "";
	String conceptImportant = "";
	String conceptUnderstood = "";
	

	public FormEvent_SessionBuilder(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

	public FormEvent_SessionBuilder(Object source, String concept1, String concept2, String otherConcept,
			String conceptsImportant, String conceptsUnderstood) {
		super(source);
		
		this.concept1 = concept1;
		this.concept2 = concept2;
		this.otherConcept = otherConcept;
		this.conceptImportant = conceptsImportant;
		this.conceptUnderstood = conceptUnderstood;
	}

	public String getConcept1() {
		return concept1;
	}

	public void setConcept1(String concept1) {
		this.concept1 = concept1;
	}

	public String getConcept2() {
		return concept2;
	}

	public void setConcept2(String concept2) {
		this.concept2 = concept2;
	}

	public String getOtherConcept() {
		return otherConcept;
	}

	public void setOtherConcept(String otherConcept) {
		this.otherConcept = otherConcept;
	}

	public String getConceptImportant() {
		return conceptImportant;
	}

	public void setConceptImportant(String conceptImportant) {
		this.conceptImportant = conceptImportant;
	}

	public String getConceptUnderstood() {
		return conceptUnderstood;
	}

	public void setConceptUnderstood(String conceptUnderstood) {
		this.conceptUnderstood = conceptUnderstood;
	}

}
