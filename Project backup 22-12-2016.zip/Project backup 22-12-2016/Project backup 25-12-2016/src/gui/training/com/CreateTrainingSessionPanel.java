package gui.training.com;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import control.gui.FormListener;
import settings.UI_Settings;

public class CreateTrainingSessionPanel extends JPanel {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JScrollPane scroller;
	
	private JPanel canvasPanel;
    private JPanel centerPanel;
    
    /////////////////////////////////////
    private JPanel pageHeader;
    private JPanel pageTitlePanel;
    public JPanel locator1 = new JPanel();
    public JPanel locator2 = new JPanel();
    public JPanel locator3 = new JPanel();
    public JPanel locator4 = new JPanel();
    public JPanel locator5 = new JPanel();
    public JPanel locator6 = new JPanel();
    
    private List<JPanel> locatorList = new ArrayList<JPanel>();
    
    
    private JLabel pageTitle;
    
    private JTextPane pageHeaderText;
    
    private GridBagConstraints gc = new GridBagConstraints();
    
    private Step1 step1Object = new Step1();
    private Step2 step2Object = new Step2();
    private Step3 step3Object = new Step3();
    private Step4 step4Object = new Step4();
    private Step5 step5Object = new Step5();
    private Step6 step6Object = new Step6();

    
    JPanel cards;
    
    JPanel card1;
    JPanel card2;
    JPanel card3;
    JPanel card4;
    JPanel card5;
    JPanel card6;
    
    final static String STEP1 = "Step1";
    final static String STEP2 = "Step2";
    final static String STEP3 = "Step3";
    final static String STEP4 = "Step4";
    final static String STEP5 = "Step5";
    final static String STEP6 = "Step6";
    
    private CreateTrainingSessionPanel createSessionObject;

    
    private Dimension headerDimension = new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 130);
	
	public CreateTrainingSessionPanel(){
		
		createSessionObject = this;
		
		initializeCards();
	}
	
	private void initializeCards() {
		card1 = step1Object.run(createSessionObject);
		card2 = step2Object.run(createSessionObject);
		card3 = step3Object.run(createSessionObject);
		card4 = step4Object.run();
		card5 = step5Object.run();
		card6 = step6Object.run();

		
		cards = new JPanel(new CardLayout());
		cards.add(card1, STEP1);
		cards.add(card2, STEP2);
		cards.add(card3, STEP3);
		cards.add(card4, STEP4);
		cards.add(card5, STEP5);
		cards.add(card6, STEP6);
		
	}

	public Component run(){
		
		scroller = initialize();
		
		return scroller;
	}

	private JScrollPane initialize() {
		
		buildPageHeader();
		buildPageLocationBar();
		
		centerPanel = new JPanel();
		centerPanel.setBackground(Color.WHITE);
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        
		cards.setAlignmentY(Component.LEFT_ALIGNMENT);
		centerPanel.add(cards);
        
        
        
		/****************************Create the canvas**************************/
		
		canvasPanel = new JPanel();
		canvasPanel.setLayout( new BorderLayout(0,0) ); 
		
		/*********************************************************************************************************************************/
		/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvasPanel.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 900));
		canvasPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 900));
		/*********************************************************************************************************************************/
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvasPanel);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());	
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
		
		//Add the details section and table sections to the canvas.
		canvasPanel.add(pageHeader, BorderLayout.NORTH);
		canvasPanel.add(centerPanel, BorderLayout.CENTER);
		
		return scroller;
	}
	
	private void buildPageLocationBar() {
		
		locator1 = getStepPanel(1);
		//Initialize step 1 locator color//
		locator1.setBackground(LOCATOR_ACTIVE_COLOR);
		
		locator2 = getStepPanel(2);
		locator3 = getStepPanel(3);
		locator4 = getStepPanel(4);
		locator5 = getStepPanel(5);
		locator6 = getStepPanel(6);
		
		locatorList.add(locator1);
		locatorList.add(locator2);
		locatorList.add(locator3);
		locatorList.add(locator4);
		locatorList.add(locator5);
		locatorList.add(locator6);

		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));
		container.setBackground(Color.WHITE);
		
		JPanel locationBar = new JPanel(new GridBagLayout());
		setPanelSize(locationBar, new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, 30));
		locationBar.setBackground(Color.WHITE);
		
		JPanel filler = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
		setPanelSize(filler, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, 30));
		filler.setBackground(Color.WHITE);
		
		locationBar.setAlignmentY(Component.LEFT_ALIGNMENT);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,20,10,5);
		locationBar.add(locator1, gc);
		
		gc.gridx = 1;
		locationBar.add(locator2, gc);
		gc.gridx = 2;
		locationBar.add(locator3, gc);
		gc.gridx = 3;
		locationBar.add(locator4, gc);
		gc.gridx = 4;
		locationBar.add(locator5, gc);
		gc.gridx = 6;
		gc.insets = new Insets(0,10,10,50);
		locationBar.add(locator6, gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,0,0,0);
		container.add(locationBar,gc);
		
		gc.gridx = 2;
		container.add(filler);
		pageHeader.add(container,gc);
	}

	private JPanel getStepPanel(int value) {
		JPanel panel = new JPanel();

		panel.setPreferredSize(new Dimension(100,7));
		panel.setMinimumSize(new Dimension(100,7));
		panel.setBackground(LOCATOR_REST_COLOR);
		panel.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
		switch(value){
			case 1: {
				panel.addMouseListener(new MouseAdapter(){
					public void mousePressed(MouseEvent e){
						resetLocatorColors();
						locator1.setBackground(LOCATOR_ACTIVE_COLOR);
						CardLayout cl = (CardLayout)(cards.getLayout());
						cl.show(cards, STEP1);
					}
				});
				break;
			}
			case 2: {
				panel.addMouseListener(new MouseAdapter(){
					public void mousePressed(MouseEvent e){
						resetLocatorColors();
						locator2.setBackground(LOCATOR_ACTIVE_COLOR);
						CardLayout cl = (CardLayout)(cards.getLayout());
						cl.show(cards, STEP2);
					}
				});
				break;
			}
			case 3: {
				panel.addMouseListener(new MouseAdapter(){
					public void mousePressed(MouseEvent e){
						resetLocatorColors();
						locator3.setBackground(LOCATOR_ACTIVE_COLOR);
						CardLayout cl = (CardLayout)(cards.getLayout());
						cl.show(cards, STEP3);
					}
				});
				break;
			}
			case 4: {
				panel.addMouseListener(new MouseAdapter(){
					public void mousePressed(MouseEvent e){
						resetLocatorColors();
						locator4.setBackground(LOCATOR_ACTIVE_COLOR);
						CardLayout cl = (CardLayout)(cards.getLayout());
						cl.show(cards, STEP4);					
						}
				});
				break;
			}
			case 5: {
				panel.addMouseListener(new MouseAdapter(){
					public void mousePressed(MouseEvent e){
						resetLocatorColors();
						locator5.setBackground(LOCATOR_ACTIVE_COLOR);
						CardLayout cl = (CardLayout)(cards.getLayout());
						cl.show(cards, STEP5);					
						}
				});
				break;
			}
			case 6: {
				panel.addMouseListener(new MouseAdapter(){
					public void mousePressed(MouseEvent e){
						resetLocatorColors();
						locator6.setBackground(LOCATOR_ACTIVE_COLOR);
						CardLayout cl = (CardLayout)(cards.getLayout());
						cl.show(cards, STEP6);					
						}
				});
				break;
			}
			default:
		}
		return panel;
	}

	protected void resetLocatorColors() {
		for(int i = 0; i < locatorList.size(); i++){
			locatorList.get(i).setBackground(LOCATOR_REST_COLOR);
		}
	}

	private void buildPageHeader() {
		pageHeader = new JPanel();
		pageHeader.setLayout(new BoxLayout(pageHeader, BoxLayout.Y_AXIS));
		pageHeader.setBackground(Color.WHITE);
		setPanelSize(pageHeader, headerDimension);
		/////////////////////////////////////////////////////////////////////////////////
		
		pageTitle = new JLabel("What is a Training Session Plan?");
		pageTitle.setFont(pageTitle.getFont().deriveFont(16.0f));
		
		/////////////////////////////////////////////////////////////////////////////////
		pageTitlePanel = new JPanel();
		pageTitlePanel.setBackground(UI_Settings.getButtonPanelColor());
		pageTitlePanel.setLayout(new BoxLayout(pageTitlePanel, BoxLayout.X_AXIS));
		pageTitlePanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		pageTitlePanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		pageTitlePanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(pageTitle);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));

		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		pageTitlePanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pageTitlePanel.add(rightPanel);
		/////////////////////////////////////////////////////////////////////////////////
		JPanel pageHeaderTextPanel = new JPanel(new GridBagLayout());
		setPanelSize(pageHeaderTextPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 70));
		pageHeaderTextPanel.setBackground(Color.WHITE);

		pageHeaderText = new JTextPane();
		pageHeaderText.setFont(pageHeaderText.getFont().deriveFont(11.0f));
		pageHeaderText.setForeground(UI_Settings.getComponentsFontColorDark());
		pageHeaderText.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(pageHeaderText.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.5);
		
		pageHeaderText.setParagraphAttributes(set, true);
		
		pageHeaderText.setText("A training session plan, is an organized description of the activities"
				+ " and resources you'll use to guide a group toward a specific learning objective.\nIt details the subject matter that"
				+ " you'll teach, how long each section should take, the methods of instruction for each topic covered, and the measures"
				+ " you'll use to check that people have learned what you needed them to learn.\n");
		

		
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,22,0,20);
		pageHeaderTextPanel.add(pageHeaderText,gc);
		/////////////////////////////////////////////////////////////////////////////////
		pageHeader.add(Box.createVerticalStrut(10));

		pageTitlePanel.setAlignmentY(Component.LEFT_ALIGNMENT);
		pageHeader.add(pageTitlePanel);
		
		pageHeaderTextPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
		pageHeader.add(pageHeaderTextPanel);
	}

	public void setFormListener(FormListener listener){
		//this.formListener = listener;
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}

	public static final Color LOCATOR_REST_COLOR = new Color(225,225,225);
	public static final Color LOCATOR_ACTIVE_COLOR = new Color(76,163,238);

	public JScrollPane getScroller() {
		return this.scroller;
	}

	public void resetScrollBars() {
		 if(this.scroller != null){
			 this.scroller.getViewport().setViewPosition(new Point(0,0));
		 }		
	}
}