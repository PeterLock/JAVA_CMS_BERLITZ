package gui.certificates.com;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ColorUIResource;

import control.gui.TableTemplate;
import settings.UI_Settings;
import utilities.AutoCompletion;
import utilities.SentryModule;

public class CertificatesPane extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JTabbedPane pane = new JTabbedPane();
    JFrame controllingFrame; //needed for dialogs
    JPasswordField passwordField;

	/**********************************************************************************************************************************/

	TD_PrintCertificate viewAllCustomersData = new TD_PrintCertificate();
	TableTemplate viewAllCertificatesTable = new TableTemplate(viewAllCustomersData, viewAllCustomersData.getCOLUMN_PERCENTAGES(), "");

	
	public CertificatesPane() {
        initializeUI();
    }

    private void initializeUI() {
    	
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, java.awt.Toolkit.getDefaultToolkit().getScreenSize().height));

        UIManager.put("Label.font", UI_Settings.getComponentsFontPlain());
    	UIManager.put("Label.foreground", UI_Settings.getComponentsFontColorDark());
    	
    	UIManager.put("OptionPane.messageFont", new Font("System", Font.PLAIN, 12));
    	UIManager.put("OptionPane.buttonFont", new Font("System", Font.PLAIN, 12));
    	
        //OK
        UIManager.put("TabbedPane.selected", new ColorUIResource(UI_Settings.getBottomTabColor()));
        UIManager.put("TabbedPane.unselectedTabBackground", UI_Settings.getCmsGray());       
        
        pane.setForeground(Color.WHITE);
        pane.setFocusable(false);
        pane.setBorder(new EmptyBorder(0, 0, 0, 0));


        //OK
        UIManager.getDefaults().put("TabbedPane.tabAreaInsets", new Insets(0,0,0,0));
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0)); 
        

        //Sets the JPanel container to black
        setBackground(UI_Settings.getCmsTabSecondLvlGrey());
        pane.addTab("<html><body><table width='100' style='font-size:11'><td style='text-align:center'>Print Certificates</td></table></body></html>", showCertificates());		//0
        
        //Set the text color for each tab
        pane.setForeground(Color.WHITE);

        pane.setBackgroundAt(0, UI_Settings.getCmsGray());	//0

    
        changeUI(UI_Settings.getBottomTabColor());

    }

    public void changeUI( Color bottomTabColor) {
        pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            @Override protected int calculateTabHeight(
              int tabPlacement, int tabIndex, int fontHeight) {
            	
    	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       focus = UI_Settings.getCmsTabSecondLvlGrey();
            	
              return 27;
            }
            
            
            @Override protected void paintTab(
              Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
              Rectangle iconRect, Rectangle textRect) {
        
               rects[tabIndex].height = 25 + 1;
               rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
              
              super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
            }
          });
        
        //Add the tab to the canvas
        this.add(pane, BorderLayout.CENTER);		
	}

	public static void showFrame() {
        JPanel panel = new CertificatesPane();
        panel.setOpaque(true);

        JFrame frame = new JFrame("CMS Test Screen");
        JFrame.setDefaultLookAndFeelDecorated(false);
        frame.setPreferredSize(UI_Settings.getMinimumScreenSize());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }
    
    public void changeTheme(Color c) {
      UIManager.put("TabbedPane.selected",new ColorUIResource(c));
		 
      pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          @Override protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
            return 27;
          }
      });
      
	pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
	    @Override protected int calculateTabHeight(
	      int tabPlacement, int tabIndex, int fontHeight) {
	    	
	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
	       focus = UI_Settings.getCmsTabSecondLvlGrey();
	    	
	      return 27;
	    }
	    
	    
	    @Override protected void paintTab(
	      Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
	      Rectangle iconRect, Rectangle textRect) {
	
	       rects[tabIndex].height = 25 + 1;
	       rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
	      
	      super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
	    }
	  });
	}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                CertificatesPane.showFrame();
            }
        });
    }
    

		public Component showCertificates()
		{
			JPanel canvas;
			JPanel detailsPanel;
			JPanel centerPanel;
			
			JButton btnSearch;
			
			btnSearch = new JButton("Search");
			btnSearch.setCursor(new Cursor(Cursor.HAND_CURSOR));
			btnSearch.setPreferredSize(UI_Settings.getJbuttonSize());
			btnSearch.setFont(UI_Settings.getComponentInputFontSize());
			
			
			
			JButton btnPrint;
			
			btnPrint = new JButton("Print");
			btnPrint.setCursor(new Cursor(Cursor.HAND_CURSOR));
			btnPrint.setPreferredSize(new Dimension(150,UI_Settings.getJbuttonSize().height));
			btnPrint.setMinimumSize(new Dimension(150,UI_Settings.getJbuttonSize().height));
			
			
	        passwordField = new JPasswordField(15);
	        passwordField.setActionCommand(UI_Settings.getOk());

	        JLabel label = new JLabel("Enter the password: ");
	        label.setLabelFor(passwordField);
			
			/***********************Initialize Fields******************************/
			JTextField txtFirstName;
			JTextField txtLastName;
			
			@SuppressWarnings("rawtypes")
			List<JComboBox> comboboxes = new ArrayList<JComboBox>();
			
			
			JComboBox<?> cmbCertificateType = new JComboBox<Object>(UI_Settings.getCertificateType());
			JComboBox<?> cmbMaterial = new JComboBox<Object>(UI_Settings.getBooks());
			JComboBox<?> cmbMonthStart = new JComboBox<Object>(UI_Settings.getMonths());
			JComboBox<?> cmbLevel = new JComboBox<Object>(UI_Settings.getLevels());
			
			JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
			failedMessage.setForeground(UI_Settings.getFailedMessageColor());

			failedMessage.setVisible(false);

			
			JLabel labels[] = new JLabel[4];
					
			labels[0] = new JLabel("reset fields");
			labels[1] = new JLabel("print");
			labels[2] = new JLabel("delete");
			labels[3] = new JLabel("hint");
			
			for(int i = 0; i < 4; i++){
				labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
				labels[i].setCursor(UI_Settings.getJlabelCursor());
			}
			

			/*********************************************************Create Combo Boxes*********************************************************/
			cmbMaterial.setFont(UI_Settings.getComponentInputFontSize());
			cmbMaterial.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
			//AutoCompletion.enable(cmbMaterial, 150,27);
			comboboxes.add(cmbMaterial);
			
			cmbCertificateType.setPreferredSize(new Dimension(129, UI_Settings.getComboBoxHeight()));
			cmbCertificateType.setFont(UI_Settings.getComponentInputFontSize());
			cmbCertificateType.setMinimumSize(cmbCertificateType.getPreferredSize());
			//AutoCompletion.enable(cmbCertificateType, 129, UI_Settings.getComboBoxHeight());
			comboboxes.add(cmbCertificateType);
			
			cmbLevel.setPreferredSize(new Dimension(80, 27));
			cmbLevel.setFont(UI_Settings.getComponentInputFontSize());
			//AutoCompletion.enable(cmbLevel, 80, 27);
			comboboxes.add(cmbLevel);
			
			cmbMonthStart.setPreferredSize(new Dimension(120, 27));
			cmbMonthStart.setFont(UI_Settings.getComponentInputFontSize());
			//AutoCompletion.enable(cmbMonthStart, 120, 27);
			comboboxes.add(cmbMonthStart);
			/***************************************************Create textFields********************************************************************/
			txtFirstName = new JTextField(10);
			txtFirstName.setMinimumSize(txtFirstName.getPreferredSize());
			txtFirstName.setHorizontalAlignment(JTextField.LEFT);
			
			txtLastName = new JTextField(10);
			txtLastName.setMinimumSize(txtLastName.getPreferredSize());
			txtLastName.setHorizontalAlignment(JTextField.LEFT);
			
			/****************************Create the canvas**************************/
			canvas = new JPanel();
			canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
			/**********************Create the components panel***********************/
			detailsPanel = new JPanel();
			detailsPanel.setBackground(Color.WHITE);
			detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
			detailsPanel.setLayout(new GridBagLayout());
			/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
			labels[0].addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){
					
			       int action = JOptionPane.showConfirmDialog(CertificatesPane.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
			       
			       if(action == JOptionPane.OK_OPTION){
			    	   
			    	   for(int i = 0; i < comboboxes.size(); i++){
			    		   
			    		   comboboxes.get(i).setSelectedIndex(0);
			    		   comboboxes.get(i).getEditor().getEditorComponent().setBackground(Color.WHITE);
			    		   
			    	   }
			    	   
			   		   txtFirstName.setText("");
					   txtLastName.setText("");
					   
					   txtFirstName.setBackground(Color.WHITE);
					   txtLastName.setBackground(Color.WHITE);
					   
					   viewAllCertificatesTable.setRowSelected(0, 0);

					   failedMessage.setVisible(false);
			       }
				}
			});
			GridBagConstraints gc = new GridBagConstraints();
			//////////////////////////////////////////Begin Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 3;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(-7,10,7,9);
			detailsPanel.add(new JLabel("Customer Name:"), gc); //Customer name label
			
			//////////////////////////////////////////Begin Column 2 ///////////////////////////////////////////
			gc.gridx = 1;
			gc.gridy = 2;
			gc.anchor = GridBagConstraints.SOUTHWEST;
			gc.insets = new Insets(5,0,-5,3);
			detailsPanel.add(new JLabel("First Name"), gc); //FirstName Label

			gc.gridx = 1;
			gc.gridy = 3;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,-3,-5,3);
			
			detailsPanel.add(txtFirstName, gc); //FirstName TextField
			
			//////////////////////////////////////////Begin Column 3 ///////////////////////////////////////////
			gc.gridx = 2;
			gc.gridy = 2;
			gc.anchor = GridBagConstraints.SOUTHWEST;
			gc.insets = new Insets(33,-3,-5,7);
			detailsPanel.add(new JLabel("Last Name"), gc); //Last Name Label

			gc.gridx = 2;
			gc.gridy = 3;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,-7,-5,17);
			detailsPanel.add(txtLastName, gc); //Last Name TextField
			//////////////////////////////////////////Begin Column 4///////////////////////////////////////////	
			gc.gridx = 3;
			gc.gridy = 3;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(-7,-7,7,17);
			detailsPanel.add(new JLabel("Month Started:"), gc); //Month started label
			//////////////////////////////////////////Begin Column 5///////////////////////////////////////////	

			gc.gridx = 4;
			gc.gridy = 3;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(4,-7,-4,17);
			detailsPanel.add(cmbMonthStart, gc); //Month started combo
			//////////////////////////////////////////Begin Column 6///////////////////////////////////////////		

			
			gc.gridx = 5;
			gc.gridy = 3;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(-7,2,7,29);
			detailsPanel.add(new JLabel("Material:"), gc); //Material label
			//////////////////////////////////////////Begin Column 7///////////////////////////////////////////		

			gc.gridx = 7;
			gc.gridy = 3;
			gc.insets = new Insets(-6,-25,6,25);
			detailsPanel.add(cmbMaterial, gc); //Materials Title ComboBox
			//////////////////////////////////////////Begin Column 8///////////////////////////////////////////	

			gc.gridx = 8;
			gc.gridy = 3;
			gc.insets = new Insets(-7,10,7,10);
			detailsPanel.add(new JLabel("Level:"), gc); //Level label
			//////////////////////////////////////////Begin Column 9///////////////////////////////////////////	

			gc.gridx = 9;
			gc.gridy = 3;
			gc.insets = new Insets(3,3,13,7);
			detailsPanel.add(cmbLevel, gc); //Levels combo
			/******************************************************Add the Buttons Panel************************************************/

			
			JPanel buttonPanel = new JPanel();
			buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
			buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
			buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
			buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
			buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

			
			JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
			leftPanel.setBackground(Color.WHITE);
			leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			leftPanel.add(failedMessage);
			
			JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 2));
			rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
			rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			rightPanel.add(labels[0]);
			
			btnSearch.addMouseListener(new MouseAdapter(){
				
				
				private String firstname;
				private String lastname;
				private String material;
				private String monthstarted;
				private String certificate;
				
				
				
				public void mousePressed(MouseEvent e){
					
					firstname = txtFirstName.getText();
					lastname = txtLastName.getText();
					material = (String)cmbMaterial.getSelectedItem();
					monthstarted = (String)cmbMonthStart.getSelectedItem();
					certificate = (String)cmbCertificateType.getSelectedItem();
					
				}
				
				public void mouseReleased(MouseEvent e){
					
					
					if(checkValues()){
						
						FormEvent ev = new FormEvent(this, firstname, lastname, material, monthstarted, certificate);
						
						JOptionPane.showMessageDialog(CertificatesPane.this, "Search successful"
								+ "\n\nFirst Name: " + ev.getFirstname()
								+ "\nLast Name: " + ev.getLastname()
								+ "\nMaterial: " + ev.getMaterial()
								+ "\nMonth Started: " + ev.getMonthstarted(), ""
								, JOptionPane.INFORMATION_MESSAGE);
						
					}
					

					
				}

				private boolean checkValues() {
					
					if(firstname.isEmpty() && lastname.isEmpty() && monthstarted.isEmpty() && material.isEmpty()){
						
						failedMessage.setVisible(true);
						
						txtFirstName.setBackground(UI_Settings.getComponentErrorColor());
						txtLastName.setBackground(UI_Settings.getComponentErrorColor());
						
						cmbMonthStart.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						cmbMaterial.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						
						JOptionPane.showMessageDialog(CertificatesPane.this, UI_Settings.getDlgCertificatesSearchStudentFail(), ""
								, JOptionPane.WARNING_MESSAGE);
						
						return false;
						
					}else{
						
						failedMessage.setVisible(false);
						
						txtFirstName.setBackground(Color.WHITE);
						txtLastName.setBackground(Color.WHITE);
						
						cmbMonthStart.getEditor().getEditorComponent().setBackground(Color.WHITE);
						cmbMaterial.getEditor().getEditorComponent().setBackground(Color.WHITE);
					}
					
					
					return true;
				}
				
				
			});
			
			
			rightPanel.add(btnSearch);
			

			
			leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
			buttonPanel.add(leftPanel);
			
			rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
			buttonPanel.add(rightPanel);			
		
			/*************************************************Print Report Button Panel**************************************************/
			int paneloffset = 20;
			Border border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);

			
			JPanel bottomButtons = new JPanel(new GridBagLayout());
			bottomButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-paneloffset));
			bottomButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-paneloffset));
			bottomButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-paneloffset));
			bottomButtons.setBackground(Color.WHITE);
				
				//Add the comments box//
				JPanel reportsFolder = new JPanel(new GridBagLayout());
				reportsFolder.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-paneloffset));
				reportsFolder.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-paneloffset));
				reportsFolder.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-paneloffset));
				reportsFolder.setBackground(Color.WHITE);
				
				
					JPanel lowerButtons = new JPanel();
					lowerButtons.setBackground(UI_Settings.getButtonPanelColor());
					lowerButtons.setLayout(new BoxLayout(lowerButtons, BoxLayout.X_AXIS));
					lowerButtons.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3*2, UI_Settings.getDetailsButtonPanelHeight()));
					lowerButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getDetailsButtonPanelHeight()));
					lowerButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getDetailsButtonPanelHeight()));
					
					JPanel lowerleft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
					lowerleft.setBackground(Color.WHITE);
					//lowerleft.add(new JLabel("Left Side"));

					JPanel lowerright = new JPanel(new FlowLayout(FlowLayout.RIGHT, 25, 0));
					lowerright.setBackground(UI_Settings.getComponentpanefillcolor());
					//lowerright.add(new JLabel("Right Side"));

					lowerleft.setAlignmentX(Component.LEFT_ALIGNMENT);
					lowerButtons.add(lowerleft);
					
					lowerright.setAlignmentX(Component.RIGHT_ALIGNMENT);
					lowerButtons.add(lowerright);
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,0,0,0);
					reportsFolder.add(lowerButtons, gc);
					
				
				JPanel passwordPanel = new JPanel(new GridBagLayout());
				passwordPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-paneloffset));
				passwordPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-paneloffset));
				passwordPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-paneloffset));
				passwordPanel.setBackground(Color.WHITE);
				
					JPanel panel3 = new JPanel(new GridBagLayout());
					panel3.setBackground(new Color(246,246,246));
					panel3.setBorder(border);
					panel3.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getRegularPanelHeight()-70));
					panel3.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getRegularPanelHeight()-70));
					panel3.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getRegularPanelHeight()-70));
		
					
					btnPrint.addMouseListener(new MouseAdapter(){
						public void mouseReleased(MouseEvent e){
							
								SentryModule module = new SentryModule();
							
					           char[] input = passwordField.getPassword();
					            if (module.takeInput(input)) {
					                JOptionPane.showMessageDialog(controllingFrame,
					                    "Welcome administrator. The certificate has been printed.");
					            } else {
					                JOptionPane.showMessageDialog(controllingFrame,
					                    "To print a customers certificate enter the administrators password",
					                    "Error Message",
					                    JOptionPane.ERROR_MESSAGE);
					            }
			
					            //Zero out the possible password, for security.
					            Arrays.fill(input, '0');
			
					            passwordField.selectAll();
							
						}
					});
					
					labels[3].setCursor(UI_Settings.getJlabelCursor());
					labels[3].addMouseListener(new MouseAdapter(){
						public void mouseClicked(MouseEvent e){
							
							JOptionPane.showMessageDialog(controllingFrame,
					                "The administrator password can be found with the \"Kids Coordinator\"\n"
					              + "or by contacting your \"Branch Manager\".");
							
						}
					});
					JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 3));
					adminPanel.setBackground(Color.WHITE);
					adminPanel.add(new JLabel("Administrator password:"));
					adminPanel.add(passwordField);
					adminPanel.add(labels[3]);
					
					gc.gridx = 0;
					gc.gridy = 1;
					gc.gridheight = 1;
					gc.gridwidth = 2;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.SOUTHWEST;
					gc.insets = new Insets(5,0,0,0);
					
					panel3.add(adminPanel, gc);
					
					
					gc.gridx = 0;
					gc.gridy = 2;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 0.1;
					gc.weighty = 0.1;
					gc.insets = new Insets(5,0,0,20);
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.EAST;
					panel3.add(btnPrint, gc);//Print customer report button
					
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.anchor = GridBagConstraints.SOUTHWEST;
					gc.insets = new Insets(0,0,0,0);
					
					passwordPanel.add(panel3, gc);
					
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(5,5,5,0);
			bottomButtons.add(reportsFolder, gc);
			
			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.3;
			gc.weighty = 0.3;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(5,5,5,10);
			bottomButtons.add(passwordPanel, gc);
			
			/********************************************************Set the Table Objects Sizes**************************************************/

			viewAllCertificatesTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*15)));
			viewAllCertificatesTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*15)));
			
			/******************************************************Create the Table Data Panel************************************************/
			centerPanel = new JPanel();
			centerPanel.setBackground(UI_Settings.getButtonPanelColor());
	        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
	        
	        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	        centerPanel.add(buttonPanel);
	        
	        viewAllCertificatesTable.setAlignmentY(Component.LEFT_ALIGNMENT);
	        centerPanel.add(viewAllCertificatesTable);
	        
	        bottomButtons.setAlignmentY(Component.LEFT_ALIGNMENT);
	        centerPanel.add(bottomButtons);
	        
			/*********************************************************************************************************************************/
			/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
			canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 750));
			canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 750));
			JScrollPane scroller = new JScrollPane(canvas);
			//Change the width of the scroll-bar
			scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
			scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
			//Change the visibility of the scroll-bar
			scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			scroller.setBorder(BorderFactory.createEmptyBorder());		
			
			//Add the details section and table sections to the canvas.
			canvas.add(detailsPanel, BorderLayout.NORTH);
			canvas.add(centerPanel, BorderLayout.CENTER);
			
			scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
			
			return scroller;
	}//END viewAlerts
}