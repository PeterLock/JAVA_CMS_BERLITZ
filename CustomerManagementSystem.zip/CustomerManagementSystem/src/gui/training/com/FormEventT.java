package gui.training.com;

import java.util.EventObject;

public class FormEventT extends EventObject {


	private static final long serialVersionUID = 1L;
	private String empName;
	private String trainingFor;
	private String requestBy;
	private String completeBy;
	private int requestID;

	public FormEventT(Object source, String empName, String trainingFor, String requestBy, String completeBy, int number) {
		super(source);
		
		this.empName = empName;
		this.trainingFor = trainingFor;
		this.requestBy = requestBy;
		this.completeBy = completeBy;
		this.requestID = number;
		
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getTrainingFor() {
		return trainingFor;
	}

	public void setTrainingFor(String trainingFor) {
		this.trainingFor = trainingFor;
	}

	public String getRequestBy() {
		return requestBy;
	}

	public void setRequestBy(String requestBy) {
		this.requestBy = requestBy;
	}

	public String getCompleteBy() {
		return completeBy;
	}

	public void setCompleteBy(String completeBy) {
		this.completeBy = completeBy;
	}

	public int getRequestID() {
		return requestID;
	}

	public void setRequestID(int requestID) {
		this.requestID = requestID;
	}

}
