package gui.events.com;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_EGroupDetails extends AbstractTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int GROUP_MATERIAL = 0;
	public final static int LEVEL = 1;
	public final static int GROUP_DAY = 2;
	public final static int NUMBER_OF_STUDENTS_IN_CLASS = 3;
	public final static int MAX_CLASS_SIZE_ALLOWED = 4;
	
	
	public Object[][]values =
		{
				{"Timezone", new Integer(1), "Monday", new Integer(3), new Integer(6)},
				{"", "", "", "", "", ""}
		};
	
	public final static String[] COLUMN_NAMES = {"Group Material", "Level",
			"Group Day", "Number of Students in Class", "Max Class Size Allowed"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	


	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}



	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList(10,10,10,12,10));

}
