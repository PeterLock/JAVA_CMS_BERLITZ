package control.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.UIManager;

import customer.controller.Controller;
import customer.gui.CustomerPane;
import group.gui.GroupControlCenter;
import settings.UI_Settings;



public class MenuBar extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private UI_Settings UI = new UI_Settings();

	private Toolbar toolBar = new Toolbar();
	
	
	private JFileChooser fileChooser;
	
	private customer.controller.Controller customer_controller = new customer.controller.Controller();
	private group.controller.Controller group_controller = new group.controller.Controller();
	
	
	private List<Object> object_list = new ArrayList<Object>();

	
	public MenuBar(Toolbar toolBar, List<Object> object_list){	
		this.toolBar = toolBar;
		this.object_list = object_list;
	}
	
	
	public JMenuBar addMenu(){
		
		fileChooser = new JFileChooser();
		fileChooser.addChoosableFileFilter(new CustomerFileFilter());

		//Menu-bar
		Font f = new Font(UI.getMenuFont(), Font.PLAIN, UI.getMenuFontSize());
		UIManager.put("Menu.font", f);	
		UIManager.put("MenuItem.font", f);
		UIManager.put("MenuBar.border", BorderFactory.createLineBorder(UI.getMenuBarColor(), 1));

		
		BackgroundMenuBar menuBar = new BackgroundMenuBar();
		menuBar.setPreferredSize(new Dimension((int) java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth(), UI_Settings.getMinMenuHeight()));
		menuBar.setColor(UI.getMenuBarColor());
		menuBar.setForeground(Color.WHITE);

		//First Menu
		JMenu fileMenu = new JMenu("<html><p style='margin-bottom:0'>File</p></html>");
		fileMenu.setPreferredSize(new Dimension(60, UI_Settings.getMinMenuHeight()));
		//Change the Menu back color
		fileMenu.setForeground(Color.WHITE);
		fileMenu.setOpaque(false);
		fileMenu.setMnemonic(KeyEvent.VK_F);
		fileMenu.getAccessibleContext().setAccessibleDescription("The file menu.");
		JMenuItem newFileItem = new JMenuItem("New");
		newFileItem.setPreferredSize(new Dimension(UI_Settings.getMinMenuWidth(), newFileItem.getPreferredSize().height));
		
		JMenuItem openItem = new JMenuItem("Open File ...");
		JMenuItem closeItem = new JMenuItem("Close");
		JMenuItem closeAllItem = new JMenuItem("Close All");
		JMenuItem saveItem = new JMenuItem("Save");
		JMenuItem saveAsItem = new JMenuItem("Save As");
		JMenuItem saveAllItem = new JMenuItem("Save All");
		JMenuItem revertItem = new JMenuItem("Revert");
		JMenuItem renameItem = new JMenuItem("Rename");
		JMenuItem refreshItem = new JMenuItem("Refresh");
		JMenuItem printItem = new JMenuItem("Print");
		JMenuItem restartItem = new JMenuItem("Restart");
		JMenuItem importDataItem = new JMenuItem("Import...");
		JMenuItem exportDataItem = new JMenuItem("Export...");
		JMenuItem propertiesItem = new JMenuItem("Properties");
		JMenuItem exitItem = new JMenuItem("Exit");

		fileMenu.add(newFileItem); 
		fileMenu.add(openItem);
		fileMenu.addSeparator();
		fileMenu.add(closeItem);
		fileMenu.add(closeAllItem);
		fileMenu.addSeparator();
		fileMenu.add(saveItem);
		fileMenu.add(saveAsItem);
		fileMenu.add(saveAllItem);
		fileMenu.add(revertItem);
		fileMenu.addSeparator();
		fileMenu.add(renameItem);
		fileMenu.add(refreshItem);
		fileMenu.addSeparator();
		fileMenu.add(printItem);
		fileMenu.addSeparator();
		fileMenu.add(restartItem);
		fileMenu.addSeparator();
		fileMenu.add(importDataItem);
		fileMenu.add(exportDataItem);
		fileMenu.addSeparator();
		fileMenu.add(propertiesItem);
		fileMenu.addSeparator();
		fileMenu.add(exitItem);
		
		fileMenu.setMnemonic(KeyEvent.VK_F);
		exitItem.setMnemonic(KeyEvent.VK_X);
		
		importDataItem.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e){
				
				if(fileChooser.showOpenDialog(MenuBar.this) == JFileChooser.APPROVE_OPTION){
					try {
						customer_controller.loadFromFile(fileChooser.getSelectedFile());
						group_controller.loadFromFile(fileChooser.getSelectedFile());
						
						//////////////////////////////////////////////////////
						CustomerPane customerPane;
						customerPane = (CustomerPane) object_list.get(0);
						customerPane.refresh();
						
						GroupControlCenter groupPane;
						groupPane = (GroupControlCenter) object_list.get(1);
						groupPane.refresh();
						
						
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(MenuBar.this, "Could not load data from file - Customers", "Load Error", JOptionPane.ERROR_MESSAGE);
					}
				};
				
			}
			
		});
		
		exportDataItem.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e){
				
				if(fileChooser.showSaveDialog(MenuBar.this) == JFileChooser.APPROVE_OPTION){
					try {
						customer_controller.saveToFile(fileChooser.getSelectedFile());
						group_controller.saveToFile(fileChooser.getSelectedFile());
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(MenuBar.this, "Could not save data to file - Customers", "Load Error", JOptionPane.ERROR_MESSAGE);
					}
				};
				
			}
			
		});
		
		exitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
		
		exitItem.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				
				
				int action = JOptionPane.showConfirmDialog(MenuBar.this, 
						"Do you really want to exit the application?", 
						"Confirm Exit", JOptionPane.OK_CANCEL_OPTION);
						
				
				if(action == JOptionPane.OK_OPTION){
					System.exit(0);
				}
				
			}
		});
	

		//Second Menu
		JMenu edit = new JMenu("Edit");
		edit.setPreferredSize(new Dimension(60, UI_Settings.getMinMenuHeight()));
		edit.setOpaque(false);
		JMenuItem redoItem = new JMenuItem("Redo");
		JMenuItem undoItem = new JMenuItem("Undo Typing");
		JMenuItem cutItem = new JMenuItem("Cut");
		JMenuItem copyItem = new JMenuItem("Copy");
		JMenuItem pasteItem = new JMenuItem("Paste");
		JMenuItem clearItem = new JMenuItem("Clear");
		JMenuItem selectAllItem = new JMenuItem("Select All");
		JMenuItem duplicateItem = new JMenuItem("Duplicate");
		JMenuItem pdmItem = new JMenuItem("Permantely Delete");
		JMenuItem findItem = new JMenuItem("Find");
		JMenuItem findNextItem = new JMenuItem("Find/Replace");
		JMenuItem findPreviousItem = new JMenuItem("Find Previous");
		JMenuItem spellCheck = new JMenuItem("Spelling and Grammar");
		JMenuItem emoji = new JMenuItem("Insert Emoji & Symbols");
		
		edit.add(redoItem);
		edit.add(undoItem);
		edit.addSeparator();
		edit.add(cutItem);
		edit.add(copyItem);
		edit.add(pasteItem);
		edit.addSeparator();
		edit.add(clearItem);
		edit.add(selectAllItem);
		edit.add(duplicateItem);
		edit.add(pdmItem);
		edit.addSeparator();
		edit.add(findItem);
		edit.add(findNextItem);
		edit.add(findPreviousItem);
		edit.add(spellCheck);
		edit.addSeparator();
		edit.add(emoji);
		
		//Third Menu
		JMenu view = new JMenu("View");
		view.setPreferredSize(new Dimension(60, UI_Settings.getMinMenuHeight()));
		view.setOpaque(false);
		JMenuItem previousItem = new JMenuItem("Previous");
		JMenuItem nextItem = new JMenuItem("Next");
		JMenu arrangeBy = new JMenu("Arrange By");
		JMenuItem filtersItem = new JMenuItem("Filters");
		JMenuItem efsItem = new JMenuItem("Enter Full Screen");
		
		view.add(previousItem);
		view.add(nextItem);
		view.addSeparator();
		view.add(arrangeBy);
		JMenuItem nameItem = new JMenuItem("Name");
		JMenuItem dateCreatedItem = new JMenuItem("Date Created");
		JMenuItem materialsItem = new JMenuItem("Material");
		arrangeBy.add(nameItem);
		arrangeBy.add(dateCreatedItem);
		arrangeBy.addSeparator();
		arrangeBy.add(materialsItem);
		view.addSeparator();
		view.add(filtersItem);
		view.addSeparator();
		view.add(efsItem);
		
		
		//Fourth Menu
		JMenu format = new JMenu("Format");
		format.setPreferredSize(new Dimension(80, UI_Settings.getMinMenuHeight()));
		format.setOpaque(false);
		JMenuItem fontItem = new JMenuItem("Font");
		JMenuItem styleItem = new JMenuItem("Style");
		JMenuItem sizeItem = new JMenuItem("Size");
		JMenuItem colorItem = new JMenuItem("Color");
		JMenuItem highlightItem = new JMenuItem("Highlight");
		JMenuItem increaseFontItem = new JMenuItem("Increase Font Size");
		JMenuItem decreaseFontItem = new JMenuItem("Decrease Font Size");
		JMenuItem alignmentItem = new JMenuItem("Alignment");
		
		format.add(fontItem);
		format.add(styleItem);
		format.add(sizeItem);
		format.add(colorItem);
		format.add(highlightItem);
		format.addSeparator();
		format.add(increaseFontItem);
		format.add(decreaseFontItem);
		format.addSeparator();
		format.add(alignmentItem);

		//Fifth Menu
		JMenu reports = new JMenu("Reports");
		reports.setPreferredSize(new Dimension(80, UI_Settings.getMinMenuHeight()));
		reports.setOpaque(false);
		JMenuItem templatesItem = new JMenuItem("View Templates");
		JMenu reportsItem = new JMenu("Student Reports");
		JMenuItem enrolled = new JMenuItem("Forward Reports");
		JMenuItem viewAllItem = new JMenuItem("View All");
		JMenuItem addReportItem  = new JMenuItem("Add Report");
		reportsItem.add(viewAllItem);
		reportsItem.add(addReportItem);
		reports.add(templatesItem);
		reports.add(reportsItem);
		reports.add(enrolled);
		
		//Sixth Menu
		JMenu administrative = new JMenu("Administrative");
		administrative.setPreferredSize(new Dimension(100, UI_Settings.getMinMenuHeight()));
		administrative.setOpaque(false);
		
		//Seventh Menu
		JMenu window = new JMenu("Window");
		window.setPreferredSize(new Dimension(80, UI_Settings.getMinMenuHeight()));
		window.setOpaque(false);
		
		JMenuItem minimizeItem = new JMenuItem("Minimize");
		JMenuItem zoomItem = new JMenuItem("Zoom");
		JMenuItem cmsStatusItem = new JMenuItem("CMS Status");
		JMenuItem cmsErrorsItem = new JMenuItem("CMS Errors");
		JMenuItem remindersItems = new JMenuItem("Reminders");
		JMenuItem searchPeopleItem = new JMenuItem("Search People");

		window.add(minimizeItem);
		window.add(zoomItem);
		window.add(cmsStatusItem);
		window.add(cmsErrorsItem);
		window.addSeparator();
		window.add(remindersItems);
		window.add(searchPeopleItem);

		//Eighth Menu
		JMenu help = new JMenu("Help");
		help.setPreferredSize(new Dimension(120, UI_Settings.getMinMenuHeight()));
		help.setOpaque(false);
		
		JMenuItem searchItem = new JMenuItem("Search");
		JMenuItem BICMSHelpItem = new JMenuItem("Berlitz International CMS Help");
		JMenuItem whatsNewItem = new JMenuItem("Whats New");
		
		help.add(searchItem);
		help.add(BICMSHelpItem);
		help.add(whatsNewItem);

		JMenu settings = new JMenu();
		settings.setIcon(createIcon("/icons_c/change_color_gallery.png"));
		settings.setPreferredSize(new Dimension(30, UI_Settings.getMinMenuHeight()));
		settings.setToolTipText("Choose a different color scheme");
		settings.setOpaque(false);
		
		JMenuItem theme1 = new JMenuItem("Pine");
		theme1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				TabPane.changeUI(new Color(35, 150, 85), new Color(32,137,42));
				
				Color menuBarColor = new Color(0,14,0);
				
				menuBar.setColor(menuBarColor);
				menuBar.setBorder(BorderFactory.createLineBorder(menuBarColor));
				
				toolBar.setToolBarColor(new Color(23,29,44));

			}
		});
		JMenuItem theme2 = new JMenuItem("Rich blue");
		theme2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				TabPane.changeUI(new Color(84, 173, 250), new Color(34,153,250));
				
				Color menuBarColor = new Color(21, 124, 188);
				
				menuBar.setColor(menuBarColor);
				menuBar.setBorder(BorderFactory.createLineBorder(menuBarColor));
				
				toolBar.setToolBarColor(new Color(5,61,96));
				
				repaint();	
				
				
			}
		});
		JMenuItem theme3 = new JMenuItem("Strawberry");
		theme3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				
				TabPane.changeUI(new Color(109,15,44), new Color(165,38,70));

				Color menuBarColor = new Color(0,14,0);
				
				menuBar.setColor(menuBarColor);
				menuBar.setBorder(BorderFactory.createLineBorder(menuBarColor));
				
				toolBar.setToolBarColor(new Color(23,29,44));
				
				repaint();	
				
			}
		});
		
		JMenuItem theme4 = new JMenuItem("Deep Fog");
		theme4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				TabPane.changeUI(new Color(128,153,156), new Color(63,77,79));
				
				Color menuBarColor = new Color(16, 30, 38);
				
				menuBar.setColor(menuBarColor);
				menuBar.setBorder(BorderFactory.createLineBorder(menuBarColor));
				
				toolBar.setToolBarColor(new Color(33,43,54));
				
				repaint();	
				
				
			}
		});
		JMenuItem theme5 = new JMenuItem("Chocolate");
		theme5.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				//AlertsPane.pane.setForeground(new Color(71,50,43));

				TabPane.changeUI(new Color(71,50,43), new Color(108,23,46));
				
				Color menuBarColor = new Color(13,20,28);
				

				
				menuBar.setColor(menuBarColor);
				menuBar.setBorder(BorderFactory.createLineBorder(menuBarColor));
				
				toolBar.setToolBarColor(new Color(25,37,52));
				
				
			}
		});
		JMenuItem theme6 = new JMenuItem("Purple Orchid");
		theme6.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				TabPane.changeUI(new Color(75,18,86), new Color(45,7,54));
				
				Color menuBarColor = new Color(0,14,0);
				
				menuBar.setColor(menuBarColor);
				menuBar.setBorder(BorderFactory.createLineBorder(menuBarColor));
				
				toolBar.setToolBarColor(new Color(23,29,44));
				
				repaint();		

			}
		});
		JMenuItem theme7 = new JMenuItem("Warm Marbel");
		theme7.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				TabPane.changeUI(new Color(209,193,156), new Color(193,147,32));
				
				Color menuBarColor = new Color(0,14,0);
				
				menuBar.setColor(menuBarColor);
				menuBar.setBorder(BorderFactory.createLineBorder(menuBarColor));
				
				toolBar.setToolBarColor(new Color(23,29,44));
				
				repaint();					
			}
		});
		JMenuItem theme8 = new JMenuItem("Dark Tiel");
		theme8.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				TabPane.changeUI(new Color(8,76,77), new Color(3, 51, 51));
			
				Color menuBarColor = new Color(0,14,0);
				
				menuBar.setColor(menuBarColor);
				menuBar.setBorder(BorderFactory.createLineBorder(menuBarColor));
				
				toolBar.setToolBarColor(new Color(23,29,44));
				
				repaint();	
			
			
			}
		});
		
		settings.add(theme1);
		settings.add(theme2);
		settings.add(theme3);
		settings.add(theme4);
		settings.add(theme5);
		settings.add(theme6);
		settings.add(theme7);
		settings.add(theme8);

		menuBar.add(fileMenu);
		menuBar.add(edit);
		menuBar.add(view);
		menuBar.add(format);
		menuBar.add(reports);
		menuBar.add(administrative);
		menuBar.add(window);
		menuBar.add(help);
        menuBar.add(Box.createHorizontalGlue());
		menuBar.add(settings);

		return menuBar;
	}
	
	private ImageIcon createIcon(String path){
		URL url = getClass().getResource(path);
		
		if(url == null) {
			System.out.println("Unable to load image: " + path);
			return null;
		}
		
		ImageIcon icon = new ImageIcon(url);
		
		return icon;
	}


	public void setCustomerController(Controller customer_controller) {
		this.customer_controller = customer_controller;
	}


	public void setGroupController(group.controller.Controller group_controller) {
		this.group_controller = group_controller;
	}


}
