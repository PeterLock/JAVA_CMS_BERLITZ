package group.gui;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_Members extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int CUSTOMER_NAME = 0;
	public final static int JOINED_GROUP = 1;
	public final static int KC_COMMENTS = 2;
	
	public Object[][]values =
		{
				{"Kate Smith", "January 2016", "Strongest, solid speaking and expands well. Not shy in class. An excellent student overall." },
				{"Bill Bagins", "September 2015", "Overactive imagination about a place called Gondor. Distracts other students with these stories."},
				{"", "", ""},
				{"", "", ""},
				{"", "", ""},
				{"", "", ""}
		};
	
	public final static String[] COLUMN_NAMES = {"Group Member Name", "Date Joined", "General Comments"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}
	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList(15,15,70));

}
