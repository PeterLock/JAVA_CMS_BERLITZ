package group.gui;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_AddCustomer extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int CUSTOMER_NAME = 0;
	public final static int MATERIAL_NAME = 1;
	public final static int LEVEL = 2;
	public final static int MONTH_STARTED = 3;
	public final static int PREDICTED = 4;
	
	public Object[][]values =
		{
				{"", "", "", "", "" },
				{"", "", "", "", "" },
				{"", "", "", "", "" },
				{"", "", "", "", "" },
				{"", "", "", "", "" },
				{"", "", "", "", "" }
		};
	
	public final static String[] COLUMN_NAMES = {"Customer Name", "Material", "Level", "Month Started",
		"Month Predicted to Completed"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	
	public ArrayList<Integer> getCUSTOMER_PERCENTAGES() {
		return CUSTOMER_PERCENTAGES;
	}

	public static void setCUSTOMER_PERCENTAGES(ArrayList<Integer> cUSTOMER_PERCENTAGES) {
		CUSTOMER_PERCENTAGES = cUSTOMER_PERCENTAGES;
	}

	private static ArrayList<Integer> CUSTOMER_PERCENTAGES = new ArrayList<>(Arrays.asList( 20,20,20,20,20));

}
