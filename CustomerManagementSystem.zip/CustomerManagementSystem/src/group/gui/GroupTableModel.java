package group.gui;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import group.model.Group;

@SuppressWarnings("serial")
public class GroupTableModel extends AbstractTableModel{
	
	private List<Group>db;
	
	private String[] colNames = {"Group Name", "Group Material", "Group Level", "Class Size", "Max Size", "Time", "Day"};
	
	public void setData(List<Group>db){
		this.db = db;
	}
	
	@Override
	public int getRowCount() {
		return db.size();
	}

	@Override
	public int getColumnCount() {
		return 7;
	}
	
	@Override
	public String getColumnName(int column) {
		return colNames[column];
	}


	@Override
	public Object getValueAt(int row, int col) {
		Group group = db.get(row);
		
		switch(col){
		case 0:
			return group.getGroupName();
		case 1:
			return group.getGroupMaterial();
		case 2:
			return group.getLevel();
		case 3:
			return group.getCurrentClassSize();
		case 4:
			return group.getMaxClassSize();
		case 5:
			return group.getTime();
		case 6:
			return group.getDay();
		}
		return null;
	}

}
