package group.gui;

import java.util.EventObject;

public class FormEvent extends EventObject {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -392648272918377466L;
	private String groupName;
	private String groupMaterial;
	private String groupLevel;
	private String groupDay;
	private String groupTime;
	private String groupClassSize;
	private String groupMaxClassSize;
	private int id = 0;

	public FormEvent(Object source, String groupName, String groupMaterial, String groupLevel, String groupDay, String groupTime, String classSize, String maxSize, int id) {
		super(source);
		
		this.groupName = groupName;
		this.groupMaterial = groupMaterial;
		this.groupLevel = groupLevel;
		this.groupDay = groupDay;
		this.groupTime = groupTime;
		this.groupClassSize = classSize;
		this.groupMaxClassSize = maxSize;
		this.id = id;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupMaterial() {
		return groupMaterial;
	}

	public void setGroupMaterial(String groupMaterial) {
		this.groupMaterial = groupMaterial;
	}

	public String getGroupLevel() {
		return groupLevel;
	}

	public void setGroupLevel(String groupLevel) {
		this.groupLevel = groupLevel;
	}

	public String getGroupDay() {
		return groupDay;
	}

	public void setGroupDay(String groupDay) {
		this.groupDay = groupDay;
	}

	public String getGroupTime() {
		return groupTime;
	}

	public void setGroupTime(String groupTime) {
		this.groupTime = groupTime;
	}

	public String getGroupClassSize() {
		return groupClassSize;
	}

	public void setGroupClassSize(String groupClassSize) {
		this.groupClassSize = groupClassSize;
	}

	public String getGroupMaxClassSize() {
		return groupMaxClassSize;
	}

	public void setGroupMaxClassSize(String groupMaxClassSize) {
		this.groupMaxClassSize = groupMaxClassSize;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
