package group.gui;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_ViewAllCustomer extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int CUSTOMER_NAME = 0;
	public final static int MATERIAL_NAME = 1;
	public final static int LEVEL = 2;
	public final static int MONTH_STARTED = 3;
	public final static int PREDICTED = 4;
	
	public Object[][]values =
		{
				{"Amy Smith", "Reading Explorer", new Integer(1), "January 2016", "October 2016" },
				{"Kate Smith", "Review lessons", new Integer(1), "February 2016", "-"},
				{"Anthony McCullen", "Reading Explorer", new Integer(2), "February 2016", "September 2016"},
				{"Lilly Wei", "Pathways", new Integer(1), "April 2016", "November 2016"},
				{"Simon Smit", "Pathways", new Integer(1), "January 2016", "August 2016"},
				{"David Cameron", "Timezones", new Integer(1), "May 2016",  "December 2016"},
		};
	
	public final static String[] COLUMN_NAMES = {"Customer Name", "Material", "Level", "Month Started",
		"Month Predicted to Completed"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	public int getRowCount() {
		return values.length;
	}
	
	
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}
	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList(20,20,20,20,20));

}
