package group.controller;


import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import group.gui.FormEvent;
import group.model.Database;
import group.model.Group;

public class Controller {
	
	
	public Controller(){
	}
	
	public void showGroupControllerMessage(){
		System.out.println("Inside group controller");
	}
	
	static Database db = new Database();
	
	public void addGroup(group.gui.FormEvent ev) {
		
		String groupName = ev.getGroupName();
		String groupMaterial = ev.getGroupMaterial();
		String level = ev.getGroupLevel();
		String day = ev.getGroupDay();
		String time = ev.getGroupTime();
		String currentClassSize = ev.getGroupClassSize();
		String maxClassSize = ev.getGroupMaxClassSize();
		int id = ev.getId();
		
		System.out.println("Group Name: " + ev.getGroupName());
		System.out.println("Group Material: " + ev.getGroupMaterial());
		System.out.println("Group Level: " + ev.getGroupLevel());
		System.out.println("Group Day: " + ev.getGroupDay());
		System.out.println("Group Time: " + ev.getGroupTime());
		System.out.println("Group Class Size: " + ev.getGroupClassSize());
		System.out.println("Group Max Class Size: " + ev.getGroupMaxClassSize());
		
		Group group = new Group(groupName, groupMaterial, level, day, time, currentClassSize, maxClassSize, id);

		db.addEmptyGroup(group);
	}

	public void save() throws SQLException {
		db.save();
	}

	public void load() throws SQLException {
		db.load();
	}

	public void connect() throws Exception {
		db.connect();
	}

	public void saveToFile(File file) throws IOException {
		//db.saveToFile(file);
	}
	
	public void loadFromFile(File file) throws IOException {
		//db.loadFromFile(file);
	}

	public void removeGroup(int row) {
		db.removeGroup(row);
		
	}

	public void setNumberOfRows(int tableRowNumber) {
		db.setAddNewRowNumber(tableRowNumber);
	}

	public static List<Group> getGroup() {
		return db.getGroup();
	}
	
	public static List<Group> getEmptyGroup() {
		return db.getEmptyGroup();
	}

	public void addEmptyGroup(FormEvent ev) {
		String groupName = ev.getGroupName();
		String groupMaterial = ev.getGroupMaterial();
		String level = ev.getGroupLevel();
		String day = ev.getGroupDay();
		String time = ev.getGroupTime();
		String currentClassSize = ev.getGroupClassSize();
		String maxClassSize = ev.getGroupMaxClassSize();
		int id = ev.getId();
		
		
		Group group = new Group(groupName, groupMaterial, level, day, time, currentClassSize, maxClassSize, id);

		db.addEmptyGroup(group);
	}

}
