package group.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import customer.model.Customer;
import customer.model.MonthCategory;


public class Database {
	
	
	private List<Group> group_list = new ArrayList<Group>();
	
	private List<Group> loaded_group_list = new ArrayList<Group>();

	
	private int count = 0;
	private int setNumberOfRows = 0;
	private Connection con;
	
	public Database(){
		
	}
	
	public void connect() throws Exception{
		
		if(con != null)return;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new Exception("Driver not found");
		}
		

		String url = "jdbc:mysql://localhost:3306/CIS_DB?autoReconnect=true&useSSL=false";
		
		con = DriverManager.getConnection(url, "root", "password");
		
		System.out.println("Connected: " + con.getCatalog());
		
	}
	
	public void disconnect(){
		if(con != null){
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println("Can't close the connection");
			}
		}
	}
	
	public void save() throws SQLException{
		
		String checkSql = "select count(*) as count from groups where ID=?";
		PreparedStatement checkStmt = con.prepareStatement(checkSql);
		
		String insertSql = "insert into groups (id, name, material, level, class_size, max_class_size, day, time) values (?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement insertStatement = con.prepareStatement(insertSql);
		

		String updateSql = "update groups set name=?, material=?, level=?, class_size=?, max_class_size=?, day=?, time=? where id=?";
		PreparedStatement updateStatement = con.prepareStatement(updateSql);
		
		for(Group groups : group_list){
			
			int t = groups.getId();
			if(t > 0){
				
				int id = groups.getId();
				String groupName = groups.getGroupName();
				String material = groups.getGroupMaterial();
				String level = groups.getLevel();
				String class_size = groups.getCurrentClassSize();
				String max_class_size = groups.getMaxClassSize();
				String day = groups.getDay();
				String time = groups.getTime();
				
				checkStmt.setInt(1, id);
				
				ResultSet checkResult = checkStmt.executeQuery();
				checkResult.next();
				
				int count = checkResult.getInt(1);
				
				
				if(count == 0){
					System.out.println("Inserting group with ID " + id);
					
					int col = 1;

					insertStatement.setInt(col++, id);
					insertStatement.setString(col++, groupName);
					insertStatement.setString(col++, material);
					insertStatement.setString(col++, level);
					insertStatement.setString(col++, class_size);
					insertStatement.setString(col++, max_class_size);
					insertStatement.setString(col++, day);
					insertStatement.setString(col++, time);

					insertStatement.executeUpdate();

				}
				else{
					System.out.println("Updating customer with ID " + id);
					
					int col = 1;
					
					updateStatement.setString(col++, groupName);
					updateStatement.setString(col++, material);
					updateStatement.setString(col++, level);
					updateStatement.setString(col++, class_size);
					updateStatement.setString(col++, max_class_size);
					updateStatement.setString(col++, day);
					updateStatement.setString(col++, time);
					
					updateStatement.setInt(col++, id);
					
					updateStatement.executeUpdate();
				}
			}
		}
		updateStatement.close();
		insertStatement.close();
		checkStmt.close();
		
	}
	
	public void load() throws SQLException{
		
		loaded_group_list.clear();

		String sql = "select id, name, material, level, class_size, max_class_size, day, time from groups order by name";
		Statement selectStatement = con.createStatement();
		
		ResultSet results = selectStatement.executeQuery(sql);
		
		while(results.next()){
			int id = results.getInt("id");
			String groupName = results.getString("name");
			String groupMaterial = results.getString("material");
			String level = results.getString("level");
			String class_size = results.getString("class_size");
			String max_class_size = results.getString("max_class_size");
			String day = results.getString("day");
			String time = results.getString("time");
			
			Group group = new Group(groupName, groupMaterial, level, day, time, class_size, max_class_size, id);
			
			loaded_group_list.add(group);
		}
		
		results.close();
		selectStatement.close();
		
	}

	public void addEmptyGroup(Group group) {
		
		if(this.group_list.size()==setNumberOfRows){
			this.group_list.add(0, group);
			this.group_list.remove(this.group_list.get(this.getEmptyGroup().size()-1));
		}else{
			if(count >setNumberOfRows){
				this.group_list.add(0, group);
			}else{
				this.group_list.add(0, group);
				count++;	
			}
		}
	}
	
	public void printGroup(){
		
		for(int i=0; i< loaded_group_list.size(); i++){
			System.out.println("Group Name2: " + loaded_group_list.get(i).getGroupName() + " Group ID: " + loaded_group_list.get(i).getId() + ".");
		}
		
	}
	
	public void saveToFile(File file) throws IOException{
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		Group[] groups = this.group_list.toArray(new Group[this.group_list.size()]);
		
		oos.writeObject(groups);
		
		fos.close();
		oos.close();
		
	}
	
	public void loadFromFile(File file) throws IOException {
		
	}

	public void removeGroup(int index) {
		if(index <0){
			return;
		}else{
			int remove_id = group_list.get(index).getId();
			
			group_list.remove(index);

			populateRemainingRows(group_list, setNumberOfRows);
			
			delete(remove_id);
			
			try {
				this.save();
			} catch (SQLException e) {
				System.err.println("Unable to save groups to DB");
				e.printStackTrace();
			}

		}		
	}
	
	private void delete(int remove_id) {
		System.out.println("Inside the delete method with id : " + remove_id);
		
		 try 
		 {  
			PreparedStatement statement = con.prepareStatement("DELETE FROM Groups WHERE id = ?");
			statement.setInt(1,remove_id);
			statement.executeUpdate(); 
			
			System.err.println("Exiting delete try/catch");

		 }
		 catch(Exception e)
		 {
		     System.out.println("An error deleting this record has been found.");
		 }
		 
	}

	public void setAddNewRowNumber(int i) {
		setNumberOfRows = i;
	}

	public List<Group> getGroup() {
		return loaded_group_list;
	}
	
	public List<Group> getEmptyGroup() {
		return group_list;
	}
	
	public void populateRemainingRows(List<Group> data, int j) {
		
       	for(int i = data.size()+1; i <=j; i++){
       		data.add(new Group("", "", "", "", "", "", "", 0));
    	}
	}

}
