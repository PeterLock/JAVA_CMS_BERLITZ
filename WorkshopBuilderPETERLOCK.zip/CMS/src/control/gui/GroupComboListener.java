package control.gui;

import javax.swing.DefaultComboBoxModel;

public interface GroupComboListener {
	public DefaultComboBoxModel reloadComboModel();
	public void reloadAllComboBoxes();
}
