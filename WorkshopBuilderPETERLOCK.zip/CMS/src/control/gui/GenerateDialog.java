package control.gui;

import javax.swing.JDialog;

import customer.gui.CustomerControlCenter;

public class GenerateDialog extends JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GenerateDialog(CustomerControlCenter customerPane){
		super();
		
		setSize(300,650);
	}
}
