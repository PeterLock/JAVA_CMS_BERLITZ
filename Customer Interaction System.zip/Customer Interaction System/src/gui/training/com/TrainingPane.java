package gui.training.com;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ColorUIResource;

import control.gui.TableTemplate;
import settings.UI_Settings;
import utilities.SentryModule;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class TrainingPane extends JPanel {

	private static final long serialVersionUID = 1L;
	static JTabbedPane pane = new JTabbedPane();
	UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	TextPrompt textPrompt;
	
	
    JFrame controllingFrame; //needed for dialogs
    JPasswordField passwordField;
	
	/*****************************************************Create the Table Data Resources**********************************************/

	TD_SendRequest requestTrainingTableData = new TD_SendRequest();
	TD_ViewRequests viewRequestsTableData = new TD_ViewRequests();
	
	
	TableTemplate requestTrainingTable = new TableTemplate(requestTrainingTableData, requestTrainingTableData.getCOLUMN_PERCENTAGES(), "");
	TableTemplate viewRequestsTrainingTable = new TableTemplate(viewRequestsTableData, viewRequestsTableData.getCOLUMN_PERCENTAGES(), "" );
	/**********************************************************************************************************************************/
	
	public TrainingPane() {
        initializeUI();
    }

    private void initializeUI() {
    	
    	UIManager.put("Label.font", UI_Settings.getComponentsFontPlain());
    	UIManager.put("Label.foreground", UI_Settings.getComponentsFontColorDark());
    	
    	UIManager.put("OptionPane.messageFont", new Font("System", Font.PLAIN, 12));
    	UIManager.put("OptionPane.buttonFont", new Font("System", Font.PLAIN, 12));

        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, java.awt.Toolkit.getDefaultToolkit().getScreenSize().height));

        //OK
        UIManager.put("TabbedPane.selected", new ColorUIResource(UI_Settings.getBottomTabColor()));
        UIManager.put("TabbedPane.unselectedTabBackground", UI_Settings.getCmsGray());       
        
        pane.setForeground(Color.WHITE);
        pane.setFocusable(false);
        pane.setBorder(new EmptyBorder(0, 0, 0, 0));


        //OK
        UIManager.getDefaults().put("TabbedPane.tabAreaInsets", new Insets(0,0,0,0));
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0)); 
        

        //Sets the JPanel container to black
        setBackground(UI_Settings.getCmsTabSecondLvlGrey());
        pane.addTab("<html><body><table width='130' style='font-size:11'><td style='text-align:center'>Send Training Request</td></table></body></html>", sendTrainingRequest());		//1
        pane.addTab("<html><body><table width='120' style='font-size:11'><td style='text-align:center'>View Sent Requests</td></table></body></html>", viewRequests());		//0

        //Set the text color for each tab
        pane.setForeground(Color.WHITE);

        pane.setBackgroundAt(0, UI_Settings.getCmsGray());	//0
        pane.setBackgroundAt(1, UI_Settings.getCmsGray());	//1
    
        changeUI(UI_Settings.getBottomTabColor());

    }

    public void changeUI( Color bottomTabColor) {
        pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            @Override protected int calculateTabHeight(
              int tabPlacement, int tabIndex, int fontHeight) {
            	
    	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       focus = UI_Settings.getCmsTabSecondLvlGrey();
            	
              return 27;
            }
            
            
            @Override protected void paintTab(
              Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
              Rectangle iconRect, Rectangle textRect) {
        
               rects[tabIndex].height = 25 + 1;
               rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
              
              super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
            }
          });
        
        //Add the tab to the canvas
        this.add(pane, BorderLayout.CENTER);		
	}
    

	public Component sendTrainingRequest()
	{
		JPanel pnlCanvas;
		JPanel pnlDetails;
		JPanel pnlCenter;
		JPanel pnlInformation;
		JPanel pnlButtons;
		JPanel pnlPassword;
		JPanel pnlMessageContainer;

		JPasswordField passwordField;
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());

        JLabel label = new JLabel("Enter the password: ");
        label.setLabelFor(passwordField);
		
		JTextArea txtAreaMessage = new JTextArea(9, 60);

		/***********************Initialize Fields******************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage.setVisible(false);
		
		JLabel labels[] = new JLabel[8];
		
		
 		
 		labels[0] = new JLabel("reset fields");
 		labels[1] = new JLabel("generate e-mail");
		labels[2] = new JLabel("e-Mail that will sent:");
		labels[3] = new JLabel("help");
		labels[4] = new JLabel("Request to be sent:");
		labels[5] = new JLabel("Administrator password");
		labels[6] = new JLabel("help");
		labels[7] = new JLabel("Training requests are automatically saved");
		
		for(int i = 0; i < 7; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		//Change label[4] color back to black
		labels[4].setForeground(UI_Settings.getComponentsFontColorDark());
		
		JButton btnGenerate = new JButton("Generate e-mail");
		btnGenerate.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnGenerate.setFont(UI_Settings.getComponentInputFontSize());
		
		JButton btnSend = new JButton("Send request to your local manager");
		btnSend.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnSend.setFont(UI_Settings.getComponentInputFontSize());
		
		txtAreaMessage.setMinimumSize(txtAreaMessage.getPreferredSize());
		txtAreaMessage.setEditable(false);
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(10, 20, 5, 0);
		CompoundBorder border = new CompoundBorder(line, empty);
		txtAreaMessage.setBorder(border);
		txtAreaMessage.setWrapStyleWord(true);
		txtAreaMessage.setLineWrap(true);
		textPrompt = new TextPrompt("<to generate a request make sure all of the dropdown boxes above have been selected>", txtAreaMessage);
		txtAreaMessage.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaMessage.setMargin( new Insets(15,50,10,10) );
		
		
		/*********************************************************Create the ComboBoxes*********************************************************/
		JComboBox<?> cmbEmpName = new JComboBox<Object>(UI_Settings.getEmployeeNames());
		JComboBox<?> cmbMaterialTraining = new JComboBox<Object>(UI_Settings.getBooks());
		JComboBox<?> cmbCompleteTrainingBy = new JComboBox<Object>(UI_Settings.getTrainingToBeCompletedBy());
		JComboBox<?> cmbRequestFrom = new JComboBox<Object>(UI_Settings.getEmployeeNames());
		
		
		@SuppressWarnings("rawtypes")
		List<JComboBox> comboboxes = new ArrayList<JComboBox>();
		
		
		/*********************************************************Create Combo Boxes*********************************************************/
		cmbEmpName.setPreferredSize(new Dimension(160, UI_Settings.getComboBoxHeight()));
		cmbEmpName.setFont(UI_Settings.getComponentInputFontSize());
		cmbEmpName.setMinimumSize(cmbEmpName.getPreferredSize());
		//AutoCompletion.enable(cmbEmpName, 160, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbEmpName);
		
		cmbMaterialTraining.setPreferredSize(new Dimension(160, UI_Settings.getComboBoxHeight()));
		cmbMaterialTraining.setFont(UI_Settings.getComponentInputFontSize());
		cmbMaterialTraining.setMinimumSize(cmbMaterialTraining.getPreferredSize());
		//AutoCompletion.enable(cmbMaterialTraining, 160, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbMaterialTraining);
		
		cmbCompleteTrainingBy.setPreferredSize(new Dimension(160, UI_Settings.getComboBoxHeight()));
		cmbCompleteTrainingBy.setFont(UI_Settings.getComponentInputFontSize());
		cmbCompleteTrainingBy.setMinimumSize(cmbCompleteTrainingBy.getPreferredSize());
		//AutoCompletion.enable(cmbCompleteTrainingBy, 160, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbCompleteTrainingBy);
		
		cmbRequestFrom.setPreferredSize(new Dimension(135, UI_Settings.getComboBoxHeight()));
		cmbRequestFrom.setFont(UI_Settings.getComponentInputFontSize());
		cmbRequestFrom.setMinimumSize(cmbRequestFrom.getPreferredSize());
		//AutoCompletion.enable(cmbRequestFrom, 135, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbRequestFrom);
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(TrainingPane.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   
		    	   for(int i = 0; i < comboboxes.size(); i++) {
		    		   comboboxes.get(i).setSelectedIndex(0);
		    		   comboboxes.get(i).getEditor().getEditorComponent().setBackground(Color.WHITE);
		    	   }
				   
		    	   failedMessage.setVisible(false);
		    	   
				   txtAreaMessage.setText("");
				   passwordField.setText("");
				   
				   requestTrainingTable.setRowSelected(0, 0);
		       }
			}
		});
	
		/****************************Create the canvas**************************/
		
		pnlCanvas = new JPanel();
		pnlCanvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		
		/**********************Create the components panel***********************/
		
		pnlDetails = new JPanel();
		pnlDetails.setBackground(Color.WHITE);
		pnlDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		pnlDetails.setLayout(new GridBagLayout());
		
		GridBagConstraints gc = new GridBagConstraints();
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(53,10,0,10);
		pnlDetails.add(new JLabel("Employee Name"), gc); //Employee Name Label
		
		///////////////////////////////column 1////////////////////////////
		gc.gridx = 1;
		gc.gridy = 	0;
		gc.insets = new Insets(47,10,0,10);
		gc.anchor = GridBagConstraints.NORTHWEST;
		pnlDetails.add(cmbEmpName, gc); //Employee name ComboBox
		
		///////////////////////////////column 2////////////////////////////
		gc.gridx = 2;
		gc.gridy = 0;
		gc.insets = new Insets(53,0,0,0);
		gc.anchor = GridBagConstraints.NORTHWEST;
		pnlDetails.add(new JLabel("Training For"), gc); //Training For Label

		///////////////////////////////column 3////////////////////////////
		gc.gridx = 3;
		gc.gridy = 0;
		gc.insets = new Insets(47,0,0,0);
		gc.anchor = GridBagConstraints.NORTHWEST;
		pnlDetails.add(cmbMaterialTraining, gc); //Training For ComboBox
		
		///////////////////////////////column 4////////////////////////////
		gc.gridx = 4;
		gc.gridy = 0;
		gc.insets = new Insets(53,0,0,0);
		pnlDetails.add(new JLabel("Request Made By"), gc); //Request Made By Label
		///////////////////////////////column 5////////////////////////////
		gc.gridx = 5;
		gc.gridy = 0;
		gc.insets = new Insets(47,0,0,0);
		pnlDetails.add(cmbRequestFrom, gc); //Request Made By Combo
		///////////////////////////////column 6////////////////////////////
		
		gc.gridx = 6;
		gc.gridy = 0;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(53,0,0,0);
		pnlDetails.add(new JLabel("Completed By"), gc); //Completed By Label
		
		///////////////////////////////column 7////////////////////////////
		
		gc.gridx = 7;
		gc.gridy = 0;
		gc.insets = new Insets(47,0,0,0);
		pnlDetails.add(cmbCompleteTrainingBy, gc); //Completed By Combo
		/******************************************************Add the Buttons Panel************************************************/
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);
		//rightPanel.add(btnGenerate);
		
		labels[1].addMouseListener(new MouseListener(){
			
			private String empName;
			private String trainingFor;
			private String requestBy;
			private String completeBy;
			
			private String message;

			public void mouseClicked(MouseEvent e) {
			}

			public void mousePressed(MouseEvent e) {
				
				empName = (String)cmbEmpName.getSelectedItem();
				trainingFor = (String)cmbMaterialTraining.getSelectedItem();
				requestBy = (String)cmbRequestFrom.getSelectedItem();
				completeBy = (String)cmbCompleteTrainingBy.getSelectedItem();
				
			}

			public void mouseReleased(MouseEvent e) {
				
				if(checkValues()){
					
					int number = 0;
					
					FormEventT ev = new FormEventT(this, empName, trainingFor, requestBy, completeBy, number);
					
					generateMessage(ev);
					
					txtAreaMessage.setText(message);
					
					JOptionPane.showMessageDialog(TrainingPane.this,
							"Generate Training Request"
							+ "\n\nEmployee Name: " + ev.getEmpName()
							+ "\nTraining For: " + ev.getTrainingFor()
							+ "\nRequest By: " + ev.getRequestBy()
							+ "\nComplete By: " + ev.getCompleteBy()
							+ "\nRequest ID: " + ev.getRequestID(),
							"", JOptionPane.INFORMATION_MESSAGE);
				}
				
			}

			private void generateMessage(FormEventT ev) {
				
				DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
			   	Date dateobj = new Date();
				
				message = "Dear " + UI_Settings.getManagersName() 
							+ "\n\nI would like to request that [" + ev.getEmpName() + "] be trained in [" + ev.getTrainingFor() + "]"
							+ " by [" + ev.getCompleteBy() + "] if possible. "
							+ "This email was sent on [" + df.format(dateobj) + " JST]."
							+ "\n\nRegards, " + ev.getRequestBy();
				
			}

			private boolean checkValues() {
				
				if(empName.isEmpty() || trainingFor.isEmpty() || requestBy.isEmpty() || completeBy.isEmpty()){
					failedMessage.setVisible(true);
					
					if(empName.isEmpty()){
						cmbEmpName.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						txtAreaMessage.setText("");
					}else{
						cmbEmpName.getEditor().getEditorComponent().setBackground(Color.WHITE);
					}
					
					if(trainingFor.isEmpty()){
						cmbMaterialTraining.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						txtAreaMessage.setText("");
					}else{
						cmbMaterialTraining.getEditor().getEditorComponent().setBackground(Color.WHITE);
					}
					
					if(requestBy.isEmpty()){
						cmbRequestFrom.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						txtAreaMessage.setText("");
					}else{
						cmbRequestFrom.getEditor().getEditorComponent().setBackground(Color.WHITE);
					}
					
					if(completeBy.isEmpty()){
						cmbCompleteTrainingBy.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						txtAreaMessage.setText("");
					}else{
						cmbCompleteTrainingBy.getEditor().getEditorComponent().setBackground(Color.WHITE);
					}
					
					return false;
				}
				
				failedMessage.setVisible(false);
				return true;
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}
		});

		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		
		/******************************************Generate request panel***************************************/
		
		JPanel trainingRequestsSavedPanel = new JPanel();
		trainingRequestsSavedPanel.setBackground(UI_Settings.getButtonPanelColor());
		trainingRequestsSavedPanel.setLayout(new BoxLayout(trainingRequestsSavedPanel, BoxLayout.X_AXIS));
		trainingRequestsSavedPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		trainingRequestsSavedPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		trainingRequestsSavedPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel pnlGenLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
		pnlGenLeft.setBackground(Color.WHITE);
		pnlGenLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenLeft.add(labels[4]);
		
		JPanel pnlGenRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		pnlGenRight.setBackground(Color.WHITE);
		pnlGenRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenRight.add(labels[1]);
		//rightPanel.add(btnSort);

		
		pnlGenLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		trainingRequestsSavedPanel.add(pnlGenLeft);
		
		pnlGenRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		trainingRequestsSavedPanel.add(pnlGenRight);
		
		/*******************************************Message panel*************************************************************/
		//Begin Nested Details Panels (lowest panel on screen)
		pnlInformation = new JPanel();
		pnlInformation.setBackground(Color.WHITE);
		pnlInformation.setLayout(new GridBagLayout());
		pnlInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

			//Create the far left container for the group details information
			pnlMessageContainer = new JPanel(new GridBagLayout());
			pnlMessageContainer.setBackground(Color.WHITE);
			pnlMessageContainer.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-20));
			pnlMessageContainer.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-20));
			pnlMessageContainer.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel pnlMessageArea = new JPanel(new GridBagLayout());
				pnlMessageArea.setBackground(Color.WHITE);
				Border informationBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
				//pnlMessageArea.setBorder(informationBorder);
				pnlMessageArea.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-20));
				pnlMessageArea.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-20));
				pnlMessageArea.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-20));

				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,23,0);
				
				pnlMessageArea.add(txtAreaMessage, gc);
				
				/////////////////////////////////////////
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,17,5);
			
				pnlMessageContainer.add(pnlMessageArea, gc);
			
		
		pnlInformation.add(pnlMessageContainer, gc);
		
		/////////////////////////////////////////
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,5,0,5);
	
		pnlMessageContainer.add(pnlMessageArea, gc);
		//////////////////////////////////////////Main Column 3 ///////////////////////////////////////////
		pnlButtons = new JPanel(new GridBagLayout());
		pnlButtons.setBackground(Color.WHITE);
		pnlButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3+10, UI_Settings.getRegularPanelHeight()));
		pnlButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3+10, UI_Settings.getRegularPanelHeight()));
		pnlButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3+10, UI_Settings.getRegularPanelHeight()));
	
		
			pnlPassword = new JPanel(new GridBagLayout());
			pnlPassword.setBackground(new Color(246,246,246));
			pnlPassword.setBorder(informationBorder);
			pnlPassword.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)+10, UI_Settings.getRegularPanelHeight()-50));
			pnlPassword.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)+10, UI_Settings.getRegularPanelHeight()-50));
			pnlPassword.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)+10, UI_Settings.getRegularPanelHeight()-50));

			int password;
			btnSend.addMouseListener(new MouseAdapter(){
				public void mouseReleased(MouseEvent e){
					
					if(txtAreaMessage.getText().equals("")){
						System.err.println("Nothing there");
						return;
					}
					
					SentryModule module = new SentryModule();
					
			           char[] input = passwordField.getPassword();
			            if (module.takeInput(input)) {
			                JOptionPane.showMessageDialog(controllingFrame,
			                    "Welcome administrator. The request has been sent.");
			            } else {
			                JOptionPane.showMessageDialog(controllingFrame,
			                    "To send a training request please enter the correct password.",
			                    "Error Message",
			                    JOptionPane.ERROR_MESSAGE);
			            }
	
			            //Zero out the possible password, for security.
			            Arrays.fill(input, '0');
	
			            passwordField.selectAll();
					
				}
			});
			
			labels[6].setCursor(UI_Settings.getJlabelCursor());
			labels[6].addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){
					
					JOptionPane.showMessageDialog(controllingFrame,
			                "The administrator password can be found with the \"Kids Coordinator\"\n"
			              + "or by contacting your \"Branch Manager\".");
					
				}
			});
			JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 3));
			adminPanel.setBackground(Color.WHITE);
			adminPanel.add(new JLabel("Administrator password:"));
			adminPanel.add(passwordField);
			adminPanel.add(labels[6]);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTH;
			gc.insets = new Insets(15,0,0,0);
			
			pnlPassword.add(adminPanel, gc);
			

			gc.gridx = 0;
			gc.gridy = 2;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.insets = new Insets(-5,5,10,0);
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			pnlPassword.add(btnSend, gc);//Send request button
			
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.NORTH;
			gc.insets = new Insets(0,0,0,0);
			
			pnlButtons.add(pnlPassword, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(-7,0,0,5);
			
			
			pnlButtons.add(new JLabel("This action cannot be undone"), gc);
		
		gc.gridx = 2;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,10);
		
		//Add the nested panels to the container panel (information panel)
		pnlInformation.add(pnlButtons, gc);

		/********************************************************Create the Table Objects**************************************************/
		
		requestTrainingTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*10)));
		requestTrainingTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*10)));
		
		/******************************************************Create the Table Data Panel*************************************************/
		pnlCenter = new JPanel();
		pnlCenter.setBackground(Color.WHITE);

        pnlCenter.setLayout(new BoxLayout(pnlCenter, BoxLayout.Y_AXIS));
        
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        pnlCenter.add(buttonPanel);
        
        requestTrainingTable.setAlignmentY(Component.LEFT_ALIGNMENT);
        pnlCenter.add(requestTrainingTable);
        
        trainingRequestsSavedPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        pnlCenter.add(trainingRequestsSavedPanel);
        
        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        pnlCenter.add(pnlInformation);
       // centerPanel.add(Box.createVerticalStrut(20));
        

        int end;
		/*********************************************************************************************************************************/
		/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		pnlCanvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getCanvasSize700()));
		pnlCanvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getCanvasSize700()));
		
		/*********************************************************************************************************************************/
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(pnlCanvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());	
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
		
		//Add the details section and table sections to the canvas.
		pnlCanvas.add(pnlDetails, BorderLayout.NORTH);
		pnlCanvas.add(pnlCenter, BorderLayout.CENTER);
		
		return scroller;
	}//END sendTrainingRequest

	
	public Component viewRequests()
	{
		JPanel pnlCanvas;
		JPanel pnlDetails;
		JPanel pnlCenter;
		JPanel pnlInformation;
		JPanel pnlButtons;
		JPanel pnlPassword;
		JPanel pnlMessageContainer;
		
		JPasswordField passwordField;
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());

        JLabel label = new JLabel("Enter the password: ");
        label.setLabelFor(passwordField);
		
		JTextArea txtAreaMessage = new JTextArea(9, 60);

		/***********************Initialize Fields******************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage.setVisible(false);
		
		JLabel labels[] = new JLabel[8];
		
		
 		
 		labels[0] = new JLabel("reset fields");
 		labels[1] = new JLabel("delete all saved requests");
		labels[2] = new JLabel("e-Mail that will sent:");
		labels[3] = new JLabel("help");
		labels[4] = new JLabel("Request to be sent:");
		labels[5] = new JLabel("Administrator password");
		labels[6] = new JLabel("help");
		labels[7] = new JLabel("Training requests are automatically saved");
		
		for(int i = 0; i < 7; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		//Change label[4] color back to black
		labels[4].setForeground(UI_Settings.getComponentsFontColorDark());
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnSearch.setPreferredSize(UI_Settings.getJbuttonSize());
		btnSearch.setFont(UI_Settings.getComponentInputFontSize());
		
		JButton btnDelete = new JButton("Delete selected request");
		btnDelete.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnDelete.setFont(UI_Settings.getComponentInputFontSize());
		
		txtAreaMessage.setMinimumSize(txtAreaMessage.getPreferredSize());
		txtAreaMessage.setEditable(false);
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(10, 20, 5, 0);
		CompoundBorder border = new CompoundBorder(line, empty);
		txtAreaMessage.setBorder(border);
		
		//txtAreaMessage.setBorder(UI_Settings.getBorderoutline());
		txtAreaMessage.setWrapStyleWord(true);
		txtAreaMessage.setLineWrap(true);
		textPrompt = new TextPrompt("<no request selected>", txtAreaMessage);
		txtAreaMessage.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaMessage.setMargin( new Insets(15,50,10,10) );
		
		
		/*********************************************************Create the ComboBoxes*********************************************************/
		JComboBox<?> cmbEmpName = new JComboBox<Object>(UI_Settings.getEmployeeNames());
		JComboBox<?> cmbMaterialTraining = new JComboBox<Object>(UI_Settings.getBooks());
		JComboBox<?> cmbCompleteTrainingBy = new JComboBox<Object>(UI_Settings.getTrainingToBeCompletedBy());
		JComboBox<?> cmbRequestFrom = new JComboBox<Object>(UI_Settings.getEmployeeNames());
		
		
		@SuppressWarnings("rawtypes")
		List<JComboBox> comboboxes = new ArrayList<JComboBox>();
		
		
		/*********************************************************Create Combo Boxes*********************************************************/
		cmbEmpName.setPreferredSize(new Dimension(160, UI_Settings.getComboBoxHeight()));
		cmbEmpName.setFont(UI_Settings.getComponentInputFontSize());
		cmbEmpName.setMinimumSize(cmbEmpName.getPreferredSize());
		//AutoCompletion.enable(cmbEmpName, 160, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbEmpName);
		
		cmbMaterialTraining.setPreferredSize(new Dimension(160, UI_Settings.getComboBoxHeight()));
		cmbMaterialTraining.setFont(UI_Settings.getComponentInputFontSize());
		cmbMaterialTraining.setMinimumSize(cmbMaterialTraining.getPreferredSize());
		//AutoCompletion.enable(cmbMaterialTraining, 160, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbMaterialTraining);
		
		cmbCompleteTrainingBy.setPreferredSize(new Dimension(160, UI_Settings.getComboBoxHeight()));
		cmbCompleteTrainingBy.setFont(UI_Settings.getComponentInputFontSize());
		cmbCompleteTrainingBy.setMinimumSize(cmbCompleteTrainingBy.getPreferredSize());
		//AutoCompletion.enable(cmbCompleteTrainingBy, 160, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbCompleteTrainingBy);
		
		cmbRequestFrom.setPreferredSize(new Dimension(135, UI_Settings.getComboBoxHeight()));
		cmbRequestFrom.setFont(UI_Settings.getComponentInputFontSize());
		cmbRequestFrom.setMinimumSize(cmbRequestFrom.getPreferredSize());
		//AutoCompletion.enable(cmbRequestFrom, 135, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbRequestFrom);
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(TrainingPane.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   
		    	   for(int i = 0; i < comboboxes.size(); i++) {
		    		   comboboxes.get(i).setSelectedIndex(0);
		    		   comboboxes.get(i).getEditor().getEditorComponent().setBackground(Color.WHITE);
		    	   }
				   
		    	   failedMessage.setVisible(false);
		    	   
				   txtAreaMessage.setText("");
				   passwordField.setText("");
				   
				   requestTrainingTable.setRowSelected(0, 0);
		       }
			}
		});
	
		/****************************Create the canvas**************************/
		
		pnlCanvas = new JPanel();
		pnlCanvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		
		/**********************Create the components panel***********************/
		
		pnlDetails = new JPanel();
		pnlDetails.setBackground(Color.WHITE);
		pnlDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		pnlDetails.setLayout(new GridBagLayout());
		
		GridBagConstraints gc = new GridBagConstraints();
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(53,10,0,10);
		pnlDetails.add(new JLabel("Employee Name"), gc); //Employee Name Label
		
		///////////////////////////////column 1////////////////////////////
		gc.gridx = 1;
		gc.gridy = 	0;
		gc.insets = new Insets(47,10,0,10);
		gc.anchor = GridBagConstraints.NORTHWEST;
		pnlDetails.add(cmbEmpName, gc); //Employee name ComboBox
		
		///////////////////////////////column 2////////////////////////////
		gc.gridx = 2;
		gc.gridy = 0;
		gc.insets = new Insets(53,0,0,0);
		gc.anchor = GridBagConstraints.NORTHWEST;
		pnlDetails.add(new JLabel("Training For"), gc); //Training For Label

		///////////////////////////////column 3////////////////////////////
		gc.gridx = 3;
		gc.gridy = 0;
		gc.insets = new Insets(47,0,0,0);
		gc.anchor = GridBagConstraints.NORTHWEST;
		pnlDetails.add(cmbMaterialTraining, gc); //Training For ComboBox
		
		///////////////////////////////column 4////////////////////////////
		gc.gridx = 4;
		gc.gridy = 0;
		gc.insets = new Insets(53,0,0,0);
		pnlDetails.add(new JLabel("Request Made By"), gc); //Request Made By Label
		///////////////////////////////column 5////////////////////////////
		gc.gridx = 5;
		gc.gridy = 0;
		gc.insets = new Insets(47,0,0,0);
		pnlDetails.add(cmbRequestFrom, gc); //Request Made By Combo
		///////////////////////////////column 6////////////////////////////
		
		gc.gridx = 6;
		gc.gridy = 0;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(53,0,0,0);
		pnlDetails.add(new JLabel("Completed By"), gc); //Completed By Label
		
		///////////////////////////////column 7////////////////////////////
		
		gc.gridx = 7;
		gc.gridy = 0;
		gc.insets = new Insets(47,0,0,0);
		pnlDetails.add(cmbCompleteTrainingBy, gc); //Completed By Combo
		/******************************************************Add the Buttons Panel************************************************/
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 3));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);
		rightPanel.add(btnSearch);

		//rightPanel.add(btnGenerate);
		
		labels[1].addMouseListener(new MouseAdapter(){
			
			public void mouseReleased(MouseEvent e){
				
				SentryModule module = new SentryModule();
				
		           char[] input = passwordField.getPassword();
		            if (module.takeInput(input)) {
		                JOptionPane.showMessageDialog(controllingFrame,
		                    "Welcome administrator. All requests have been deleted.");
		            } else {
		                JOptionPane.showMessageDialog(controllingFrame,
		                    "To delete a training request please enter the correct password.",
		                    "Error Message",
		                    JOptionPane.ERROR_MESSAGE);
		            }

		            //Zero out the possible password, for security.
		            Arrays.fill(input, '0');

		            passwordField.selectAll();
				
			}

		});

		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		
		/******************************************Generate request panel***************************************/
		
		JPanel trainingRequestsSavedPanel = new JPanel();
		trainingRequestsSavedPanel.setBackground(UI_Settings.getButtonPanelColor());
		trainingRequestsSavedPanel.setLayout(new BoxLayout(trainingRequestsSavedPanel, BoxLayout.X_AXIS));
		trainingRequestsSavedPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		trainingRequestsSavedPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		trainingRequestsSavedPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel pnlGenLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
		pnlGenLeft.setBackground(Color.WHITE);
		pnlGenLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenLeft.add(labels[4]);
		
		JPanel pnlGenRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		pnlGenRight.setBackground(Color.WHITE);
		pnlGenRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenRight.add(labels[1]);
		//rightPanel.add(btnSort);

		
		pnlGenLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		trainingRequestsSavedPanel.add(pnlGenLeft);
		
		pnlGenRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		trainingRequestsSavedPanel.add(pnlGenRight);
		
		/*******************************************Message panel*************************************************************/
		//Begin Nested Details Panels (lowest panel on screen)
		pnlInformation = new JPanel();
		pnlInformation.setBackground(Color.WHITE);
		pnlInformation.setLayout(new GridBagLayout());
		pnlInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

			//Create the far left container for the group details information
			pnlMessageContainer = new JPanel(new GridBagLayout());
			pnlMessageContainer.setBackground(Color.WHITE);
			pnlMessageContainer.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-20));
			pnlMessageContainer.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-20));
			pnlMessageContainer.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel pnlMessageArea = new JPanel(new GridBagLayout());
				pnlMessageArea.setBackground(Color.WHITE);
				Border informationBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
				//pnlMessageArea.setBorder(informationBorder);
				pnlMessageArea.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-20));
				pnlMessageArea.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-20));
				pnlMessageArea.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-20));

				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,23,0);
				
				pnlMessageArea.add(txtAreaMessage, gc);
				
				/////////////////////////////////////////
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,17,5);
			
				pnlMessageContainer.add(pnlMessageArea, gc);
			
		
		pnlInformation.add(pnlMessageContainer, gc);
		
		/////////////////////////////////////////
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,5,0,5);
	
		pnlMessageContainer.add(pnlMessageArea, gc);
		//////////////////////////////////////////Main Column 3 ///////////////////////////////////////////
		pnlButtons = new JPanel(new GridBagLayout());
		pnlButtons.setBackground(Color.WHITE);
		pnlButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3+10, UI_Settings.getRegularPanelHeight()));
		pnlButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3+10, UI_Settings.getRegularPanelHeight()));
		pnlButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3+10, UI_Settings.getRegularPanelHeight()));
	
		
			pnlPassword = new JPanel(new GridBagLayout());
			pnlPassword.setBackground(new Color(246,246,246));
			pnlPassword.setBorder(informationBorder);
			pnlPassword.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)+10, UI_Settings.getRegularPanelHeight()-50));
			pnlPassword.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)+10, UI_Settings.getRegularPanelHeight()-50));
			pnlPassword.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)+10, UI_Settings.getRegularPanelHeight()-50));

			int password;
			btnDelete.addMouseListener(new MouseAdapter(){
				public void mouseReleased(MouseEvent e){
					
					SentryModule module = new SentryModule();
					
			           char[] input = passwordField.getPassword();
			            if (module.takeInput(input)) {
			                JOptionPane.showMessageDialog(controllingFrame,
			                    "Welcome administrator. The request has been deleted.");
			            } else {
			                JOptionPane.showMessageDialog(controllingFrame,
			                    "To delete a training request please enter the correct password.",
			                    "Error Message",
			                    JOptionPane.ERROR_MESSAGE);
			            }
	
			            //Zero out the possible password, for security.
			            Arrays.fill(input, '0');
	
			            passwordField.selectAll();
					
				}
			});
			
			labels[6].setCursor(UI_Settings.getJlabelCursor());
			labels[6].addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){
					
					JOptionPane.showMessageDialog(controllingFrame,
			                "The administrator password can be found with the \"Kids Coordinator\"\n"
			              + "or by contacting your \"Branch Manager\".");
					
				}
			});
			JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 3));
			adminPanel.setBackground(Color.WHITE);
			adminPanel.add(new JLabel("Administrator password:"));
			adminPanel.add(passwordField);
			adminPanel.add(labels[6]);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTH;
			gc.insets = new Insets(15,0,0,0);
			
			pnlPassword.add(adminPanel, gc);
			

			gc.gridx = 0;
			gc.gridy = 2;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.insets = new Insets(-5,5,10,0);
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			pnlPassword.add(btnDelete, gc);//Send request button
			
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.NORTH;
			gc.insets = new Insets(0,0,0,0);
			
			pnlButtons.add(pnlPassword, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(-7,0,0,5);
			
			
			pnlButtons.add(new JLabel("This action cannot be undone"), gc);
		
		gc.gridx = 2;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,10);
		
		//Add the nested panels to the container panel (information panel)
		pnlInformation.add(pnlButtons, gc);

		/********************************************************Create the Table Objects**************************************************/
		
		viewRequestsTrainingTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*10)));
		viewRequestsTrainingTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*10)));
		
		/******************************************************Create the Table Data Panel*************************************************/
		pnlCenter = new JPanel();
		pnlCenter.setBackground(Color.WHITE);

        pnlCenter.setLayout(new BoxLayout(pnlCenter, BoxLayout.Y_AXIS));
        
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        pnlCenter.add(buttonPanel);
        
        viewRequestsTrainingTable.setAlignmentY(Component.LEFT_ALIGNMENT);
        pnlCenter.add(viewRequestsTrainingTable);
        
        trainingRequestsSavedPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        pnlCenter.add(trainingRequestsSavedPanel);
        
        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        pnlCenter.add(pnlInformation);
       // centerPanel.add(Box.createVerticalStrut(20));
        

        int end;
		/*********************************************************************************************************************************/
		/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		pnlCanvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getCanvasSize700()));
		pnlCanvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getCanvasSize700()));
		
		/*********************************************************************************************************************************/
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(pnlCanvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());	
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
		
		//Add the details section and table sections to the canvas.
		pnlCanvas.add(pnlDetails, BorderLayout.NORTH);
		pnlCanvas.add(pnlCenter, BorderLayout.CENTER);
		
		return scroller;
	}//END viewSentRequests
			
	
	public static void showFrame() {
        JPanel panel = new TrainingPane();
        panel.setOpaque(true);

        JFrame frame = new JFrame("CMS Test Screen");
        JFrame.setDefaultLookAndFeelDecorated(false);
        frame.setPreferredSize(UI_Settings.getMinimumScreenSize());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }
    
    public void changeTheme(Color c) {
      UIManager.put("TabbedPane.selected",new ColorUIResource(c));
		 
      pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          @Override protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
            return 27;
          }
      });
      
	pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
	    @Override protected int calculateTabHeight(
	      int tabPlacement, int tabIndex, int fontHeight) {
	    	
	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
	       focus = UI_Settings.getCmsTabSecondLvlGrey();
	    	
	      return 27;
	    }
	    
	    
	    @Override protected void paintTab(
	      Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
	      Rectangle iconRect, Rectangle textRect) {
	
	       rects[tabIndex].height = 25 + 1;
	       rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
	      
	      super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
	    }
	  });
	}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                TrainingPane.showFrame();
            }
        });
    }
    
	/*********************************************************************************************************************************************/
    
    //Must be called from the event dispatch thread.
    protected void resetFocus() {
       // passwordField.requestFocusInWindow();
    }
}
