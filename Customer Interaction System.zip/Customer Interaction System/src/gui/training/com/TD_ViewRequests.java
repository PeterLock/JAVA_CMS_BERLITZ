package gui.training.com;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_ViewRequests extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int INSTRUCTOR_NAME = 0;
	public final static int REQUEST_TRAINING_TO_BE_ON = 1;
	public final static int REQUEST_TRAINING_TO_BE_COMPLETED_BY = 2;
	public final static int BASE_LC = 3;
	public final static int REQUEST_MADE_TO = 4;
	
	public Object[][]values =
		{
				{"", "", "", "", "" },
				{"", "", "", "", "" },
				{"", "", "", "", "" },
				{"", "", "", "", "" },
				{"", "", "", "", "" },
				{"", "", "", "", "" },
				{"", "", "", "", "" },
				{"", "", "", "", "" },
				{"", "", "", "", "" },
				{"", "", "", "", "" }
		};
	
	public final static String[] COLUMN_NAMES = {"Instructor Name", "Requested to be trained in", 
		"Training to be completed by", "Base LC", "Request Made To"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}
	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList(20,20,20,20,20));

}
