package gui.reports.com;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_ViewAllReports extends AbstractTableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int CUSTOMER_NAME = 0;
	public final static int MATERIAL_NAME = 1;
	public final static int LEVEL = 2;
	public final static int MONTH_STARTED = 3;
	public final static int GROUP_NAME = 4;
	public final static int GROUP_DAY = 5;
	public final static int PREDICTED = 6;
	
	public Object[][]values =
		{
				{"Kate Smith", "Reading Explorer", new Integer(1), "January 2016", "Koala", "Friday", "October 2016" },
				{"Anthony McCullen", "Reading Explorer", new Integer(2), "February 2016", "-", "-", "September 2016"},
				{"Lilly Wei", "Pathways", new Integer(1), "April 2016", "Penguin", "Wednesday", "November 2016"},
				{"Simon Smit", "Pathways", new Integer(1), "January 2016", "Pineapple", "Thursday", "August 2016"},
				{"David Cameron", "Timezones", new Integer(1), "May 2016", "Peach", "Monday", "December 2016"},
				{"Roger Rogerton", "Pathways", new Integer(2), "December 2015", "-", "-", "January 2016"},
		};
	
	public final static String[] COLUMN_NAMES = {"Customer Name", "Material", "Level", "Month Started",
		"Group Name", "Group Day", "Month Predicted to Completed"};
	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}
	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList(14,14,10,14,14,14,18));

}
