package gui.reports.com;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ColorUIResource;

import control.gui.TableTemplate;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.SentryModule;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class ReportsPane extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JTabbedPane pane = new JTabbedPane();
	UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	
	

	TextPrompt textPrompt;
	Boolean ignoreEvents;
	
    JFrame controllingFrame; //needed for dialogs
    JPasswordField passwordField;
    JPasswordField passwordField2;

    
	/**********************************************************************************************************************************/
	
	TD_ReportsOnFile reportsOnFileTableData = new TD_ReportsOnFile();
	TableTemplate reportsOnFile = new TableTemplate(reportsOnFileTableData, reportsOnFileTableData.getCOLUMN_PERCENTAGES(), "");
	
	
	////////////////////////////////////////////////////////Add Reports Tab///////////////////////////////////////////////////////////
	///////////////Reports Top/////////////
	//VIEW ALL CUSTOMERS//
	TD_ViewAllReports viewAllTableData = new TD_ViewAllReports();
	TableTemplate tableVAStudents = new TableTemplate(viewAllTableData, viewAllTableData.getCOLUMN_PERCENTAGES(), "");
	
	
	///////////////Reports View All Customers/////////////
	
	TD_AddReport viewallTableData = new TD_AddReport();
	TableTemplate tableAR_ViewAll = new TableTemplate(viewallTableData, viewallTableData.getCOLUMN_PERCENTAGES(), "");	
	
	TD_ReportsTopSection reportsTopTableData = new TD_ReportsTopSection();
	TableTemplate tableAR_ReportTop = new TableTemplate(reportsTopTableData, reportsTopTableData.getCOLUMN_PERCENTAGES(), "Teens Student Report");
	

	
	///////////////Reports Middle - CheckBoxes/////////////
	TD_ReportsModel reportsTableModelData = new TD_ReportsModel();
	TableTemplate tableAR_Middle = new TableTemplate(reportsTableModelData, reportsTableModelData.getCOLUMN_PERCENTAGES(), "");
	
	
	///////////////Reports Added/////////////
	TD_ReportsAdded reportsAddedModelData = new TD_ReportsAdded();
	TableTemplate tableAR_ReportsAdded= new TableTemplate(reportsAddedModelData, reportsAddedModelData.getCOLUMN_PERCENTAGES(), "Reports Added");
	
	/**********************************************************************************************************************************/
	public ReportsPane() {
        initializeUI();
    }

    private void initializeUI() {
    	
    	UIManager.put("Label.font", UI_Settings.getComponentsFontPlain());
    	UIManager.put("Label.foreground", UI_Settings.getComponentsFontColorDark());
    	
    	UIManager.put("OptionPane.messageFont", new Font("System", Font.PLAIN, 12));
    	UIManager.put("OptionPane.buttonFont", new Font("System", Font.PLAIN, 12));
    	
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, java.awt.Toolkit.getDefaultToolkit().getScreenSize().height));

        //OK
        UIManager.put("TabbedPane.selected", new ColorUIResource(UI_Settings.getBottomTabColor()));
        UIManager.put("TabbedPane.unselectedTabBackground", UI_Settings.getCmsGray());       
        
        pane.setForeground(Color.WHITE);
        pane.setFocusable(false);
        pane.setBorder(new EmptyBorder(0, 0, 0, 0));

        //OK
        UIManager.getDefaults().put("TabbedPane.tabAreaInsets", new Insets(0,0,0,0));
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0)); 
        

        //Sets the JPanel container to black
        setBackground(UI_Settings.getCmsTabSecondLvlGrey());
        pane.addTab("<html><body><table width='70' style='font-size:11'><td style='text-align:center'>View All</td></table></body></html>", viewAllReports());		//0
        pane.addTab("<html><body><table width='90' style='font-size:11'><td style='text-align:center'>Add Report</td></table></body></html>", addReport());		//1
        
        //Set the text color for each tab
        pane.setForeground(Color.WHITE);

        pane.setBackgroundAt(0, UI_Settings.getCmsGray());	//0
        pane.setBackgroundAt(1, UI_Settings.getCmsGray());	//1

    
        changeUI(UI_Settings.getBottomTabColor());

    }

    public void changeUI( Color bottomTabColor) {
        pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            @Override protected int calculateTabHeight(
              int tabPlacement, int tabIndex, int fontHeight) {
            	
    	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       focus = UI_Settings.getCmsTabSecondLvlGrey();
            	
              return 27;
            }
            
            
            @Override protected void paintTab(
              Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
              Rectangle iconRect, Rectangle textRect) {
        
               rects[tabIndex].height = 25 + 1;
               rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
              
              super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
            }
          });
        
        //Add the tab to the canvas
        this.add(pane, BorderLayout.CENTER);		
	}

	public static void showFrame() {
        JPanel panel = new ReportsPane();
        panel.setOpaque(true);

        JFrame frame = new JFrame("CMS Test Screen");
        JFrame.setDefaultLookAndFeelDecorated(false);
        frame.setPreferredSize(UI_Settings.getMinimumScreenSize());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }
    
    public void changeTheme(Color c) {
      UIManager.put("TabbedPane.selected",new ColorUIResource(c));
		 
      pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          @Override protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
            return 27;
          }
      });
      
	pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
	    @Override protected int calculateTabHeight(
	      int tabPlacement, int tabIndex, int fontHeight) {
	    	
	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
	       focus = UI_Settings.getCmsTabSecondLvlGrey();
	    	
	      return 27;
	    }
	    
	    
	    @Override protected void paintTab(
	      Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
	      Rectangle iconRect, Rectangle textRect) {
	
	       rects[tabIndex].height = 25 + 1;
	       rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
	      
	      super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
	    }
	  });
	}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                ReportsPane.showFrame();
            }
        });
    }
	/**
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 */
    /**
     * Method name: viewAllReports()
     * ====================================================================================================================================
     * This method creates the viewAllReports pane and returns it to the calling method.
     * Precondition: Must be invoked.
     * Postcondition: Returns the viewAllReports pane.
     * 
     * @return Returns the viewAllReports details pane to the calling method.
     */
	public Component viewAllReports()
	{
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		
		/***********************Initialize Fields******************************/
		JTextField txtFirstName;
		JTextField txtLastName;
		
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());

        JLabel label = new JLabel("Enter the password: ");
        label.setLabelFor(passwordField);
        
        passwordField2 = new JPasswordField(15);
        passwordField2.setActionCommand(UI_Settings.getOk());

        JLabel label2 = new JLabel("Enter the password: ");
        label.setLabelFor(passwordField2);
		
		JButton btnSearch;
		JButton btnPrint;
		JButton btnDeleteSavedReport; 
		

		btnDeleteSavedReport = new JButton("Delete Saved Report");
		btnDeleteSavedReport.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnDeleteSavedReport.setPreferredSize(btnDeleteSavedReport.getPreferredSize());
		btnDeleteSavedReport.setFont(UI_Settings.getComponentInputFontSize());
		
		JTextArea messageTextArea = new JTextArea(6, 40);
		
		messageTextArea.setMinimumSize(messageTextArea.getPreferredSize());
		messageTextArea.setEditable(true);
		messageTextArea.setBorder(UI_Settings.getBorderoutline());
		messageTextArea.setWrapStyleWord(true);
		messageTextArea.setLineWrap(true);
		messageTextArea.setDocument(new JTextFieldLimit(280));
		textPrompt = new TextPrompt("<no report comments found>", messageTextArea);

		
		
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage.setVisible(false);
		
		JLabel labels[] = new JLabel[7];

				
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("view this report");
		labels[2] = new JLabel("Administrator password");
		labels[3] = new JLabel("delete this report");
		labels[4] = new JLabel("help");
		labels[5] = new JLabel("edit report comments");		
		labels[6] = new JLabel("print saved report");
	
		for(int i = 0; i < 7; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}

		
		/*********************************************************Create Combo Boxes*********************************************************/
		List <JComboBox> comboboxes = new ArrayList<JComboBox>();
		List <JTextField> textfields = new ArrayList<JTextField>();
		
		JComboBox<?> cmbStartMonth = new JComboBox<Object>(UI_Settings.getMonths());
		JComboBox<?> cmbLevel = new JComboBox<Object>(UI_Settings.getLevels());
		
				

		
		JComboBox<?> cmbGroupName = new JComboBox<Object>(UI_Settings.getGroups());
		JComboBox<?> cmbReportType = new JComboBox<Object>(UI_Settings.getReportType());
		JComboBox<?> cmbMaterial = new JComboBox<Object>(UI_Settings.getBooks());


		cmbMaterial.setFont(UI_Settings.getComponentInputFontSize());
		cmbMaterial.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		//AutoCompletion.enable(cmbMaterial, 150,27);
		comboboxes.add(cmbMaterial);
		
		cmbGroupName.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbGroupName.setMinimumSize(cmbGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbGroupName, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbGroupName);

		cmbReportType.setPreferredSize(new Dimension(129, UI_Settings.getComboBoxHeight()));
		cmbReportType.setFont(UI_Settings.getComponentInputFontSize());
		cmbReportType.setMinimumSize(cmbReportType.getPreferredSize());
		//AutoCompletion.enable(cmbReportType, 129, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbReportType);
		
		cmbLevel.setPreferredSize(new Dimension(80, 27));
		cmbLevel.setFont(UI_Settings.getComponentInputFontSize());
		//AutoCompletion.enable(cmbLevel, 80, 27);
		
		cmbStartMonth.setPreferredSize(new Dimension(120, 27));
		cmbStartMonth.setFont(UI_Settings.getComponentInputFontSize());
		//AutoCompletion.enable(cmbStartMonth, 120, 27);
		
		/***************************************************Create textFields********************************************************************/
		
		txtFirstName = new JTextField(10);
		txtFirstName.setMinimumSize(txtFirstName.getPreferredSize());
		txtFirstName.setHorizontalAlignment(JTextField.LEFT);
		textfields.add(txtFirstName);

		txtLastName = new JTextField(10);
		txtLastName.setMinimumSize(txtLastName.getPreferredSize());
		txtLastName.setHorizontalAlignment(JTextField.LEFT);
		textfields.add(txtLastName);
		
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		detailsPanel.setLayout(new GridBagLayout());
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(ReportsPane.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   
		    	   failedMessage.setVisible(false);
		    	   
		    	   for(int i = 0; i < comboboxes.size(); i++){
		    		   comboboxes.get(i).setSelectedIndex(0);
		    	   }
		    	   
		    	   
				   tableVAStudents.setRowSelected(0, 0);
				   reportsOnFile.setRowSelected(0, 0);
				   
				   
				   for(int i = 0; i < textfields.size(); i++){
					   textfields.get(i).setText("");
				   }
				   
				   messageTextArea.setText("");
				   passwordField.setText("");
		       }
			}
		});
		GridBagConstraints gc = new GridBagConstraints();
		//////////////////////////////////////////Begin Column 1 ///////////////////////////////////////////
		
		gc.gridx = 0;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-7,10,7,9);
		detailsPanel.add(new JLabel("Customer Name:"), gc); //Customer name label
		
		//////////////////////////////////////////Begin Column 2 ///////////////////////////////////////////
		gc.gridx = 1;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(5,0,-5,3);
		detailsPanel.add(new JLabel("First Name"), gc); //FirstName Label

		gc.gridx = 1;
		gc.gridy = 3;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,-3,-5,3);
		
		detailsPanel.add(txtFirstName, gc); //FirstName TextField
		
		//////////////////////////////////////////Begin Column 3 ///////////////////////////////////////////
		gc.gridx = 2;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(33,-3,-5,7);
		detailsPanel.add(new JLabel("Last Name"), gc); //Last Name Label

		gc.gridx = 2;
		gc.gridy = 3;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,-7,-5,17);
		detailsPanel.add(txtLastName, gc); //Last Name TextField
		//////////////////////////////////////////Begin Column 4///////////////////////////////////////////	
		gc.gridx = 3;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-7,-7,7,17);
		detailsPanel.add(new JLabel("Month Started:"), gc); //Month started label
		//////////////////////////////////////////Begin Column 5///////////////////////////////////////////	

		gc.gridx = 4;
		gc.gridy = 3;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(4,-7,-4,17);
		detailsPanel.add(cmbStartMonth, gc); //Month started combo
		//////////////////////////////////////////Begin Column 6///////////////////////////////////////////		

		
		gc.gridx = 5;
		gc.gridy = 3;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-7,2,7,29);
		detailsPanel.add(new JLabel("Material:"), gc); //Material label
		//////////////////////////////////////////Begin Column 7///////////////////////////////////////////		

		gc.gridx = 7;
		gc.gridy = 3;
		gc.insets = new Insets(-6,-25,6,25);
		detailsPanel.add(cmbMaterial, gc); //Materials Title ComboBox
		//////////////////////////////////////////Begin Column 8///////////////////////////////////////////	

		gc.gridx = 8;
		gc.gridy = 3;
		gc.insets = new Insets(-7,10,7,10);
		detailsPanel.add(new JLabel("Level:"), gc); //Level label
		//////////////////////////////////////////Begin Column 9///////////////////////////////////////////	

		gc.gridx = 9;
		gc.gridy = 3;
		gc.insets = new Insets(3,3,13,7);
		detailsPanel.add(cmbLevel, gc); //Levels combo
		
		/******************************************************Add the Buttons Panel************************************************/

		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 2));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);
		
		
		btnSearch = new JButton("Search");
		btnSearch.setPreferredSize(UI_Settings.getJbuttonSize());
		btnSearch.setFont(UI_Settings.getComponentInputFontSize());
		
		btnSearch.addMouseListener(new MouseAdapter(){
			
			private String firstname;
			private String lastname;
			private String groupname;
			private String material;
			private String reporttype;
			
			
			public void mousePressed(MouseEvent e){
				
				firstname = txtFirstName.getText();
				lastname = txtLastName.getText();
				groupname = (String)cmbGroupName.getSelectedItem();
				material = (String)cmbMaterial.getSelectedItem();
				reporttype = (String)cmbReportType.getSelectedItem();
				
			}
			
			public void mouseReleased(MouseEvent e){
				
				if(checkValues()){
					
					FormEventVR ev = new FormEventVR(this, firstname, lastname, groupname, material, reporttype);
					
					JOptionPane.showMessageDialog(
							ReportsPane.this,
							"View All Reports"
							+ "\n\nFirst Name: " + ev.getFirstname()
							+ "\nLast Name:" + ev.getLastname()
							+ "\nGroup Name: " + ev.getGroupname()
							+ "\nMaterial Name: " + ev.getMaterial()
							+ "\nReport Type: " + ev.getReporttype(),
							"", JOptionPane.INFORMATION_MESSAGE);
				}
				
			}

			private boolean checkValues() {
				if(firstname.isEmpty() && lastname.isEmpty() && groupname.isEmpty() && material.isEmpty() && reporttype.isEmpty()){
					failedMessage.setVisible(true);
					
					for(int i = 0; i < textfields.size(); i++) textfields.get(i).setBackground(UI_Settings.getComponentErrorColor());
					
					for(int i = 0; i < comboboxes.size(); i++) comboboxes.get(i).getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
					
					JOptionPane.showMessageDialog(ReportsPane.this, UI_Settings.getDlgReportsViewallNoselectionFail(), "", JOptionPane.WARNING_MESSAGE);
					return false;
				}else{
					for(int i = 0; i < textfields.size(); i++) textfields.get(i).setBackground(Color.WHITE);
					
					for(int i = 0; i < comboboxes.size(); i++) comboboxes.get(i).getEditor().getEditorComponent().setBackground(Color.WHITE);
				}
				
				failedMessage.setVisible(false);
				return true;
			}
		});
		
		rightPanel.add(btnSearch);
		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		
		/******************************************************Add the Buttons Panel************************************************/
		JPanel pnlReportsOnFile = new JPanel();
		pnlReportsOnFile.setBackground(UI_Settings.getButtonPanelColor());
		pnlReportsOnFile.setLayout(new BoxLayout(pnlReportsOnFile, BoxLayout.X_AXIS));
		pnlReportsOnFile.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		pnlReportsOnFile.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		pnlReportsOnFile.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel panelLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 8));
		panelLeft.setBackground(Color.WHITE);
		panelLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		panelLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		panelLeft.add(new JLabel("Reports On File:"));
		
		JPanel panelRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
		panelRight.setBackground(UI_Settings.getComponentpanefillcolor());
		panelRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		panelRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		panelRight.add(new JLabel("Filter:"));
		panelRight.add(cmbReportType);

		
		panelLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		pnlReportsOnFile.add(panelLeft);
		
		panelRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pnlReportsOnFile.add(panelRight);
			
		/******************************************************Add the Buttons Panel************************************************/
		btnPrint = new JButton("Print");
		btnPrint.setPreferredSize(UI_Settings.getJbuttonSize());
		btnPrint.setFont(UI_Settings.getComponentInputFontSize());
		
		JPanel panelButtons = new JPanel();
		panelButtons.setBackground(UI_Settings.getButtonPanelColor());
		panelButtons.setLayout(new BoxLayout(panelButtons, BoxLayout.X_AXIS));
		panelButtons.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		panelButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		panelButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel lft = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
		lft.setBackground(Color.WHITE);
		lft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		lft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		lft.add(new JLabel("Report Comments:"));
		
		JPanel rgt = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 3));
		rgt.setBackground(UI_Settings.getComponentpanefillcolor());
		rgt.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rgt.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		//rgt.add(btnPrint);

		
		lft.setAlignmentX(Component.LEFT_ALIGNMENT);
		panelButtons.add(lft);
		
		rgt.setAlignmentX(Component.RIGHT_ALIGNMENT);
		panelButtons.add(rgt);	
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel information = new JPanel();
		information.setBackground(Color.WHITE);
		information.setLayout(new GridBagLayout());
		information.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		information.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		information.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));

			//Create the far left container for the group details information
			JPanel pnlGroupDetails = new JPanel(new GridBagLayout());
			pnlGroupDetails.setBackground(Color.WHITE);
			pnlGroupDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getSmallPanelHeight()));
			pnlGroupDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getSmallPanelHeight()));
			pnlGroupDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getSmallPanelHeight()));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel panel1 = new JPanel(new GridBagLayout());
				panel1.setBackground(Color.WHITE);
				panel1.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getSmallPanelHeight()));
				panel1.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getSmallPanelHeight()));
				panel1.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getSmallPanelHeight()));
				////Col 1///
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,0);
				
				panel1.add(messageTextArea, gc);
				
				

				
				/////////////////////////////////////////
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,0);
			
				pnlGroupDetails.add(panel1, gc);
			
		
		information.add(pnlGroupDetails, gc);
			
		//////////////////////////////////////////Main Column 3 ///////////////////////////////////////////
		//Create the second panel from the left (comments panel)
		JPanel pblButtons = new JPanel(new GridBagLayout());
		pblButtons.setBackground(Color.WHITE);
		pblButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()));
		pblButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()));
		pblButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()));
	
		
			JPanel panel3 = new JPanel(new GridBagLayout());
			Border panel3border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
			panel3.setBorder(panel3border);
			panel3.setBackground(new Color(246,246,246));
			panel3.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()+10));
			panel3.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()+10));
			panel3.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()+10));

			
			btnDeleteSavedReport.addMouseListener(new MouseAdapter(){
				public void mouseReleased(MouseEvent e){

					
						SentryModule module = new SentryModule();
					
						char[] input = passwordField.getPassword();
			            if (module.takeInput(input)) {
			                JOptionPane.showMessageDialog(controllingFrame,
			                    "Welcome administrator. The report has been deleted.");
			            } else {
			                JOptionPane.showMessageDialog(controllingFrame,
			                    "To delete a report please enter the correct password.",
			                    "Error Message",
			                    JOptionPane.ERROR_MESSAGE);
			            }
	
			            //Zero out the possible password, for security.
			            Arrays.fill(input, '0');
	
			            passwordField.selectAll();
					
				}
			});
			
			labels[4].setCursor(UI_Settings.getJlabelCursor());
			labels[4].addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){
					
					JOptionPane.showMessageDialog(controllingFrame,
			                "The administrator password can be found with the \"Kids Coordinator\"\n"
			              + "or by contacting your \"Branch Manager\".");
					
				}
			});
			int o;

			
			JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 3, 3));
			adminPanel.setBackground(Color.WHITE);
			adminPanel.add(new JLabel("Administrator password:"));
			adminPanel.add(passwordField);
			adminPanel.add(labels[4]);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(15,0,0,0);
			
			panel3.add(adminPanel, gc);
			
			
			gc.gridx = 0;
			gc.gridy = 2;
			gc.gridheight = 1;
			gc.gridwidth = 2;
			gc.insets = new Insets(-2,10,0,0);
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.EAST;
			panel3.add(btnDeleteSavedReport, gc);//Delete Customer Admin label
			
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;

			gc.anchor = GridBagConstraints.NORTH;
			gc.insets = new Insets(-10,0,0,0);
			
			pblButtons.add(panel3, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(-20,0,0,5);
			
			
			pblButtons.add(new JLabel("This action cannot be undone"), gc);
		
		gc.gridx = 2;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,10,0,10);
		
		//Add the nested panels to the container panel (information panel)
		information.add(pblButtons, gc);
		
		/******************************************************Add the Buttons Panel************************************************/
		
		JPanel pnlEditPrint = new JPanel();
		pnlEditPrint.setBackground(Color.WHITE);
		pnlEditPrint.setLayout(new BoxLayout(pnlEditPrint, BoxLayout.X_AXIS));
		pnlEditPrint.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		pnlEditPrint.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		pnlEditPrint.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel editLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 5));
		editLeft.setBackground(Color.WHITE);
		editLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3*2, UI_Settings.getTableButtonsPanelHeight()));
		editLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getTableButtonsPanelHeight()));
		editLeft.add(labels[5]);
		editLeft.add(labels[6]);

		
		JPanel printRight = new JPanel(new FlowLayout(FlowLayout.LEFT, 60, 5));
		printRight.setBackground(Color.WHITE);
		printRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
		printRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
		printRight.add(new JLabel("This action cannot be undone"));
		
		editLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		pnlEditPrint.add(editLeft);
		
		printRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pnlEditPrint.add(printRight);
		/*******************************************Set the GC for the save, search, and reset buttons.*************************************/
		tableVAStudents.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		tableVAStudents.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		
		reportsOnFile.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		reportsOnFile.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		centerPanel = new JPanel();
		centerPanel.setBackground(Color.WHITE);
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
       
        tableVAStudents.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(tableVAStudents);
        
        centerPanel.add(Box.createVerticalStrut(10));
        
        pnlReportsOnFile.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlReportsOnFile);

        
        reportsOnFile.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(reportsOnFile);
        
        panelButtons.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(panelButtons);
        
        information.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(information);
        
        pnlEditPrint.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlEditPrint);
        
        
		/*********************************************************************************************************************************/
		/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 750));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 750));
		
		//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		///////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly///////////////////
		canvas.setMaximumSize(UI_Settings.getMinimumScreenSize());
		canvas.setPreferredSize(UI_Settings.getMinimumScreenSize());

		
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());


		/*
		 * *******************************************************************************************************************************
		 */
		return scroller;
	}//End viewAll
	/**
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 */
    /**
     * Method name: addReport()
     * ====================================================================================================================================
     * This method creates the addReport pane and returns it to the calling method.
     * Precondition: Must be invoked.
     * Postcondition: Returns the addReport pane.
     * 
     * @return Returns the addReport details pane to the calling method.
     */
	public Component addReport()
	{
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		
		/***********************Declare Fields******************************/
		JTextField txtFirstName;
		JTextField txtLastName;
		JTextField txtReportDate;
		JTextField txtManagerName;
		JTextField txtOralOneTest;
		JTextField txtMidLevelTest;
		JTextField txtMidLevelTotalTest;
		JTextField txtOralTwoTest;
		JTextField txtEndLevelScore;
		JTextField txtTotalScore;
		
		JTextField txtLessonType;
		JTextField txtMaterial;
		JTextField txtLangaugeCenter;
		JTextField txtUnitPage;
		JTextField txtLevel;
		
		JButton btnSearch;
		JButton btnSave;
		JButton btnViewReport;
		JButton btnPrintReport;
		
		
		btnSave = new JButton("Save Report");
		btnSave.setPreferredSize(UI_Settings.getJbuttonSize());
		btnSave.setFont(UI_Settings.getComponentInputFontSize());
		
		btnViewReport = new JButton("View Report");
		btnViewReport.setPreferredSize(UI_Settings.getJbuttonSize());
		btnViewReport.setFont(UI_Settings.getComponentInputFontSize());
		
		btnPrintReport = new JButton("Print Report");
		btnPrintReport.setPreferredSize(UI_Settings.getJbuttonSize());
		btnPrintReport.setPreferredSize(UI_Settings.getJbuttonSize());
		btnPrintReport.setFont(UI_Settings.getComponentInputFontSize());
		
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage.setVisible(false);
		
		JLabel labels[] = new JLabel[12];
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("edit presets");
		labels[2] = new JLabel("auto-fill");
		labels[3] = new JLabel("generate report comment");
		labels[4] = new JLabel("Report Generated Comments");
		labels[5] = new JLabel("edit comments");
		labels[6] = new JLabel("view report");
		labels[7] = new JLabel("print report");
		labels[8] = new JLabel("edit comments");
		labels[9] = new JLabel("go to reports folder");
		labels[10] = new JLabel("reset local fields");
		labels[11] = new JLabel("help");



		for( int i = 0; i <12; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}

		JTextArea reportCommentTextArea = new JTextArea(9, 60);
		
		//txtAreaMessage.setBorder(UI_Settings.getBorderoutline());
		reportCommentTextArea.setWrapStyleWord(true);
		reportCommentTextArea.setEditable(true);
		reportCommentTextArea.setLineWrap(true);
		textPrompt = new TextPrompt("<report comments are generated based upon the selections made from the checkboxes above>", reportCommentTextArea);
		reportCommentTextArea.setFont(UI_Settings.getComponentInputFontSize());
		reportCommentTextArea.setMargin( new Insets(0,0,0,0) );

		
		/***********************Save button ActionListener***********************/
		btnSave = new JButton("Save Report");
		
		btnSave.addMouseListener(new MouseAdapter(){
			public void mouseReleased(MouseEvent e){
				
					SentryModule module = new SentryModule();
				
		           char[] input = passwordField2.getPassword();
		            if (module.takeInput(input)) {
		                
							int number = idGenerator.getUniqueCustomerID();
							
							labels[8].setEnabled(true);
							
							int action = JOptionPane.showConfirmDialog(ReportsPane.this, "Welcome administrator. The report has been saved. Report ID is:" + number, "", 
									JOptionPane.OK_CANCEL_OPTION);
	
							   if(action == JOptionPane.OK_OPTION){
						       }
		                
		            } else {
		                JOptionPane.showMessageDialog(controllingFrame,
		                    "To save a customers report enter the administrators password",
		                    "Error Message",
		                    JOptionPane.ERROR_MESSAGE);
		            }

		            //Zero out the possible password, for security.
		            Arrays.fill(input, '0');

		            passwordField2.selectAll();
			}
		});
		
		
		btnSave.setCursor(UI_Settings.getJlabelCursor());
		btnSave.setPreferredSize(UI_Settings.getJbuttonSize());
		btnSave.setFont(UI_Settings.getComponentInputFontSize());

		/*********************************************************Create Combo Boxes*********************************************************/
		List<JComboBox> comboboxes = new ArrayList<JComboBox>();
		
		JComboBox<?> cmbGroups = new JComboBox<Object>(UI_Settings.getGroups());
		JComboBox<?> cmbReportType = new JComboBox<Object>(UI_Settings.getReportType());
		JComboBox<?> cmbMaterial = new JComboBox<Object>(UI_Settings.getBooks());
		JComboBox<String> cmbEmpNames = new JComboBox<String>(UI_Settings.getEmployeeNames());
		JComboBox<?> cmbStartMonth = new JComboBox<Object>(UI_Settings.getMonths());
		JComboBox<?> cmbLevel = new JComboBox<Object>(UI_Settings.getLevels());

		cmbEmpNames.setPreferredSize(new Dimension(135, UI_Settings.getComboBoxHeight()));
		cmbEmpNames.setFont(UI_Settings.getComponentInputFontSize());
		
		cmbMaterial.setFont(UI_Settings.getComponentInputFontSize());
		cmbMaterial.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));

		
		cmbGroups.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		cmbGroups.setFont(UI_Settings.getComponentInputFontSize());
		
		cmbLevel.setPreferredSize(new Dimension(80, 27));
		cmbLevel.setFont(UI_Settings.getComponentInputFontSize());
		
		cmbStartMonth.setPreferredSize(new Dimension(120, 27));
		cmbStartMonth.setFont(UI_Settings.getComponentInputFontSize());
		
		for(int i = 0; i < comboboxes.size(); i++){
			
			comboboxes.get(i).setFont(UI_Settings.getComponentInputFontSize());
			comboboxes.get(i).setMinimumSize(comboboxes.get(i).getMinimumSize());
			
		}
		
		
		/***************************************************Create textFields********************************************************************/
		
		List<JTextField> textfields = new ArrayList<JTextField>();
		
		txtFirstName = new JTextField(10);
		textfields.add(txtFirstName);

		txtLastName = new JTextField(10);
		textfields.add(txtLastName);
		
		txtReportDate = new JTextField(12);
		
		DateFormat df = new SimpleDateFormat("dd/MM/yy");
		Date dateobj = new Date();
		txtReportDate.setText(df.format(dateobj));
		textfields.add(txtReportDate);
		
		txtManagerName = new JTextField(10);
		textPrompt = new TextPrompt("-", txtManagerName);
		textfields.add(txtManagerName);
		txtManagerName.setEditable(true);
		////////////////////////////////////////////////////////////////////////
		txtOralOneTest = new JTextField(5);
		textPrompt = new TextPrompt("-", txtOralOneTest);
		textfields.add(txtOralOneTest);
		
		txtMidLevelTest = new JTextField(5);
		textPrompt = new TextPrompt("-", txtMidLevelTest);
		textfields.add(txtMidLevelTest);
		
		txtMidLevelTotalTest = new JTextField(5);
		textPrompt = new TextPrompt("-", txtMidLevelTotalTest);
		textfields.add(txtMidLevelTotalTest);
		
		txtOralTwoTest = new JTextField(5);
		textPrompt = new TextPrompt("-", txtOralTwoTest);
		textfields.add(txtOralTwoTest);
		
		txtEndLevelScore = new JTextField(5);
		textPrompt = new TextPrompt("-", txtEndLevelScore);
		textfields.add(txtEndLevelScore);
		
		txtTotalScore = new JTextField(5);
		textPrompt = new TextPrompt("-", txtTotalScore);
		textfields.add(txtTotalScore);
		

		for(int i = 0; i < textfields.size(); i++){
			textfields.get(i).setEditable(true);
			textfields.get(i).setMinimumSize(textfields.get(i).getPreferredSize());
		}
		
		for(int i = 0; i < 5; i++) textfields.get(i).setHorizontalAlignment(JTextField.LEFT);
		
		for(int i = 5; i < textfields.size(); i++) {
			textfields.get(i).setHorizontalAlignment(JTextField.CENTER);
			textfields.get(i).setEditable(true);
		}

		txtReportDate.setEditable(true);
		txtReportDate.setHorizontalAlignment(JTextField.CENTER);
		txtReportDate.setFont(UI_Settings.getComponentInputFontSize());
		//////////////////////////////////Report Top TextBoxes//////////////////////

		txtLessonType = new JTextField(7);
		textPrompt = new TextPrompt("-", txtLessonType);
		textfields.add(txtLessonType);
		
		txtMaterial = new JTextField(7);
		textPrompt = new TextPrompt("-", txtMaterial);
		textfields.add(txtMaterial);
		
		txtLangaugeCenter = new JTextField(7);
		textPrompt = new TextPrompt("-", txtLangaugeCenter);
		textfields.add(txtLangaugeCenter);
		
		txtUnitPage = new JTextField(7);
		textPrompt = new TextPrompt("-", txtUnitPage);
		textfields.add(txtUnitPage);
		
		txtLevel = new JTextField(7);
		textPrompt = new TextPrompt("-", txtLevel);
		textfields.add(txtLevel);
		///////////////////////////////////Declare mouse listeners///////////////////
		////////////Reset local fields listener/////////////
		labels[10].addMouseListener(new MouseAdapter(){
			
			public void mouseReleased(MouseEvent e){
				
				reportCommentTextArea.setText("");
				passwordField2.setText("");
				
				txtReportDate.setText(df.format(dateobj));

				txtManagerName.setText("");
				txtOralOneTest.setText("");
				txtMidLevelTest.setText("");
				txtMidLevelTotalTest.setText("");
				txtOralTwoTest.setText("");
				txtEndLevelScore.setText("");
				txtTotalScore.setText("");
				
				cmbEmpNames.setSelectedIndex(0);
				
			}
			
		});
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		detailsPanel.setLayout(new GridBagLayout());
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(ReportsPane.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   cmbGroups.setSelectedIndex(0);
		    	   cmbReportType.setSelectedIndex(0);
		    	   cmbMaterial.setSelectedIndex(0);
				   
				   tableAR_ViewAll.setRowSelected(0, 0);
				   tableAR_ReportTop.setRowSelected(0, 0);
				   tableAR_Middle.setRowSelected(0, 0);
				   tableAR_ReportsAdded.setRowSelected(0, 0);
				   
					txtFirstName.setText("");
					txtLastName.setText("");
				   
					txtOralOneTest.setText("");
					txtMidLevelTest.setText("");
					txtMidLevelTotalTest.setText("");
					txtOralTwoTest.setText("");
					txtEndLevelScore.setText("");
					txtTotalScore.setText("");
					txtReportDate.setText("");
					txtManagerName.setText("");
					
					reportCommentTextArea.setText("");
					
					txtLessonType.setText("");
					txtMaterial.setText("");
					txtLangaugeCenter.setText("");
					txtUnitPage.setText("");
					txtLevel.setText("");
		       }
			}
		});
		GridBagConstraints gc = new GridBagConstraints();
		
		//////////////////////////////////////////Begin Column 1 ///////////////////////////////////////////
		
		gc.gridx = 0;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-7,10,7,9);
		detailsPanel.add(new JLabel("Customer Name:"), gc); //Customer name label
		
		//////////////////////////////////////////Begin Column 2 ///////////////////////////////////////////
		gc.gridx = 1;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(5,0,-5,3);
		detailsPanel.add(new JLabel("First Name"), gc); //FirstName Label

		gc.gridx = 1;
		gc.gridy = 3;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,-3,-5,3);
		
		detailsPanel.add(txtFirstName, gc); //FirstName TextField
		
		//////////////////////////////////////////Begin Column 3 ///////////////////////////////////////////
		gc.gridx = 2;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(33,-3,-5,7);
		detailsPanel.add(new JLabel("Last Name"), gc); //Last Name Label

		gc.gridx = 2;
		gc.gridy = 3;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,-7,-5,17);
		detailsPanel.add(txtLastName, gc); //Last Name TextField
		//////////////////////////////////////////Begin Column 4///////////////////////////////////////////	
		gc.gridx = 3;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-7,-7,7,17);
		detailsPanel.add(new JLabel("Month Started:"), gc); //Month started label
		//////////////////////////////////////////Begin Column 5///////////////////////////////////////////	

		gc.gridx = 4;
		gc.gridy = 3;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(4,-7,-4,17);
		detailsPanel.add(cmbStartMonth, gc); //Month started combo
		//////////////////////////////////////////Begin Column 6///////////////////////////////////////////		

		
		gc.gridx = 5;
		gc.gridy = 3;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-7,2,7,29);
		detailsPanel.add(new JLabel("Material:"), gc); //Material label
		//////////////////////////////////////////Begin Column 7///////////////////////////////////////////		

		gc.gridx = 7;
		gc.gridy = 3;
		gc.insets = new Insets(-6,-25,6,25);
		detailsPanel.add(cmbMaterial, gc); //Materials Title ComboBox
		//////////////////////////////////////////Begin Column 8///////////////////////////////////////////	

		gc.gridx = 8;
		gc.gridy = 3;
		gc.insets = new Insets(-7,10,7,10);
		detailsPanel.add(new JLabel("Level:"), gc); //Level label
		//////////////////////////////////////////Begin Column 9///////////////////////////////////////////	

		gc.gridx = 9;
		gc.gridy = 3;
		gc.insets = new Insets(3,3,13,7);
		detailsPanel.add(cmbLevel, gc); //Levels combo
		
		/******************************************************Add the Buttons Panel************************************************/

		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));

		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 2));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);
		
		btnSearch = new JButton("Search");
		btnSearch.setCursor(UI_Settings.getJlabelCursor());
		btnSearch.setPreferredSize(UI_Settings.getJbuttonSize());
		btnSearch.setFont(UI_Settings.getComponentInputFontSize());
		
		btnSearch.addMouseListener(new MouseAdapter(){
			
			private String firstname;
			private String lastname; 
			private String groupname;
			private String material;
			private String reporttype;
			
			
			public void mousePressed(MouseEvent e){
				
				firstname = txtFirstName.getText();
				lastname = txtLastName.getText();
				groupname = (String)cmbGroups.getSelectedItem();
				material = (String)cmbMaterial.getSelectedItem();
				reporttype = (String)cmbReportType.getSelectedItem();
				
			}
			
			public void mouseReleased(MouseEvent e){
				
				if(checkSearchValues()){
					
					int number = 0;
					
					FormEventAR ev = new FormEventAR(this, firstname, lastname, groupname, material, reporttype, number);
					
					JOptionPane.showMessageDialog(
							ReportsPane.this,
							"Search for student"
							+ "\n\nFirst Name: " + ev.getFirstname()
							+ "\nLast Name: " + ev.getLastname()
							+ "\nGroup Name: " + ev.getGroupname()
							+ "\nMaterial: " + ev.getMaterial()
							+ "\nReport Type: " + ev.getReporttype(),
							"", JOptionPane.INFORMATION_MESSAGE);
				}
				
			}

			private boolean checkSearchValues() {
				if(firstname.isEmpty() || lastname.isEmpty() || groupname.isEmpty() || material.isEmpty() && reporttype.isEmpty()){
					
					failedMessage.setVisible(true);
					
					if(firstname.isEmpty()){
						txtFirstName.setBackground(UI_Settings.getComponentErrorColor());
					}else{
						txtFirstName.setBackground(Color.WHITE);
					}
					
					if(lastname.isEmpty()){
						txtLastName.setBackground(UI_Settings.getComponentErrorColor());
					}else{
						txtLastName.setBackground(Color.WHITE);
					}
					
					if(groupname.isEmpty()){
						cmbGroups.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
					}else{
						cmbGroups.getEditor().getEditorComponent().setBackground(Color.WHITE);
					}
					
					if(material.isEmpty()){
						cmbMaterial.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
					}else{
						cmbMaterial.getEditor().getEditorComponent().setBackground(Color.WHITE);
					}
					
					if(reporttype.isEmpty()){
						cmbReportType.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
					}else{
						cmbReportType.getEditor().getEditorComponent().setBackground(Color.WHITE);
					}
					
							
					JOptionPane.showMessageDialog(ReportsPane.this, UI_Settings.getDlgReportsViewallNoselectionFail(), "", JOptionPane.WARNING_MESSAGE);
					return false;
				}
				
				failedMessage.setVisible(false);
				
				for(int i = 0; i < textfields.size(); i++)textfields.get(i).setBackground(Color.WHITE);
				
				for(int i = 0; i < comboboxes.size(); i++)comboboxes.get(i).getEditor().getEditorComponent().setBackground(Color.WHITE);
				
				
				return true;
			}
			
		});
		
		
		rightPanel.add(btnSearch);
		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		/*************************************************Report Top Edit and AutoFill Button Panel*******************************************************/
		JPanel reportTopEditButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 2));
		reportTopEditButtonPanel.setBackground(Color.WHITE);
		reportTopEditButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 25));
		reportTopEditButtonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 25));
		reportTopEditButtonPanel.add(labels[1]);//Edit text button
		//reportTopEditButtonPanel.add(labels[2]);//Auto-fill text button
		//////////////////////////////////////////////////////Add the report details panel////////////////////////////////////////////////
		Border border = BorderFactory.createLineBorder(new Color(224,224,224));
		
		JPanel reportTop = new JPanel(new GridBagLayout());
		reportTop.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-20));
		reportTop.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-20));
		reportTop.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-20));
		reportTop.setBackground(Color.WHITE);
		
			JPanel reportTopContents = new JPanel(new GridBagLayout());
			reportTopContents.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width-10, UI_Settings.getSmallPanelHeight()-10));
			reportTopContents.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width-10, UI_Settings.getSmallPanelHeight()-10));
			reportTopContents.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width-10, UI_Settings.getSmallPanelHeight()-10));
			reportTopContents.setBackground(new Color(246,246,246));
			reportTopContents.setBorder(border);
		
			//////////////////Add the text boxes to this area////////////////

			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,20,0,0);
			reportTopContents.add(new JLabel("Lesson Type:"), gc);
			
			
			gc.gridx = 1;
			gc.gridy = 0;
			reportTopContents.add(txtLessonType, gc);
			
			gc.gridx = 2;
			gc.gridy = 0;
			reportTopContents.add(new JLabel("Material: "), gc);
			
			gc.gridx = 3;
			gc.gridy = 0;
			reportTopContents.add(txtMaterial, gc);
			
			gc.gridx = 4;
			gc.gridy = 0;
			reportTopContents.add(new JLabel("Language Center: "), gc);
			
			gc.gridx = 5;
			gc.gridy = 0;
			reportTopContents.add(txtLangaugeCenter, gc);
			
			gc.gridx = 6;
			gc.gridy = 0;
			reportTopContents.add(new JLabel("Unit/Page: "), gc);
			
			gc.gridx = 7;
			gc.gridy = 0;
			reportTopContents.add(txtUnitPage, gc);
			
			gc.gridx = 8;
			gc.gridy = 0;
			reportTopContents.add(new JLabel("Level: "), gc);
			
			gc.gridx = 9;
			gc.gridy = 0;
			reportTopContents.add(txtLevel, gc);
			
		gc.gridx = 0;
		gc.gridy = 0;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,5,5,10);
		reportTop.add(reportTopContents, gc);
		/***********************************************************************************************************************************/
		tableAR_ViewAll.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		tableAR_ViewAll.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));

		tableAR_ReportTop.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*2)));
		tableAR_ReportTop.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*2)));
		tableAR_ReportTop.setRowSelectionAllowed(false);
		
		
		tableAR_Middle.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*14)));
		tableAR_Middle.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*14)));
		//////////////////////////////////////////////////////Add the report details panel////////////////////////////////////////////////
		JPanel testScorePanel = new JPanel(new GridBagLayout());
		testScorePanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-20));
		testScorePanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-20));
		testScorePanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-20));
		testScorePanel.setBackground(Color.WHITE);
		
			JPanel testScorePanelContents = new JPanel(new GridBagLayout());
			testScorePanelContents.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width-10, UI_Settings.getSmallPanelHeight()-10));
			testScorePanelContents.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width-10, UI_Settings.getSmallPanelHeight()-10));
			testScorePanelContents.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width-10, UI_Settings.getSmallPanelHeight()-10));
			testScorePanelContents.setBackground(new Color(246,246,246));
			testScorePanelContents.setBorder(border);
		
			//////////////////Add the text boxes to this area////////////////
	
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,20,0,0);
			testScorePanelContents.add(new JLabel("Oral:"), gc);
			
			
			gc.gridx = 1;
			gc.gridy = 0;
			testScorePanelContents.add(txtOralOneTest, gc);
			
			gc.gridx = 2;
			gc.gridy = 0;
			testScorePanelContents.add(new JLabel("Mid-Level: "), gc);
			
			gc.gridx = 3;
			gc.gridy = 0;
			testScorePanelContents.add(txtMidLevelTest, gc);
			
			gc.gridx = 4;
			gc.gridy = 0;
			testScorePanelContents.add(new JLabel("Mid-Level Total:"), gc);
			
			gc.gridx = 5;
			gc.gridy = 0;
			testScorePanelContents.add(txtMidLevelTotalTest, gc);
			
			gc.gridx = 6;
			gc.gridy = 0;
			testScorePanelContents.add(new JLabel("Oral:"), gc);
			
			gc.gridx = 7;
			gc.gridy = 0;
			testScorePanelContents.add(txtOralTwoTest, gc);
			
			gc.gridx = 8;
			gc.gridy = 0;
			testScorePanelContents.add(new JLabel("End of Level:"), gc);
			
			gc.gridx = 9;
			gc.gridy = 0;
			testScorePanelContents.add(txtEndLevelScore, gc);
			
			gc.gridx = 10;
			gc.gridy = 0;
			testScorePanelContents.add(new JLabel("Total:"), gc);
			
			gc.gridx = 11;
			gc.gridy = 0;
			testScorePanelContents.add(txtTotalScore, gc);
			
		gc.gridx = 0;
		gc.gridy = 0;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,5,5,10);
		testScorePanel.add(testScorePanelContents, gc);
		
		labels[3].addMouseListener(new MouseAdapter(){
			
			private List<Integer> results = new ArrayList<Integer>();
			
			public void mousePressed(MouseEvent e){
				
				populate();
				
			}

			private void populate() {
				
				//Test score grading
				//4 - Excellent
				//3 - Very Good
				//2 - Good
				//1 - Please Review
				
				
				
				for(int i = 0; i < tableAR_Middle.getRowCount(); i++){
					
					
					for(int x = 1; x < tableAR_Middle.getColumnCount(); x++){
						
						Object selectedObject = (Object) tableAR_Middle.getModel().getValueAt(i, x);
						
						
						
					}
					
					System.out.println();
					
				}
				
				for(int index = 0; index < results.size(); index++){
					System.out.println(results.get(index));
				}
				
			}

			private String getResultString(Integer data) {
				
				switch(data){
				
				case 1: return "excellent";
				
				case 2: return "very good";
				
				case 3: return "good";
				
				case 4: return "please review";
				
				default: return "no reult given";
				
				}
			}
	
		});
		/******************************************************Add the Generate Report Buttons Panel************************************************/

		
		JPanel generateButtonPanel = new JPanel();
		generateButtonPanel.setBackground(UI_Settings.getButtonPanelColor());
		generateButtonPanel.setLayout(new BoxLayout(generateButtonPanel, BoxLayout.X_AXIS));
		generateButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		generateButtonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		generateButtonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
		left.setBackground(Color.WHITE);
		left.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		left.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		left.add(new JLabel("Generated Report Comments:"));
		
		JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		right.setBackground(UI_Settings.getComponentpanefillcolor());
		right.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		right.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		right.add(labels[3]);

		
		left.setAlignmentX(Component.LEFT_ALIGNMENT);
		generateButtonPanel.add(left);
		
		right.setAlignmentX(Component.RIGHT_ALIGNMENT);
		generateButtonPanel.add(right);
		
		/////////////////////////////Add the Reports Comments and Date of Report, Written By, and Manager Name components///////////////
		
		int paneloffset = 20;
		
		JPanel commentsPanel = new JPanel(new GridBagLayout());
		commentsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-paneloffset));
		commentsPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-paneloffset));
		commentsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-paneloffset));
		commentsPanel.setBackground(Color.WHITE);
			
			//Add the comments box//
			JPanel comments = new JPanel(new GridBagLayout());
			comments.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-paneloffset));
			comments.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-paneloffset));
			comments.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-paneloffset));
			comments.setBackground(Color.WHITE);
			comments.setBorder(border);
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,5,0,5);
			comments.add(reportCommentTextArea, gc);
			
			JPanel reportDetails = new JPanel(new GridBagLayout());
			reportDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-paneloffset));
			reportDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-paneloffset));
			reportDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-paneloffset));
			reportDetails.setBackground(new Color(246,246,246));
			reportDetails.setBorder(border);
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(5,20,0,0);
			reportDetails.add(new JLabel("Date of Report:"), gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			reportDetails.add(new JLabel("Report Prepared By:"), gc);
			
			gc.gridx = 0;
			gc.gridy = 2;
			reportDetails.add(new JLabel("Manager of Instruction:"), gc);
			
			
			gc.gridx = 1;
			gc.gridy = 0;
			reportDetails.add(txtReportDate, gc);
			
			gc.gridx = 1;
			gc.gridy = 1;
			reportDetails.add(cmbEmpNames, gc);
			
			gc.gridx = 1;
			gc.gridy = 2;
			reportDetails.add(txtManagerName, gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(5,5,5,0);
		commentsPanel.add(comments, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.3;
		gc.weighty = 0.3;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(5,5,5,10);
		commentsPanel.add(reportDetails, gc);
		/*************************************************Print Report Button Panel**************************************************/
		JPanel bottomButtons = new JPanel(new GridBagLayout());
		bottomButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-paneloffset));
		bottomButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-paneloffset));
		bottomButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-paneloffset));
		bottomButtons.setBackground(Color.WHITE);
			
			//Add the comments box//
			JPanel reportsFolder = new JPanel(new GridBagLayout());
			reportsFolder.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-paneloffset));
			reportsFolder.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-paneloffset));
			reportsFolder.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-paneloffset));
			reportsFolder.setBackground(Color.WHITE);
			
			
				JPanel lowerButtons = new JPanel();
				lowerButtons.setBackground(UI_Settings.getButtonPanelColor());
				lowerButtons.setLayout(new BoxLayout(lowerButtons, BoxLayout.X_AXIS));
				lowerButtons.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3*2, UI_Settings.getDetailsButtonPanelHeight()));
				lowerButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getDetailsButtonPanelHeight()));
				lowerButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getDetailsButtonPanelHeight()));
				
				JPanel lowerleft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
				lowerleft.setBackground(Color.WHITE);
				lowerleft.add(labels[9]);

				JPanel lowerright = new JPanel(new FlowLayout(FlowLayout.RIGHT, 25, 0));
				lowerright.setBackground(UI_Settings.getComponentpanefillcolor());
				lowerright.add(labels[10]);
				lowerright.add(labels[8]);

				lowerleft.setAlignmentX(Component.LEFT_ALIGNMENT);
				lowerButtons.add(lowerleft);
				
				lowerright.setAlignmentX(Component.RIGHT_ALIGNMENT);
				lowerButtons.add(lowerright);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,0,0);
				reportsFolder.add(lowerButtons, gc);
				
			
			JPanel passwordPanel = new JPanel(new GridBagLayout());
			passwordPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-paneloffset));
			passwordPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-paneloffset));
			passwordPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-paneloffset));
			passwordPanel.setBackground(Color.WHITE);
			//passwordPanel.setBorder(border);
			
				JPanel panel3 = new JPanel(new GridBagLayout());
				panel3.setBackground(new Color(246,246,246));
				panel3.setBorder(border);
				panel3.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getRegularPanelHeight()-70));
				panel3.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getRegularPanelHeight()-70));
				panel3.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getRegularPanelHeight()-70));
	
				
				btnPrintReport.addMouseListener(new MouseAdapter(){
					public void mouseReleased(MouseEvent e){
						
							SentryModule module = new SentryModule();
						
				           char[] input = passwordField2.getPassword();
				            if (module.takeInput(input)) {
				                JOptionPane.showMessageDialog(controllingFrame,
				                    "Welcome administrator. The report has been printed.");
				            } else {
				                JOptionPane.showMessageDialog(controllingFrame,
				                    "To print a customers report enter the administrators password",
				                    "Error Message",
				                    JOptionPane.ERROR_MESSAGE);
				            }
		
				            //Zero out the possible password, for security.
				            Arrays.fill(input, '0');
		
				            passwordField2.selectAll();
						
					}
				});
				
				labels[11].setCursor(UI_Settings.getJlabelCursor());
				labels[11].addMouseListener(new MouseAdapter(){
					public void mouseClicked(MouseEvent e){
						
						JOptionPane.showMessageDialog(controllingFrame,
				                "The administrator password can be found with the \"Kids Coordinator\"\n"
				              + "or by contacting your \"Branch Manager\".");
						
					}
				});
				JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 3));
				adminPanel.setBackground(Color.WHITE);
				adminPanel.add(new JLabel("Administrator password:"));
				adminPanel.add(passwordField2);
				adminPanel.add(labels[11]);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 2;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.SOUTHWEST;
				gc.insets = new Insets(5,0,0,0);
				
				panel3.add(adminPanel, gc);
				
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.insets = new Insets(5,79,0,0);
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				panel3.add(btnPrintReport, gc);//Print customer report button
				
				gc.gridx = 1;
				gc.gridy = 2;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.insets = new Insets(5,-20,0,10);
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				panel3.add(btnSave, gc);//Save customer report button
				
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.anchor = GridBagConstraints.SOUTHWEST;
				gc.insets = new Insets(0,0,0,0);
				
				passwordPanel.add(panel3, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,0);
				
				passwordPanel.add(new JLabel("This action cannot be undone"), gc);

		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(5,5,5,0);
		bottomButtons.add(reportsFolder, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.3;
		gc.weighty = 0.3;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(5,5,5,10);
		bottomButtons.add(passwordPanel, gc);
		/**********************************************************Start Building the table***********************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(Color.WHITE);
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        tableAR_ViewAll.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(tableAR_ViewAll);
        
       // centerPanel.add(Box.createVerticalStrut(20));
         int end;
         
        centerPanel.add(Box.createVerticalStrut(10));

        reportTop.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(reportTop);
        
        reportTopEditButtonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(reportTopEditButtonPanel);
        
        
        tableAR_Middle.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(tableAR_Middle);
        
        centerPanel.add(Box.createVerticalStrut(5));
        
        testScorePanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(testScorePanel);

        centerPanel.add(Box.createVerticalStrut(10));

        
        generateButtonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(generateButtonPanel);
        
        commentsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(commentsPanel);
        
        bottomButtons.setAlignmentY(Component.RIGHT_ALIGNMENT);
        centerPanel.add(bottomButtons);
        
		/*********************************************************************************************************************************/
		/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 1200));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 1200));
		
		
		//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		///////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly///////////////////

		
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
		return scroller;
	}//End addReport
	/*********************************************************************************************************************************************/
    
    //Must be called from the event dispatch thread.
    protected void resetFocus() {
        passwordField.requestFocusInWindow();
    }
}