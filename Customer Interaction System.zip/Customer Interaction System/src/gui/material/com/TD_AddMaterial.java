package gui.material.com;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_AddMaterial extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int MATERIAL_ID = 0;
	public final static int MATERIAL_NAME = 1;
	public final static int PUBLISHER = 2;
	public final static int EDITION = 3;
	public final static int MATERIAL_DESCRIPTION = 4;
	
	public Object[][]values =
		{
				{ new Integer(23423), "Time Zone", "Andrew Robinson", "2nd Edition", "Time Zones is a four-level, four skilled series that combines a communicative approach ..."},
				{"", "", "", "", ""}
		};
	
	public final static String[] COLUMN_NAMES = {"Material ID", "Material Name", "Publisher", "Edition",
		"Material Description" };


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}
	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList( 10, 20, 20, 10, 40));

}
