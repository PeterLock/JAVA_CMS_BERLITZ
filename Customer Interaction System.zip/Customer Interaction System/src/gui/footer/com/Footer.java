package gui.footer.com;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class Footer extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Footer(){
		
		
		JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 0,3));
		
		this.setBackground(new Color(25,31,37));
		footer.setPreferredSize(new Dimension((int) java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth(), 17));
		footer.setMinimumSize(new Dimension((int) java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth(), 17));
		footer.setBackground(new Color(25,31,37));
		
		JLabel message = new JLabel("Customer Interaction Management System. All rights reserved \u2120 2017");
		message.setForeground(new Color(63,77,79));
		footer.add(message);
		footer.setVisible(true);
		add(footer);
		
	}
	
	static void main(String[] args){
		
		Footer footer = new Footer();
		footer.setVisible(true);
		
	}

}
