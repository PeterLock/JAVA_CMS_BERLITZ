package settings;

import javax.swing.table.AbstractTableModel;

public class TableNoData extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	public Object[][]values =
		{
				{ new Integer(0), true, true, new Integer(0)},
				{ new Integer(0), true, true, new Integer(0)}

		};
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public Class<?> getColumnClass(int col) {
		switch(col){
		case 0: 
			return Integer.class;
		case 1: 
			return Boolean.class;
		case 2: 
			return Boolean.class;
		case 3:
			return Integer.class;
		default:
			return null;
		}
	}


	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
}
