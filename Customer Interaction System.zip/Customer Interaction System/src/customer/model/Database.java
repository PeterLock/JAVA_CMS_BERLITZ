package customer.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Database {
	
	private List<Customer> viewall_customers;
	private List<Customer> addnew_customers;

	private int count = 0;
	private Connection con;
	
	public Database(){
		
		viewall_customers = new ArrayList<Customer>();
		addnew_customers = new ArrayList<Customer>();

	}
	
	public void connect() throws Exception{
		
		if(con != null)return;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new Exception("Driver not found");
		}
		

		String url = "jdbc:mysql://localhost:3306/CIS_DB?autoReconnect=true&useSSL=false";
		
		con = DriverManager.getConnection(url, "root", "password");
		
		System.out.println("Connected: " + con.getCatalog());
		
	}
	
	public void disconnect(){
		if(con != null){
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println("Can't close the connection");
			}
		}
	}
	
	public void save() throws SQLException{
		
		String checkSql = "select count(*) as count from customers where ID=?";
		
		PreparedStatement checkStmt = con.prepareStatement(checkSql);
		
		String insertSql = "insert into customers (id, firstName, lastName, month, material, level, age, listening, speaking, reading, participation, cooperation, interests, comments) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		PreparedStatement insertStatement = con.prepareStatement(insertSql);
		
		String updateSql = "update customers set firstName=?, lastName=?, month=?, material=?, level=?, age=?, listening=?, speaking=?, reading=?, participation=?, cooperation=?, interests=?, comments=? where id=?";
		PreparedStatement updateStatement = con.prepareStatement(updateSql);
		
		for(Customer customer : addnew_customers){
			
			int t = customer.getId();
			if(t > 0){
				
				int id = customer.getId();

				String firstName = customer.getFirstname();
				
				String lastName = customer.getLastname();
				MonthCategory month = customer.getMonthCategory();
				String material = customer.getMaterial();
				String level = customer.getLevel();
				String age = customer.getAge();
				int listening = customer.getListening();
				int speaking = customer.getSpeaking();
				int reading = customer.getReading();
				int participation = customer.getParticipation();
				int cooperation = customer.getCooperation();
				String interests = customer.getInterests();
				String comments = customer.getComments();
				
				checkStmt.setInt(1, id);
				
				ResultSet checkResult = checkStmt.executeQuery();
				checkResult.next();
				
				int count = checkResult.getInt(1);
				
				
				if(count == 0){
					System.out.println("Inserting customer with ID " + id);
					
					int col = 1;
					
					insertStatement.setInt(col++, id);
					insertStatement.setString(col++, firstName);
					insertStatement.setString(col++, lastName);
					insertStatement.setString(col++, month.name());
					insertStatement.setString(col++, material);
					insertStatement.setString(col++, level);
					insertStatement.setString(col++, age);
					insertStatement.setInt(col++, listening);
					insertStatement.setInt(col++, speaking);
					insertStatement.setInt(col++, reading);
					insertStatement.setInt(col++, participation);
					insertStatement.setInt(col++, cooperation);
					insertStatement.setString(col++, interests);
					insertStatement.setString(col++, comments);
					
					insertStatement.executeUpdate();

				}
				else{
					System.out.println("Updating customer with ID " + id);
					
					int col = 1;
					
					System.out.println(month.name());
					
					updateStatement.setString(col++, firstName);
					updateStatement.setString(col++, lastName);
					updateStatement.setString(col++, month.name());
					updateStatement.setString(col++, material);
					updateStatement.setString(col++, level);
					updateStatement.setString(col++, age);
					updateStatement.setInt(col++, listening);
					updateStatement.setInt(col++, speaking);
					updateStatement.setInt(col++, reading);
					updateStatement.setInt(col++, participation);
					updateStatement.setInt(col++, cooperation);
					updateStatement.setString(col++, interests);
					updateStatement.setString(col++, comments);
					updateStatement.setInt(col++, id);
					
					updateStatement.executeUpdate();
				}
			}
		}
		updateStatement.close();
		insertStatement.close();
		checkStmt.close();
	}
	
	public void load() throws SQLException{
		viewall_customers.clear();
		
		String sql = "select id, firstName, lastName, month, material, level, age, listening, speaking, reading, participation, cooperation, interests, comments from Customers order by firstName";
		Statement selectStatement = con.createStatement();
		
		ResultSet results = selectStatement.executeQuery(sql);
		
		while(results.next()){
			int id = results.getInt("id");
			String firstName = results.getString("firstName");
			String lastName = results.getString("lastName");
			String month = results.getString("month");
			String material = results.getString("material");
			String level = results.getString("level");
			String age = results.getString("age");
			int listen = results.getInt("listening");
			int speak = results.getInt("speaking");
			int read = results.getInt("reading");
			int par = results.getInt("participation");
			int coop = results.getInt("cooperation");
			String interests = results.getString("interests");
			String comments = results.getString("comments");
			
			
			
			Customer customer = new Customer(firstName, lastName, MonthCategory.valueOf(month), material,
				 level, id, listen, speak, read, par, coop, age, interests,
				 comments);
			
			viewall_customers.add(customer);
			
		}
		
		if(viewall_customers.size() < 13){
			populateRemainingRows(viewall_customers, 13);
		}
		
		results.close();
		selectStatement.close();
	}
	
	
	public void removeCustomer(int index, int i){
		if(index <0){
			return;
		}else{
			if( i == 1){
				int remove_id = viewall_customers.get(index).getId();
				
				viewall_customers.remove(index);
				populateRemainingRows(viewall_customers, 13);
				
				delete(remove_id);
				
				try {
					this.save();
				} catch (SQLException e) {
					System.err.println("Unable to save database");
			}
			if( i == 2){
				addnew_customers.remove(index);
				populateRemainingRows(addnew_customers, 11);			
				}
			}
		}
	}
	
	private void delete(int remove_id) {
		System.out.println("Inside the delete method with id : " + remove_id);
		
		 try 
		 {  
			PreparedStatement statement = con.prepareStatement("DELETE FROM Customers WHERE id = ?");
			statement.setInt(1,remove_id);
			statement.executeUpdate(); 
			
			System.err.println("Exiting delete try/catch");

		 }
		 catch(Exception e)
		 {
		     System.out.println("An error deleting this record has been found.");
		 }
		 
		 
		 
	}

	public void addCustomer(Customer customer){
		//The table is initially filled with 10 empty rows. For the first 6 user input rows
		//remove the last row (the empty row). After that just add to the array as usual.
		if(this.addnew_customers.size()==11){
			this.addnew_customers.add(0, customer);
			this.addnew_customers.remove(this.addnew_customers.get(11-1));
		}else{
			if(count >11){
				this.addnew_customers.add(0, customer);
			}else{
				this.addnew_customers.add(0, customer);
				count++;	
			}
		}
	}
	
	public void addEmptyCustomer(Customer customer){
		//The table is initially filled with 13 empty rows. For the first 13 user input rows
		//remove the last row (the empty row). After that just add to the array as usual.
		if(this.viewall_customers.size()==13){
			this.viewall_customers.add(0, customer);
			this.viewall_customers.remove(this.viewall_customers.get(this.getEmpty_customer().size()-1));
		}else{
			
			if(count >13){
				this.viewall_customers.add(0, customer);
			}else{
				this.viewall_customers.add(0, customer);
				count++;	
			}
		}
	}
	
	public List<Customer>getCustomer(){
		return viewall_customers;
	}
	
	public List<Customer> getEmpty_customer() {
		return addnew_customers;
	}
	
	public void saveToFile(File file) throws IOException{
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		Customer[] customers = this.viewall_customers.toArray(new Customer[this.viewall_customers.size()]);
		
		oos.writeObject(customers);
		
		fos.close();
		oos.close();
		
	}
	
	public void loadFromFile(File file) throws IOException {
		FileInputStream fis = new FileInputStream(file);
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		try {
			Customer[] customers = (Customer[]) ois.readObject();
			
			viewall_customers.clear();
			viewall_customers.addAll(Arrays.asList(customers));

			if(viewall_customers.size() < 13){
				populateRemainingRows(viewall_customers, 13);
			}
		
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		fis.close();
		ois.close();
		
	}

	private void populateRemainingRows(List<Customer> data, int j) {
       	for(int i = data.size()+1; i <=j; i++){
       		data.add(new Customer("", "", null, "", "", 0, 0,  0,  0,  0,  0,  "",  "", ""));
    	}
	}

	public String getName() {
		//On the TODO list//
		return "CIS_DB";
	}

	public void search(String firstName, String lastName, String month, String material, String level) throws SQLException {

		viewall_customers.clear();
		
		String first = firstName;
		
		
		if(firstName.isEmpty()){
			
		}

		String searchSql = "select * from Customers where firstName ='" + first + "'";
		
/*		pstmt = conn.prepareStatement("select * FROM Courses WHERE " 
		         + "(product = ? or ? is null) " 
		         + "and (location = ? or ? is null) " 
		         + "and (courseType = ? or ? is null)" 
		         + "and (category = ? or ? is null)"); */
		
		
		try {
			connect();
		} catch (Exception e) {
			System.out.println("Cannot connect to the database");
		}
		Statement selectStatement = con.createStatement();
		
		ResultSet results = selectStatement.executeQuery(searchSql);
		
		while(results.next()){
			int id = results.getInt("id");
			String first_name = results.getString("firstName");
			String last_name = results.getString("lastName");
			String _month = results.getString("month");
			String _material = results.getString("material");
			String _level = results.getString("level");
			String age = results.getString("age");
			int listen = results.getInt("listening");
			int speak = results.getInt("speaking");
			int read = results.getInt("reading");
			int par = results.getInt("participation");
			int coop = results.getInt("cooperation");
			String interests = results.getString("interests");
			String comments = results.getString("comments");
			
			
			
			Customer customer = new Customer(first_name, last_name, MonthCategory.valueOf(_month), _material,
				 _level, id, listen, speak, read, par, coop, age, interests,
				 comments);
			
			viewall_customers.add(customer);
			
		}
		
		if(viewall_customers.size() < 13){
			populateRemainingRows(viewall_customers, 13);
		}
		
		results.close();
		selectStatement.close();
	}
	
}
