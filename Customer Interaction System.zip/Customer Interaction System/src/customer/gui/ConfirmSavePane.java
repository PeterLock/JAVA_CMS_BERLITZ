package customer.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import control.gui.FormListener;
import customer.controller.Controller;
import customer.model.MonthCategory;
import settings.UI_Settings;
import utilities.FrameDragListener;
import utilities.JTextFieldLimit;
import utilities.TextPrompt;


public class ConfirmSavePane {
	
	private JFrame frame;
	private JPanel panel;
	private JPanel header;
	private JPanel btnPanel;
	
	private JButton btnConfirm;
	private JButton btnCancel;
	
	private JTextField txtFirstname;
	private JTextField txtLastname;
	private JTextField txtMonthStarted;
	private JTextField txtMaterial;
	private JTextField txtLevel;
	private JTextField txtlistening;
	private JTextField txtSpeaking;
	private JTextField txtReading;
	private JTextField txtParticipation;
	private JTextField txtCooperation;
	private JTextField txtAge;
	private JTextField txtID;
	
	private JTextArea txtAreaInterests;
	private JTextArea txtAreaComments;
	
	private JLabel lblCloseWindow;
	private JLabel lblViewInterests = new JLabel("view interests");
	private JLabel lblViewComments = new JLabel("view comments");
	
	
	private int frame_width = 450;
	private int frame_height = 590;

	private Dimension dimension = new Dimension(frame_width, frame_height);
	
	private List <JTextField> textfields = new ArrayList<JTextField>();
	private Border border = BorderFactory.createLineBorder(new Color(180,180,180));


	private FormEvent ev;
	private FormListener formListener;
	private TablePanel tablePanel;
	private Controller controller;
	
	
	public ConfirmSavePane(FormEvent ev, FormListener formListener, TablePanel tablePanel, Controller controller) {
		
		this.ev = ev;
		this.formListener = formListener;
		this.tablePanel = tablePanel;
		this.controller = controller;
		
	}

	public void run() {
		
		int width = (int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
		int height = (int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
		
		panel = new JPanel(new GridBagLayout());
		panel.setSize(dimension);
		panel.setMinimumSize(dimension);
		panel.setMaximumSize(dimension);
		panel.setBackground(Color.WHITE);
		
		initializeComponents();
		addComponents();
		
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		frame.setContentPane(panel);
		FrameDragListener frameDragListener = new FrameDragListener(frame);
		frame.addMouseListener(frameDragListener);
		frame.addMouseMotionListener(frameDragListener);
		frame.setPreferredSize(panel.getPreferredSize());
		frame.setSize(dimension);
		frame.setUndecorated(true);
		frame.getRootPane().setWindowDecorationStyle(JRootPane.NONE);
		frame.setLocation(width/2-frame_width/2, height/2-frame_height/2);  //Centers the frame//
		frame.setVisible(true);
		frame.pack();
	}

	private void initializeComponents() {
		
		int textfield_sizes = 20;
		
		lblViewInterests.setForeground(UI_Settings.getComponentsFontColorLight());
		lblViewInterests.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		
		lblViewComments.setForeground(UI_Settings.getComponentsFontColorLight());
		lblViewComments.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

		lblCloseWindow = new JLabel("close window [x]");
		lblCloseWindow.setForeground(Color.WHITE);
		lblCloseWindow.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
		lblCloseWindow.addMouseListener(new MouseAdapter(){
			
			public void mouseReleased(MouseEvent e){
				frame.setVisible(false);
			}
			
		});
		
		btnConfirm = new JButton("Confirm");
		btnConfirm.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnConfirm.setPreferredSize(UI_Settings.getJbuttonSize());
		btnConfirm.setFont(UI_Settings.getComponentInputFontSize());
		btnConfirm.addMouseListener(new MouseAdapter(){
			
			public void mouseReleased(MouseEvent e){
				
				if(formListener != null){
					formListener.formEventOccurred(ev);
					tablePanel.refresh();
					frame.setVisible(false);
				}
				
			}
		});
		
		btnCancel = new JButton("Cancel");
		btnCancel.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnCancel.setPreferredSize(UI_Settings.getJbuttonSize());
		btnCancel.setFont(UI_Settings.getComponentInputFontSize());
		
		btnCancel.addMouseListener(new MouseAdapter(){
			
			public void mouseReleased(MouseEvent e){
				frame.setVisible(false);
			}
			
		});
		
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(5, 5, 5, 5);
		CompoundBorder border = new CompoundBorder(line, empty);
		
		txtAreaComments = new JTextArea(2, 4);
		txtAreaComments.setEditable(false);
		txtAreaComments.setBorder(UI_Settings.getBorderoutline());
		txtAreaComments.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaComments.setWrapStyleWord(true);
		txtAreaComments.setLineWrap(true);
		txtAreaComments.setDocument(new JTextFieldLimit(150));
		txtAreaComments.setBorder(border);
		txtAreaComments.setPreferredSize(txtAreaComments.getPreferredSize());
		@SuppressWarnings("unused")
		TextPrompt textPrompt = new TextPrompt("<no comments added>", txtAreaComments);
		
		
		txtAreaInterests = new JTextArea(2, 4);
		txtAreaInterests.setEditable(false);
		txtAreaInterests.setBorder(UI_Settings.getBorderoutline());
		txtAreaInterests.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaInterests.setWrapStyleWord(true);
		txtAreaInterests.setLineWrap(true);
		txtAreaInterests.setDocument(new JTextFieldLimit(150));
		txtAreaInterests.setBorder(border);
		txtAreaInterests.setPreferredSize(txtAreaInterests.getPreferredSize());
		textPrompt = new TextPrompt("<no interests added>", txtAreaInterests);
		
		
		
		txtFirstname = new JTextField(textfield_sizes);
		txtLastname = new JTextField(textfield_sizes);
		txtMonthStarted = new JTextField(textfield_sizes);
		txtMaterial = new JTextField(textfield_sizes);
		txtLevel = new JTextField(textfield_sizes);
		txtLevel.setHorizontalAlignment(JTextField.CENTER);
		
		txtlistening = new JTextField(textfield_sizes);
		txtSpeaking = new JTextField(textfield_sizes);
		txtReading = new JTextField(textfield_sizes);
		txtParticipation = new JTextField(textfield_sizes);
		txtCooperation = new JTextField(textfield_sizes);
		
		txtlistening.setHorizontalAlignment(JTextField.CENTER);
		txtSpeaking.setHorizontalAlignment(JTextField.CENTER);
		txtReading.setHorizontalAlignment(JTextField.CENTER);
		txtParticipation.setHorizontalAlignment(JTextField.CENTER);
		txtCooperation.setHorizontalAlignment(JTextField.CENTER);

		
		txtAge = new JTextField(textfield_sizes);
		txtAge.setHorizontalAlignment(JTextField.LEFT);
		txtID = new JTextField(textfield_sizes);

		txtFirstname.setText(ev.getFirstname());
		txtLastname.setText(ev.getLastname());
		
		if(ev.getMonth() !=0){
			MonthCategory monthCategory = MonthCategory.values()[ev.getMonth()-1];
			txtMonthStarted.setText(monthCategory.toString());
		}else{
			txtMonthStarted.setText("");
		}
		
		
		
		txtMaterial.setText(ev.getMaterial());
		txtLevel.setText(ev.getLevel());
		
		txtlistening.setText(isEmpty(ev.getListen()));
		txtSpeaking.setText(isEmpty(ev.getSpeak()));
		txtReading.setText(isEmpty(ev.getRead()));
		txtParticipation.setText(isEmpty(ev.getParticipation()));
		txtCooperation.setText(isEmpty(ev.getCooperation()));
		
		txtAge.setText(ev.getAge());
		
		txtID.setText(Integer.toString(ev.getId()));
		
		
		
		
		if(ev.getInterests() !=null){
			txtAreaInterests.setText(ev.getInterests());
		}
		
		if(ev.getInterests() !=null){
			txtAreaComments.setText(ev.getComments());
		}
		
		
		textfields.add(txtFirstname);
		textfields.add(txtLastname);
		textfields.add(txtMonthStarted);
		textfields.add(txtMaterial);
		textfields.add(txtLevel);
		textfields.add(txtlistening);
		textfields.add(txtSpeaking);
		textfields.add(txtReading);
		textfields.add(txtParticipation);
		textfields.add(txtCooperation);
		textfields.add(txtAge);
		textfields.add(txtID);
		
		for(int i = 0; i < textfields.size(); i++){
			textfields.get(i).setMinimumSize(textfields.get(i).getPreferredSize());
			textfields.get(i).setEditable(false);
			//textfields.get(i).setFont(UI_Settings.getComponentInputFontSize());
			textfields.get(i).setForeground(UI_Settings.getComponentInputFontColor());
			textfields.get(i).setHorizontalAlignment(JTextField.CENTER);
		}
		
		btnPanel = new JPanel();
		btnPanel.setBorder(new EmptyBorder(0,0,0,0));
		btnPanel.setBackground(new Color(246,246,246));
		btnPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 0));
		btnPanel.setPreferredSize(new Dimension((int) dimension.getWidth(), UI_Settings.getPopupHeaderHeight()));
		btnPanel.setMinimumSize(new Dimension(new Dimension((int) dimension.getWidth(), UI_Settings.getPopupHeaderHeight())));
		btnPanel.setMaximumSize(new Dimension(new Dimension((int) dimension.getWidth(), UI_Settings.getPopupHeaderHeight())));
		btnPanel.add(btnCancel);
		btnPanel.add(btnConfirm);

		
		header = new JPanel();
		header.setBorder(new EmptyBorder(0,0,0,0));
		header.setBackground(Color.WHITE);
		header.setLayout(new BoxLayout(header, BoxLayout.X_AXIS));
		header.setPreferredSize(new Dimension((int) dimension.getWidth(), UI_Settings.getPopupHeaderHeight()));
		header.setMinimumSize(new Dimension(new Dimension((int) dimension.getWidth(), UI_Settings.getPopupHeaderHeight())));
		header.setMaximumSize(new Dimension(new Dimension((int) dimension.getWidth(), UI_Settings.getPopupHeaderHeight())));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 5));
		leftPanel.setBackground(UI_Settings.getPopupHeaderColor());
		leftPanel.setPreferredSize(new Dimension((int) dimension.getWidth()/2, UI_Settings.getPopupHeaderHeight()));
		leftPanel.setMinimumSize(new Dimension((int) dimension.getWidth()/2, UI_Settings.getPopupHeaderHeight()));
		//leftPanel.add(new JLabel("<left-side>"));
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
		rightPanel.setBackground(UI_Settings.getPopupHeaderColor());
		rightPanel.setPreferredSize(new Dimension((int) dimension.getWidth()/2, UI_Settings.getPopupHeaderHeight()));
		rightPanel.setMinimumSize(new Dimension((int) dimension.getWidth()/2, UI_Settings.getPopupHeaderHeight()));
		rightPanel.add(lblCloseWindow);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		header.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		header.add(rightPanel);
		
	}

	private String isEmpty(int data) {
		
		if(data <=0)return "0/5";
		else{
			if(data >=5){
				return "5/5";
			}else{
				return data + "/5";
			}
		}
	}


	private void addComponents() {
		GridBagConstraints gc = new GridBagConstraints();
		
		////Row 1///
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 2;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,30,0);
		panel.add(header, gc);
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,15,0,0);
		panel.add(new JLabel("First Name:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,0,0,20);
		panel.add(txtFirstname, gc);
		
		gc.gridx = 0;
		gc.gridy = 2;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,15,0,0);
		panel.add(new JLabel("Last Name:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,0,0,20);
		panel.add(txtLastname, gc);
		
	
		gc.gridx = 0;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,15,0,0);
		panel.add(new JLabel("Customer ID:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,0,0,20);
		panel.add(txtID, gc);
		
		gc.gridx = 0;
		gc.gridy = 4;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,15,0,0);
		panel.add(new JLabel("Date Joined"), gc);
		
		gc.gridx = 1;
		gc.gridy = 4;
		gc.insets = new Insets(0,0,0,20);
		panel.add(txtMonthStarted, gc);
	
		gc.gridx = 0;
		gc.gridy = 5;
		gc.gridheight = 1;
		gc.gridwidth = 2;
		gc.weightx = 2;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,15,0,0);
		panel.add(new JLabel("Material:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 5;
		gc.gridheight = 1;
		gc.gridwidth = 3;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,0,0,20);
		panel.add(txtMaterial, gc);
		
		gc.gridx = 0;
		gc.gridy = 6;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,15,0,0);
		panel.add(new JLabel("Age:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 6;
		gc.insets = new Insets(0,0,0,20);
		panel.add(txtAge, gc);
		
		gc.gridx = 0;
		gc.gridy = 7;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,15,0,0);
		panel.add(new JLabel("Level:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 7;
		gc.insets = new Insets(0,0,0,20);
		panel.add(txtLevel, gc);
	
	
		gc.gridx = 0;
		gc.gridy = 8;
		gc.insets = new Insets(0,15,0,0);
		panel.add(new JLabel("Listening:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 8;
		gc.insets = new Insets(0,0,0,20);
		panel.add(txtlistening, gc);
		
		gc.gridx = 0;
		gc.gridy = 9;
		gc.insets = new Insets(0,15,0,0);
		panel.add(new JLabel("Speaking:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 9;
		gc.insets = new Insets(0,0,0,20);
		panel.add(txtSpeaking, gc);
			
		gc.gridx = 0;
		gc.gridy = 10;
		gc.insets = new Insets(0,15,0,0);
		panel.add(new JLabel("Reading:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 10;
		gc.insets = new Insets(0,0,0,20);
		panel.add(txtReading, gc);
		
		gc.gridx = 0;
		gc.gridy = 11;
		gc.insets = new Insets(0,15,0,0);
		panel.add(new JLabel("Participation:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 11;
		gc.insets = new Insets(0,0,0,20);
		panel.add(txtParticipation, gc);
		
		gc.gridx = 0;
		gc.gridy = 12;
		gc.insets = new Insets(0,15,0,0);
		panel.add(new JLabel("Cooperation:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 12;
		gc.insets = new Insets(0,0,0,20);
		panel.add(txtCooperation, gc);
		
		gc.gridx = 0;
		gc.gridy = 13;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(10,15,0,0);
		panel.add(new JLabel("Comments:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 13;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(10,4,10,24);
		panel.add(txtAreaComments, gc);
		
		gc.gridx = 0;
		gc.gridy = 14;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,15,0,0);
		panel.add(new JLabel("Interests:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 14;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,4,10,24);
		panel.add(txtAreaInterests, gc);
		
		gc.gridx = 0;
		gc.gridy = 15;
		gc.gridheight = 1;
		gc.gridwidth = 2;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(10,5,10,5);
		panel.add(btnPanel, gc);
	}
}