package group.controller;


import java.util.List;

import customer.gui.FormEvent;
import customer.model.Customer;
import customer.model.Database;
import customer.model.MonthCategory;

public class Controller {
	
	static Database db = new Database();
	
	public static List<Customer> getCustomer(){
		return db.getCustomer();
	}
	
	public static List<Customer> getEmptyCustomer(){
		return db.getEmpty_customer();
	}
	
	
	public void addCustomer(FormEvent ev){
		

		String firstname = ev.getFirstname();
		String lastname = ev.getLastname();
		int monthId = ev.getMonth();
		String material = ev.getMaterial();
		String level = ev.getLevel();
		int id = ev.getId();
		
		MonthCategory monthCategory = null;
		
		switch(monthId){
		
		case 1:
			monthCategory = MonthCategory.January;
			break;
		case 2:
			monthCategory = MonthCategory.February;
			break;
		case 3:
			monthCategory = MonthCategory.March;
			break;
		case 4:
			monthCategory = MonthCategory.April;
			break;
		case 5:
			monthCategory = MonthCategory.May;
			break;
		case 6:
			monthCategory = MonthCategory.June;
			break;
		case 7:
			monthCategory = MonthCategory.July;
			break;
		case 8:
			monthCategory = MonthCategory.August;
			break;
		case 9:
			monthCategory = MonthCategory.September;
			break;
		case 10:
			monthCategory = MonthCategory.October;
			break;
		case 11:
			monthCategory = MonthCategory.November;
			break;
		case 12:
			monthCategory = MonthCategory.December;
			break;
		default:
		
		}
		
		 int listen = ev.getListen();
		 int speak = ev.getSpeak();
		 int read = ev.getRead();
		 int par = ev.getParticipation();
		 int coop = ev.getCooperation();
		 String age = ev.getAge();
		 String interests = ev.getInterests();
		 String comments = ev.getComments();
		 
		
		Customer customer = new Customer(firstname, lastname, monthCategory, material,
			 level, id, listen, speak, read, par, coop, age, interests,
			 	comments);
		
		
		db.addCustomer(customer);
	}
	
	///////////////////////////////////////////////////////////////////////
	public void addEmptyCustomer(FormEvent ev){
			
	
			String firstname = ev.getFirstname();
			String lastname = ev.getLastname();
			int monthId = ev.getMonth();
			String material = ev.getMaterial();
			String level = ev.getLevel();
			int id = ev.getId();
			
			MonthCategory monthCategory = null;
			
			switch(monthId){
			
			case 1:
				monthCategory = MonthCategory.January;
				break;
			case 2:
				monthCategory = MonthCategory.February;
				break;
			case 3:
				monthCategory = MonthCategory.March;
				break;
			case 4:
				monthCategory = MonthCategory.April;
				break;
			case 5:
				monthCategory = MonthCategory.May;
				break;
			case 6:
				monthCategory = MonthCategory.June;
				break;
			case 7:
				monthCategory = MonthCategory.July;
				break;
			case 8:
				monthCategory = MonthCategory.August;
				break;
			case 9:
				monthCategory = MonthCategory.September;
				break;
			case 10:
				monthCategory = MonthCategory.October;
				break;
			case 11:
				monthCategory = MonthCategory.November;
				break;
			case 12:
				monthCategory = MonthCategory.December;
				break;
			default:
			
			}
			
			 int listen = ev.getListen();
			 int speak = ev.getSpeak();
			 int read = ev.getRead();
			 int par = ev.getParticipation();
			 int coop = ev.getCooperation();
			 String age = ev.getAge();
			 String interests = ev.getInterests();
			 String comments = ev.getComments();
			 
			
			Customer customer = new Customer(firstname, lastname, monthCategory, material,
				 level, id, listen, speak, read, par, coop, age, interests,
				 	comments);
			
			
			db.addEmptyCustomer(customer);
		}


}
