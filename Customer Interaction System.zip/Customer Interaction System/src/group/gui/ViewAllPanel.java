package group.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.TextPrompt;

public class ViewAllPanel extends JPanel {
	
	public void ViewAllPanel(){
	}
	
	public Component run() {
		JScrollPane scroller = initialize();
		return scroller;
	}
	
	
	public JScrollPane initialize(){
		
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		
		//JButton btnDeleteGroup;
		JButton btnAddGroup;

		
		//Center Panel fields
		JTextField txtTopPanelStudentName;
		JTextField txtTopPanelAge;
		
		JTextField txtTopGroupName;
		JTextField txtTopGroupID;
		JTextField txtTopGroupPos;
		JTextField txtTopGroupLev;
		JTextField txtTopGroupDay;
		JTextField txtTopGroupTime;
		JTextField txtTopGroupMax;
		JTextField txtTopGroupMat;
		
		JPasswordField passwordField;
	    passwordField = new JPasswordField(10);
	    passwordField.setActionCommand(UI_Settings.getOk());
	    
	    JTextArea txtMoveFromNameContainer;
		/***************************************************Create labels***********************************************************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage.setVisible(false);
		
		JLabel labels[] = new JLabel[8];
		labels[0] = new JLabel("reset data");
		labels[1] = new JLabel("undo move");
		labels[2] = new JLabel("help");
		labels[3] = new JLabel("help");
		labels[4] = new JLabel("move");
		labels[5] = new JLabel("view interests");
		labels[6] = new JLabel("view comments");
		labels[7] = new JLabel("reset move to data");
		
		
		for(int i = 0; i < 8; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());	
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		////////Initialize local fields here for convenience/////////
		txtMoveFromNameContainer = new JTextArea(7, 20);
		txtMoveFromNameContainer.setEditable(true);
		txtMoveFromNameContainer.setBorder(UI_Settings.getBorderoutline());
		txtMoveFromNameContainer.setWrapStyleWord(true);
		txtMoveFromNameContainer.setLineWrap(true);
		txtMoveFromNameContainer.setDocument(new JTextFieldLimit(150));
		
		txtMoveFromNameContainer.setPreferredSize(txtMoveFromNameContainer.getPreferredSize());
		
		/*********************************************Add the Bottom Panel TextFields***********************/

		int size = 13;
		
		
		List <JTextField> textfieldsGroupDetailsTop = new ArrayList<JTextField>();
		List <JTextField> textfieldsGroupDetailsBottom = new ArrayList<JTextField>();

		
		
		txtTopGroupName = new JTextField(size);
		txtTopGroupName.setMinimumSize(txtTopGroupName.getPreferredSize());
		txtTopGroupName.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupName); 
		
		txtTopGroupID = new JTextField(size);
		txtTopGroupID.setMinimumSize(txtTopGroupID.getPreferredSize());
		txtTopGroupID.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupID); 

		
		txtTopGroupPos = new JTextField(size);
		txtTopGroupPos.setMinimumSize(txtTopGroupPos.getPreferredSize());
		txtTopGroupPos.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupPos); 

		
		txtTopGroupLev = new JTextField(size);
		txtTopGroupLev.setMinimumSize(txtTopGroupLev.getPreferredSize());
		txtTopGroupLev.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupLev); 
		
		txtTopGroupDay = new JTextField(size);
		txtTopGroupDay.setMinimumSize(txtTopGroupDay.getPreferredSize());
		txtTopGroupDay.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupDay); 

		
		txtTopGroupTime = new JTextField(size);
		txtTopGroupTime.setMinimumSize(txtTopGroupTime.getPreferredSize());
		txtTopGroupTime.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupTime); 

		
		txtTopGroupMax = new JTextField(size);
		txtTopGroupMax.setMinimumSize(txtTopGroupMax.getPreferredSize());
		txtTopGroupMax.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupMax); 

		
		txtTopGroupMat = new JTextField(size);
		txtTopGroupMat.setMinimumSize(txtTopGroupMat.getPreferredSize());
		txtTopGroupMat.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupMat); 
		
		txtTopPanelStudentName = new JTextField(10);
		txtTopPanelStudentName.setEditable(true);
		txtTopPanelStudentName.setMinimumSize(txtTopPanelStudentName.getPreferredSize());
		TextPrompt textPrompt = new TextPrompt("-", txtTopPanelStudentName);
		txtTopPanelStudentName.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetailsTop.add(txtTopPanelStudentName);
		
		txtTopPanelAge = new JTextField(5);
		txtTopPanelAge.setEditable(true);
		txtTopPanelAge.setMinimumSize(txtTopPanelAge.getPreferredSize());
		textPrompt = new TextPrompt("-", txtTopPanelAge);
		txtTopPanelAge.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetailsTop.add(txtTopPanelAge);
		
		
		/*********************************************************Create Combo Boxes*********************************************************/
		JComboBox<String> cmbMoveFromGroupName = new JComboBox<String>(UI_Settings.getGroups());
		cmbMoveFromGroupName.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbMoveFromGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbMoveFromGroupName.setMinimumSize(cmbMoveFromGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbMoveFromGroupName, 180, UI_Settings.getComboBoxHeight());

		JComboBox<String> cmbMoveToGroupName = new JComboBox<String>(UI_Settings.getGroups());
		cmbMoveToGroupName.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbMoveToGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbMoveToGroupName.setMinimumSize(cmbMoveToGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbMoveToGroupName, 180, UI_Settings.getComboBoxHeight());
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		//Reset move to button//
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
				failedMessage.setVisible(false);
				
				for(int i = 0; i < textfieldsGroupDetailsTop.size(); i++){
					textfieldsGroupDetailsTop.get(i).setText("");
				}
				
				txtMoveFromNameContainer.setText("");
				
				cmbMoveFromGroupName.setSelectedIndex(0);
				
				passwordField.setText("");
				   
			}
		});
		//Reset move to button//
		labels[7].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				for(int i = 0; i < textfieldsGroupDetailsBottom.size(); i++){
					textfieldsGroupDetailsBottom.get(i).setText("");
				}
				cmbMoveToGroupName.setSelectedIndex(0);
				passwordField.setText("");
			}
		});
		/*****************************************************************************************************************************/

		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		GridBagConstraints gc = new GridBagConstraints();
		
		////////////////////////////////////////////////////////////////
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		container.setBackground(Color.WHITE);
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		container.add(new JLabel("Select the group you want view:"));
		container.add(cmbMoveFromGroupName);
		
		container.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(container);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(17,0,0,0);
		detailsPanel.add(firstRow, gc);
		/******************************************************Add the Buttons Panel************************************************/
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 25));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 25));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 25));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 7));
		rightPanel.setBackground(Color.WHITE);
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 25));
		rightPanel.add(labels[0]);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		
		
		/*************************************************Add Student to Group Buttons Panel***********************************************/
		JPanel middleComponents = new JPanel(new GridBagLayout());
		middleComponents.setBackground(Color.WHITE);

		middleComponents.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		middleComponents.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		
		/////////////////////////////Start the center panels///////////////////////////////////	
		int topFrameHeight = 210;
		
		JPanel pnlCenterTopPanel = new JPanel(new GridBagLayout());
		pnlCenterTopPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		pnlCenterTopPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		pnlCenterTopPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		
		JPanel pnlCenterTopLeft = new JPanel(new GridBagLayout());
		pnlCenterTopLeft.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		pnlCenterTopLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		pnlCenterTopLeft.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		
		Border darkBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY);


			//add components to the left panel
			pnlCenterTopLeft.setBorder(darkBorder);
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(30,10,0,0);
			pnlCenterTopLeft.add(new JLabel("Click on the students name to select:"), gc);
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,10,20,10);
			pnlCenterTopLeft.add(txtMoveFromNameContainer, gc);
			
		JPanel pnlCenterTopRight = new JPanel(new GridBagLayout());
		pnlCenterTopRight.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setBackground(Color.WHITE);

			int centerTopHeight = 50;
			JPanel pnlCenterTopRightTop = new JPanel(new GridBagLayout());
			pnlCenterTopRightTop.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setBackground(Color.WHITE);

				//Add the contents of this panel - the student name and the student age plus buttons
				//Add the student name panel//
				JPanel pnlStudentName = new JPanel(new GridBagLayout());
				pnlStudentName.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				pnlStudentName.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				pnlStudentName.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				pnlStudentName.setBorder(darkBorder);
				pnlStudentName.setBackground(Color.WHITE);
					//Add student name fields//
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 0.2;
					gc.weighty = 0.2;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,10,0,0);
					pnlStudentName.add(new JLabel("Student Name:"),gc);
					gc.gridx = 1;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 0.2;
					gc.weighty = 0.2;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,10,0,0);
					pnlStudentName.add(txtTopPanelStudentName,gc);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 0.2;
				gc.weighty = 0.2;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,0,0);
				pnlCenterTopRightTop.add(pnlStudentName,gc);
				
				JPanel pnlStudentButtons = new JPanel(new GridBagLayout());
				pnlStudentButtons.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				pnlStudentButtons.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				pnlStudentButtons.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				pnlStudentButtons.setBorder(darkBorder);
				pnlStudentButtons.setBackground(Color.WHITE);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,1);
				pnlStudentButtons.add(new JLabel("Age:"), gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,-20,0,0);
				pnlStudentButtons.add(txtTopPanelAge, gc);
				
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,0);
				pnlStudentButtons.add(labels[5], gc);
				
				gc.gridx = 3;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,0);
				pnlStudentButtons.add(labels[6], gc);
				
				
				
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,1);
				pnlCenterTopRightTop.add(pnlStudentButtons, gc);

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		pnlCenterTopRight.add(pnlCenterTopRightTop, gc);
		
				//Add the contents of the bottom panel, the group details
				//Add the group details (toprightbottom)
				JPanel pnlTopGroupDetails = new JPanel(new GridBagLayout());
				pnlTopGroupDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
				pnlTopGroupDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
				pnlTopGroupDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
				pnlTopGroupDetails.setBackground(Color.WHITE);
				pnlTopGroupDetails.setBorder(darkBorder);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(20,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Name:"),gc);
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group ID:"),gc);
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Positions Available:"),gc);
				gc.gridx = 0;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Level:"),gc);
				gc.gridx = 1;
				gc.gridy = 0;
				gc.insets = new Insets(15,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupName,gc);
				gc.gridx = 1;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupID,gc);
				gc.gridx = 1;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupPos,gc);
				gc.gridx = 1;
				gc.gridy = 3;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupLev,gc);
				gc.gridx = 2;
				gc.gridy = 0;
				gc.insets = new Insets(20,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Day:"),gc);
				gc.gridx = 2;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Time:"),gc);
				gc.gridx = 2;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Size:"),gc);
				gc.gridx = 2;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Material:"),gc);
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(15,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupDay,gc);
				gc.gridx = 3;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupTime,gc);
				gc.gridx = 3;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupMax,gc);
				gc.gridx = 3;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupMat,gc);
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,0,1,0);
		pnlCenterTopRight.add(pnlTopGroupDetails, gc);
		
				
		pnlCenterTopLeft.setBackground(new Color(246,246,246));
		

		
		//This is the main container panel for the North most components on the central stage - namely pnlCenterTopLeftPanel and pnlCenterTopRight//
		pnlCenterTopPanel.setBackground(Color.WHITE);
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,5,0,5);
			pnlCenterTopPanel.add(pnlCenterTopLeft, gc);
			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,5,0,10);
			pnlCenterTopPanel.add(pnlCenterTopRight, gc);
		////////////////////////////END OF THE TOP LEVEL COMPONENTS////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////

		///////////////////////////////////////////////////////////////////////////////////////
		JPanel pnlGroupDetails = new JPanel();
		pnlGroupDetails.setBackground(Color.WHITE);
		pnlGroupDetails.setLayout(new GridBagLayout());
		pnlGroupDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-40));
		pnlGroupDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-40));
		pnlGroupDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-40));

			//Create the far left container for the web address details information
			JPanel pnlGroupLeft = new JPanel(new GridBagLayout());
			pnlGroupLeft.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
			pnlGroupLeft.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
			pnlGroupLeft.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
			
				//Add the nested panels to the container panel (information panel)
				Border panel1border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);

				JPanel pnlLeft = new JPanel(new GridBagLayout());
				pnlLeft.setBackground(Color.WHITE);
				//pnlLeft.setBorder(panel1border);
				pnlLeft.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
				pnlLeft.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
				pnlLeft.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.insets = new Insets(0,0,0,0);
				pnlGroupLeft.add(pnlLeft, gc);
				
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.insets = new Insets(5,5,5,5);
				pnlGroupDetails.add(pnlGroupLeft, gc);
		
		
			//Create the far left container for the web address details information
			JPanel pnlGroupButton = new JPanel(new GridBagLayout());
			pnlGroupButton.setBackground(Color.WHITE);
			pnlGroupButton.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
			pnlGroupButton.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
			pnlGroupButton.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel pnlDeleteGroup = new JPanel(new GridBagLayout());
				pnlDeleteGroup.setBackground(new Color(246,246,246));
				pnlDeleteGroup.setBorder(panel1border);
				pnlDeleteGroup.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
				pnlDeleteGroup.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
				pnlDeleteGroup.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));

				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,0);
				

				
				labels[2].setCursor(UI_Settings.getJlabelCursor());
				labels[2].addMouseListener(new MouseAdapter(){
					public void mouseClicked(MouseEvent e){
						
						
					}
				});
				
				btnAddGroup = new JButton("Add New Group");
				btnAddGroup.setCursor(UI_Settings.getJlabelCursor());
				btnAddGroup.setFont(UI_Settings.getComponentInputFontSize());
				btnAddGroup.setPreferredSize(new Dimension(150,UI_Settings.getJbuttonSize().height));
				btnAddGroup.setMinimumSize(new Dimension(150,UI_Settings.getJbuttonSize().height));
				btnAddGroup.addMouseListener(new MouseAdapter(){
					
					private String group_name;
					
					public void mousePressed(MouseEvent e){
						group_name = (String)cmbMoveToGroupName.getSelectedItem();
					}
					
					public void mouseReleased(MouseEvent e){
						//Temp block while developing - remove later
	/*							SentryModule module = new SentryModule();
						
				           char[] input = passwordField.getPassword();
				            if (module.takeInput(input)) {
								passwordField.setText("");
				                AddGroupPane pane = new AddGroupPane();
								pane.run();
								
				            } else {
				                JOptionPane.showMessageDialog(controllingFrame,
				                    "Welcome Administrator. Please enter the correct password.",
				                    "Welcome Administrator",
				                    JOptionPane.WARNING_MESSAGE);
									passwordField.setText("");

				            }
		
				            //Zero out the possible password, for security.
				            Arrays.fill(input, '0');
		
				            passwordField.selectAll();*/
					}
					
				});
				
				
				JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 3));
				adminPanel.setBackground(Color.WHITE);
				adminPanel.add(new JLabel("Administrator password:"));
				adminPanel.add(passwordField);
				adminPanel.add(labels[2]);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 2;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTH;
				gc.insets = new Insets(15,0,0,0);
				
				pnlDeleteGroup.add(adminPanel, gc);
				
				gc.gridx = 1;
				gc.gridy = 2;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.insets = new Insets(0,0,0,25);
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHEAST;
				pnlDeleteGroup.add(btnAddGroup, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.anchor = GridBagConstraints.NORTH;
				gc.insets = new Insets(0,0,0,5);
				
				pnlGroupButton.add(pnlDeleteGroup, gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(5,5,5,5);
				pnlGroupDetails.add(pnlGroupButton, gc);
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
	    centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
	    
	    
	    buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(buttonPanel);
	    
	    pnlCenterTopPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(pnlCenterTopPanel);
	    
	    centerPanel.add(Box.createVerticalStrut(5));

	    pnlGroupDetails.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(pnlGroupDetails);
		/*********************************************************************************************************************************/
		///////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly///////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 600));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 600));
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());		
		//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return(scroller);
	}
}
