package group.gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import control.gui.TableTemplate;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class AddStudentPanel extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	TextPrompt textPrompt;
	Boolean ignoreEvents = false;
	
	
	TD_AddCustomer addCustomerTableData = new TD_AddCustomer();
	TD_ViewAllCustomer viewallCustomersTableData = new TD_ViewAllCustomer();
	TD_Members groupMembersTableData = new TD_Members();
	
	TableTemplate addNewCustomerTable = new TableTemplate(addCustomerTableData, addCustomerTableData.getCUSTOMER_PERCENTAGES(), "");
	TableTemplate viewAllCustomersTable = new TableTemplate(viewallCustomersTableData, viewallCustomersTableData.getCOLUMN_PERCENTAGES(), "");
	TableTemplate groupMemberListTable = new TableTemplate(groupMembersTableData, groupMembersTableData.getCOLUMN_PERCENTAGES(), "Group Members");

	
	public AddStudentPanel(){
	}

	public Component run(){
		
		JScrollPane scroller = initialize();
		
		return scroller;
	}

	@SuppressWarnings("unused")
	private JScrollPane initialize() {
		
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		JPanel pnlAssessmentDetails;
		
		
		
		JTextField txtLastName;
		JTextField txtFirstName;
		JTextField txtMaterial;
		JTextField txtPositionsAvailable;
		
		JTextField txtListen;
		JTextField txtSpeak;
		JTextField txtRead;
		JTextField txtParticipate;
		JTextField txtCooperate;
		
		JTextField txtGroupName;
		JTextField txtGroupID;
		JTextField txtGroupPos;
		JTextField txtGroupLev;
		JTextField txtGroupDay;
		JTextField txtGroupTime;
		JTextField txtGroupMax;
		JTextField txtGroupMat;
		
		JLabel assessmentOptional = new JLabel("Assessment Details [optional");

		
		pnlAssessmentDetails = new JPanel(new GridBagLayout());
		pnlAssessmentDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 70));
		pnlAssessmentDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 70));
		pnlAssessmentDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 70));
		pnlAssessmentDetails.setBackground(Color.WHITE);

		
		List<JTextField> textfields = new ArrayList<JTextField>();
		List<JTextField> textfieldsGroupDetails = new ArrayList<JTextField>();

		@SuppressWarnings("rawtypes")
		List<JComboBox> comboboxes = new ArrayList<JComboBox>();
		List<TextPrompt> textprompts = new ArrayList<TextPrompt>();

		
		JCheckBox chkNewStudent;
		JCheckBox chkExistingStudent;
		
		JPanel cards; 
		JPanel card1;
		JPanel card2;
		
		JPanel cardsButtons;
		JPanel cardsNCButtonsPanel;
		JPanel cardsECButtonsPanel;
		
		cards = new JPanel(new CardLayout());
		cardsButtons = new JPanel(new CardLayout());
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setCursor(UI_Settings.getJlabelCursor());
		btnSearch.setPreferredSize(UI_Settings.getJbuttonSize());
		btnSearch.setFont(UI_Settings.getComponentInputFontSize());
		
		JButton btnSaveStudent;
		JButton btnAddStudent;
		
		JTextArea txtAreaMemberNames;

		
		final String NEW_CUSTOMER_PANEL = "New Customer";
		final String EXISTING_CUSTOMER_PANEL = "Existing Customer";
		
		final String NEW_CUSTOMER_PANEL_BUTTONS = "New Customer Buttons";
		final String EXISTING_CUSTOMER_PANEL_BUTTONS = "Existing Customer Buttons";
		/***************************************************Create labels***********************************************************************/
		JLabel failedMessage1 = new JLabel(UI_Settings.getFailedMessage());
		failedMessage1.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage1.setVisible(false);
		
		JLabel failedMessage2 = new JLabel(UI_Settings.getFailedMessage());
		failedMessage2.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage2.setVisible(false);
		
		JLabel labels[] = new JLabel[11];
		
		labels[0] = new JLabel("generate");
		labels[1] = new JLabel("reset fields");
		labels[2] = new JLabel("reset fields");
		labels[3] = new JLabel("show assessment details");
		labels[4] = new JLabel("Assessment details (optional)");
		labels[5] = new JLabel("edit");
		labels[6] = new JLabel("delete");
		labels[7] = new JLabel("reset local fields");
		labels[8] = new JLabel("edit comment for group member");
		labels[9] = new JLabel("edit");
		labels[10] = new JLabel("delete");
		
		
		for(int i = 0; i < 11; i++) {
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());	
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		/***************************************************Create textFields********************************************************************/
		txtFirstName = new JTextField(10);
		txtFirstName.setMinimumSize(txtFirstName.getPreferredSize());
		txtFirstName.setHorizontalAlignment(JTextField.LEFT);
		textfields.add(txtFirstName); 
		
		txtLastName = new JTextField(10);
		txtLastName.setMinimumSize(txtLastName.getPreferredSize());
		txtLastName.setHorizontalAlignment(JTextField.LEFT);
		textfields.add(txtLastName); 

		txtPositionsAvailable = new JTextField(5);
		txtPositionsAvailable.setEditable(false);
		txtPositionsAvailable.setMinimumSize(txtPositionsAvailable.getPreferredSize());
		TextPrompt textPrompt = new TextPrompt("-", txtPositionsAvailable);
		txtPositionsAvailable.setHorizontalAlignment(JTextField.CENTER);	
		textfields.add(txtPositionsAvailable); 

		txtMaterial = new JTextField(15);
		txtMaterial.setEditable(false);
		txtMaterial.setMinimumSize(txtMaterial.getPreferredSize());
		textPrompt = new TextPrompt("-", txtMaterial);
		txtMaterial.setHorizontalAlignment(JTextField.CENTER);
		textfields.add(txtMaterial); 
		/*********************************************Add the Bottom Panel TextFields***********************/

		int size = 13;
		
		String prompt = "-";
		
		
		txtGroupName = new JTextField(size);
		txtGroupName.setMinimumSize(txtGroupName.getPreferredSize());
		txtGroupName.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupName); 
		TextPrompt textPrompt1 = new TextPrompt(prompt, txtGroupName);
		textprompts.add(textPrompt1);
		
		txtGroupID = new JTextField(size);
		txtGroupID.setMinimumSize(txtGroupID.getPreferredSize());
		txtGroupID.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupID); 
		TextPrompt textPromp2 = new TextPrompt(prompt, txtGroupID);
		textprompts.add(textPromp2);

		
		txtGroupPos = new JTextField(size);
		txtGroupPos.setMinimumSize(txtGroupPos.getPreferredSize());
		txtGroupPos.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupPos); 
		TextPrompt textPrompt3 = new TextPrompt(prompt, txtGroupPos);
		textprompts.add(textPrompt3);

		
		txtGroupLev = new JTextField(size);
		txtGroupLev.setMinimumSize(txtGroupLev.getPreferredSize());
		txtGroupLev.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupLev); 
		TextPrompt textPrompt4 = new TextPrompt(prompt, txtGroupLev);
		textprompts.add(textPrompt4);
		
		txtGroupDay = new JTextField(size);
		txtGroupDay.setMinimumSize(txtGroupDay.getPreferredSize());
		txtGroupDay.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupDay); 
		TextPrompt textPrompt5 = new TextPrompt(prompt, txtGroupDay);
		textprompts.add(textPrompt5);

		
		txtGroupTime = new JTextField(size);
		txtGroupTime.setMinimumSize(txtGroupTime.getPreferredSize());
		txtGroupTime.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupTime); 
		TextPrompt textPrompt6 = new TextPrompt(prompt, txtGroupTime);
		textprompts.add(textPrompt6);

		
		txtGroupMax = new JTextField(size);
		txtGroupMax.setMinimumSize(txtGroupMax.getPreferredSize());
		txtGroupMax.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupMax); 
		TextPrompt textPrompt7 = new TextPrompt(prompt, txtGroupMax);
		textprompts.add(textPrompt7);

		
		txtGroupMat = new JTextField(size);
		txtGroupMat.setMinimumSize(txtGroupMat.getPreferredSize());
		txtGroupMat.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupMat); 
		TextPrompt textPrompt8 = new TextPrompt(prompt, txtGroupMat);
		textprompts.add(textPrompt8);

		/////////////////////////////////////////////////////////////
		txtListen = new JTextField(8);
		txtListen.setEditable(true);
		txtListen.setMinimumSize(txtListen.getPreferredSize());
		textPrompt = new TextPrompt("0 / 5", txtListen);
		txtListen.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetails.add(txtListen); 
		
		txtSpeak = new JTextField(8);
		txtSpeak.setEditable(true);
		txtSpeak.setMinimumSize(txtSpeak.getPreferredSize());
		textPrompt = new TextPrompt("0 / 5", txtSpeak);
		txtSpeak.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetails.add(txtSpeak); 
		
		txtRead = new JTextField(8);
		txtRead.setEditable(true);
		txtRead.setMinimumSize(txtRead.getPreferredSize());
		textPrompt = new TextPrompt("0 / 5", txtRead);
		txtRead.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetails.add(txtRead); 
		
		txtParticipate = new JTextField(8);
		txtParticipate.setEditable(true);
		txtParticipate.setMinimumSize(txtParticipate.getPreferredSize());
		textPrompt = new TextPrompt("0 / 5", txtParticipate);
		txtParticipate.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetails.add(txtParticipate); 
		
		txtCooperate = new JTextField(8);
		txtCooperate.setEditable(true);
		txtCooperate.setMinimumSize(txtCooperate.getPreferredSize());
		textPrompt = new TextPrompt("0 / 5", txtCooperate);
		txtCooperate.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetails.add(txtCooperate); 
		/*********************************************************Create the Combo Boxes*********************************************************/
		JComboBox<String> cmbMaterial = new JComboBox<String>(UI_Settings.getBooks());
		cmbMaterial.setFont(UI_Settings.getComponentInputFontSize());
		cmbMaterial.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbMaterial.setMaximumSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbMaterial.setMinimumSize(cmbMaterial.getPreferredSize());
		//AutoCompletion.enable(cmbMaterial, 150, 27);
		
		comboboxes.add(cmbMaterial);
		
		JComboBox<?> cmbLevels = new JComboBox<Object>(UI_Settings.getLevels());
		cmbLevels.setPreferredSize(new Dimension(80, 27));
		cmbLevels.setFont(UI_Settings.getComponentInputFontSize());
		//AutoCompletion.enable(cmbLevels, 80, 27);
		
		comboboxes.add(cmbLevels);
		
		JComboBox<?> cmbMonths = new JComboBox<Object>(UI_Settings.getMonths());
		cmbMonths.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		cmbMonths.setFont(UI_Settings.getComponentInputFontSize());
		cmbMonths.setMinimumSize(cmbMonths.getPreferredSize());
		//AutoCompletion.enable(cmbMonths, 120, 27);
		
		comboboxes.add(cmbMonths);
		
		JComboBox<String> cmbGroupName = new JComboBox<String>(UI_Settings.getGroups());
		cmbGroupName.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbGroupName.setMinimumSize(cmbGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbGroupName, 180, 27);
		
		comboboxes.add(cmbGroupName);
	
		/**********************************Create CheckBoxes***********************************/
		chkExistingStudent = new JCheckBox("Existing Student");
		chkNewStudent = new JCheckBox("New Student");
		
		chkNewStudent.setFont(UI_Settings.getComponentsFontPlain());
		chkNewStudent.setForeground(UI_Settings.getComponentsFontColorLight());
		chkNewStudent.setSelected(true);
		chkNewStudent.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e) {
				if(chkNewStudent.isSelected()==true){
					chkExistingStudent.setSelected(false);
					pnlAssessmentDetails.setVisible(true);
					assessmentOptional.setVisible(true);
					
					resetASTG_TextFields(textfields, comboboxes, failedMessage1, failedMessage2);
					
					for(int i = 0; i < textprompts.size(); i++) {
						textprompts.get(i).setText("-");
						textfieldsGroupDetails.get(i).setEditable(true);
					}
					
					CardLayout cl = (CardLayout)(cards.getLayout());
					cl.show(cards, NEW_CUSTOMER_PANEL);
					
					CardLayout cl2 = (CardLayout)(cardsButtons.getLayout());
					cl2.show(cardsButtons, NEW_CUSTOMER_PANEL_BUTTONS);
					
				}
			}
		});
		
		chkExistingStudent.setFont(UI_Settings.getComponentsFontPlain());
		chkExistingStudent.setForeground(UI_Settings.getComponentsFontColorLight());
		chkExistingStudent.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				if(chkExistingStudent.isSelected()==true){
					chkNewStudent.setSelected(false);
					pnlAssessmentDetails.setVisible(false);
					assessmentOptional.setVisible(false);
					
					resetASTG_TextFields(textfields, comboboxes, failedMessage1, failedMessage2);
					
					for(int i = 0; i < textprompts.size(); i++){
						textprompts.get(i).setText("-");
						textfieldsGroupDetails.get(i).setEditable(false);
					}

					
					CardLayout cl = (CardLayout)(cards.getLayout());
					cl.show(cards, EXISTING_CUSTOMER_PANEL);
					
					CardLayout cl2 = (CardLayout)(cardsButtons.getLayout());
					cl2.show(cardsButtons, EXISTING_CUSTOMER_PANEL_BUTTONS);
					
				}				
			}
		});
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		////////////////Reset button  on card layout 2/////////////
		labels[1].addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(AddStudentPanel.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   
					resetASTG_TextFields(textfields, comboboxes, failedMessage1, failedMessage2);


		       }
			}
		});
		////////////////Reset button  on card layout 2/////////////
		labels[2].addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(AddStudentPanel.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   
					resetASTG_TextFields(textfields, comboboxes, failedMessage1, failedMessage2);

		       }
			}
		});
		
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/***********************************     **Create edit, delete, table header and print panels***************************************/
		JPanel addGroupTableButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		addGroupTableButtonPanel.add(new JLabel("Positions Available"));//Positions available label
		addGroupTableButtonPanel.setBackground(UI_Settings.getButtonPanelColor());
		addGroupTableButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		addGroupTableButtonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		
		JPanel showAllCustomersButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		showAllCustomersButtonPanel.add(labels[3]);//Show assessment details label
		showAllCustomersButtonPanel.setBackground(UI_Settings.getButtonPanelColor());
		showAllCustomersButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		showAllCustomersButtonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(UI_Settings.getButtonPanelColor());
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		detailsPanel.setLayout(new GridBagLayout());
		
		//Create the GridBagConstraints object
		GridBagConstraints gc = new GridBagConstraints();
		/**********************************************************Card layout for the details panel********************************************************/
		//Contains the Add New Student and Existing Student CheckBoxes
		JPanel checkBoxesPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		checkBoxesPanel.setBackground(UI_Settings.getButtonPanelColor());
		checkBoxesPanel.add(chkNewStudent);
		checkBoxesPanel.add(chkExistingStudent);
		checkBoxesPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableButtonsPanelHeight()+10));
		checkBoxesPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableButtonsPanelHeight()+10));

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 10;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		
		detailsPanel.add(checkBoxesPanel, gc);
		/////////////////////////////////////////////////////Card 1 - New Customer//////////////////////////////////////////////
		
		gc.gridx = 0;
		gc.gridy = 2;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,10,13,-24);
		detailsPanel.add(new JLabel("Customer Name:"), gc); //Customer name label
		
		//////////////////////////////////////////Begin Column 2 ///////////////////////////////////////////
		gc.gridx = 1;
		gc.gridy = 1;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(-7,12,7,-12);
		detailsPanel.add(new JLabel("First Name"), gc); //FirstName Label

		gc.gridx = 1;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-7,9,7,-9);
		detailsPanel.add(textfields.get(0), gc); //FirstName TextField
		
		
		//////////////////////////////////////////Begin Column 3 ///////////////////////////////////////////
		gc.gridx = 2;
		gc.gridy = 1;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(-7,-12,7,12);
		detailsPanel.add(new JLabel("Last Name"), gc); //Last Name Label

		gc.gridx = 2;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-7,-16,7,16);
		detailsPanel.add(txtLastName, gc); //Last Name TextField
		//////////////////////////////////////////Begin Column 4///////////////////////////////////////////	
		gc.gridx = 3;
		gc.gridy = 2;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,-27,13,27);
		detailsPanel.add(new JLabel("Month Started:"), gc); //Month started label
		//////////////////////////////////////////Begin Column 5///////////////////////////////////////////	

		gc.gridx = 4;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-8,-27,8,27);
		detailsPanel.add(cmbMonths, gc); //Month started combo
		//////////////////////////////////////////Begin Column 6///////////////////////////////////////////		

		
		gc.gridx = 5;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,-18,13,18);
		detailsPanel.add(new JLabel("Material:"), gc); //Material label
		//////////////////////////////////////////Begin Column 7///////////////////////////////////////////		

		gc.gridx = 7;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-12,-24,12,24);
		detailsPanel.add(cmbMaterial, gc); //Materials Title ComboBox
		//////////////////////////////////////////Begin Column 8///////////////////////////////////////////	

		gc.gridx = 8;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,0,13,0);
		detailsPanel.add(new JLabel("Level:"), gc); //Level label
		//////////////////////////////////////////Begin Column 9///////////////////////////////////////////	
		gc.gridx = 9;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-11,2,11,-2);
		detailsPanel.add(cmbLevels, gc); //Level combo
		

		/******************************************************Add the Buttons Panel************************************************/
		cardsNCButtonsPanel = new JPanel();
		
		cardsNCButtonsPanel.setLayout(new BoxLayout(cardsNCButtonsPanel, BoxLayout.X_AXIS));
		cardsNCButtonsPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		cardsNCButtonsPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		cardsNCButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel ncLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		ncLeftPanel.setBackground(Color.WHITE);
		ncLeftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ncLeftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ncLeftPanel.add(failedMessage1);
		
		btnSaveStudent = new JButton("Save");
		btnSaveStudent.setFont(UI_Settings.getComponentInputFontSize());
		btnSaveStudent.setCursor(UI_Settings.getJlabelCursor());
		btnSaveStudent.setPreferredSize(UI_Settings.getJbuttonSize());
		
		
		JPanel ncRightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		ncRightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		ncRightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ncRightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ncRightPanel.add(labels[1]);
		//ncRightPanel.add(btnSaveStudent);
		
		btnAddStudent = new JButton("Add Student To Group");
		btnAddStudent.setFont(UI_Settings.getComponentInputFontSize());
		btnAddStudent.setCursor(UI_Settings.getJlabelCursor());
		
		//ncRightPanel.add(btnAddStudent);

		
		ncLeftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		cardsNCButtonsPanel.add(ncLeftPanel);
		
		ncRightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		cardsNCButtonsPanel.add(ncRightPanel);
		
		
		cardsECButtonsPanel = new JPanel();
		cardsECButtonsPanel.setBackground(UI_Settings.getButtonPanelColor());
		cardsECButtonsPanel.setLayout(new BoxLayout(cardsECButtonsPanel, BoxLayout.X_AXIS));
		cardsECButtonsPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		cardsECButtonsPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		cardsECButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel ecLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		ecLeftPanel.setBackground(Color.WHITE);
		ecLeftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ecLeftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ecLeftPanel.add(failedMessage2);
		//leftPanel.add();
		
		JPanel ecRightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 2));
		ecRightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		ecRightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ecRightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ecRightPanel.add(labels[2]);
		ecRightPanel.add(btnSearch);

		
		ecLeftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		cardsECButtonsPanel.add(ecLeftPanel);
		
		ecRightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		cardsECButtonsPanel.add(ecRightPanel);
		

		
		cardsNCButtonsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsECButtonsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsNCButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsECButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
	
		cardsButtons.add(cardsNCButtonsPanel, NEW_CUSTOMER_PANEL_BUTTONS);
		cardsButtons.add(cardsECButtonsPanel, EXISTING_CUSTOMER_PANEL_BUTTONS );
		
		
		////////////////////////////////////////////////////////Create the Card Layout for the details panel/////////////////////////////////////////////////////////////////////////////////////
		card1 = new JPanel(new GridBagLayout());
		card2 = new JPanel(new GridBagLayout());
		
		int cardsHeight = 6;
		
		card1.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		card2.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		cards.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		
		card1.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		card2.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		cards.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		
		////////////////////////////////////////////////////CARDS 1/////////////////////////////////////////////////////////////
		gc.gridx = 0;
		gc.gridy = 6;
		gc.gridheight = 5;
		gc.gridwidth = 10;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(2,0,-2,0);
		gc.fill = GridBagConstraints.HORIZONTAL;
		card1.add(addNewCustomerTable, gc); //View all customers table list	
		////////////////////////////////////////////////////CARDS 2/////////////////////////////////////////////////////////////
		btnSearch.addMouseListener(new MouseAdapter(){
			
			private String firstname;
			private String lastname;
			private String month;
			private String material;
			private Integer level;
			
			public void mousePressed(MouseEvent e) {

				firstname = txtFirstName.getText();
				lastname = txtLastName.getText();
				month = (String) cmbMonths.getSelectedItem();
				material = (String) cmbMaterial.getSelectedItem();
				level = (Integer)cmbLevels.getSelectedItem();
				}
			
			public void mouseReleased(MouseEvent e){
				
				if(checkValues()){
					
					
					for(int i = 0; i < textfields.size(); i++){
						textfields.get(i).setBackground(Color.WHITE);
					}
					
					for(int i = 0; i < comboboxes.size(); i++){
						comboboxes.get(i).getEditor().getEditorComponent().setBackground(Color.WHITE);
					}
					
					
				}
			}

			private boolean checkValues() {
				
				if(firstname.isEmpty() && lastname.isEmpty() && month.isEmpty() && material.isEmpty() && level == null){
					
					failedMessage2.setVisible(true);
					
					for(int i = 0; i < textfields.size()-1; i++){
						textfields.get(i).setBackground(UI_Settings.getComponentErrorColor());
					}
					
					for(int i = 0; i < comboboxes.size()-1; i++){
						comboboxes.get(i).getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
					}
					
					
					JOptionPane.showMessageDialog(AddStudentPanel.this, UI_Settings.getDlgSearchExistingStudentFail(), "", JOptionPane.WARNING_MESSAGE);
					return false;
				}
				failedMessage2.setVisible(false);
				return true;
			}
	
		});
		gc.gridx = 0;
		gc.gridy = 6;
		gc.gridheight = 5;
		gc.gridwidth = 10;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(2,0,-2,0);
		gc.fill = GridBagConstraints.HORIZONTAL;
		card2.add(viewAllCustomersTable, gc); //View all customers table list
		/////////////////////////////////////////////Add the Cards to the details panel///////////////////////////////////////
		card1.setBackground(Color.WHITE);
		card2.setBackground(Color.WHITE);
		
		cards.add(card1, NEW_CUSTOMER_PANEL);
		cards.add(card2, EXISTING_CUSTOMER_PANEL);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 10;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(30,0,-30,0);
		
		/********************************************************Set the Table Objects Sizes**************************************************/
		addNewCustomerTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		addNewCustomerTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		
		viewAllCustomersTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		viewAllCustomersTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		
		groupMemberListTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*7)));
		groupMemberListTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*7)));
		/******************************************************Add the edit-delete split panel************************************************/
		/*
		 * Add the edit and delete text buttons on a split screen - for future use
		 * 
		 */
		
		JPanel editdeletePanel = new JPanel();
		editdeletePanel.setBackground(UI_Settings.getButtonPanelColor());
		editdeletePanel.setLayout(new BoxLayout(editdeletePanel, BoxLayout.X_AXIS));
		editdeletePanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		editdeletePanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		editdeletePanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel edLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 7));
		edLeft.setBackground(Color.WHITE);
		edLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		edLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		
		edLeft.add(assessmentOptional);
		
		JPanel edRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 7));
		edRight.setBackground(UI_Settings.getComponentpanefillcolor());
		edRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		edRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		edRight.add(labels[9]);
		edRight.add(labels[10]);

		
		edLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		editdeletePanel.add(edLeft);
		
		edRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		editdeletePanel.add(edRight);
		/******************************************************add the enter assessment scores panel************************************************/
		
		///create the inner panel with the border///
		JPanel assessDetails = new JPanel(new GridBagLayout());
		assessDetails.setBackground(new Color(246,246,246));
		Border panel3border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
		assessDetails.setBorder(panel3border);
		assessDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 60));
		assessDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 60));
		assessDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 60));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-5,10,0,10);
		assessDetails.add(new JLabel("Listening:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		gc.insets = new Insets(-10,-20,0,20);
		assessDetails.add(txtListen, gc);
		
		gc.gridx = 2;
		gc.gridy = 1;
		gc.insets = new Insets(-5,-15,0,15);
		assessDetails.add(new JLabel("Speaking:"), gc);
		
		gc.gridx = 3;
		gc.gridy = 1;
		gc.insets = new Insets(-10,-10,0,10);
		assessDetails.add(txtSpeak, gc);
		
		gc.gridx = 4;
		gc.gridy = 1;
		gc.insets = new Insets(-5,10,0,0);
		assessDetails.add(new JLabel("Reading:"), gc);
		
		gc.gridx = 5;
		gc.gridy = 1;
		gc.insets = new Insets(-10,10,0,0);
		assessDetails.add(txtRead, gc);
		
		gc.gridx = 6;
		gc.gridy = 1;
		gc.insets = new Insets(-5,10,0,0);
		assessDetails.add(new JLabel("Participation:"), gc);
		
		gc.gridx = 7;
		gc.gridy = 1;
		gc.insets = new Insets(-10,10,0,0);
		assessDetails.add(txtParticipate, gc);
		
		gc.gridx = 8;
		gc.gridy = 1;
		gc.insets = new Insets(-5,10,0,0);
		assessDetails.add(new JLabel("Cooperation:"), gc);
		
		gc.gridx = 9;
		gc.gridy = 1;
		gc.insets = new Insets(-10,10,0,0);
		assessDetails.add(txtCooperate, gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,10,0,10);
		pnlAssessmentDetails.add(assessDetails, gc);

		
		
		//////////////////////////////////////////////End Add Assessments Entry Panel////////////////////////////////////////////
		
		JPanel middleComponents = new JPanel(new GridBagLayout());
		middleComponents.setBackground(Color.WHITE);

		middleComponents.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		middleComponents.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,10,0,-26);

		middleComponents.add(new JLabel("Select the group you want view"), gc);
		
		
		/******************************************************Add the Buttons Panel************************************************/
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 2));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
	
		leftPanel.add(new JLabel("Group Name:"));
		leftPanel.add(cmbGroupName);
		
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 3));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		//rightPanel.add(btnAddStudent);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		middleComponents.add(buttonPanel, gc);
		/*****************************************************Add the group details and member list panel***********************************/
		////////Initialize local fields here for convenience/////////
		txtAreaMemberNames = new JTextArea(6, 20);
		txtAreaMemberNames.setEditable(true);
		txtAreaMemberNames.setBorder(UI_Settings.getBorderoutline());
		txtAreaMemberNames.setWrapStyleWord(true);
		txtAreaMemberNames.setLineWrap(true);
		txtAreaMemberNames.setDocument(new JTextFieldLimit(150));
		
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(5, 5, 5, 5);
		CompoundBorder border = new CompoundBorder(line, empty);
		txtAreaMemberNames.setBorder(border);
		
		txtAreaMemberNames.setPreferredSize(txtAreaMemberNames.getPreferredSize());
		textPrompt = new TextPrompt("<this group contains no members>", txtAreaMemberNames);
		
		//Make the group information panel
		JPanel pnlGroupInformation = new JPanel(new GridBagLayout());
		
		pnlGroupInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+10));
		pnlGroupInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+10));
		pnlGroupInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+10));
		pnlGroupInformation.setBackground(Color.WHITE);
		
			//Make the member list panel
			JPanel pnlMemberList = new JPanel(new GridBagLayout());
			pnlMemberList.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()+10));
			pnlMemberList.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()+10));
			pnlMemberList.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()+10));
			pnlMemberList.setBackground(Color.WHITE);
		
				JPanel panel1 = new JPanel(new GridBagLayout());
				panel1.setBackground(Color.WHITE);
				Border panel1border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
				panel1.setBorder(panel1border);
				panel1.setPreferredSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
				panel1.setMinimumSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
				panel1.setMaximumSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
				
					//Add the contents to the member list panel
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(10,13,-10,0);
					panel1.add(new JLabel("Group Members:"), gc);
					
					gc.gridx = 0;
					gc.gridy = 1;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(10,10,5,10);
					panel1.add(txtAreaMemberNames, gc);
				
				
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.insets = new Insets(5,5,0,5);
				
				pnlMemberList.add(panel1,gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		
		pnlGroupInformation.add(pnlMemberList, gc);
		////////////////////DONE///////////////////
		//Make the member list panel
		JPanel pnlGroupDetails = new JPanel(new GridBagLayout());
		
		pnlGroupDetails.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
		pnlGroupDetails.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
		pnlGroupDetails.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
		
		pnlGroupDetails.setBackground(Color.WHITE);
	
			JPanel panel2 = new JPanel(new GridBagLayout());
			panel2.setBackground(new Color(246,246,246));
			panel2.setBorder(panel1border);
			panel2.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
			panel2.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
			panel2.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
			
				///Add the group details contents to the panel////
				//////////////Col 1///////////
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(17,20,0,0);
				panel2.add(new JLabel("Material:"), gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Group ID:"), gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Positions Available:"), gc);
				
				gc.gridx = 0;
				gc.gridy = 3;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Group Level:"), gc);
				/////////Col 2////////
				gc.gridx = 1;
				gc.gridy = 0;
				gc.insets = new Insets(10,20,0,0);
				panel2.add(txtGroupMat, gc);
				
				gc.gridx = 1;
				gc.gridy = 1;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtGroupID, gc);
				
				gc.gridx = 1;
				gc.gridy = 2;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtGroupPos, gc);
				
				gc.gridx = 1;
				gc.gridy = 3;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtGroupLev, gc);
				/////////Col 3////////
				gc.gridx = 2;
				gc.gridy = 0;
				gc.insets = new Insets(17,20,0,0);
				panel2.add(new JLabel("Group Day:"), gc);
				
				gc.gridx = 2;
				gc.gridy = 1;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Group Time:"), gc);
				
				gc.gridx = 2;
				gc.gridy = 2;
				panel2.add(new JLabel("Group Size:"), gc);
				
				////////Col 4///////
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(10,20,0,0);
				panel2.add(txtGroupDay, gc);
				
				gc.gridx = 3;
				gc.gridy = 1;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtGroupTime, gc);
				
				gc.gridx = 3;
				gc.gridy = 2;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtGroupMax, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,5,5,5);
				pnlGroupDetails.add(panel2,gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridwidth = 2;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,5);
		
		pnlGroupInformation.add(pnlGroupDetails, gc);
		
		/********************************************************Add the Remove Student and Add Student Buttons****************************/
		JPanel addStudentsButtonPanel = new JPanel();
		addStudentsButtonPanel.setLayout(new BoxLayout(addStudentsButtonPanel, BoxLayout.X_AXIS));
		/***********************Add student button ActionListener***********************/
		btnAddStudent.addMouseListener(new MouseAdapter(){
			
			
			private String firstname;
			private String lastname;
			private String month;
			private String material;
			private Integer level;
			private String groupname;
			
			String[] rowData = new String[viewAllCustomersTable.getColumnCount()];
			int selectedRowIndex;
			


			public void mousePressed(MouseEvent e) {

				firstname = txtFirstName.getText();
				lastname = txtLastName.getText();
				month = (String) cmbMonths.getSelectedItem();
				material = (String) cmbMaterial.getSelectedItem();
				level = (Integer)cmbLevels.getSelectedIndex();
				groupname = (String)cmbGroupName.getSelectedItem();
				
			}
			
			public void mouseReleased(MouseEvent e){
				
				selectedRowIndex = viewAllCustomersTable.getSelectedRow();
				
				for(int i = 0; i < viewAllCustomersTable.getColumnCount(); i++){
					
					Object selectedObject = (Object) viewAllCustomersTable.getModel().getValueAt(selectedRowIndex, i);

					rowData[i] = selectedObject.toString();
					
				}

				
				if(checkValues(firstname, lastname, month, material, level)){
					
					
				}			
			}

			private boolean checkValues(String firstName, String lastName, String month, String material, Integer level) {
				
				
				/*Do validation check to make sure all of the fields have been entered for a new customer*/
				
				if(chkNewStudent.isSelected()){
					
					if(firstName.isEmpty() || lastName.isEmpty() || month.isEmpty() || material.isEmpty() || (level == -1) || groupname.isEmpty()){
						
						failedMessage1.setVisible(true);

						if(firstName.isEmpty()){
							txtFirstName.setBackground(UI_Settings.getComponentErrorColor());
						}else{
							txtFirstName.setBackground(Color.WHITE);
						}
						
						if(lastName.isEmpty()){
							txtLastName.setBackground(UI_Settings.getComponentErrorColor());
						}else{
							txtLastName.setBackground(Color.WHITE);
						}
						
						if(month.isEmpty()){
							cmbMonths.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						}else{
							cmbMonths.getEditor().getEditorComponent().setBackground(Color.WHITE);
						}
						
						if(material.isEmpty()){
							cmbMaterial.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						}else{
							cmbMaterial.getEditor().getEditorComponent().setBackground(Color.WHITE);
						}
						
						if(level == -1){
							cmbLevels.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						}else{
							cmbLevels.getEditor().getEditorComponent().setBackground(Color.WHITE);
							
						}
						
						/*Do a validation check to make sure the user has selected a group to add the customer too*/
						
						if(groupname.isEmpty()){
							cmbGroupName.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						}else{
							cmbGroupName.getEditor().getEditorComponent().setBackground(Color.WHITE);
						}
						
						JOptionPane.showMessageDialog(AddStudentPanel.this, UI_Settings.getDlgAddNewStudentToGroupFail(), "", JOptionPane.WARNING_MESSAGE);
						return false;
					}
					
					/*Do a validation check to make sure the user has entered a first and last name at least 2 letters long.*/
					
					if((firstName.length() == 1) && (lastName.length() == 1)){
						
						txtFirstName.setBackground(UI_Settings.getComponentErrorColor());
						txtLastName.setBackground(UI_Settings.getComponentErrorColor());
						failedMessage1.setVisible(true);
						
						JOptionPane.showMessageDialog(AddStudentPanel.this, UI_Settings.getDlgAddNewCustomerBothNamesTooShortFail(), "", JOptionPane.WARNING_MESSAGE);
						return false;
						
					}else{
						txtFirstName.setBackground(Color.WHITE);
						txtLastName.setBackground(Color.WHITE);
					}
					
					/*Do a validation check to make sure the first name is at least 2 letters long*/
					
					if(firstName.length() <= 1){
						
						txtFirstName.setBackground(UI_Settings.getComponentErrorColor());
						failedMessage1.setVisible(true);
						
						JOptionPane.showMessageDialog(AddStudentPanel.this, UI_Settings.getDlgAddNewCustomerFirstNamesTooShortFail(), "", JOptionPane.WARNING_MESSAGE);
						return false;
					}else{
						txtFirstName.setBackground(Color.WHITE);
					}
					
					/*Do a validation check to make sure the last name is at least 2 letters long*/
					
					if(lastName.length() <= 1){
						
						txtLastName.setBackground(UI_Settings.getComponentErrorColor());
						failedMessage1.setVisible(true);
						
						JOptionPane.showMessageDialog(AddStudentPanel.this, UI_Settings.getDlgAddNewCustomerLastNamesTooShortFail(), "", JOptionPane.WARNING_MESSAGE);
						return false;
					}else{
						txtLastName.setBackground(Color.WHITE);
					}
					failedMessage1.setVisible(false);
					return true;
					
				}//End if(chkNewStudent.isSelected())
				
				
				/*Do a validation check to make sure the group name has been selected*/
				
				if(chkExistingStudent.isSelected()){
					
					if(groupname.isEmpty()){
						
						cmbGroupName.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						failedMessage2.setVisible(true);

						JOptionPane.showMessageDialog(AddStudentPanel.this, UI_Settings.getDlgAddExistingStudentToGroupNogroupselectedFail(), "", JOptionPane.WARNING_MESSAGE);
						return false;
					}else{
						
						failedMessage2.setVisible(false);
						cmbGroupName.getEditor().getEditorComponent().setBackground(Color.WHITE);
					}
					
					//Validate the table. If rowData[0] is null then the table doesnt contain any data.
					if(rowData[0] == null){
						
						failedMessage2.setVisible(true);
						
						JOptionPane.showMessageDialog(AddStudentPanel.this, UI_Settings.getDlgAddExistingStudentToGroupNoSelectionFromTableFail(), "", JOptionPane.WARNING_MESSAGE);
						return false;
					}else{
						failedMessage2.setVisible(false);
					}
				}//End chkExistingStduent.isSelected
				
			return true;	
			}//End checkValues
		});
		/*********************End Add student button ActionListener**********************/
		
		JPanel removePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		removePanel.setBackground(UI_Settings.getButtonPanelColor());
		removePanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		removePanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		removePanel.add(labels[7]);//reset locally button
	
		JPanel addPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 3));
		addPanel.setBackground(UI_Settings.getButtonPanelColor());
		addPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		addPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		addPanel.add(btnAddStudent);//add student button 
		
		removePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		addStudentsButtonPanel.add(removePanel);
		
		addPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		addStudentsButtonPanel.add(addPanel);
		
		addStudentsButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,UI_Settings.getTableButtonsPanelHeight()));
		addStudentsButtonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		/******************************************************Add Assessment Details Buttons Panel************************************************/
		
		JPanel addAssessmentButtonPanel = new JPanel();
		addAssessmentButtonPanel.setBackground(UI_Settings.getButtonPanelColor());
		addAssessmentButtonPanel.setLayout(new BoxLayout(addAssessmentButtonPanel, BoxLayout.X_AXIS));
		
		
		JPanel leftSide = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		leftSide.setBackground(UI_Settings.getButtonPanelColor());
		leftSide.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftSide.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		
		
		JPanel rightSide = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		rightSide.setBackground(UI_Settings.getButtonPanelColor());
		rightSide.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightSide.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightSide.add(labels[4]);	//add assessment details (optional) label
		rightSide.add(labels[5]); //edit label	
		rightSide.add(labels[6]); //delete label
		
		leftSide.setAlignmentX(Component.LEFT_ALIGNMENT);
		addAssessmentButtonPanel.add(leftSide);
		
		rightSide.setAlignmentX(Component.RIGHT_ALIGNMENT);
		addAssessmentButtonPanel.add(rightSide);
		addAssessmentButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 40));
		addAssessmentButtonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 40));
		
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        centerPanel.add(cardsButtons);
        
        centerPanel.add(cards);
        
        editdeletePanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(editdeletePanel);
        
        pnlAssessmentDetails.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlAssessmentDetails);
        
        middleComponents.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(middleComponents);
        
        pnlGroupInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlGroupInformation);
        
        addStudentsButtonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(addStudentsButtonPanel);

        
        
        /*********************************************************************************************************************************/
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));

		//////////////////////////////Search, save, reset button row///////////////////
		//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		
		/*********************************************************************************************************************************/
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());	
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
		
		return scroller;
	}
	
	protected void resetASTG_TextFields(List<JTextField> textfields, @SuppressWarnings("rawtypes") List<JComboBox> comboboxes, JLabel x, JLabel y) {
		
		for(int i = 0; i < textfields.size(); i++){
			textfields.get(i).setText("");
			textfields.get(i).setBackground(Color.WHITE);
		}	
		
		for(int i = 0; i < comboboxes.size(); i++){
			comboboxes.get(i).setSelectedIndex(0);
			comboboxes.get(i).getEditor().getEditorComponent().setBackground(Color.WHITE);
		}	
		
   	   	x.setVisible(false);
   	   	y.setVisible(false);	
   	   	
   	   	addNewCustomerTable.setRowSelected(0, 0);
   	   	viewAllCustomersTable.setRowSelected(0, 0);
   	   	groupMemberListTable.setRowSelected(0, 0);
		
	}
}
