package group.gui;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_MoveStudentTo extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int CUSTOMER_NAME = 0;
	public final static int GROUP_NAME = 1;
	public final static int JOINED_GROUP = 2;
	public final static int KC_COMMENTS = 3;
	
	public Object[][]values =
		{
				{"Amy Smith", "Koala", "January 2016", "Strongest, solid speaking and expands well. Not shy in class. An excellent student overall." },
				{"Bill Bagins", "Koala", "September 2015", "Overactive imagination about a place called Gondor. Distracts other students with these stories."},
				{"Sally McIntire", "Koala", "August 2015", "Shy. Doesnt say much but catches on quickly."},
				{"", "", "", ""},
				{"", "", "", ""},
				{"", "", "", ""},
		};
	
	public final static String[] COLUMN_NAMES = {"Customer Name", "Group Name", "Date Joined", "KC Comments on Group Member Abilities"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}
	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList(10,10,10,60));

}
