package group.gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ColorUIResource;

import control.gui.TableTemplate;
import customer.gui.ConfirmSavePane;
import group.controller.Controller;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.SentryModule;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class GroupPane extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JTabbedPane pane = new JTabbedPane();
	
	private customer.controller.Controller controller_customer;
	private group.controller.Controller controller_group;
	
	UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	TextPrompt textPrompt;
	Boolean ignoreEvents = false;
	
    JFrame controllingFrame; //needed for dialogs
    JPasswordField passwordField;

	
	/*****************************************************Create the Table Data Resources**********************************************/

	TD_ViewAll viewallTableData = new TD_ViewAll();
	TD_AddGroup addGroupTableData = new TD_AddGroup();
	TD_Members groupMembersTableData = new TD_Members();
	TD_MoveStudentTo groupMemberToTableData = new TD_MoveStudentTo();
	TD_AddCustomer addCustomerTableData = new TD_AddCustomer();
	TD_ViewAllCustomer viewallCustomersTableData = new TD_ViewAllCustomer();
	
	
	//View all tab
	TableTemplate viewallTable = new TableTemplate(viewallTableData, viewallTableData.getCOLUMN_PERCENTAGES(), "");
	TableTemplate groupMembersTable = new TableTemplate(groupMembersTableData, groupMembersTableData.getCOLUMN_PERCENTAGES(), "");
	

	//Add Group tab
	TableTemplate addGroupTable = new TableTemplate(addGroupTableData, addGroupTableData.getCOLUMN_PERCENTAGES(), "");
	

	//Move Student Between Groups Tab
	TableTemplate groupMemberListFromTableNoHeader = new TableTemplate(groupMembersTableData, groupMembersTableData.getCOLUMN_PERCENTAGES(), "");
	TableTemplate groupMemberListToTableNoHeader = new TableTemplate(groupMemberToTableData, groupMemberToTableData.getCOLUMN_PERCENTAGES(), "");
	

	//Add Student To Group tab
	TableTemplate addNewCustomerTable = new TableTemplate(addCustomerTableData, addCustomerTableData.getCUSTOMER_PERCENTAGES(), "");
	TableTemplate viewAllCustomersTable = new TableTemplate(viewallCustomersTableData, viewallCustomersTableData.getCOLUMN_PERCENTAGES(), "");
	TableTemplate groupMemberListTable = new TableTemplate(groupMembersTableData, groupMembersTableData.getCOLUMN_PERCENTAGES(), "Group Members");
	
	/**
	 * @param controller ********************************************************************************************************************************/
	
	public GroupPane() {
		
		this.controller_customer = controller_customer;
		this.controller_group = controller_group;
		
        initializeUI();
        
    }
	
    private void initializeUI() {
    	
      	UIManager.put("Label.font", UI_Settings.getComponentsFontPlain());
    	UIManager.put("Label.foreground", UI_Settings.getComponentsFontColorDark());
    	
    	UIManager.put("OptionPane.messageFont", new Font("System", Font.PLAIN, 12));
    	UIManager.put("OptionPane.buttonFont", new Font("System", Font.PLAIN, 12));
    	
    	
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, java.awt.Toolkit.getDefaultToolkit().getScreenSize().height));

        //OK
        UIManager.put("TabbedPane.selected", new ColorUIResource(UI_Settings.getBottomTabColor()));
        UIManager.put("TabbedPane.unselectedTabBackground", UI_Settings.getCmsGray());       
        
        pane.setForeground(UI_Settings.getButtonPanelColor());
        pane.setFocusable(false);
        pane.setBorder(new EmptyBorder(0, 0, 0, 0));

        UIManager.getDefaults().put("TabbedPane.tabAreaInsets", new Insets(0,0,0,0));
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0)); 
        
        //Sets the JPanel container to black
        setBackground(UI_Settings.getCmsTabSecondLvlGrey());
        pane.addTab("<html><body><table width='100' style='font-size:11'><td style='text-align:center'>View Group</td></table></body></html>", viewGroup());		//0
        pane.addTab("<html><body><table width='150' style='font-size:11'><td style='text-align:center'>Add Student To Group</td></table></body></html>", addStudentToGroup());		//1
        pane.addTab("<html><body><table width='200' style='font-size:11'><td style='text-align:center'>Move Student To Another Group</td></table></body></html>", moveStudent());		//1

        //Set the text color for each tab
        pane.setForeground(UI_Settings.getButtonPanelColor());

        pane.setBackgroundAt(0, UI_Settings.getCmsGray());	//0
        pane.setBackgroundAt(1, UI_Settings.getCmsGray());	//1
        pane.setBackgroundAt(2, UI_Settings.getCmsGray());	//2
    
        changeUI(UI_Settings.getBottomTabColor());
    }

    public void changeUI( Color bottomTabColor) {
        pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            @Override protected int calculateTabHeight(
              int tabPlacement, int tabIndex, int fontHeight) {
            	
    	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       focus = UI_Settings.getCmsTabSecondLvlGrey();
            	
              return 27;
            }
            
            
            @Override protected void paintTab(
              Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
              Rectangle iconRect, Rectangle textRect) {
        
               rects[tabIndex].height = 25 + 1;
               rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
              
              super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
            }
          });
        
        //Add the tab to the canvas
        this.add(pane, BorderLayout.CENTER);		
	}

	public static void showFrame() {
        JPanel panel = new GroupPane();
        panel.setOpaque(true);

        JFrame frame = new JFrame("CMS Test Screen");
        JFrame.setDefaultLookAndFeelDecorated(false);
        frame.setPreferredSize(UI_Settings.getMinimumScreenSize());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }
    
    public void changeTheme(Color c) {
      UIManager.put("TabbedPane.selected",new ColorUIResource(c));
		 
      pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          @Override protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
            return 27;
          }
      });
      
	pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
	    @Override protected int calculateTabHeight(
	      int tabPlacement, int tabIndex, int fontHeight) {
	    	
	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
	       focus = UI_Settings.getCmsTabSecondLvlGrey();
	    	
	      return 27;
	    }
	    
	    
	    @Override protected void paintTab(
	      Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
	      Rectangle iconRect, Rectangle textRect) {
	
	       rects[tabIndex].height = 25 + 1;
	       rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
	      
	      super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
	    }
	  });
	}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                GroupPane.showFrame();
            }
        });
    }
    
	public Component viewGroup()
	{		
		int xsxsx;
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		
		//JButton btnDeleteGroup;
		JButton btnAddGroup;

		
		//Center Panel fields
		JTextField txtTopPanelStudentName;
		JTextField txtTopPanelAge;
		
		JTextField txtTopGroupName;
		JTextField txtTopGroupID;
		JTextField txtTopGroupPos;
		JTextField txtTopGroupLev;
		JTextField txtTopGroupDay;
		JTextField txtTopGroupTime;
		JTextField txtTopGroupMax;
		JTextField txtTopGroupMat;
		
		JPasswordField passwordField;
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
        
        JTextArea txtMoveFromNameContainer;
		/***************************************************Create labels***********************************************************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage.setVisible(false);
		
		JLabel labels[] = new JLabel[8];
		labels[0] = new JLabel("reset data");
		labels[1] = new JLabel("undo move");
		labels[2] = new JLabel("help");
		labels[3] = new JLabel("help");
		labels[4] = new JLabel("move");
		labels[5] = new JLabel("view interests");
		labels[6] = new JLabel("view comments");
		labels[7] = new JLabel("reset move to data");
		
		labels[1].addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				JOptionPane.showMessageDialog(GroupPane.this, "The undo move comment for group member button has been pressed.", "", JOptionPane.PLAIN_MESSAGE);
			}
		});
		
		for(int i = 0; i < 8; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());	
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		////////Initialize local fields here for convenience/////////
		txtMoveFromNameContainer = new JTextArea(7, 20);
		txtMoveFromNameContainer.setEditable(true);
		txtMoveFromNameContainer.setBorder(UI_Settings.getBorderoutline());
		txtMoveFromNameContainer.setWrapStyleWord(true);
		txtMoveFromNameContainer.setLineWrap(true);
		txtMoveFromNameContainer.setDocument(new JTextFieldLimit(150));
		
		txtMoveFromNameContainer.setPreferredSize(txtMoveFromNameContainer.getPreferredSize());
		textPrompt = new TextPrompt("<no customer names found>", txtMoveFromNameContainer);
		
		/*********************************************Add the Bottom Panel TextFields***********************/

		int size = 13;
		
		
		List <JTextField> textfieldsGroupDetailsTop = new ArrayList<JTextField>();
		List <JTextField> textfieldsGroupDetailsBottom = new ArrayList<JTextField>();

		
		
		txtTopGroupName = new JTextField(size);
		txtTopGroupName.setMinimumSize(txtTopGroupName.getPreferredSize());
		txtTopGroupName.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupName); 
		
		txtTopGroupID = new JTextField(size);
		txtTopGroupID.setMinimumSize(txtTopGroupID.getPreferredSize());
		txtTopGroupID.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupID); 

		
		txtTopGroupPos = new JTextField(size);
		txtTopGroupPos.setMinimumSize(txtTopGroupPos.getPreferredSize());
		txtTopGroupPos.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupPos); 

		
		txtTopGroupLev = new JTextField(size);
		txtTopGroupLev.setMinimumSize(txtTopGroupLev.getPreferredSize());
		txtTopGroupLev.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupLev); 
		
		txtTopGroupDay = new JTextField(size);
		txtTopGroupDay.setMinimumSize(txtTopGroupDay.getPreferredSize());
		txtTopGroupDay.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupDay); 

		
		txtTopGroupTime = new JTextField(size);
		txtTopGroupTime.setMinimumSize(txtTopGroupTime.getPreferredSize());
		txtTopGroupTime.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupTime); 

		
		txtTopGroupMax = new JTextField(size);
		txtTopGroupMax.setMinimumSize(txtTopGroupMax.getPreferredSize());
		txtTopGroupMax.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupMax); 

		
		txtTopGroupMat = new JTextField(size);
		txtTopGroupMat.setMinimumSize(txtTopGroupMat.getPreferredSize());
		txtTopGroupMat.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupMat); 
		
		txtTopPanelStudentName = new JTextField(10);
		txtTopPanelStudentName.setEditable(true);
		txtTopPanelStudentName.setMinimumSize(txtTopPanelStudentName.getPreferredSize());
		textPrompt = new TextPrompt("-", txtTopPanelStudentName);
		txtTopPanelStudentName.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetailsTop.add(txtTopPanelStudentName);
		
		txtTopPanelAge = new JTextField(5);
		txtTopPanelAge.setEditable(true);
		txtTopPanelAge.setMinimumSize(txtTopPanelAge.getPreferredSize());
		textPrompt = new TextPrompt("-", txtTopPanelAge);
		txtTopPanelAge.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetailsTop.add(txtTopPanelAge);
		
		
		/*********************************************************Create Combo Boxes*********************************************************/
		JComboBox<String> cmbMoveFromGroupName = new JComboBox<String>(UI_Settings.getGroups());
		cmbMoveFromGroupName.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbMoveFromGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbMoveFromGroupName.setMinimumSize(cmbMoveFromGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbMoveFromGroupName, 180, UI_Settings.getComboBoxHeight());

		JComboBox<String> cmbMoveToGroupName = new JComboBox<String>(UI_Settings.getGroups());
		cmbMoveToGroupName.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbMoveToGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbMoveToGroupName.setMinimumSize(cmbMoveToGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbMoveToGroupName, 180, UI_Settings.getComboBoxHeight());
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		//Reset move to button//
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
				failedMessage.setVisible(false);
				
				for(int i = 0; i < textfieldsGroupDetailsTop.size(); i++){
					textfieldsGroupDetailsTop.get(i).setText("");
				}
				
				txtMoveFromNameContainer.setText("");
				
				cmbMoveFromGroupName.setSelectedIndex(0);
				
				passwordField.setText("");
				   
			}
		});
		//Reset move to button//
		labels[7].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				for(int i = 0; i < textfieldsGroupDetailsBottom.size(); i++){
					textfieldsGroupDetailsBottom.get(i).setText("");
				}
				cmbMoveToGroupName.setSelectedIndex(0);
				passwordField.setText("");
			}
		});
		/*****************************************************************************************************************************/
	
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		GridBagConstraints gc = new GridBagConstraints();
		
		////////////////////////////////////////////////////////////////
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		container.setBackground(Color.WHITE);
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		container.add(new JLabel("Select the group you want view:"));
		container.add(cmbMoveFromGroupName);
		
		container.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(container);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(17,0,0,0);
		detailsPanel.add(firstRow, gc);
		/******************************************************Add the Buttons Panel************************************************/
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 25));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 25));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 25));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 7));
		rightPanel.setBackground(Color.WHITE);
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 25));
		rightPanel.add(labels[0]);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		
		
		/*************************************************Add Student to Group Buttons Panel***********************************************/
		JPanel middleComponents = new JPanel(new GridBagLayout());
		middleComponents.setBackground(Color.WHITE);

		middleComponents.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		middleComponents.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		
		/////////////////////////////Start the center panels///////////////////////////////////	
		int topFrameHeight = 210;
		
		JPanel pnlCenterTopPanel = new JPanel(new GridBagLayout());
		pnlCenterTopPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		pnlCenterTopPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		pnlCenterTopPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		
		JPanel pnlCenterTopLeft = new JPanel(new GridBagLayout());
		pnlCenterTopLeft.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		pnlCenterTopLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		pnlCenterTopLeft.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		
		Border darkBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY);


			//add components to the left panel
			pnlCenterTopLeft.setBorder(darkBorder);
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(30,10,0,0);
			pnlCenterTopLeft.add(new JLabel("Click on the students name to select:"), gc);
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,10,20,10);
			pnlCenterTopLeft.add(txtMoveFromNameContainer, gc);
			
		JPanel pnlCenterTopRight = new JPanel(new GridBagLayout());
		pnlCenterTopRight.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setBackground(Color.WHITE);

			int centerTopHeight = 50;
			JPanel pnlCenterTopRightTop = new JPanel(new GridBagLayout());
			pnlCenterTopRightTop.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setBackground(Color.WHITE);

				//Add the contents of this panel - the student name and the student age plus buttons
				//Add the student name panel//
				JPanel pnlStudentName = new JPanel(new GridBagLayout());
				pnlStudentName.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				pnlStudentName.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				pnlStudentName.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				pnlStudentName.setBorder(darkBorder);
				pnlStudentName.setBackground(Color.WHITE);
					//Add student name fields//
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 0.2;
					gc.weighty = 0.2;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,10,0,0);
					pnlStudentName.add(new JLabel("Student Name:"),gc);
					gc.gridx = 1;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 0.2;
					gc.weighty = 0.2;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,10,0,0);
					pnlStudentName.add(txtTopPanelStudentName,gc);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 0.2;
				gc.weighty = 0.2;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,0,0);
				pnlCenterTopRightTop.add(pnlStudentName,gc);
				
				JPanel pnlStudentButtons = new JPanel(new GridBagLayout());
				pnlStudentButtons.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				pnlStudentButtons.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				pnlStudentButtons.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				pnlStudentButtons.setBorder(darkBorder);
				pnlStudentButtons.setBackground(Color.WHITE);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,1);
				pnlStudentButtons.add(new JLabel("Age:"), gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,-20,0,0);
				pnlStudentButtons.add(txtTopPanelAge, gc);
				
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,0);
				pnlStudentButtons.add(labels[5], gc);
				
				gc.gridx = 3;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,0);
				pnlStudentButtons.add(labels[6], gc);
				
				
				
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,1);
				pnlCenterTopRightTop.add(pnlStudentButtons, gc);

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		pnlCenterTopRight.add(pnlCenterTopRightTop, gc);
		
				//Add the contents of the bottom panel, the group details
				//Add the group details (toprightbottom)
				JPanel pnlTopGroupDetails = new JPanel(new GridBagLayout());
				pnlTopGroupDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
				pnlTopGroupDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
				pnlTopGroupDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
				pnlTopGroupDetails.setBackground(Color.WHITE);
				pnlTopGroupDetails.setBorder(darkBorder);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(20,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Name:"),gc);
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group ID:"),gc);
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Positions Available:"),gc);
				gc.gridx = 0;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Level:"),gc);
				gc.gridx = 1;
				gc.gridy = 0;
				gc.insets = new Insets(15,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupName,gc);
				gc.gridx = 1;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupID,gc);
				gc.gridx = 1;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupPos,gc);
				gc.gridx = 1;
				gc.gridy = 3;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupLev,gc);
				gc.gridx = 2;
				gc.gridy = 0;
				gc.insets = new Insets(20,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Day:"),gc);
				gc.gridx = 2;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Time:"),gc);
				gc.gridx = 2;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Size:"),gc);
				gc.gridx = 2;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Material:"),gc);
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(15,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupDay,gc);
				gc.gridx = 3;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupTime,gc);
				gc.gridx = 3;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupMax,gc);
				gc.gridx = 3;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupMat,gc);
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,0,1,0);
		pnlCenterTopRight.add(pnlTopGroupDetails, gc);
		
				
		pnlCenterTopLeft.setBackground(new Color(246,246,246));
		

		
		//This is the main container panel for the North most components on the central stage - namely pnlCenterTopLeftPanel and pnlCenterTopRight//
		pnlCenterTopPanel.setBackground(Color.WHITE);
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,5,0,5);
			pnlCenterTopPanel.add(pnlCenterTopLeft, gc);
			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,5,0,10);
			pnlCenterTopPanel.add(pnlCenterTopRight, gc);
		////////////////////////////END OF THE TOP LEVEL COMPONENTS////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////

		///////////////////////////////////////////////////////////////////////////////////////
		JPanel pnlGroupDetails = new JPanel();
		pnlGroupDetails.setBackground(Color.WHITE);
		pnlGroupDetails.setLayout(new GridBagLayout());
		pnlGroupDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-40));
		pnlGroupDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-40));
		pnlGroupDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-40));

			//Create the far left container for the web address details information
			JPanel pnlGroupLeft = new JPanel(new GridBagLayout());
			pnlGroupLeft.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
			pnlGroupLeft.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
			pnlGroupLeft.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
			
				//Add the nested panels to the container panel (information panel)
				Border panel1border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);

				JPanel pnlLeft = new JPanel(new GridBagLayout());
				pnlLeft.setBackground(Color.WHITE);
				//pnlLeft.setBorder(panel1border);
				pnlLeft.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
				pnlLeft.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
				pnlLeft.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.insets = new Insets(0,0,0,0);
				pnlGroupLeft.add(pnlLeft, gc);
				
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.insets = new Insets(5,5,5,5);
				pnlGroupDetails.add(pnlGroupLeft, gc);
		
		
			//Create the far left container for the web address details information
			JPanel pnlGroupButton = new JPanel(new GridBagLayout());
			pnlGroupButton.setBackground(Color.WHITE);
			pnlGroupButton.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
			pnlGroupButton.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
			pnlGroupButton.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel pnlDeleteGroup = new JPanel(new GridBagLayout());
				pnlDeleteGroup.setBackground(new Color(246,246,246));
				pnlDeleteGroup.setBorder(panel1border);
				pnlDeleteGroup.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
				pnlDeleteGroup.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
				pnlDeleteGroup.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));

				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,0);
				
	
				
				labels[2].setCursor(UI_Settings.getJlabelCursor());
				labels[2].addMouseListener(new MouseAdapter(){
					public void mouseClicked(MouseEvent e){
						
						JOptionPane.showMessageDialog(controllingFrame,
				                "The administrator password can be found with the \"Kids Coordinator\"\n"
				              + "or by contacting your \"Branch Manager\".");
						
					}
				});
				
				btnAddGroup = new JButton("Add New Group");
				btnAddGroup.setCursor(UI_Settings.getJlabelCursor());
				btnAddGroup.setFont(UI_Settings.getComponentInputFontSize());
				btnAddGroup.setPreferredSize(new Dimension(150,UI_Settings.getJbuttonSize().height));
				btnAddGroup.setMinimumSize(new Dimension(150,UI_Settings.getJbuttonSize().height));
				btnAddGroup.addMouseListener(new MouseAdapter(){
					
					private String group_name;
					
					public void mousePressed(MouseEvent e){
						group_name = (String)cmbMoveToGroupName.getSelectedItem();
						
		                AddGroupPane pane = new AddGroupPane(controller_group);
		                
						pane.run();
					}
					
					public void mouseReleased(MouseEvent e){
						//Temp block while developing - remove later
/*							SentryModule module = new SentryModule();
						
				           char[] input = passwordField.getPassword();
				            if (module.takeInput(input)) {
								passwordField.setText("");
				                AddGroupPane pane = new AddGroupPane();
								pane.run();
								
				            } else {
				                JOptionPane.showMessageDialog(controllingFrame,
				                    "Welcome Administrator. Please enter the correct password.",
				                    "Welcome Administrator",
				                    JOptionPane.WARNING_MESSAGE);
									passwordField.setText("");

				            }
		
				            //Zero out the possible password, for security.
				            Arrays.fill(input, '0');
		
				            passwordField.selectAll();*/
					}
					
				});
				
				
				JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 3));
				adminPanel.setBackground(Color.WHITE);
				adminPanel.add(new JLabel("Administrator password:"));
				adminPanel.add(passwordField);
				adminPanel.add(labels[2]);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 2;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTH;
				gc.insets = new Insets(15,0,0,0);
				
				pnlDeleteGroup.add(adminPanel, gc);
				
				gc.gridx = 1;
				gc.gridy = 2;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.insets = new Insets(0,0,0,25);
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHEAST;
				pnlDeleteGroup.add(btnAddGroup, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.anchor = GridBagConstraints.NORTH;
				gc.insets = new Insets(0,0,0,5);
				
				pnlGroupButton.add(pnlDeleteGroup, gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(5,5,5,5);
				pnlGroupDetails.add(pnlGroupButton, gc);
		
		/********************************************************Set the Table Objects Sizes**************************************************/
		groupMemberListFromTableNoHeader.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		groupMemberListFromTableNoHeader.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		
		groupMemberListToTableNoHeader.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		groupMemberListToTableNoHeader.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        pnlCenterTopPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlCenterTopPanel);
        
        centerPanel.add(Box.createVerticalStrut(5));

        pnlGroupDetails.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlGroupDetails);
		/*********************************************************************************************************************************/
		///////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly///////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 600));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 600));
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());		
		//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return scroller;
	}//END VIEW GROUP

	/******************************************************************addStudentToGroup*************************************/
	public Component addStudentToGroup()
	{
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		JPanel pnlAssessmentDetails;
		
		
		
		JTextField txtLastName;
		JTextField txtFirstName;
		JTextField txtMaterial;
		JTextField txtPositionsAvailable;
		
		JTextField txtListen;
		JTextField txtSpeak;
		JTextField txtRead;
		JTextField txtParticipate;
		JTextField txtCooperate;
		
		JTextField txtGroupName;
		JTextField txtGroupID;
		JTextField txtGroupPos;
		JTextField txtGroupLev;
		JTextField txtGroupDay;
		JTextField txtGroupTime;
		JTextField txtGroupMax;
		JTextField txtGroupMat;
		
		JLabel assessmentOptional = new JLabel("Assessment Details [optional");
;

		
		pnlAssessmentDetails = new JPanel(new GridBagLayout());
		pnlAssessmentDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 70));
		pnlAssessmentDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 70));
		pnlAssessmentDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 70));
		pnlAssessmentDetails.setBackground(Color.WHITE);

		
		List<JTextField> textfields = new ArrayList<JTextField>();
		List<JTextField> textfieldsGroupDetails = new ArrayList<JTextField>();

		@SuppressWarnings("rawtypes")
		List<JComboBox> comboboxes = new ArrayList<JComboBox>();
		List<TextPrompt> textprompts = new ArrayList<TextPrompt>();

		
		JCheckBox chkNewStudent;
		JCheckBox chkExistingStudent;
		
		JPanel cards; 
		JPanel card1;
		JPanel card2;
		
		JPanel cardsButtons;
		JPanel cardsNCButtonsPanel;
		JPanel cardsECButtonsPanel;
		
		cards = new JPanel(new CardLayout());
		cardsButtons = new JPanel(new CardLayout());
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setCursor(UI_Settings.getJlabelCursor());
		btnSearch.setPreferredSize(UI_Settings.getJbuttonSize());
		btnSearch.setFont(UI_Settings.getComponentInputFontSize());
		
		JButton btnSaveStudent;
		JButton btnAddStudent;
		
		JTextArea txtAreaMemberNames;

		
		final String NEW_CUSTOMER_PANEL = "New Customer";
		final String EXISTING_CUSTOMER_PANEL = "Existing Customer";
		
		final String NEW_CUSTOMER_PANEL_BUTTONS = "New Customer Buttons";
		final String EXISTING_CUSTOMER_PANEL_BUTTONS = "Existing Customer Buttons";
		/***************************************************Create labels***********************************************************************/
		JLabel failedMessage1 = new JLabel(UI_Settings.getFailedMessage());
		failedMessage1.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage1.setVisible(false);
		
		JLabel failedMessage2 = new JLabel(UI_Settings.getFailedMessage());
		failedMessage2.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage2.setVisible(false);
		
		JLabel labels[] = new JLabel[11];
		
		labels[0] = new JLabel("generate");
		labels[1] = new JLabel("reset fields");
		labels[2] = new JLabel("reset fields");
		labels[3] = new JLabel("show assessment details");
		labels[4] = new JLabel("Assessment details (optional)");
		labels[5] = new JLabel("edit");
		labels[6] = new JLabel("delete");
		labels[7] = new JLabel("reset local fields");
		labels[8] = new JLabel("edit comment for group member");
		labels[9] = new JLabel("edit");
		labels[10] = new JLabel("delete");
		
		labels[3].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(GroupPane.this, "The show assessment details button has been pressed.", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		labels[4].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(GroupPane.this, "The add assessment details (optional) button has been pressed.", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		labels[5].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(GroupPane.this, "The edit button has been pressed.", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		labels[6].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(GroupPane.this, "The delete button has been pressed.", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		labels[7].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(GroupPane.this, "The reset locally button has been pressed", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		labels[8].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(GroupPane.this, "The edit comment for group member button has been pressed.", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		
		for(int i = 0; i < 11; i++) {
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());	
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		/***************************************************Create textFields********************************************************************/
		txtFirstName = new JTextField(10);
		txtFirstName.setMinimumSize(txtFirstName.getPreferredSize());
		txtFirstName.setHorizontalAlignment(JTextField.LEFT);
		textfields.add(txtFirstName); 
		
		txtLastName = new JTextField(10);
		txtLastName.setMinimumSize(txtLastName.getPreferredSize());
		txtLastName.setHorizontalAlignment(JTextField.LEFT);
		textfields.add(txtLastName); 

		txtPositionsAvailable = new JTextField(5);
		txtPositionsAvailable.setEditable(false);
		txtPositionsAvailable.setMinimumSize(txtPositionsAvailable.getPreferredSize());
		textPrompt = new TextPrompt("-", txtPositionsAvailable);
		txtPositionsAvailable.setHorizontalAlignment(JTextField.CENTER);	
		textfields.add(txtPositionsAvailable); 

		txtMaterial = new JTextField(15);
		txtMaterial.setEditable(false);
		txtMaterial.setMinimumSize(txtMaterial.getPreferredSize());
		textPrompt = new TextPrompt("-", txtMaterial);
		txtMaterial.setHorizontalAlignment(JTextField.CENTER);
		textfields.add(txtMaterial); 
		/*********************************************Add the Bottom Panel TextFields***********************/

		int size = 13;
		
		String prompt = "-";
		
		
		txtGroupName = new JTextField(size);
		txtGroupName.setMinimumSize(txtGroupName.getPreferredSize());
		txtGroupName.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupName); 
		TextPrompt textPrompt1 = new TextPrompt(prompt, txtGroupName);
		textprompts.add(textPrompt1);
		
		txtGroupID = new JTextField(size);
		txtGroupID.setMinimumSize(txtGroupID.getPreferredSize());
		txtGroupID.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupID); 
		TextPrompt textPromp2 = new TextPrompt(prompt, txtGroupID);
		textprompts.add(textPromp2);

		
		txtGroupPos = new JTextField(size);
		txtGroupPos.setMinimumSize(txtGroupPos.getPreferredSize());
		txtGroupPos.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupPos); 
		TextPrompt textPrompt3 = new TextPrompt(prompt, txtGroupPos);
		textprompts.add(textPrompt3);

		
		txtGroupLev = new JTextField(size);
		txtGroupLev.setMinimumSize(txtGroupLev.getPreferredSize());
		txtGroupLev.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupLev); 
		TextPrompt textPrompt4 = new TextPrompt(prompt, txtGroupLev);
		textprompts.add(textPrompt4);
		
		txtGroupDay = new JTextField(size);
		txtGroupDay.setMinimumSize(txtGroupDay.getPreferredSize());
		txtGroupDay.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupDay); 
		TextPrompt textPrompt5 = new TextPrompt(prompt, txtGroupDay);
		textprompts.add(textPrompt5);

		
		txtGroupTime = new JTextField(size);
		txtGroupTime.setMinimumSize(txtGroupTime.getPreferredSize());
		txtGroupTime.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupTime); 
		TextPrompt textPrompt6 = new TextPrompt(prompt, txtGroupTime);
		textprompts.add(textPrompt6);

		
		txtGroupMax = new JTextField(size);
		txtGroupMax.setMinimumSize(txtGroupMax.getPreferredSize());
		txtGroupMax.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupMax); 
		TextPrompt textPrompt7 = new TextPrompt(prompt, txtGroupMax);
		textprompts.add(textPrompt7);

		
		txtGroupMat = new JTextField(size);
		txtGroupMat.setMinimumSize(txtGroupMat.getPreferredSize());
		txtGroupMat.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetails.add(txtGroupMat); 
		TextPrompt textPrompt8 = new TextPrompt(prompt, txtGroupMat);
		textprompts.add(textPrompt8);

		/////////////////////////////////////////////////////////////
		txtListen = new JTextField(8);
		txtListen.setEditable(true);
		txtListen.setMinimumSize(txtListen.getPreferredSize());
		textPrompt = new TextPrompt("0 / 5", txtListen);
		txtListen.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetails.add(txtListen); 
		
		txtSpeak = new JTextField(8);
		txtSpeak.setEditable(true);
		txtSpeak.setMinimumSize(txtSpeak.getPreferredSize());
		textPrompt = new TextPrompt("0 / 5", txtSpeak);
		txtSpeak.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetails.add(txtSpeak); 
		
		txtRead = new JTextField(8);
		txtRead.setEditable(true);
		txtRead.setMinimumSize(txtRead.getPreferredSize());
		textPrompt = new TextPrompt("0 / 5", txtRead);
		txtRead.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetails.add(txtRead); 
		
		txtParticipate = new JTextField(8);
		txtParticipate.setEditable(true);
		txtParticipate.setMinimumSize(txtParticipate.getPreferredSize());
		textPrompt = new TextPrompt("0 / 5", txtParticipate);
		txtParticipate.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetails.add(txtParticipate); 
		
		txtCooperate = new JTextField(8);
		txtCooperate.setEditable(true);
		txtCooperate.setMinimumSize(txtCooperate.getPreferredSize());
		textPrompt = new TextPrompt("0 / 5", txtCooperate);
		txtCooperate.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetails.add(txtCooperate); 
		/*********************************************************Create the Combo Boxes*********************************************************/
		JComboBox<String> cmbMaterial = new JComboBox<String>(UI_Settings.getBooks());
		cmbMaterial.setFont(UI_Settings.getComponentInputFontSize());
		cmbMaterial.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbMaterial.setMaximumSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbMaterial.setMinimumSize(cmbMaterial.getPreferredSize());
		//AutoCompletion.enable(cmbMaterial, 150, 27);
		
		comboboxes.add(cmbMaterial);
		
		JComboBox<?> cmbLevels = new JComboBox<Object>(UI_Settings.getLevels());
		cmbLevels.setPreferredSize(new Dimension(80, 27));
		cmbLevels.setFont(UI_Settings.getComponentInputFontSize());
		//AutoCompletion.enable(cmbLevels, 80, 27);
		
		comboboxes.add(cmbLevels);
		
		JComboBox<?> cmbMonths = new JComboBox<Object>(UI_Settings.getMonths());
		cmbMonths.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		cmbMonths.setFont(UI_Settings.getComponentInputFontSize());
		cmbMonths.setMinimumSize(cmbMonths.getPreferredSize());
		//AutoCompletion.enable(cmbMonths, 120, 27);
		
		comboboxes.add(cmbMonths);
		
		JComboBox<String> cmbGroupName = new JComboBox<String>(UI_Settings.getGroups());
		cmbGroupName.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbGroupName.setMinimumSize(cmbGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbGroupName, 180, 27);
		
		comboboxes.add(cmbGroupName);
	
		/**********************************Create CheckBoxes***********************************/
		chkExistingStudent = new JCheckBox("Existing Student");
		chkNewStudent = new JCheckBox("New Student");
		
		chkNewStudent.setFont(UI_Settings.getComponentsFontPlain());
		chkNewStudent.setForeground(UI_Settings.getComponentsFontColorLight());
		chkNewStudent.setSelected(true);
		chkNewStudent.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e) {
				if(chkNewStudent.isSelected()==true){
					chkExistingStudent.setSelected(false);
					pnlAssessmentDetails.setVisible(true);
					assessmentOptional.setVisible(true);
					
					resetASTG_TextFields(textfields, comboboxes, failedMessage1, failedMessage2);
					
					for(int i = 0; i < textprompts.size(); i++) {
						textprompts.get(i).setText("-");
						textfieldsGroupDetails.get(i).setEditable(true);
					}
					
					CardLayout cl = (CardLayout)(cards.getLayout());
					cl.show(cards, NEW_CUSTOMER_PANEL);
					
					CardLayout cl2 = (CardLayout)(cardsButtons.getLayout());
					cl2.show(cardsButtons, NEW_CUSTOMER_PANEL_BUTTONS);
					
				}
			}
		});
		
		chkExistingStudent.setFont(UI_Settings.getComponentsFontPlain());
		chkExistingStudent.setForeground(UI_Settings.getComponentsFontColorLight());
		chkExistingStudent.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				if(chkExistingStudent.isSelected()==true){
					chkNewStudent.setSelected(false);
					pnlAssessmentDetails.setVisible(false);
					assessmentOptional.setVisible(false);
					
					resetASTG_TextFields(textfields, comboboxes, failedMessage1, failedMessage2);
					
					for(int i = 0; i < textprompts.size(); i++){
						textprompts.get(i).setText("-");
						textfieldsGroupDetails.get(i).setEditable(false);
					}

					
					CardLayout cl = (CardLayout)(cards.getLayout());
					cl.show(cards, EXISTING_CUSTOMER_PANEL);
					
					CardLayout cl2 = (CardLayout)(cardsButtons.getLayout());
					cl2.show(cardsButtons, EXISTING_CUSTOMER_PANEL_BUTTONS);
					
				}				
			}
		});
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		////////////////Reset button  on card layout 2/////////////
		labels[1].addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(GroupPane.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   
					resetASTG_TextFields(textfields, comboboxes, failedMessage1, failedMessage2);


		       }
			}
		});
		////////////////Reset button  on card layout 2/////////////
		labels[2].addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(GroupPane.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   
					resetASTG_TextFields(textfields, comboboxes, failedMessage1, failedMessage2);

		       }
			}
		});
		
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/***********************************     **Create edit, delete, table header and print panels***************************************/
		JPanel addGroupTableButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		addGroupTableButtonPanel.add(new JLabel("Positions Available"));//Positions available label
		addGroupTableButtonPanel.setBackground(UI_Settings.getButtonPanelColor());
		addGroupTableButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		addGroupTableButtonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		
		JPanel showAllCustomersButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		showAllCustomersButtonPanel.add(labels[3]);//Show assessment details label
		showAllCustomersButtonPanel.setBackground(UI_Settings.getButtonPanelColor());
		showAllCustomersButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		showAllCustomersButtonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(UI_Settings.getButtonPanelColor());
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		detailsPanel.setLayout(new GridBagLayout());
		
		//Create the GridBagConstraints object
		GridBagConstraints gc = new GridBagConstraints();
		/**********************************************************Card layout for the details panel********************************************************/
		//Contains the Add New Student and Existing Student CheckBoxes
		JPanel checkBoxesPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		checkBoxesPanel.setBackground(UI_Settings.getButtonPanelColor());
		checkBoxesPanel.add(chkNewStudent);
		checkBoxesPanel.add(chkExistingStudent);
		checkBoxesPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableButtonsPanelHeight()+10));
		checkBoxesPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableButtonsPanelHeight()+10));

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 10;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		
		detailsPanel.add(checkBoxesPanel, gc);
		/////////////////////////////////////////////////////Card 1 - New Customer//////////////////////////////////////////////
		
		gc.gridx = 0;
		gc.gridy = 2;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,10,13,-24);
		detailsPanel.add(new JLabel("Customer Name:"), gc); //Customer name label
		
		//////////////////////////////////////////Begin Column 2 ///////////////////////////////////////////
		gc.gridx = 1;
		gc.gridy = 1;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(-7,12,7,-12);
		detailsPanel.add(new JLabel("First Name"), gc); //FirstName Label

		gc.gridx = 1;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-7,9,7,-9);
		detailsPanel.add(textfields.get(0), gc); //FirstName TextField
		
		
		//////////////////////////////////////////Begin Column 3 ///////////////////////////////////////////
		gc.gridx = 2;
		gc.gridy = 1;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(-7,-12,7,12);
		detailsPanel.add(new JLabel("Last Name"), gc); //Last Name Label

		gc.gridx = 2;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-7,-16,7,16);
		detailsPanel.add(txtLastName, gc); //Last Name TextField
		//////////////////////////////////////////Begin Column 4///////////////////////////////////////////	
		gc.gridx = 3;
		gc.gridy = 2;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,-27,13,27);
		detailsPanel.add(new JLabel("Month Started:"), gc); //Month started label
		//////////////////////////////////////////Begin Column 5///////////////////////////////////////////	

		gc.gridx = 4;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-8,-27,8,27);
		detailsPanel.add(cmbMonths, gc); //Month started combo
		//////////////////////////////////////////Begin Column 6///////////////////////////////////////////		

		
		gc.gridx = 5;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,-18,13,18);
		detailsPanel.add(new JLabel("Material:"), gc); //Material label
		//////////////////////////////////////////Begin Column 7///////////////////////////////////////////		

		gc.gridx = 7;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-12,-24,12,24);
		detailsPanel.add(cmbMaterial, gc); //Materials Title ComboBox
		//////////////////////////////////////////Begin Column 8///////////////////////////////////////////	

		gc.gridx = 8;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,0,13,0);
		detailsPanel.add(new JLabel("Level:"), gc); //Level label
		//////////////////////////////////////////Begin Column 9///////////////////////////////////////////	
		gc.gridx = 9;
		gc.gridy = 2;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-11,2,11,-2);
		detailsPanel.add(cmbLevels, gc); //Level combo
		

		/******************************************************Add the Buttons Panel************************************************/
		cardsNCButtonsPanel = new JPanel();
		
		cardsNCButtonsPanel.setLayout(new BoxLayout(cardsNCButtonsPanel, BoxLayout.X_AXIS));
		cardsNCButtonsPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		cardsNCButtonsPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		cardsNCButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel ncLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		ncLeftPanel.setBackground(Color.WHITE);
		ncLeftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ncLeftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ncLeftPanel.add(failedMessage1);
		
		btnSaveStudent = new JButton("Save");
		btnSaveStudent.setFont(UI_Settings.getComponentInputFontSize());
		btnSaveStudent.setCursor(UI_Settings.getJlabelCursor());
		btnSaveStudent.setPreferredSize(UI_Settings.getJbuttonSize());
		
		
		JPanel ncRightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		ncRightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		ncRightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ncRightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ncRightPanel.add(labels[1]);
		//ncRightPanel.add(btnSaveStudent);
		
		btnAddStudent = new JButton("Add Student To Group");
		btnAddStudent.setFont(UI_Settings.getComponentInputFontSize());
		btnAddStudent.setCursor(UI_Settings.getJlabelCursor());
		
		//ncRightPanel.add(btnAddStudent);

		
		ncLeftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		cardsNCButtonsPanel.add(ncLeftPanel);
		
		ncRightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		cardsNCButtonsPanel.add(ncRightPanel);
		
		
		cardsECButtonsPanel = new JPanel();
		cardsECButtonsPanel.setBackground(UI_Settings.getButtonPanelColor());
		cardsECButtonsPanel.setLayout(new BoxLayout(cardsECButtonsPanel, BoxLayout.X_AXIS));
		cardsECButtonsPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		cardsECButtonsPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		cardsECButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel ecLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		ecLeftPanel.setBackground(Color.WHITE);
		ecLeftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ecLeftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ecLeftPanel.add(failedMessage2);
		//leftPanel.add();
		
		JPanel ecRightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 2));
		ecRightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		ecRightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ecRightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		ecRightPanel.add(labels[2]);
		ecRightPanel.add(btnSearch);

		
		ecLeftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		cardsECButtonsPanel.add(ecLeftPanel);
		
		ecRightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		cardsECButtonsPanel.add(ecRightPanel);
		

		
		cardsNCButtonsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsECButtonsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsNCButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsECButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
		cardsButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()));
	
		cardsButtons.add(cardsNCButtonsPanel, NEW_CUSTOMER_PANEL_BUTTONS);
		cardsButtons.add(cardsECButtonsPanel, EXISTING_CUSTOMER_PANEL_BUTTONS );
		
		
		////////////////////////////////////////////////////////Create the Card Layout for the details panel/////////////////////////////////////////////////////////////////////////////////////
		card1 = new JPanel(new GridBagLayout());
		card2 = new JPanel(new GridBagLayout());
		
		int cardsHeight = 6;
		
		card1.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		card2.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		cards.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		
		card1.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		card2.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		cards.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*cardsHeight+5)));
		
		////////////////////////////////////////////////////CARDS 1/////////////////////////////////////////////////////////////
		gc.gridx = 0;
		gc.gridy = 6;
		gc.gridheight = 5;
		gc.gridwidth = 10;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(2,0,-2,0);
		gc.fill = GridBagConstraints.HORIZONTAL;
		card1.add(addNewCustomerTable, gc); //View all customers table list	
		////////////////////////////////////////////////////CARDS 2/////////////////////////////////////////////////////////////
		btnSearch.addMouseListener(new MouseAdapter(){
			
			private String firstname;
			private String lastname;
			private String month;
			private String material;
			private Integer level;
			private String groupname;
			
			public void mousePressed(MouseEvent e) {

				firstname = txtFirstName.getText();
				lastname = txtLastName.getText();
				month = (String) cmbMonths.getSelectedItem();
				material = (String) cmbMaterial.getSelectedItem();
				level = (Integer)cmbLevels.getSelectedItem();
				}
			
			public void mouseReleased(MouseEvent e){
				
				if(checkValues()){
					
					
					for(int i = 0; i < textfields.size(); i++){
						textfields.get(i).setBackground(Color.WHITE);
					}
					
					for(int i = 0; i < comboboxes.size(); i++){
						comboboxes.get(i).getEditor().getEditorComponent().setBackground(Color.WHITE);
					}
					
					
				}
			}

			private boolean checkValues() {
				
				if(firstname.isEmpty() && lastname.isEmpty() && month.isEmpty() && material.isEmpty() && level == null){
					
					failedMessage2.setVisible(true);
					
					for(int i = 0; i < textfields.size()-1; i++){
						textfields.get(i).setBackground(UI_Settings.getComponentErrorColor());
					}
					
					for(int i = 0; i < comboboxes.size()-1; i++){
						comboboxes.get(i).getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
					}
					
					
					JOptionPane.showMessageDialog(GroupPane.this, UI_Settings.getDlgSearchExistingStudentFail(), "", JOptionPane.WARNING_MESSAGE);
					return false;
				}
				failedMessage2.setVisible(false);
				return true;
			}
	
		});
		gc.gridx = 0;
		gc.gridy = 6;
		gc.gridheight = 5;
		gc.gridwidth = 10;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(2,0,-2,0);
		gc.fill = GridBagConstraints.HORIZONTAL;
		card2.add(viewAllCustomersTable, gc); //View all customers table list
		/////////////////////////////////////////////Add the Cards to the details panel///////////////////////////////////////
		card1.setBackground(Color.WHITE);
		card2.setBackground(Color.WHITE);
		
		cards.add(card1, NEW_CUSTOMER_PANEL);
		cards.add(card2, EXISTING_CUSTOMER_PANEL);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 10;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(30,0,-30,0);
		
		/********************************************************Set the Table Objects Sizes**************************************************/
		addNewCustomerTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		addNewCustomerTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		
		viewAllCustomersTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		viewAllCustomersTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		
		groupMemberListTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*7)));
		groupMemberListTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*7)));
		/******************************************************Add the edit-delete split panel************************************************/
		/*
		 * Add the edit and delete text buttons on a split screen - for future use
		 * 
		 */
		
		JPanel editdeletePanel = new JPanel();
		editdeletePanel.setBackground(UI_Settings.getButtonPanelColor());
		editdeletePanel.setLayout(new BoxLayout(editdeletePanel, BoxLayout.X_AXIS));
		editdeletePanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		editdeletePanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		editdeletePanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel edLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 7));
		edLeft.setBackground(Color.WHITE);
		edLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		edLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		
		edLeft.add(assessmentOptional);
		
		JPanel edRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 7));
		edRight.setBackground(UI_Settings.getComponentpanefillcolor());
		edRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		edRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		edRight.add(labels[9]);
		edRight.add(labels[10]);

		
		edLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		editdeletePanel.add(edLeft);
		
		edRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		editdeletePanel.add(edRight);
		/******************************************************add the enter assessment scores panel************************************************/
		
		///create the inner panel with the border///
		JPanel assessDetails = new JPanel(new GridBagLayout());
		assessDetails.setBackground(new Color(246,246,246));
		Border panel3border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
		assessDetails.setBorder(panel3border);
		assessDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 60));
		assessDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 60));
		assessDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 60));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-5,10,0,10);
		assessDetails.add(new JLabel("Listening:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		gc.insets = new Insets(-10,-20,0,20);
		assessDetails.add(txtListen, gc);
		
		gc.gridx = 2;
		gc.gridy = 1;
		gc.insets = new Insets(-5,-15,0,15);
		assessDetails.add(new JLabel("Speaking:"), gc);
		
		gc.gridx = 3;
		gc.gridy = 1;
		gc.insets = new Insets(-10,-10,0,10);
		assessDetails.add(txtSpeak, gc);
		
		gc.gridx = 4;
		gc.gridy = 1;
		gc.insets = new Insets(-5,10,0,0);
		assessDetails.add(new JLabel("Reading:"), gc);
		
		gc.gridx = 5;
		gc.gridy = 1;
		gc.insets = new Insets(-10,10,0,0);
		assessDetails.add(txtRead, gc);
		
		gc.gridx = 6;
		gc.gridy = 1;
		gc.insets = new Insets(-5,10,0,0);
		assessDetails.add(new JLabel("Participation:"), gc);
		
		gc.gridx = 7;
		gc.gridy = 1;
		gc.insets = new Insets(-10,10,0,0);
		assessDetails.add(txtParticipate, gc);
		
		gc.gridx = 8;
		gc.gridy = 1;
		gc.insets = new Insets(-5,10,0,0);
		assessDetails.add(new JLabel("Cooperation:"), gc);
		
		gc.gridx = 9;
		gc.gridy = 1;
		gc.insets = new Insets(-10,10,0,0);
		assessDetails.add(txtCooperate, gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,10,0,10);
		pnlAssessmentDetails.add(assessDetails, gc);

		
		
		//////////////////////////////////////////////End Add Assessments Entry Panel////////////////////////////////////////////
		
		JPanel middleComponents = new JPanel(new GridBagLayout());
		middleComponents.setBackground(Color.WHITE);

		middleComponents.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		middleComponents.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,10,0,-26);

		middleComponents.add(new JLabel("Select the group you want view"), gc);
		
		
		/******************************************************Add the Buttons Panel************************************************/
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 2));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
	
		leftPanel.add(new JLabel("Group Name:"));
		leftPanel.add(cmbGroupName);
		
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 3));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		//rightPanel.add(btnAddStudent);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		middleComponents.add(buttonPanel, gc);
		/*****************************************************Add the group details and member list panel***********************************/
		////////Initialize local fields here for convenience/////////
		txtAreaMemberNames = new JTextArea(6, 20);
		txtAreaMemberNames.setEditable(true);
		txtAreaMemberNames.setBorder(UI_Settings.getBorderoutline());
		txtAreaMemberNames.setWrapStyleWord(true);
		txtAreaMemberNames.setLineWrap(true);
		txtAreaMemberNames.setDocument(new JTextFieldLimit(150));
		
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(5, 5, 5, 5);
		CompoundBorder border = new CompoundBorder(line, empty);
		txtAreaMemberNames.setBorder(border);
		
		txtAreaMemberNames.setPreferredSize(txtAreaMemberNames.getPreferredSize());
		textPrompt = new TextPrompt("<this group contains no members>", txtAreaMemberNames);
		
		//Make the group information panel
		JPanel pnlGroupInformation = new JPanel(new GridBagLayout());
		
		pnlGroupInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+10));
		pnlGroupInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+10));
		pnlGroupInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+10));
		pnlGroupInformation.setBackground(Color.WHITE);
		
			//Make the member list panel
			JPanel pnlMemberList = new JPanel(new GridBagLayout());
			pnlMemberList.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()+10));
			pnlMemberList.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()+10));
			pnlMemberList.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()+10));
			pnlMemberList.setBackground(Color.WHITE);
		
				JPanel panel1 = new JPanel(new GridBagLayout());
				panel1.setBackground(Color.WHITE);
				Border panel1border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
				panel1.setBorder(panel1border);
				panel1.setPreferredSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
				panel1.setMinimumSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
				panel1.setMaximumSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
				
					//Add the contents to the member list panel
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(10,13,-10,0);
					panel1.add(new JLabel("Group Members:"), gc);
					
					gc.gridx = 0;
					gc.gridy = 1;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(10,10,5,10);
					panel1.add(txtAreaMemberNames, gc);
				
				
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.insets = new Insets(5,5,0,5);
				
				pnlMemberList.add(panel1,gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		
		pnlGroupInformation.add(pnlMemberList, gc);
		////////////////////DONE///////////////////
		//Make the member list panel
		JPanel pnlGroupDetails = new JPanel(new GridBagLayout());
		
		pnlGroupDetails.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
		pnlGroupDetails.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
		pnlGroupDetails.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
		
		pnlGroupDetails.setBackground(Color.WHITE);
	
			JPanel panel2 = new JPanel(new GridBagLayout());
			panel2.setBackground(new Color(246,246,246));
			panel2.setBorder(panel1border);
			panel2.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
			panel2.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
			panel2.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
			
				///Add the group details contents to the panel////
				//////////////Col 1///////////
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(17,20,0,0);
				panel2.add(new JLabel("Material:"), gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Group ID:"), gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Positions Available:"), gc);
				
				gc.gridx = 0;
				gc.gridy = 3;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Group Level:"), gc);
				/////////Col 2////////
				gc.gridx = 1;
				gc.gridy = 0;
				gc.insets = new Insets(10,20,0,0);
				panel2.add(txtGroupMat, gc);
				
				gc.gridx = 1;
				gc.gridy = 1;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtGroupID, gc);
				
				gc.gridx = 1;
				gc.gridy = 2;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtGroupPos, gc);
				
				gc.gridx = 1;
				gc.gridy = 3;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtGroupLev, gc);
				/////////Col 3////////
				gc.gridx = 2;
				gc.gridy = 0;
				gc.insets = new Insets(17,20,0,0);
				panel2.add(new JLabel("Group Day:"), gc);
				
				gc.gridx = 2;
				gc.gridy = 1;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Group Time:"), gc);
				
				gc.gridx = 2;
				gc.gridy = 2;
				panel2.add(new JLabel("Group Size:"), gc);
				
				////////Col 4///////
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(10,20,0,0);
				panel2.add(txtGroupDay, gc);
				
				gc.gridx = 3;
				gc.gridy = 1;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtGroupTime, gc);
				
				gc.gridx = 3;
				gc.gridy = 2;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtGroupMax, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,5,5,5);
				pnlGroupDetails.add(panel2,gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridwidth = 2;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,5);
		
		pnlGroupInformation.add(pnlGroupDetails, gc);
		
		/********************************************************Add the Remove Student and Add Student Buttons****************************/
		JPanel addStudentsButtonPanel = new JPanel();
		addStudentsButtonPanel.setLayout(new BoxLayout(addStudentsButtonPanel, BoxLayout.X_AXIS));
		/***********************Add student button ActionListener***********************/
		btnAddStudent.addMouseListener(new MouseAdapter(){
			
			
			private String firstname;
			private String lastname;
			private String month;
			private String material;
			private Integer level;
			private String groupname;
			
			String[] rowData = new String[viewAllCustomersTable.getColumnCount()];
			int selectedRowIndex;
			


			public void mousePressed(MouseEvent e) {

				firstname = txtFirstName.getText();
				lastname = txtLastName.getText();
				month = (String) cmbMonths.getSelectedItem();
				material = (String) cmbMaterial.getSelectedItem();
				level = (Integer)cmbLevels.getSelectedIndex();
				groupname = (String)cmbGroupName.getSelectedItem();
				
			}
			
			public void mouseReleased(MouseEvent e){
				
				selectedRowIndex = viewAllCustomersTable.getSelectedRow();
				
				for(int i = 0; i < viewAllCustomersTable.getColumnCount(); i++){
					
					Object selectedObject = (Object) viewAllCustomersTable.getModel().getValueAt(selectedRowIndex, i);

					rowData[i] = selectedObject.toString();
					
				}

				
				if(checkValues(firstname, lastname, month, material, level)){
					
					
				}			
			}

			private boolean checkValues(String firstName, String lastName, String month, String material, Integer level) {
				
				
				/*Do validation check to make sure all of the fields have been entered for a new customer*/
				
				if(chkNewStudent.isSelected()){
					
					if(firstName.isEmpty() || lastName.isEmpty() || month.isEmpty() || material.isEmpty() || (level == -1) || groupname.isEmpty()){
						
						failedMessage1.setVisible(true);

						if(firstName.isEmpty()){
							txtFirstName.setBackground(UI_Settings.getComponentErrorColor());
						}else{
							txtFirstName.setBackground(Color.WHITE);
						}
						
						if(lastName.isEmpty()){
							txtLastName.setBackground(UI_Settings.getComponentErrorColor());
						}else{
							txtLastName.setBackground(Color.WHITE);
						}
						
						if(month.isEmpty()){
							cmbMonths.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						}else{
							cmbMonths.getEditor().getEditorComponent().setBackground(Color.WHITE);
						}
						
						if(material.isEmpty()){
							cmbMaterial.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						}else{
							cmbMaterial.getEditor().getEditorComponent().setBackground(Color.WHITE);
						}
						
						if(level == -1){
							cmbLevels.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						}else{
							cmbLevels.getEditor().getEditorComponent().setBackground(Color.WHITE);
							
						}
						
						/*Do a validation check to make sure the user has selected a group to add the customer too*/
						
						if(groupname.isEmpty()){
							cmbGroupName.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						}else{
							cmbGroupName.getEditor().getEditorComponent().setBackground(Color.WHITE);
						}
						
						JOptionPane.showMessageDialog(GroupPane.this, UI_Settings.getDlgAddNewStudentToGroupFail(), "", JOptionPane.WARNING_MESSAGE);
						return false;
					}
					
					/*Do a validation check to make sure the user has entered a first and last name at least 2 letters long.*/
					
					if((firstName.length() == 1) && (lastName.length() == 1)){
						
						txtFirstName.setBackground(UI_Settings.getComponentErrorColor());
						txtLastName.setBackground(UI_Settings.getComponentErrorColor());
						failedMessage1.setVisible(true);
						
						JOptionPane.showMessageDialog(GroupPane.this, UI_Settings.getDlgAddNewCustomerBothNamesTooShortFail(), "", JOptionPane.WARNING_MESSAGE);
						return false;
						
					}else{
						txtFirstName.setBackground(Color.WHITE);
						txtLastName.setBackground(Color.WHITE);
					}
					
					/*Do a validation check to make sure the first name is at least 2 letters long*/
					
					if(firstName.length() <= 1){
						
						txtFirstName.setBackground(UI_Settings.getComponentErrorColor());
						failedMessage1.setVisible(true);
						
						JOptionPane.showMessageDialog(GroupPane.this, UI_Settings.getDlgAddNewCustomerFirstNamesTooShortFail(), "", JOptionPane.WARNING_MESSAGE);
						return false;
					}else{
						txtFirstName.setBackground(Color.WHITE);
					}
					
					/*Do a validation check to make sure the last name is at least 2 letters long*/
					
					if(lastName.length() <= 1){
						
						txtLastName.setBackground(UI_Settings.getComponentErrorColor());
						failedMessage1.setVisible(true);
						
						JOptionPane.showMessageDialog(GroupPane.this, UI_Settings.getDlgAddNewCustomerLastNamesTooShortFail(), "", JOptionPane.WARNING_MESSAGE);
						return false;
					}else{
						txtLastName.setBackground(Color.WHITE);
					}
					failedMessage1.setVisible(false);
					return true;
					
				}//End if(chkNewStudent.isSelected())
				
				
				/*Do a validation check to make sure the group name has been selected*/
				
				if(chkExistingStudent.isSelected()){
					
					if(groupname.isEmpty()){
						
						cmbGroupName.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						failedMessage2.setVisible(true);

						JOptionPane.showMessageDialog(GroupPane.this, UI_Settings.getDlgAddExistingStudentToGroupNogroupselectedFail(), "", JOptionPane.WARNING_MESSAGE);
						return false;
					}else{
						
						failedMessage2.setVisible(false);
						cmbGroupName.getEditor().getEditorComponent().setBackground(Color.WHITE);
					}
					
					//Validate the table. If rowData[0] is null then the table doesnt contain any data.
					if(rowData[0] == null){
						
						failedMessage2.setVisible(true);
						
						JOptionPane.showMessageDialog(GroupPane.this, UI_Settings.getDlgAddExistingStudentToGroupNoSelectionFromTableFail(), "", JOptionPane.WARNING_MESSAGE);
						return false;
					}else{
						failedMessage2.setVisible(false);
					}
				}//End chkExistingStduent.isSelected
				
			return true;	
			}//End checkValues
		});
		/*********************End Add student button ActionListener**********************/
		
		JPanel removePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		removePanel.setBackground(UI_Settings.getButtonPanelColor());
		removePanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		removePanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		removePanel.add(labels[7]);//reset locally button
	
		JPanel addPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 3));
		addPanel.setBackground(UI_Settings.getButtonPanelColor());
		addPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		addPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		addPanel.add(btnAddStudent);//add student button 
		
		removePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		addStudentsButtonPanel.add(removePanel);
		
		addPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		addStudentsButtonPanel.add(addPanel);
		
		addStudentsButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,UI_Settings.getTableButtonsPanelHeight()));
		addStudentsButtonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableButtonsPanelHeight()));
		/******************************************************Add Assessment Details Buttons Panel************************************************/
		
		JPanel addAssessmentButtonPanel = new JPanel();
		addAssessmentButtonPanel.setBackground(UI_Settings.getButtonPanelColor());
		addAssessmentButtonPanel.setLayout(new BoxLayout(addAssessmentButtonPanel, BoxLayout.X_AXIS));
		
		
		JPanel leftSide = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		leftSide.setBackground(UI_Settings.getButtonPanelColor());
		leftSide.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftSide.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		
		
		JPanel rightSide = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		rightSide.setBackground(UI_Settings.getButtonPanelColor());
		rightSide.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightSide.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightSide.add(labels[4]);	//add assessment details (optional) label
		rightSide.add(labels[5]); //edit label	
		rightSide.add(labels[6]); //delete label
		
		leftSide.setAlignmentX(Component.LEFT_ALIGNMENT);
		addAssessmentButtonPanel.add(leftSide);
		
		rightSide.setAlignmentX(Component.RIGHT_ALIGNMENT);
		addAssessmentButtonPanel.add(rightSide);
		addAssessmentButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 40));
		addAssessmentButtonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 40));
		
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        centerPanel.add(cardsButtons);
        
        centerPanel.add(cards);
        
        editdeletePanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(editdeletePanel);
        
        pnlAssessmentDetails.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlAssessmentDetails);
        
        middleComponents.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(middleComponents);
        
        pnlGroupInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlGroupInformation);
        
        addStudentsButtonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(addStudentsButtonPanel);

        
        
        /*********************************************************************************************************************************/
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));

		//////////////////////////////Search, save, reset button row///////////////////
		//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		
		/*********************************************************************************************************************************/
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());	
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
		
		return scroller;
	}//END addStudentToGroup/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	protected void resetASTG_TextFields(List<JTextField> textfields, @SuppressWarnings("rawtypes") List<JComboBox> comboboxes, JLabel x, JLabel y) {
		
		for(int i = 0; i < textfields.size(); i++){
			textfields.get(i).setText("");
			textfields.get(i).setBackground(Color.WHITE);
		}	
		
		for(int i = 0; i < comboboxes.size(); i++){
			comboboxes.get(i).setSelectedIndex(0);
			comboboxes.get(i).getEditor().getEditorComponent().setBackground(Color.WHITE);
		}	
		
   	   	x.setVisible(false);
   	   	y.setVisible(false);	
   	   	
   	   	addNewCustomerTable.setRowSelected(0, 0);
   	   	viewAllCustomersTable.setRowSelected(0, 0);
   	   	groupMemberListTable.setRowSelected(0, 0);
		
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public Component moveStudent()
	{		
		int fields;

		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		
		JButton btnMoveStudent;
		
		//Center Panel fields
		JTextField txtTopPanelStudentName;
		JTextField txtTopPanelAge;
		
		JTextField txtTopGroupName;
		JTextField txtTopGroupID;
		JTextField txtTopGroupPos;
		JTextField txtTopGroupLev;
		JTextField txtTopGroupDay;
		JTextField txtTopGroupTime;
		JTextField txtTopGroupMax;
		JTextField txtTopGroupMat;
		
		JTextField txtBottomGroupName;
		JTextField txtBottomGroupID;
		JTextField txtBottomGroupPos;
		JTextField txtBottomGroupLev;
		JTextField txtBottomGroupDay;
		JTextField txtBottomGroupTime;
		JTextField txtBottomGroupMax;
		JTextField txtBottomGroupMat;
		
		JPasswordField passwordField;
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
        
        JTextArea txtMoveFromNameContainer;
        JTextArea txtMoveToNameContainer;
		/***************************************************Create labels***********************************************************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage.setVisible(false);
		
		JLabel labels[] = new JLabel[8];
		labels[0] = new JLabel("reset move from data");
		labels[1] = new JLabel("undo move");
		labels[2] = new JLabel("help");
		labels[3] = new JLabel("help");
		labels[4] = new JLabel("move");
		labels[5] = new JLabel("view interests");
		labels[6] = new JLabel("view comments");
		labels[7] = new JLabel("reset move to data");
		
		labels[1].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				JOptionPane.showMessageDialog(GroupPane.this, "The undo move comment for group member button has been pressed.", "", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
		
		for(int i = 0; i < 8; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());	
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		////////Initialize local fields here for convenience/////////
		txtMoveFromNameContainer = new JTextArea(7, 20);
		txtMoveFromNameContainer.setEditable(true);
		txtMoveFromNameContainer.setBorder(UI_Settings.getBorderoutline());
		txtMoveFromNameContainer.setWrapStyleWord(true);
		txtMoveFromNameContainer.setLineWrap(true);
		txtMoveFromNameContainer.setDocument(new JTextFieldLimit(150));
		
		txtMoveFromNameContainer.setPreferredSize(txtMoveFromNameContainer.getPreferredSize());
		textPrompt = new TextPrompt("<no customer names found>", txtMoveFromNameContainer);
		
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(5, 5, 5, 5);
		CompoundBorder border = new CompoundBorder(line, empty);
		txtMoveFromNameContainer.setBorder(border);
		////////Initialize local fields here for convenience/////////
		txtMoveToNameContainer = new JTextArea(6, 20);
		txtMoveToNameContainer.setEditable(true);
		txtMoveToNameContainer.setBorder(UI_Settings.getBorderoutline());
		txtMoveToNameContainer.setWrapStyleWord(true);
		txtMoveToNameContainer.setLineWrap(true);
		txtMoveToNameContainer.setDocument(new JTextFieldLimit(150));
		txtMoveToNameContainer.setBorder(border);
		
		txtMoveToNameContainer.setPreferredSize(txtMoveToNameContainer.getPreferredSize());
		textPrompt = new TextPrompt("<no customer names found>", txtMoveToNameContainer);
		

		/*********************************************Add the Bottom Panel TextFields***********************/

		int size = 13;
		
		
		List <JTextField> textfieldsGroupDetailsTop = new ArrayList<JTextField>();
		List <JTextField> textfieldsGroupDetailsBottom = new ArrayList<JTextField>();

		
		
		txtTopGroupName = new JTextField(size);
		txtTopGroupName.setMinimumSize(txtTopGroupName.getPreferredSize());
		txtTopGroupName.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupName); 
		
		txtTopGroupID = new JTextField(size);
		txtTopGroupID.setMinimumSize(txtTopGroupID.getPreferredSize());
		txtTopGroupID.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupID); 

		
		txtTopGroupPos = new JTextField(size);
		txtTopGroupPos.setMinimumSize(txtTopGroupPos.getPreferredSize());
		txtTopGroupPos.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupPos); 

		
		txtTopGroupLev = new JTextField(size);
		txtTopGroupLev.setMinimumSize(txtTopGroupLev.getPreferredSize());
		txtTopGroupLev.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupLev); 
		
		txtTopGroupDay = new JTextField(size);
		txtTopGroupDay.setMinimumSize(txtTopGroupDay.getPreferredSize());
		txtTopGroupDay.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupDay); 

		
		txtTopGroupTime = new JTextField(size);
		txtTopGroupTime.setMinimumSize(txtTopGroupTime.getPreferredSize());
		txtTopGroupTime.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupTime); 

		
		txtTopGroupMax = new JTextField(size);
		txtTopGroupMax.setMinimumSize(txtTopGroupMax.getPreferredSize());
		txtTopGroupMax.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupMax); 

		
		txtTopGroupMat = new JTextField(size);
		txtTopGroupMat.setMinimumSize(txtTopGroupMat.getPreferredSize());
		txtTopGroupMat.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsTop.add(txtTopGroupMat); 
		
		
		txtBottomGroupName = new JTextField(size);
		txtBottomGroupName.setMinimumSize(txtBottomGroupName.getPreferredSize());
		txtBottomGroupName.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupName); 
		
		txtBottomGroupID = new JTextField(size);
		txtBottomGroupID.setMinimumSize(txtBottomGroupID.getPreferredSize());
		txtBottomGroupID.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupID); 

		
		txtBottomGroupPos = new JTextField(size);
		txtBottomGroupPos.setMinimumSize(txtBottomGroupPos.getPreferredSize());
		txtBottomGroupPos.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupPos); 

		
		txtBottomGroupLev = new JTextField(size);
		txtBottomGroupLev.setMinimumSize(txtBottomGroupLev.getPreferredSize());
		txtBottomGroupLev.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupLev); 
		
		txtBottomGroupDay = new JTextField(size);
		txtBottomGroupDay.setMinimumSize(txtBottomGroupDay.getPreferredSize());
		txtBottomGroupDay.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupDay); 

		
		txtBottomGroupTime = new JTextField(size);
		txtBottomGroupTime.setMinimumSize(txtBottomGroupTime.getPreferredSize());
		txtBottomGroupTime.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupTime); 

		
		txtBottomGroupMax = new JTextField(size);
		txtBottomGroupMax.setMinimumSize(txtBottomGroupMax.getPreferredSize());
		txtBottomGroupMax.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupMax); 

		
		txtBottomGroupMat = new JTextField(size);
		txtBottomGroupMat.setMinimumSize(txtBottomGroupMat.getPreferredSize());
		txtBottomGroupMat.setHorizontalAlignment(JTextField.LEFT);
		textfieldsGroupDetailsBottom.add(txtBottomGroupMat); 

		txtTopPanelStudentName = new JTextField(10);
		txtTopPanelStudentName.setEditable(true);
		txtTopPanelStudentName.setMinimumSize(txtTopPanelStudentName.getPreferredSize());
		textPrompt = new TextPrompt("-", txtTopPanelStudentName);
		txtTopPanelStudentName.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetailsTop.add(txtTopPanelStudentName);
		
		txtTopPanelAge = new JTextField(5);
		txtTopPanelAge.setEditable(true);
		txtTopPanelAge.setMinimumSize(txtTopPanelAge.getPreferredSize());
		textPrompt = new TextPrompt("-", txtTopPanelAge);
		txtTopPanelAge.setHorizontalAlignment(JTextField.CENTER);
		textfieldsGroupDetailsTop.add(txtTopPanelAge);
		
		
		/*********************************************************Create Combo Boxes*********************************************************/
		JComboBox<String> cmbMoveFromGroupName = new JComboBox<String>(UI_Settings.getGroups());
		cmbMoveFromGroupName.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbMoveFromGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbMoveFromGroupName.setMinimumSize(cmbMoveFromGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbMoveFromGroupName, 180, UI_Settings.getComboBoxHeight());

		JComboBox<String> cmbMoveToGroupName = new JComboBox<String>(UI_Settings.getGroups());
		cmbMoveToGroupName.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbMoveToGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbMoveToGroupName.setMinimumSize(cmbMoveToGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbMoveToGroupName, 180, UI_Settings.getComboBoxHeight());
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		//Reset move to button//
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
				failedMessage.setVisible(false);
				
				for(int i = 0; i < textfieldsGroupDetailsTop.size(); i++){
					textfieldsGroupDetailsTop.get(i).setText("");
				}
				
				txtMoveFromNameContainer.setText("");
				
				cmbMoveFromGroupName.setSelectedIndex(0);
				
				passwordField.setText("");
				   
			}
		});
		//Reset move to button//
		labels[7].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
				for(int i = 0; i < textfieldsGroupDetailsBottom.size(); i++){
					textfieldsGroupDetailsBottom.get(i).setText("");
				}
				
				txtMoveToNameContainer.setText("");
				
				cmbMoveToGroupName.setSelectedIndex(0);
				
				passwordField.setText("");
				   
			}
		});
		/*****************************************************************************************************************************/
	
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		GridBagConstraints gc = new GridBagConstraints();
		
		////////////////////////////////////////////////////////////////
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		container.setBackground(Color.WHITE);
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		container.add(new JLabel("Select the group you want to move the student from:"));
		container.add(cmbMoveFromGroupName);
		
		container.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(container);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(17,0,0,0);
		detailsPanel.add(firstRow, gc);
		/******************************************************Add the Buttons Panel************************************************/
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 25));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 25));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 25));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 7));
		rightPanel.setBackground(Color.WHITE);
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 25));
		rightPanel.add(labels[0]);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		
		
		/*************************************************Add Student to Group Buttons Panel***********************************************/
		JPanel middleComponents = new JPanel(new GridBagLayout());
		middleComponents.setBackground(Color.WHITE);

		middleComponents.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		middleComponents.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		
		
		/******************************************************Add the Buttons Panel************************************************/

		int size2 = 80;
		JPanel moveToButtonsPanel = new JPanel();
		moveToButtonsPanel.setBackground(UI_Settings.getButtonPanelColor());
		moveToButtonsPanel.setLayout(new BoxLayout(moveToButtonsPanel, BoxLayout.X_AXIS));
		moveToButtonsPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, size2));
		moveToButtonsPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, size2));
		moveToButtonsPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, size2));

		
		JPanel leftPanel2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 26,30));
		leftPanel2.setBackground(Color.WHITE);
		leftPanel2.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, size2));
		leftPanel2.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, size2));
		leftPanel2.add(new JLabel("Select the group you want to add the student to:"));
		leftPanel2.add(cmbMoveToGroupName);
		
		
		JPanel rightPanel2 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 35));
		rightPanel2.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel2.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, size2));
		rightPanel2.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, size2));
		rightPanel2.add(labels[7]);//Reset Move To data
		
		leftPanel2.setAlignmentX(Component.LEFT_ALIGNMENT);
		moveToButtonsPanel.add(leftPanel2);
		
		rightPanel2.setAlignmentX(Component.RIGHT_ALIGNMENT);
		moveToButtonsPanel.add(rightPanel2);
		///////////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////Start the center panels///////////////////////////////////	
		int topFrameHeight = 210;
		
		JPanel pnlCenterTopPanel = new JPanel(new GridBagLayout());
		pnlCenterTopPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		pnlCenterTopPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		pnlCenterTopPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		
		JPanel pnlCenterTopLeft = new JPanel(new GridBagLayout());
		pnlCenterTopLeft.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		pnlCenterTopLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		pnlCenterTopLeft.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		
		Border darkBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY);


			//add components to the left panel
			pnlCenterTopLeft.setBorder(darkBorder);
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(30,10,0,0);
			pnlCenterTopLeft.add(new JLabel("Click on the students name to select:"), gc);
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,10,20,10);
			pnlCenterTopLeft.add(txtMoveFromNameContainer, gc);
			
		JPanel pnlCenterTopRight = new JPanel(new GridBagLayout());
		pnlCenterTopRight.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setBackground(Color.WHITE);

			int centerTopHeight = 50;
			JPanel pnlCenterTopRightTop = new JPanel(new GridBagLayout());
			pnlCenterTopRightTop.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setBackground(Color.WHITE);

				//Add the contents of this panel - the student name and the student age plus buttons
				//Add the student name panel//
				JPanel pnlStudentName = new JPanel(new GridBagLayout());
				pnlStudentName.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				pnlStudentName.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				pnlStudentName.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				pnlStudentName.setBorder(darkBorder);
				pnlStudentName.setBackground(Color.WHITE);
					//Add student name fields//
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 0.2;
					gc.weighty = 0.2;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,10,0,0);
					pnlStudentName.add(new JLabel("Student Name:"),gc);
					gc.gridx = 1;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 0.2;
					gc.weighty = 0.2;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,10,0,0);
					pnlStudentName.add(txtTopPanelStudentName,gc);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 0.2;
				gc.weighty = 0.2;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,0,0);
				pnlCenterTopRightTop.add(pnlStudentName,gc);
				
				JPanel pnlStudentButtons = new JPanel(new GridBagLayout());
				pnlStudentButtons.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				pnlStudentButtons.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				pnlStudentButtons.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				pnlStudentButtons.setBorder(darkBorder);
				pnlStudentButtons.setBackground(Color.WHITE);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,1);
				pnlStudentButtons.add(new JLabel("Age:"), gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,-20,0,0);
				pnlStudentButtons.add(txtTopPanelAge, gc);
				
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,0);
				pnlStudentButtons.add(labels[5], gc);
				
				gc.gridx = 3;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,5,0,0);
				pnlStudentButtons.add(labels[6], gc);
				
				
				
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,1);
				pnlCenterTopRightTop.add(pnlStudentButtons, gc);

				int middle;
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		pnlCenterTopRight.add(pnlCenterTopRightTop, gc);
		
				//Add the contents of the bottom panel, the group details
				//Add the group details (toprightbottom)
				JPanel pnlTopGroupDetails = new JPanel(new GridBagLayout());
				pnlTopGroupDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
				pnlTopGroupDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
				pnlTopGroupDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
				pnlTopGroupDetails.setBackground(Color.WHITE);
				pnlTopGroupDetails.setBorder(darkBorder);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(20,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Name:"),gc);
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group ID:"),gc);
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Positions Available:"),gc);
				gc.gridx = 0;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Level:"),gc);
				gc.gridx = 1;
				gc.gridy = 0;
				gc.insets = new Insets(15,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupName,gc);
				gc.gridx = 1;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupID,gc);
				gc.gridx = 1;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupPos,gc);
				gc.gridx = 1;
				gc.gridy = 3;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupLev,gc);
				gc.gridx = 2;
				gc.gridy = 0;
				gc.insets = new Insets(20,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Day:"),gc);
				gc.gridx = 2;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Time:"),gc);
				gc.gridx = 2;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Size:"),gc);
				gc.gridx = 2;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Material:"),gc);
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(15,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupDay,gc);
				gc.gridx = 3;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupTime,gc);
				gc.gridx = 3;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupMax,gc);
				gc.gridx = 3;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtTopGroupMat,gc);
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,0,1,0);
		pnlCenterTopRight.add(pnlTopGroupDetails, gc);
		
				
		pnlCenterTopLeft.setBackground(new Color(246,246,246));
		

		
		//This is the main container panel for the North most components on the central stage - namely pnlCenterTopLeftPanel and pnlCenterTopRight//
		pnlCenterTopPanel.setBackground(Color.WHITE);
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,5,0,5);
			pnlCenterTopPanel.add(pnlCenterTopLeft, gc);
			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,5,0,10);
			pnlCenterTopPanel.add(pnlCenterTopRight, gc);
		////////////////////////////END OF THE TOP LEVEL COMPONENTS////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////
		////////////////////////BEGINNING OF THE BOTTOM LEVEL COMPONENTS///////////////////////
		///////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////
			
			JPanel pnlCenterBottomPanel = new JPanel(new GridBagLayout());
			pnlCenterBottomPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight-centerTopHeight));
			pnlCenterBottomPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight-centerTopHeight));
			pnlCenterBottomPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight-centerTopHeight));
			
			JPanel pnlCenterBottomLeft = new JPanel(new GridBagLayout());
			pnlCenterBottomLeft.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight-centerTopHeight));
			pnlCenterBottomLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight-centerTopHeight));
			pnlCenterBottomLeft.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight-centerTopHeight));
			

				//add components to the left panel
				pnlCenterBottomLeft.setBorder(darkBorder);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 0.2;
				gc.weighty = 0.2;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(15,10,0,0);
				pnlCenterBottomLeft.add(new JLabel("Click on the students name to select:"), gc);
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.weightx = 0.2;
				gc.weighty = 0.2;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,10,10,10);
				pnlCenterBottomLeft.add(txtMoveToNameContainer, gc);
				
			JPanel pnlCenterBottomRight = new JPanel(new GridBagLayout());
			pnlCenterBottomRight.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
			pnlCenterBottomRight.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
			pnlCenterBottomRight.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
			pnlCenterBottomRight.setBackground(new Color(246,246,246));

					//Add the contents of the bottom panel, the group details
					//Add the group details (pnlBottomGroupDetails)
					JPanel pnlBottomGroupDetails = new JPanel(new GridBagLayout());
					pnlBottomGroupDetails.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
					pnlBottomGroupDetails.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
					pnlBottomGroupDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
					pnlBottomGroupDetails.setBackground(new Color(246,246,246));
					pnlBottomGroupDetails.setBorder(darkBorder);
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridwidth = 1;
					gc.gridheight = 1;
					gc.weightx = 0.5;
					gc.weighty = 0.5;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(20,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Group Name:"),gc);
					gc.gridx = 0;
					gc.gridy = 1;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Group ID:"),gc);
					gc.gridx = 0;
					gc.gridy = 2;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Positions Available:"),gc);
					gc.gridx = 0;
					gc.gridy = 3;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Group Level:"),gc);
					gc.gridx = 1;
					gc.gridy = 0;
					gc.insets = new Insets(15,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupName,gc);
					gc.gridx = 1;
					gc.gridy = 1;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupID,gc);
					gc.gridx = 1;
					gc.gridy = 2;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupPos,gc);
					gc.gridx = 1;
					gc.gridy = 3;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupLev,gc);
					gc.gridx = 2;
					gc.gridy = 0;
					gc.insets = new Insets(20,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Group Day:"),gc);
					gc.gridx = 2;
					gc.gridy = 1;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Group Time:"),gc);
					gc.gridx = 2;
					gc.gridy = 2;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Group Size:"),gc);
					gc.gridx = 2;
					gc.gridy = 3;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(new JLabel("Material:"),gc);
					gc.gridx = 3;
					gc.gridy = 0;
					gc.insets = new Insets(15,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupDay,gc);
					gc.gridx = 3;
					gc.gridy = 1;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupTime,gc);
					gc.gridx = 3;
					gc.gridy = 2;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupMax,gc);
					gc.gridx = 3;
					gc.gridy = 3;
					gc.insets = new Insets(0,10,0,0);
					pnlBottomGroupDetails.add(txtBottomGroupMat,gc);
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,1,0);
			pnlCenterBottomRight.add(pnlBottomGroupDetails, gc);
			
					
			pnlCenterBottomLeft.setBackground(Color.WHITE);
			

			
			//This is the main container panel for the North most components on the central stage - namely pnlCenterTopLeftPanel and pnlCenterTopRight//
			pnlCenterBottomPanel.setBackground(Color.WHITE);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 0.2;
				gc.weighty = 0.2;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,5);
				pnlCenterBottomPanel.add(pnlCenterBottomLeft, gc);
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,10);
				pnlCenterBottomPanel.add(pnlCenterBottomRight, gc);
		
		///////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////
		JPanel pnlMoveStudent = new JPanel();
		pnlMoveStudent.setBackground(Color.WHITE);
		pnlMoveStudent.setLayout(new GridBagLayout());
		pnlMoveStudent.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-40));
		pnlMoveStudent.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-40));
		pnlMoveStudent.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-40));

			//Create the far left container for the web address details information
			JPanel pnlMoveStudLeft = new JPanel(new GridBagLayout());
			pnlMoveStudLeft.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
			pnlMoveStudLeft.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
			pnlMoveStudLeft.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
			
				//Add the nested panels to the container panel (information panel)
				Border panel1border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);

				JPanel pnlLeft = new JPanel(new GridBagLayout());
				pnlLeft.setBackground(Color.WHITE);
				//pnlLeft.setBorder(panel1border);
				pnlLeft.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
				pnlLeft.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
				pnlLeft.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()-50));
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.insets = new Insets(0,0,0,0);
				pnlMoveStudLeft.add(pnlLeft, gc);
				
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.insets = new Insets(5,5,5,5);
				pnlMoveStudent.add(pnlMoveStudLeft, gc);
		
		
			//Create the far left container for the web address details information
			JPanel pnlMoveButton = new JPanel(new GridBagLayout());
			pnlMoveButton.setBackground(Color.WHITE);
			pnlMoveButton.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
			pnlMoveButton.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
			pnlMoveButton.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel pnlMove = new JPanel(new GridBagLayout());
				pnlMove.setBackground(new Color(246,246,246));
				pnlMove.setBorder(panel1border);
				pnlMove.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
				pnlMove.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));
				pnlMove.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-60));

				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,0);
				
				btnMoveStudent = new JButton("Move Student to Another Group");
				btnMoveStudent.setCursor(UI_Settings.getJlabelCursor());
				btnMoveStudent.setFont(UI_Settings.getComponentInputFontSize());
				
				btnMoveStudent.addMouseListener(new MouseAdapter(){
					
					private String movefrom;
					private String moveto;
					
					public void mousePressed(MouseEvent e){
						moveto = (String)cmbMoveToGroupName.getSelectedItem();
						movefrom = (String)cmbMoveFromGroupName.getSelectedItem();
					}
					
					public void mouseReleased(MouseEvent e){
						
							SentryModule module = new SentryModule();
						
				           char[] input = passwordField.getPassword();
				            if (module.takeInput(input)) {
								
								if(checkValues()){
									
									
									
								}
				            } else {
				                JOptionPane.showMessageDialog(controllingFrame,
				                    "To move a student please enter the correct password.",
				                    "Error Message",
				                    JOptionPane.ERROR_MESSAGE);
				            }
		
				            //Zero out the possible password, for security.
				            Arrays.fill(input, '0');
		
				            passwordField.selectAll();
					}
					private boolean checkValues() {
						
						if(moveto.isEmpty() && movefrom.isEmpty()){
							cmbMoveFromGroupName.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
							cmbMoveToGroupName.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
							failedMessage.setVisible(true);

							JOptionPane.showMessageDialog(GroupPane.this, UI_Settings.getDlgMovestudentToanotherGroupNoselectionmadeFail(), "", JOptionPane.WARNING_MESSAGE);
							return false;
						}
						
						if(moveto.isEmpty() || movefrom.isEmpty()){
							
							if(moveto.isEmpty()){
								cmbMoveToGroupName.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
								JOptionPane.showMessageDialog(GroupPane.this, UI_Settings.getDlgMovestudentToanotherGroupNoselectionmadeMovetoFail(), "", JOptionPane.WARNING_MESSAGE);
							}else{
								cmbMoveToGroupName.getEditor().getEditorComponent().setBackground(Color.WHITE);
							}
							
							if(movefrom.isEmpty()){
								cmbMoveFromGroupName.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
								failedMessage.setVisible(true);

								JOptionPane.showMessageDialog(GroupPane.this, UI_Settings.getDlgMovestudentToanotherGroupNoselectionmadeMovefromFail(), "",JOptionPane.WARNING_MESSAGE);
							}else{
								cmbMoveFromGroupName.getEditor().getEditorComponent().setBackground(Color.WHITE);
							}	

							return false;
						}
						
						if(moveto.equals(movefrom)){
							
							cmbMoveFromGroupName.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
							cmbMoveToGroupName.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
							
							failedMessage.setVisible(true);

							JOptionPane.showMessageDialog(GroupPane.this, UI_Settings.getDlgMovestudentToanotherGroupSamegroupFail(), "", JOptionPane.WARNING_MESSAGE);
							return false;
						}else{
							cmbMoveFromGroupName.getEditor().getEditorComponent().setBackground(Color.WHITE);
							cmbMoveToGroupName.getEditor().getEditorComponent().setBackground(Color.WHITE);
						}
						
						failedMessage.setVisible(false);

						return true;
					}
				});
				
				labels[2].setCursor(UI_Settings.getJlabelCursor());
				labels[2].addMouseListener(new MouseAdapter(){
					public void mouseClicked(MouseEvent e){
						
						JOptionPane.showMessageDialog(controllingFrame,
				                "The administrator password can be found with the \"Kids Coordinator\"\n"
				              + "or by contacting your \"Branch Manager\".");
						
					}
				});
				
				JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 3));
				adminPanel.setBackground(Color.WHITE);
				adminPanel.add(new JLabel("Administrator password:"));
				adminPanel.add(passwordField);
				adminPanel.add(labels[2]);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTH;
				gc.insets = new Insets(15,0,0,0);
				
				pnlMove.add(adminPanel, gc);
				
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.insets = new Insets(0,10,0,0);
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHEAST;
				pnlMove.add(btnMoveStudent, gc);//Delete material label
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.anchor = GridBagConstraints.NORTH;
				gc.insets = new Insets(0,0,0,10);
				
				pnlMoveButton.add(pnlMove, gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(5,5,5,5);
				pnlMoveStudent.add(pnlMoveButton, gc);
		
		/********************************************************Set the Table Objects Sizes**************************************************/
		groupMemberListFromTableNoHeader.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		groupMemberListFromTableNoHeader.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		
		groupMemberListToTableNoHeader.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		groupMemberListToTableNoHeader.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        pnlCenterTopPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlCenterTopPanel);
        
        moveToButtonsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(moveToButtonsPanel);
        
        pnlCenterBottomPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlCenterBottomPanel);
        
        centerPanel.add(Box.createVerticalStrut(5));

        pnlMoveStudent.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlMoveStudent);
		/*********************************************************************************************************************************/
		///////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly///////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());		
		//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return scroller;
	}//END moveStudentToAnotherGroup

}