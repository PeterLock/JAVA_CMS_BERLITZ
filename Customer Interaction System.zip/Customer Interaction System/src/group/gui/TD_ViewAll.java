package group.gui;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_ViewAll extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int GROUP_NAME = 0;
	public final static int TIME = 1;
	public final static int GROUP_MATERIAL = 2;
	public final static int LEVEL = 3;
	public final static int GROUP_DAY = 4;
	public final static int NUMBER_OF_STUDENTS_IN_CLASS = 5;
	public final static int MAX_CLASS_SIZE_ALLOWED = 6;
	
	public Object[][]values =
		{
				{"Koala", "Afternoon", "Reading Explorer", new Integer(1), "Monday", new Integer(1), new Integer(3)},
				{"Lanchester", "Evening", "Time zones", new Integer(1), "Monday", new Integer(4), new Integer(4)},
				{"London", "Noon", "Reading Explorer", new Integer(2), "Wednesday", new Integer(2), new Integer(4)},
				{"Oklahoma", "Afternoon", "Time zones", new Integer(1), "Friday", new Integer(2), new Integer(3)},
				{"Seattle", "Afternoon", "Time zones", new Integer(2), "Monday", new Integer(2), new Integer(3)},
				{"Portsmith", "Afternoon", "Reading Explorer", new Integer(1), "Thursday", new Integer(1), new Integer(3)},
				{"","","","","","",""},
				{"","","","","","",""}
		};
	
	public final static String[] COLUMN_NAMES = {"Group Name", "Time", "Group Material", "Level",
		"Group Day", "Current Class Size", "Max Class Size"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	
	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}

	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList(10, 10, 10, 10, 10, 10, 10));

}
