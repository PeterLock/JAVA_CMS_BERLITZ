package group.gui;

import javax.swing.table.AbstractTableModel;

public class TD_AddAssessment extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int CUSTOMER_ID = 0;
	public final static int CUSTOMER_NAME = 1;
	public final static int LISTENING = 2;
	public final static int SPEAKING = 3;
	public final static int READING = 4;
	public final static int PARTICIPATION = 5;
	public final static int COOPERATION = 6;
	public final static int IDEAL_LEVEL = 7;
	public final static int UPPERRANGE = 8;
	public final static int LOWER_RANGE = 9;

	
	public Object[][]values =
		{
				{new Integer(12324), "Kate Smith", new Integer(5), new Integer(3), new Integer(3), new Integer(4), new Integer(4), "Time zones", "Reading Explorer", "JHS"},
				{"", "", "", "", "", "", "", "", "", ""}
		};
	
	public final static String[] COLUMN_NAMES = {"Customer ID", "Customer Name", "Listening", "Speaking", "Reading",
		"Participation", "Cooperation", "Ideal Level", "Upper Range", "Lower Range"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
}
