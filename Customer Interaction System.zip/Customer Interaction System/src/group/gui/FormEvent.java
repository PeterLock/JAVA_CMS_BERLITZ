package group.gui;

import java.util.EventObject;

public class FormEvent extends EventObject {
	
	String groupName;
	int id;
	int currentSize;
	int maxClassSize;
	int groupLevel;
	String groupMaterial;
	String groupDay;
	String groupTime;

	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCurrentSize() {
		return currentSize;
	}
	public void setCurrentSize(int currentSize) {
		this.currentSize = currentSize;
	}
	public int getMaxClassSize() {
		return maxClassSize;
	}
	public void setMaxClassSize(int maxClassSize) {
		this.maxClassSize = maxClassSize;
	}
	public int getGroupLevel() {
		return groupLevel;
	}
	public void setGroupLevel(int groupLevel) {
		this.groupLevel = groupLevel;
	}
	public String getGroupMaterial() {
		return groupMaterial;
	}
	public void setGroupMaterial(String groupMaterial) {
		this.groupMaterial = groupMaterial;
	}
	public String getGroupDay() {
		return groupDay;
	}
	public void setGroupDay(String groupDay) {
		this.groupDay = groupDay;
	}
	public String getGroupTime() {
		return groupTime;
	}
	public void setGroupTime(String groupTime) {
		this.groupTime = groupTime;
	}
	public FormEvent(Object source) {
		super(source);
	}
	//Add Group constructor//
	public FormEvent(Object source, String groupName, int id, int currentSize, int maxClassSize, int groupLevel, String groupMaterial,
			String groupDay, String groupTime) {
		super(source);
		
		this.groupName = groupName;
		this.id = id;
		this.currentSize = currentSize;
		this.maxClassSize = maxClassSize;
		this.groupLevel = groupLevel;
		this.groupMaterial = groupMaterial;
		this.groupDay = groupDay;
		this.groupTime = groupTime;

	}

}
