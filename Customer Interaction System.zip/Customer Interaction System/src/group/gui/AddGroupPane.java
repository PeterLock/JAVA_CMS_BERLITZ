package group.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import control.gui.FormListener;
import customer.controller.Controller;
import settings.UI_Settings;
import utilities.FrameDragListener;
import utilities.UniqueIDGenerator;


public class AddGroupPane {
	
	private JFrame frame;
	private JPanel panel;
	private JPanel header;
	private JPanel btnPanel;
	
	private JPanel pnlRow1_Name;
	private JPanel pnlRow2_Size;
	private JPanel pnlRow3_ID;
	private JPanel pnlRow4_Level;
	private JPanel pnlRow5_Days;
	private JPanel pnlRow6_Time;

	
	private JButton btnConfirm;
	private JButton btnCancel;
	
	private JTextField txtGroupName;
	private JTextField txtGroupID;
	
	private JComboBox<String> cmbGroupTime;
	private JComboBox<?> cmbGroupDay;
	private JComboBox<String> cmbGroupMaterial;
	private JComboBox<?> cmbLevel;
	private JComboBox<?> cmbCurrentClassSize;
	private JComboBox<?> cmbMaxClassSizeAllowed;
	
	private int groupID;
	
	private UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	
	private List<JCheckBox> checkboxes_days = new ArrayList<JCheckBox>();
	private String[] days = new String[]{"Monday", "Tuesday", "Wednesday", "Thursday",
			"Friday", "Saturday", "Sunday"};

	
	private List<JCheckBox> checkboxes_times = new ArrayList<JCheckBox>();
	private String[] times = new String[] {"Morning", "Before Noon", "Afternoon", "Evening"};
	
	private JLabel lblCloseWindow;
	
	private int frame_width = 480;
	private int frame_height = 700;
	
	
	private Dimension dimension = new Dimension(frame_width, frame_height);
	private int combobox_size = 260;
	private int textbox_size = 20;
	
	private List <JTextField> textfields = new ArrayList<JTextField>();
	private List <JComboBox> comboboxes = new ArrayList<JComboBox>();

	JLabel reset = new JLabel("reset data");
	
	private Border border = BorderFactory.createLineBorder(new Color(180,180,180));

	


	//private FormEvent ev;
	private FormListener formListener;
	//private TablePanel tablePanel;
	private group.controller.Controller controller;
	
	
/*	public AddGroupPane(FormEvent ev, FormListener formListener, TablePanel tablePanel, Controller controller) {
		
		this.ev = ev;
		this.formListener = formListener;
		this.tablePanel = tablePanel;
		this.controller = controller;
		
	}*/

	public AddGroupPane(group.controller.Controller controller_group) {
		
		this.controller = controller_group;
		
	}

	public void run() {
		
		int width = (int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
		int height = (int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
		
		panel = new JPanel(new GridBagLayout());
		panel.setSize(dimension);
		panel.setMinimumSize(dimension);
		panel.setMaximumSize(dimension);
		panel.setBackground(Color.WHITE);
		
		
		initializeComponents();
		addComponents();
		
/*		JScrollPane scroller = new JScrollPane(panel);
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());		
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());*/
		
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(panel);
		
		FrameDragListener frameDragListener = new FrameDragListener(frame);
		frame.addMouseListener(frameDragListener);
		frame.addMouseMotionListener(frameDragListener);
		
		
		frame.setPreferredSize(panel.getPreferredSize());
		frame.setSize(dimension);
		frame.setUndecorated(true);
		frame.getRootPane().setWindowDecorationStyle(JRootPane.NONE);
		frame.setLocation(width/2-frame_width/2, height/2-frame_height/2);  //Centers the frame//
		frame.setVisible(true);
		frame.pack();
		
	}

	private void initializeComponents() {
		txtGroupName = new JTextField(textbox_size);
		txtGroupID = new JTextField(textbox_size);
		
		
		textfields.add(txtGroupName);
		textfields.add(txtGroupID);
		
		for(int i = 0; i < 7; i++){
			
			checkboxes_days.add(new JCheckBox(days[i]));

			checkboxes_days.get(i).setFont(UI_Settings.getComponentsFontPlain());
			//checkboxes_days.get(i).setForeground(UI_Settings.getComponentsFontColorLight());
			checkboxes_days.get(i).setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		}
		
		
		for(int i = 0; i < 4; i++){
			
			checkboxes_times.add(new JCheckBox(times[i]));

			checkboxes_times.get(i).setFont(UI_Settings.getComponentsFontPlain());
			//checkboxes_times.get(i).setForeground(UI_Settings.getComponentsFontColorLight());
			checkboxes_times.get(i).setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		}
		
		
		configure_checkboxes_days();
		configure_checkboxes_time();
		
		
		
		reset.setForeground(UI_Settings.getComponentsFontColorLight());
		reset.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		lblCloseWindow = new JLabel("close window [x]");
		lblCloseWindow.setForeground(Color.WHITE);
		lblCloseWindow.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
		
		
		try{
			groupID = idGenerator.getUniqueCustomerID();
			for(int i = 0; i < 20; i++){
				txtGroupID.setText(txtGroupID.getText() + "*");
			}
		} catch(NumberFormatException ec){
			txtGroupID.setText("");
			this.groupID = 0;
		}
		
		lblCloseWindow.addMouseListener(new MouseAdapter(){
			
			public void mouseReleased(MouseEvent e){
				frame.setVisible(false);
			}
			
		});
		
		btnConfirm = new JButton("Confirm");
		btnConfirm.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnConfirm.setPreferredSize(UI_Settings.getJbuttonSize());
		btnConfirm.setFont(UI_Settings.getComponentInputFontSize());
		btnConfirm.addMouseListener(new MouseAdapter(){
			
			
			String groupName;
			int id = groupID;
			int groupLevel;
			String groupMaterial;
			int maxClassSize;
			int currentSize;
			String groupDay;
			String groupTime;
			
			
			public void mousePressed(MouseEvent e){
				
				groupName = txtGroupName.getText();
				
				
				try{
					final int temp = Integer.parseInt(cmbLevel.getSelectedItem().toString());
					groupLevel = temp;
				} catch(NumberFormatException ec){
					groupLevel = 0;
				}
				
				
				
				groupMaterial = cmbGroupMaterial.getSelectedItem().toString();
				
				if(cmbMaxClassSizeAllowed.getSelectedIndex() <= 1){
					maxClassSize = 0;
				}else{
					maxClassSize = cmbMaxClassSizeAllowed.getSelectedIndex()-1;
				}
				
				if(cmbCurrentClassSize.getSelectedIndex() <= 1){
					currentSize = 0;
				}else{
					currentSize = cmbCurrentClassSize.getSelectedIndex()-1;
				}
				
				groupDay = getDay();
				groupTime = getTime();
				
				
				FormEvent ev = new FormEvent(this, groupName, id, currentSize, maxClassSize, groupLevel, groupMaterial, groupDay, groupTime);
				
				
				System.err.println("Group Name: " +ev.getGroupName());
				System.err.println("Group ID: " + ev.getId());
				System.err.println("Current Size: " + ev.getCurrentSize());
				System.err.println("Max Class Size: " + ev.getMaxClassSize());
				System.err.println("Group Level: " + ev.getGroupLevel());
				System.err.println("Group Material: " + ev.getGroupMaterial());
				System.err.println("Group Day: " + ev.getGroupDay());
				System.err.println("Group Time: " + ev.getGroupTime());

			}
			
			private String getTime() {
				String t="";
				
				for(int i = 0; i < checkboxes_times.size(); i++){
					if(checkboxes_times.get(i).isSelected()){
						t = checkboxes_times.get(i).getText();
					}
				}
				return t;
			}

			private String getDay() {
				String t="";
				
				for(int i = 0; i < checkboxes_days.size(); i++){
					if(checkboxes_days.get(i).isSelected()){
						t = checkboxes_days.get(i).getText();
					}
				}
				return t;
			}


			public void mouseReleased(MouseEvent e){
				if(formListener != null){
					//formListener.formEventOccurred(ev);
					//tablePanel.refresh();
					frame.setVisible(false);
				}
				
			}
		});
		
		btnCancel = new JButton("Cancel");
		btnCancel.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnCancel.setPreferredSize(UI_Settings.getJbuttonSize());
		btnCancel.setFont(UI_Settings.getComponentInputFontSize());
		
		btnCancel.addMouseListener(new MouseAdapter(){
			
			public void mouseReleased(MouseEvent e){
				frame.setVisible(false);
			}
			
		});
		
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(5, 5, 5, 5);
		CompoundBorder border = new CompoundBorder(line, empty);
	
		
		for(int i = 0; i < textfields.size(); i++){
			textfields.get(i).setMinimumSize(textfields.get(i).getPreferredSize());
			textfields.get(i).setEditable(true);
			//textfields.get(i).setFont(UI_Settings.getComponentInputFontSize());
			textfields.get(i).setForeground(UI_Settings.getComponentInputFontColor());
		}
		
		txtGroupID.setEditable(false);

		
		btnPanel = new JPanel();
		btnPanel.setBorder(new EmptyBorder(0,0,0,0));
		btnPanel.setBackground(new Color(235,235,235));
		btnPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 0));
		btnPanel.setPreferredSize(new Dimension((int) dimension.getWidth(), UI_Settings.getPopupHeaderHeight()));
		btnPanel.setMinimumSize(new Dimension(new Dimension((int) dimension.getWidth(), UI_Settings.getPopupHeaderHeight())));
		btnPanel.setMaximumSize(new Dimension(new Dimension((int) dimension.getWidth(), UI_Settings.getPopupHeaderHeight())));
		btnPanel.add(btnCancel);
		btnPanel.add(btnConfirm);

		
		header = new JPanel();
		header.setBorder(new EmptyBorder(0,0,0,0));
		header.setBackground(Color.WHITE);
		header.setLayout(new BoxLayout(header, BoxLayout.X_AXIS));
		header.setPreferredSize(new Dimension((int) dimension.getWidth(), UI_Settings.getPopupHeaderHeight()));
		header.setMinimumSize(new Dimension(new Dimension((int) dimension.getWidth(), UI_Settings.getPopupHeaderHeight())));
		header.setMaximumSize(new Dimension(new Dimension((int) dimension.getWidth(), UI_Settings.getPopupHeaderHeight())));


		
		cmbGroupMaterial = new JComboBox<String>(UI_Settings.getBooks());
		setComboSizes(cmbGroupMaterial, combobox_size);

		cmbLevel = new JComboBox<Object>(UI_Settings.getLevels());
		setComboSizes(cmbLevel, combobox_size);

		cmbCurrentClassSize = new JComboBox<Object>(UI_Settings.getClassSizes());
		setComboSizes(cmbCurrentClassSize, combobox_size);

		cmbMaxClassSizeAllowed = new JComboBox<Object>(UI_Settings.getClassSizes());
		setComboSizes(cmbMaxClassSizeAllowed, combobox_size);
		
		comboboxes.add(cmbGroupTime);
		comboboxes.add(cmbGroupDay);
		comboboxes.add(cmbGroupMaterial);
		comboboxes.add(cmbLevel);
		comboboxes.add(cmbCurrentClassSize);
		comboboxes.add(cmbMaxClassSizeAllowed);
		
		
		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 5));
		leftPanel.setBackground(UI_Settings.getPopupHeaderColor());
		leftPanel.setPreferredSize(new Dimension((int) dimension.getWidth()/2, UI_Settings.getPopupHeaderHeight()));
		leftPanel.setMinimumSize(new Dimension((int) dimension.getWidth()/2, UI_Settings.getPopupHeaderHeight()));
		//leftPanel.add(new JLabel("<left-side>"));
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
		rightPanel.setBackground(UI_Settings.getPopupHeaderColor());
		rightPanel.setPreferredSize(new Dimension((int) dimension.getWidth()/2, UI_Settings.getPopupHeaderHeight()));
		rightPanel.setMinimumSize(new Dimension((int) dimension.getWidth()/2, UI_Settings.getPopupHeaderHeight()));
		rightPanel.add(lblCloseWindow);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		header.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		header.add(rightPanel);
		
	}
	
	private void configure_checkboxes_time() {
		
		ItemListener listener = new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				
				if(e.getStateChange() == ItemEvent.SELECTED){
					
					if(e.getItem() == checkboxes_times.get(0)){
						resetCheckBoxDays(0);
					}
					
					if(e.getItem() == checkboxes_times.get(1)){
						resetCheckBoxDays(1);
					}
					
					if(e.getItem() == checkboxes_times.get(2)){
						resetCheckBoxDays(2);
					}
					
					if(e.getItem() == checkboxes_times.get(3)){
						resetCheckBoxDays(3);
					}
				}
			}

			private void resetCheckBoxDays(int j) {
				
				for(int i = 0; i < checkboxes_times.size(); i++){
					if(j != i){
						checkboxes_times.get(i).setSelected(false);
					}
				}
				
			}
		};
		
		for(int i = 0; i < checkboxes_times.size(); i++){
			checkboxes_times.get(i).addItemListener(listener);
		}
	}

	private void configure_checkboxes_days() {
		
		ItemListener listener = new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				
				if(e.getStateChange() == ItemEvent.SELECTED){
					
					if(e.getItem() == checkboxes_days.get(0)){
						resetCheckBoxes(0);
					}
					
					if(e.getItem() == checkboxes_days.get(1)){
						resetCheckBoxes(1);
					}
					
					if(e.getItem() == checkboxes_days.get(2)){
						resetCheckBoxes(2);
					}
					
					if(e.getItem() == checkboxes_days.get(3)){
						resetCheckBoxes(3);
					}
					
					if(e.getItem() == checkboxes_days.get(4)){
						resetCheckBoxes(4);
					}
					
					if(e.getItem() == checkboxes_days.get(5)){
						resetCheckBoxes(5);
					}
					
					if(e.getItem() == checkboxes_days.get(6)){
						resetCheckBoxes(6);
					}
				}
			}
		};
		
		for(int i = 0; i < checkboxes_days.size(); i++){
			checkboxes_days.get(i).addItemListener(listener);
		}

	}

	private void resetCheckBoxes(int j) {
		for(int i = 0; i < checkboxes_days.size(); i++){
			if(j != i){
				checkboxes_days.get(i).setSelected(false);
			}
		}
		
	}

	private void setComboSizes(JComboBox<?> combobox, int size) {
		combobox.setPreferredSize(new Dimension(size, UI_Settings.getComboBoxHeight()));
		combobox.setMinimumSize(combobox.getPreferredSize());
		combobox.setFont(UI_Settings.getComponentInputFontSize());
		
	}

/*	private String isEmpty(int data) {
		
		if(data <=0)return "0/5";
		else{
			if(data >=5){
				return "5/5";
			}else{
				return data + "/5";
			}
		}
	}*/


	private void addComponents() {
		
		GridBagConstraints gc = new GridBagConstraints();
		
		////Row 0///
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		panel.add(header, gc);
		
		pnlRow1_Name = new JPanel(new GridBagLayout());
		setPanelSize(pnlRow1_Name, new Dimension(frame_width, UI_Settings.getSmallPanelHeight()-30));
		pnlRow1_Name.setBackground(Color.WHITE);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,20,0,0);
			pnlRow1_Name.add(new JLabel("Group Name:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 0;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(0,0,0,20);
			pnlRow1_Name.add(txtGroupName, gc);
		
			
		
		pnlRow2_Size = new JPanel(new GridBagLayout());
		setPanelSize(pnlRow2_Size, new Dimension(frame_width, UI_Settings.getSmallPanelHeight()-30));
		pnlRow2_Size.setBackground(Color.WHITE);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,20,0,0);
			pnlRow2_Size.add(new JLabel("Group ID:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 0;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(0,20,0,22);
			pnlRow2_Size.add(txtGroupID, gc);
			
		
		pnlRow3_ID = new JPanel(new GridBagLayout());
		setPanelSize(pnlRow3_ID, new Dimension(frame_width, UI_Settings.getSmallPanelHeight()-10));
		pnlRow3_ID.setBackground(Color.WHITE);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(8,20,0,0);
			pnlRow3_ID.add(new JLabel("Current Class Size:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 0;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(8,-20,0,20);
			pnlRow3_ID.add(cmbCurrentClassSize, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.insets = new Insets(0,20,5,0);
			pnlRow3_ID.add(new JLabel("Max Class Size:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(0,-20,5,20);
			pnlRow3_ID.add(cmbMaxClassSizeAllowed, gc);
		
		
		pnlRow4_Level = new JPanel(new GridBagLayout());
		setPanelSize(pnlRow4_Level, new Dimension(frame_width, UI_Settings.getSmallPanelHeight()));
		pnlRow4_Level.setBackground(Color.WHITE);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(10,20,0,0);
			pnlRow4_Level.add(new JLabel("Group Level:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 0;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(10,0,0,20);
			pnlRow4_Level.add(cmbLevel, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.insets = new Insets(0,20,5,0);
			pnlRow4_Level.add(new JLabel("Group Material:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(0,0,5,20);
			pnlRow4_Level.add(cmbGroupMaterial, gc);
		
		pnlRow5_Days = new JPanel(new GridBagLayout());
		setPanelSize(pnlRow5_Days, new Dimension(frame_width, UI_Settings.getSmallPanelHeight()+20));
		pnlRow5_Days.setBackground(new Color(246,246,246));
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(10,25,0,0);
			pnlRow5_Days.add(checkboxes_days.get(0),gc);//Monday		
			
			gc.gridx = 1;
			gc.gridy = 0;
			gc.insets = new Insets(10,50,0,0);
			pnlRow5_Days.add(checkboxes_days.get(1),gc);//Tuesday
			
			gc.gridx = 2;
			gc.gridy = 0;
			gc.insets = new Insets(10,35,0,0);
			pnlRow5_Days.add(checkboxes_days.get(2),gc);//Wednesday
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.insets = new Insets(10,25,0,0);
			pnlRow5_Days.add(checkboxes_days.get(3),gc);//Thursday
			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.insets = new Insets(10,50,0,0);
			pnlRow5_Days.add(checkboxes_days.get(4),gc);//Friday
			
			gc.gridx = 2;
			gc.gridy = 1;
			gc.insets = new Insets(10,35,0,0);
			pnlRow5_Days.add(checkboxes_days.get(5),gc);//Saturday
			
			gc.gridx = 0;
			gc.gridy = 2;
			gc.insets = new Insets(10,25,10,0);
			pnlRow5_Days.add(checkboxes_days.get(6),gc);//Sunday
			
		
		pnlRow6_Time = new JPanel(new GridBagLayout());
		setPanelSize(pnlRow6_Time, new Dimension(frame_width, UI_Settings.getSmallPanelHeight()-20));
		pnlRow6_Time.setBackground(Color.WHITE);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.CENTER;
			gc.insets = new Insets(10,10,10,10);
			pnlRow6_Time.add(checkboxes_times.get(0),gc);//Morning
			
			gc.gridx = 1;
			gc.gridy = 0;
			pnlRow6_Time.add(checkboxes_times.get(1),gc);//Before Noon
			
			gc.gridx = 2;
			gc.gridy = 0;
			gc.insets = new Insets(10,15,10,10);
			pnlRow6_Time.add(checkboxes_times.get(2),gc);//Afternoon
			
			gc.gridx = 3;
			gc.gridy = 0;
			gc.insets = new Insets(10,10,10,10);
			pnlRow6_Time.add(checkboxes_times.get(3),gc);//Evening
			
			
		////Row 1///
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,5,5,5);
		panel.add(pnlRow1_Name, gc);
		
		////Row 2///
		gc.gridx = 0;
		gc.gridy = 2;
		gc.insets = new Insets(5,5,5,5);
		panel.add(pnlRow2_Size, gc);
		
		////Row 3///
		gc.gridx = 0;
		gc.gridy = 3;
		gc.insets = new Insets(5,5,5,5);
		panel.add(pnlRow3_ID, gc);
		
		////Row 4///
		gc.gridx = 0;
		gc.gridy = 4;
		gc.insets = new Insets(5,5,5,5);
		panel.add(pnlRow4_Level, gc);
		
		////Row 5///
		gc.gridx = 0;
		gc.gridy = 5;
		gc.insets = new Insets(5,5,5,5);
		panel.add(pnlRow5_Days, gc);
		
		////Row 6///
		gc.gridx = 0;
		gc.gridy = 6;
		gc.insets = new Insets(5,5,5,5);
		panel.add(pnlRow6_Time, gc);

		
		////Row 10///
		gc.gridx = 0;
		gc.gridy = 11;
		gc.gridwidth = 4;
		gc.insets = new Insets(20,0,10,0);
		gc.fill = GridBagConstraints.HORIZONTAL;
		panel.add(btnPanel, gc);
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
		container.setBorder(border);
		
	}
	

}