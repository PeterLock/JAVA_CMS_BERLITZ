import java.sql.SQLException;

import customer.model.Customer;
import customer.model.Database;
import customer.model.MonthCategory;

public class TestDatabase {

	public static void main(String[] args) {
		System.out.println("Running database test");
		
		Database db = new Database();
		try {
			db.connect();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		db.addCustomer(new Customer("Amy", "Smith", MonthCategory.April, "Swimming", "NBE-7", new Integer(54321), new Integer(5),new Integer(5), new Integer(5), new Integer(5), new Integer(5), "12", "Basketball", "Outgoing personality"));
		db.addCustomer(new Customer("Kate", "Smiles", MonthCategory.April, "Jogging", "NBE-1", new Integer(99999), new Integer(5),new Integer(5), new Integer(5), new Integer(5), new Integer(5), "12", "Playing cards", "A little shy"));
		db.addCustomer(new Customer("Andy", "Rand", MonthCategory.April, "Pathways", "NBE-3", new Integer(22322), new Integer(5),new Integer(5), new Integer(5), new Integer(5), new Integer(5), "12", "Riding", "Very talkative"));

		
		
		try {
			db.save();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			db.load();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		db.disconnect();
	}

}
