package control.gui;

public interface ToolbarListener {
	public void saveEventOccurred();
	public void refreshEventOccurred();
}
