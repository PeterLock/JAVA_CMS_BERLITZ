package control.gui;

import java.util.EventListener;

import customer.gui.FormEvent;

public interface FormListener extends EventListener{
	public void formEventOccurred(FormEvent e);
}
