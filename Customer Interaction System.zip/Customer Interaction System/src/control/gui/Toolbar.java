package control.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToolBar;

import settings.UI_Settings;

public class Toolbar extends JToolBar implements ActionListener {


	private static final long serialVersionUID = 1L;
	private JButton refreshButton;
	private JButton saveButton;
	private JButton addButton;
	private JButton importButton;
	private JButton openButton;
	private JButton searchButton;
	private JButton openMicrosoftDocumentButton;
	private JButton databaseErrorButton;
	private JButton openExcelButton;
	private JButton openWordButton;
	private JButton bargraphsButton;
	private JButton makePresentationButton;
	private JButton openCalendarButton;
	private JButton lockButton;
	private JButton printButton;
	private JButton mailButton;
	
	private ToolbarListener listener;
	
	private Color toolBarColor;
	
	private UI_Settings UI = new UI_Settings();
	
	public Toolbar(){
		setFloatable(false);
		
		toolBarColor = UI.getToolBarColor();
		
		
		this.setBackground(UI.getToolBarColor());
		this.setPreferredSize(new Dimension(700, UI_Settings.getToolbarHeight()));

		refreshButton = new JButton();
		refreshButton.setIcon(createIcon("/icons_g/database_plus.png"));
		refreshButton.setBackground(toolBarColor);
		refreshButton.setMargin(new Insets(5,0,0,0));
		refreshButton.setOpaque(true);
		refreshButton.setBorderPainted(false);
		refreshButton.setToolTipText("Reload Database");
		refreshButton.addActionListener(this);
		
		saveButton = new JButton();
		saveButton.setIcon(createIcon("/icons_g/database_insert.png"));
		saveButton.setBackground(toolBarColor);
		saveButton.setMargin(new Insets(5,0,0,0));
		saveButton.setOpaque(true);
		saveButton.setBorderPainted(false);
		saveButton.setToolTipText("Save Database");
		saveButton.addActionListener(this);
		
		
		addButton = new JButton();
		addButton.setIcon(createIcon("/icons_g/application_plus.png"));
		addButton.setBackground(toolBarColor);
		addButton.setMargin(new Insets(5,2,0,0));
		addButton.setOpaque(true);
		addButton.setBorderPainted(false);
		addButton.setToolTipText("Add Student");
		addButton.addActionListener(this);

		
		importButton = new JButton();
		importButton.setIcon(createIcon("/icons_g/table_import.png"));
		importButton.setBackground(toolBarColor);
		importButton.setMargin(new Insets(5,0,0,0));
		importButton.setOpaque(true);
		importButton.setBorderPainted(false);
		importButton.setToolTipText("Import Database");
		importButton.addActionListener(this);

		
		openButton = new JButton();
		openButton.setIcon(createIcon("/icons_g/folder_horizontal_open.png"));
		openButton.setBackground(toolBarColor);
		openButton.setMargin(new Insets(5,25,0,0));
		openButton.setOpaque(true);
		openButton.setBorderPainted(false);
		openButton.setToolTipText("Open File");
		openButton.addActionListener(this);

		
		searchButton = new JButton();
		searchButton.setIcon(createIcon("/icons_g/magnifier_left.png"));
		searchButton.setBackground(toolBarColor);
		searchButton.setMargin(new Insets(5,0,0,0));
		searchButton.setOpaque(true);
		searchButton.setBorderPainted(false);
		searchButton.setToolTipText("Search Database");
		searchButton.addActionListener(this);

		
		openMicrosoftDocumentButton = new JButton();
		openMicrosoftDocumentButton.setIcon(createIcon("/icons_g/document_office_text.png"));
		openMicrosoftDocumentButton.setBackground(toolBarColor);
		openMicrosoftDocumentButton.setMargin(new Insets(5,0,0,0));
		openMicrosoftDocumentButton.setOpaque(true);
		openMicrosoftDocumentButton.setBorderPainted(false);
		openMicrosoftDocumentButton.setToolTipText("Open Microsoft Document");
		openMicrosoftDocumentButton.addActionListener(this);

		
		databaseErrorButton = new JButton();
		databaseErrorButton.setIcon(createIcon("/icons_g/database_exclamation.png"));
		databaseErrorButton.setBackground(toolBarColor);
		databaseErrorButton.setMargin(new Insets(5,0,0,0));
		databaseErrorButton.setOpaque(true);
		databaseErrorButton.setBorderPainted(false);
		databaseErrorButton.setToolTipText("Database Error");
		databaseErrorButton.addActionListener(this);

		
		openExcelButton = new JButton();
		openExcelButton.setIcon(createIcon("/icons_g/document_excel.png"));
		openExcelButton.setBackground(toolBarColor);
		openExcelButton.setMargin(new Insets(5,25,0,0));
		openExcelButton.setOpaque(true);
		openExcelButton.setBorderPainted(false);
		openExcelButton.setToolTipText("Open Excel");
		openExcelButton.addActionListener(this);

		
		openWordButton = new JButton();
		openWordButton.setIcon(createIcon("/icons_g/document_word.png"));
		openWordButton.setBackground(toolBarColor);
		openWordButton.setMargin(new Insets(7,0,2,0));
		openWordButton.setOpaque(true);
		openWordButton.setBorderPainted(false);
		openWordButton.setToolTipText("Open Word");
		openWordButton.addActionListener(this);

		
		bargraphsButton = new JButton();
		bargraphsButton.setIcon(createIcon("/icons_g/chart_up.png"));
		bargraphsButton.setBackground(toolBarColor);
		bargraphsButton.setMargin(new Insets(7,25,0,0));
		bargraphsButton.setOpaque(true);
		bargraphsButton.setBorderPainted(false);
		bargraphsButton.setToolTipText("Show Charts");
		bargraphsButton.addActionListener(this);

		
		makePresentationButton = new JButton();
		makePresentationButton.setIcon(createIcon("/icons_g/projection_screen_presentation.png"));
		makePresentationButton.setBackground(toolBarColor);
		makePresentationButton.setMargin(new Insets(7,0,0,0));
		makePresentationButton.setOpaque(true);
		makePresentationButton.setBorderPainted(false);
		makePresentationButton.setToolTipText("Make a Presentation");
		makePresentationButton.addActionListener(this);

		
		openCalendarButton = new JButton();
		openCalendarButton.setIcon(createIcon("/icons_g/calendar.png"));
		openCalendarButton.setBackground(toolBarColor);
		openCalendarButton.setMargin(new Insets(7,0,0,0));
		openCalendarButton.setOpaque(true);
		openCalendarButton.setBorderPainted(false);
		openCalendarButton.setToolTipText("Open Calendar");
		openCalendarButton.addActionListener(this);
		
		/******************************************************Right side menu items*****************************************************/
		lockButton = new JButton();
		lockButton.setIcon(createIcon("/icons_g/lock.png"));
		lockButton.setBackground(toolBarColor);
		lockButton.setMargin(new Insets(7,0,2,0));
		lockButton.setOpaque(true);
		lockButton.setBorderPainted(false);
		lockButton.setToolTipText("Lock");
		lockButton.addActionListener(this);

		
		printButton = new JButton();
		printButton.setIcon(createIcon("/icons_c/printer.png"));
		printButton.setBackground(toolBarColor);
		printButton.setMargin(new Insets(7,0,2,0));
		printButton.setOpaque(true);
		printButton.setBorderPainted(false);
		printButton.setToolTipText("Print");
		printButton.addActionListener(this);

		
		mailButton = new JButton();
		mailButton.setIcon(createIcon("/icons_c/mail.png"));
		mailButton.setBackground(toolBarColor);
		mailButton.setMargin(new Insets(7,0,2,0));
		mailButton.setOpaque(true);
		mailButton.setBorderPainted(false);
		mailButton.setToolTipText("Mail");
		mailButton.addActionListener(this);

		
		
		add(refreshButton);
		add(saveButton);
		add(addButton);
		add(importButton);
		add(openButton);
		add(searchButton);
		add(openMicrosoftDocumentButton);
		add(databaseErrorButton);
		add(openExcelButton);
		add(openWordButton);
		add(bargraphsButton);
		add(makePresentationButton);
		add(openCalendarButton);
        add(Box.createHorizontalGlue());
        add(lockButton);
		add(printButton);
		add(mailButton);

	}

	
	private ImageIcon createIcon(String path){
		URL url = getClass().getResource(path);
		
		if(url == null){
			System.out.println("Unable to load image: " + path);
		}
		
		ImageIcon icon = new ImageIcon(url);
		
		Image img = icon.getImage();
		Image newimg = img.getScaledInstance(16, 16, java.awt.Image.SCALE_SMOOTH);
		
		icon=new ImageIcon(newimg);
		

		return icon;
	}
	
	public void setToolbarListener(ToolbarListener listener){
		this.listener = listener;
	}


	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		JButton clicked = new JButton();
		clicked = (JButton)e.getSource();
		
		
		if(clicked == refreshButton){
			if(listener != null){
				listener.refreshEventOccurred();
			}
		}
		if(clicked == saveButton){
			if(listener != null){
				listener.saveEventOccurred();
				System.out.println("Saveclicked in Toobar.java");
			}
		}
		if(clicked == addButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}		
		if(clicked == importButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}		
		if(clicked == openButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}
		if(clicked == searchButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}	
		if(clicked == openMicrosoftDocumentButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}		
		if(clicked == databaseErrorButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}	
		if(clicked == openExcelButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}	
		if(clicked == openWordButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}		
		if(clicked == bargraphsButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}		
		if(clicked == makePresentationButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}		
		if(clicked == openCalendarButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}
		
		if(clicked == lockButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}	
		if(clicked == printButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}			
		if(clicked == mailButton){
			if(listener != null){
				//listener.saveEventOccurred();
			}
		}		
	}
	
	public void setToolBarColor(Color c){
		
		this.setBackground(c);
		this.toolBarColor = c;
		
		refreshButton.setBackground(c);
		saveButton.setBackground(c);
		addButton.setBackground(c);
		importButton.setBackground(c);
		openButton.setBackground(c);
		searchButton.setBackground(c);
		openMicrosoftDocumentButton.setBackground(c);
		databaseErrorButton.setBackground(c);
		openExcelButton.setBackground(c);
		openWordButton.setBackground(c);
		bargraphsButton.setBackground(c);
		makePresentationButton.setBackground(c);
		openCalendarButton.setBackground(c);
		lockButton.setBackground(c);
		printButton.setBackground(c);
		mailButton.setBackground(c);

		repaint();
		
	}


	public void sayhello() {
		System.out.println("Hello");
	}
}
