package control.gui;

public interface SectionListener {

	void setFormListener(FormListener formListener);

}
