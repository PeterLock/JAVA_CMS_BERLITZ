package control.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.event.MouseWheelListener;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import customer.gui.CustomerTableModel;
import settings.TableNoData;
import settings.UI_Settings;


public class TableTemplate extends JPanel{

	private  TableModel tv = null;
	private static ArrayList<Integer> emptypercentages = new ArrayList<>(Arrays.asList( 25, 25, 25, 25));
	private boolean NEED_HEADER = false;
	private String tableTabData = "";
	private JTable table;
	private JScrollPane scroller;

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public TableTemplate(){
		/* TableTemplate constructor without arguments will create an
		 * empty table with columns widths set to 0.
		 */
		TableNoData tableNoData = new TableNoData();
		tv = tableNoData;
		setLayout(new BorderLayout());
		makeUI(emptypercentages);
		
	}

	public TableTemplate(TableModel data, ArrayList<Integer> tablepercentages, String header){
		/*Test whether both arguments passed are null. If an argument is null makes an empty table*/
		if((data ==null) || (tablepercentages == null)){
			
			TableNoData tableNoData = new TableNoData();
			tv = tableNoData;
			setLayout(new BorderLayout());
			makeUI(tablepercentages);
			
		} else{
			if(header != "") {
				NEED_HEADER = true;
				tableTabData = header;

			}
			
			tv = data;
			setLayout(new BorderLayout());
			makeUI(tablepercentages);

			
		}
	}
	public TableTemplate(CustomerTableModel tableModel) {
		tv = tableModel;
	}

	private JTable makeTable(){

		/***************************************Data Model***********************************************/
		table = new JTable(tv);

		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.setSelectionBackground(UI_Settings.getTableSelectedRowColor());
		table.setFont(UI_Settings.getTableFont());
		table.setFillsViewportHeight(true);
		table.setRowHeight(UI_Settings.getTableRowHeight());
		table.setRowSelectionInterval(0, 0);
		table.setDefaultEditor(Boolean.class, new MyBooleanEditor());
		
		
		//Add the CellRenderer to each Column in the Table
		for(int i = 0; i < tv.getColumnCount(); i++){
			TableColumnModel tcm = table.getColumnModel();
			TableColumn tc = tcm.getColumn(i);
			//Make sure its not of type Boolean before passing it to the setCellRenderer method. 
			if(table.getColumnClass(i) != Boolean.class){
				tc.setCellRenderer(new CellRenderer());
			}
		}

		return table;
	}
	
	public void setRowSelected(int start,int end){
		table.setRowSelectionInterval(start, end);
	}
		
	public void makeUI(ArrayList<Integer> tablepercentages){
		JPanel panel = new JPanel(new BorderLayout());
		panel.setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 200);
		panel.setBorder(BorderFactory.createEmptyBorder());
		
		/* Check to see whether a header tab is needed for the table.
		 * If one is needed, create it and add it to the top of the panel.
		 */
		if(NEED_HEADER == true){
			
			JLabel headerLabel = new JLabel(tableTabData);
			
			headerLabel.setBackground(UI_Settings.getTableTitleColor());
			headerLabel.setFont(UI_Settings.getTableFont());
			headerLabel.setPreferredSize(new Dimension(headerLabel.getPreferredSize().width+UI_Settings.getTableTabtextInnerLeftrightPadding(),UI_Settings.getTableTitleHeight()));
			headerLabel.setHorizontalAlignment(SwingConstants.CENTER);
			headerLabel.setBorder(BorderFactory.createCompoundBorder(UI_Settings.getTableTitleBorder(), UI_Settings.getBorderpadding()));
			headerLabel.setOpaque(true);
			headerLabel.setLayout(new BorderLayout());
			JPanel viewallTableHeader = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
			viewallTableHeader.setBackground(UI_Settings.getButtonPanelColor());
			viewallTableHeader.add(headerLabel);
			
			panel.add(viewallTableHeader, BorderLayout.NORTH);
		} 
		
		
		HeaderRenderer headerRender = new HeaderRenderer();
        headerRender.setHorizontalAlignment(JLabel.CENTER);

		JTable table = makeTable();
		
		table.setGridColor(UI_Settings.getTableGridLineColor());
		table.getTableHeader().setBorder( BorderFactory.createEmptyBorder());
		table.setShowGrid(true);
		

		//Loop through the columns and add the custom HEADER RENDERER
		for(int i = 0; i < table.getColumnCount(); i++){
			table.getColumnModel().getColumn(i).setHeaderRenderer(headerRender);
			headerRender.setBackground(UI_Settings.getTableHeaderColor());
			headerRender.setForeground(Color.WHITE);			
		}
		
		setJTableColumnsWidth(table, UI_Settings.getMinimumScreenSize().width, tablepercentages);
		
		scroller = new JScrollPane(table);
		
		//Needed to fill the corner component space above the JScrollPane
        JLabel cornerComponent = new JLabel("");
        cornerComponent.setBackground(UI_Settings.getTableHeaderColor());
        cornerComponent.setForeground(Color.WHITE);
    	MatteBorder matte = new MatteBorder(0, 0, 1, 1, Color.WHITE);

        cornerComponent.setBorder(matte);
        cornerComponent.setHorizontalAlignment(0);
        cornerComponent.setOpaque(true);
        scroller.setCorner(JScrollPane.UPPER_TRAILING_CORNER, cornerComponent);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		scroller.setColumnHeader(new JViewport(){

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override public Dimension getPreferredSize(){
			Dimension d = super.getPreferredSize();
			d.height = UI_Settings.getTableHeaderHeight();
			return d;
			}
		});
		////////////////////////Remove the mouseWheelListener for the table////////////////////////
		for (MouseWheelListener mwl : scroller.getMouseWheelListeners()) {
			scroller.removeMouseWheelListener(mwl);
		}
		
	    panel.add(scroller);
		
		JPanel canvas = new JPanel(new BorderLayout());
		canvas.add(panel);
		
		canvas.setBorder(BorderFactory.createEmptyBorder());
		add(canvas);
	}    
	
	public static void main(String[] args){
		EventQueue.invokeLater(new Runnable(){
			@Override public void run(){
				createAndShowGUI();
			}
		});
	}
	
	public static void setJTableColumnsWidth(JTable table, int tablePreferredWidth, ArrayList<Integer> tablepercentages) {
	    double total = 0;
	    for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
	        total += tablepercentages.get(i);
	    }
	 
	    for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
	        TableColumn column = table.getColumnModel().getColumn(i);
	        column.setPreferredWidth((int)
	                (tablePreferredWidth * (tablepercentages.get(i) / total)));
	    }
	}
	
	public void showScrollBar(Boolean value){
		if(value == true) scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
	}

		
	public static void createAndShowGUI() {
		JPanel panel = new JPanel(new BorderLayout());
        panel.add(new TableTemplate(), BorderLayout.CENTER);
        JFrame frame = new JFrame("CMS Test Screen");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
		frame.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 200));
		frame.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 200));

        frame.pack();
        frame.setVisible(true);
    }

	/*******************************************************************Cell Renderer************************************************/

  public class CellRenderer extends DefaultTableCellRenderer {

    /**
	 * 
	 */
		private static final long serialVersionUID = 1L;

		@Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setBorder(noFocusBorder);
            
            JLabel cellSpacingLabel = (JLabel) (this);
            
            if (hasFocus) {
            	 setBorder(noFocusBorder);
                 //setBorder(new LineBorder(UI_Settings.getTableSelectedRowColor()));
            }
            else{
        	    setBackground(table.getBackground());
            }

             if (isSelected) {     
                setBackground(table.getSelectionBackground());
            }
            else{
                setBackground(table.getBackground());
            }

             if ((cellSpacingLabel != null) && (value instanceof Integer == false) && (value instanceof Boolean == false)) {
                cellSpacingLabel.setBorder(new CompoundBorder(new EmptyBorder(new Insets(0, 16, 0, 0)), cellSpacingLabel.getBorder()));
            }
             
             if(value instanceof Integer){
            	 cellSpacingLabel.setHorizontalAlignment(0);
             }
            this.setOpaque(true);
            return this;
        }
    }

	public int getRowCount() {
		return table.getRowCount();
	}

	public Object getValueAt(int i, int j) {
		return table.getValueAt(i, j);
	}

	public void setRowSelectionAllowed(boolean value) {
		table.setRowSelectionAllowed(value);
	}

	public void setColumnSelectionAllowed(boolean value) {
		table.setColumnSelectionAllowed(value);
	}

	public void setCellSelection(boolean value) {
		table.setCellSelectionEnabled(value);
	}

	public int getSelectedRow() {
		return table.getSelectedRow();
	}

	public int getSelectedColumn() {
		return table.getSelectedColumn();
	}

	public TableModel getModel() {
		return tv;
	}

	public int getColumnCount() {
		return table.getColumnCount();
	}
}
/*******************************************************************Header Renderer************************************************/

 class HeaderRenderer extends JLabel implements TableCellRenderer{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Color fgColor = UIManager.getColor("TableHeader.foreground");
	private Color bgColor = UIManager.getColor("TableHeaader.background");
	
	public HeaderRenderer(){
		setOpaque(true);
	}
	
	public void setForegroundColor(Color fgColor){
		this.fgColor = fgColor;
	}
	
	public Color getForegroundColor(){
		return fgColor;
	}
	
	public void setBackgroundColor(Color bgColor){
		this.bgColor = bgColor;
	}
	
	public Color getBackgroundColor(){
		return bgColor;
	}

	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
			int row, int column) {
		
		JLabel label = this;
		label.setText((value == null)? "":(""+value.toString()));
		label.setMinimumSize(label.getPreferredSize());
		label.setPreferredSize(label.getPreferredSize());

    	MatteBorder matte = new MatteBorder(0, 0, 1, 1, Color.WHITE);
    	label.setBorder(matte);

		
		
		label.setFont(UI_Settings.getComponentsFontPlain());
		return label;
	}
}
 
 class MyBooleanEditor extends DefaultCellEditor
 {
     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	private JCheckBox checkBox;
	 
	public MyBooleanEditor()
     {
         super(new JCheckBox());
         checkBox = (JCheckBox)getComponent();
         checkBox.setHorizontalAlignment(JCheckBox.CENTER);

     }
  
     @Override
     public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
     {
    	 
    	 //System.out.println("In cell editor column is: " + column);
         for(int i = 1; i < table.getColumnCount(); i++){
        	 
         	if(i == column){
         		checkBox.setSelected(true);
         	}else{
         		table.setValueAt(false, row, i);
         		checkBox.setSelected(false);
         	}
         	 
          }
         
         Component c = super.getTableCellEditorComponent(table, value, isSelected, row, column);
         c.setBackground( table.getSelectionBackground() );
         
  
         
         return c;
     }
     
 }