package gui.reports.com;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_ReportsAdded extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int REPORT_ID = 0;
	public final static int CUSTOMER_NAME = 1;
	public final static int REPORT_TYPE = 2;
	public final static int REPORT_DATE = 3;
	public final static int COURSE_PROGRAM = 4;
	public final static int LEVEL = 5;
	public final static int LESSON_TYPE = 6;
	
	
	public Object[][]values =
		{
				{new Integer(12324), "Penny McBoatFace", "Progress", "November 2015", "Reading Explorer", new Integer(1), "Private"},
				{"", "", "", "", "", "", ""},
				{"", "", "", "", "", "", ""},
				{"", "", "", "", "", "", ""},
				{"", "", "", "", "", "", ""},
				{"", "", "", "", "", "", ""}
		};
	
	public final static String[] COLUMN_NAMES = {"Report ID", "Customer Name", 
		"Report Type", "Report Date", "Course/Program", "Level", "Lesson Type"};

	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}
	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList(15, 12, 8, 10, 10, 10, 15));

}
