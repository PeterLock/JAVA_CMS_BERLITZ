package group.model;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import customer.model.Customer;
import customer.model.MonthCategory;



public class Database {
	
	private JFrame controllingFrame; 

	private List<Group> group_list = new ArrayList<Group>();
	private List<Group> loaded_group_list = new ArrayList<Group>();
	private int flag = 0; //Test for database connection - if set to 1 it will not try to connect, load, or save//

	private List<Customer> addnew_customers;
	private List<Customer> viewall_customers;

	private int setNumberOfRows = 0;
	private int setViewAllRowNumber = 0;
	
	private int setAddCustomerRowNumber = 4;
	private int setViewAllCustomerRowNumber = 0;
	
	private int count = 0;
	private Connection con;
	
	public Database(){
		viewall_customers = new ArrayList<Customer>();
		addnew_customers = new ArrayList<Customer>();
	}
	
	public void connect() throws Exception{
		
		if(con != null)return;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new Exception("Driver not found");
		}
		

		String url = "jdbc:mysql://localhost:3306/CIS_DB?autoReconnect=true&useSSL=false";
		
		con = DriverManager.getConnection(url, "root", "password");
		
		System.out.println("Connected: " + con.getCatalog());
		
	}
	
	public void disconnect(){
		if(con != null){
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println("Can't close the connection");
			}
		}
	}
	
	public void save() throws SQLException{
		System.out.println("Group DB Save method invoked");
		String checkSql = "select count(*) as count from groups where ID=?";
		PreparedStatement checkStmt = con.prepareStatement(checkSql);
		
		String insertSql = "insert into groups (id, name, material, level, class_size, max_class_size, day, time) values (?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement insertStatement = con.prepareStatement(insertSql);
		

		String updateSql = "update groups set name=?, material=?, level=?, class_size=?, max_class_size=?, day=?, time=? where id=?";
		PreparedStatement updateStatement = con.prepareStatement(updateSql);
		
		for(Group groups : group_list){
			
			int t = groups.getId();
			if(t > 0){
				
				int id = groups.getId();
				String groupName = groups.getGroupName();
				String material = groups.getGroupMaterial();
				String level = groups.getLevel();
				String class_size = groups.getCurrentClassSize();
				String max_class_size = groups.getMaxClassSize();
				String day = groups.getDay();
				String time = groups.getTime();
				
				checkStmt.setInt(1, id);
				
				ResultSet checkResult = checkStmt.executeQuery();
				checkResult.next();
				
				int count = checkResult.getInt(1);
				
				
				if(count == 0){
					System.out.println("Inserting group with ID " + id);
					
					int col = 1;

					insertStatement.setInt(col++, id);
					insertStatement.setString(col++, groupName);
					insertStatement.setString(col++, material);
					insertStatement.setString(col++, level);
					insertStatement.setString(col++, class_size);
					insertStatement.setString(col++, max_class_size);
					insertStatement.setString(col++, day);
					insertStatement.setString(col++, time);

					insertStatement.executeUpdate();

				}
				else{
					System.out.println("Updating customer with ID " + id);
					
					int col = 1;
					
					updateStatement.setString(col++, groupName);
					updateStatement.setString(col++, material);
					updateStatement.setString(col++, level);
					updateStatement.setString(col++, class_size);
					updateStatement.setString(col++, max_class_size);
					updateStatement.setString(col++, day);
					updateStatement.setString(col++, time);
					
					updateStatement.setInt(col++, id);
					
					updateStatement.executeUpdate();
				}
			}
		}
		updateStatement.close();
		insertStatement.close();
		checkStmt.close();
		
	}
	
	public void load() throws SQLException{
		
		loaded_group_list.clear();

		String sql = "select id, name, material, level, class_size, max_class_size, day, time from groups order by name";
		Statement selectStatement = con.createStatement();
		
		ResultSet results = selectStatement.executeQuery(sql);
		
		while(results.next()){
			int id = results.getInt("id");
			String groupName = results.getString("name");
			String groupMaterial = results.getString("material");
			String level = results.getString("level");
			String class_size = results.getString("class_size");
			String max_class_size = results.getString("max_class_size");
			String day = results.getString("day");
			String time = results.getString("time");
			
			Group group = new Group(groupName, groupMaterial, level, day, time, class_size, max_class_size, id);
			
			loaded_group_list.add(group);
		}
		
		results.close();
		selectStatement.close();
		
	}

	public void addEmptyGroup(Group group) {
		
		if(this.group_list.size()==setNumberOfRows){
			this.group_list.add(0, group);
			this.group_list.remove(this.group_list.get(this.getEmptyGroup().size()-1));
		}else{
			if(count >setNumberOfRows){
				this.group_list.add(0, group);
			}else{
				this.group_list.add(0, group);
				count++;	
			}
		}
	}
	
	public void printGroup(){
		
		for(int i=0; i< loaded_group_list.size(); i++){
			System.out.println("Group Name2: " + loaded_group_list.get(i).getGroupName() + " Group ID: " + loaded_group_list.get(i).getId() + ".");
		}
		
	}
	
	public void saveToFile(File file) throws IOException{
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		Group[] groups = this.group_list.toArray(new Group[this.group_list.size()]);
		
		oos.writeObject(groups);
		
		fos.close();
		oos.close();
		
	}
	
	public void loadFromFile(File file) throws IOException {
		
	}

	public void removeGroup(int index) {
		if(index <0){
			return;
		}else{
			int remove_id = group_list.get(index).getId();
			
			group_list.remove(index);

			populateRemainingRows(group_list, setNumberOfRows);
			
			delete(remove_id);
			
			try {
				this.save();
			} catch (SQLException e) {
				System.err.println("Unable to save groups to DB");
				e.printStackTrace();
			}

		}		
	}
	
	private void delete(int remove_id) {
		 try 
		 {  
			PreparedStatement statement = con.prepareStatement("DELETE FROM Groups WHERE id = ?");
			statement.setInt(1,remove_id);
			statement.executeUpdate(); 
			
			System.err.println("Exiting delete try/catch");

		 }
		 catch(Exception e)
		 {
		     System.out.println("An error deleting this record has been found.");
		 }
		 
	}

	public void setAddNewRowNumber(int i) {
		setNumberOfRows = i;
	}

	public List<Group> getGroup() {
		return loaded_group_list;
	}
	
	public List<Group> getEmptyGroup() {
		return group_list;
	}
	
	public void populateRemainingRows(List<Group> data, int j) {
		
       	for(int i = data.size()+1; i <=j; i++){
       		data.add(new Group("", "", "", "", "", "","", 0));
    	}
	}

	public String getName() {
		return "CIS_DB";
	}

	public Group searchGroup(String groupName) throws SQLException {
		
		Group group = null;
		
		try {
			connect();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(controllingFrame,
				    "Cannot connect to the database",
				    "Warning",
				    JOptionPane.ERROR_MESSAGE);	
			e.printStackTrace();
		}
		
		
		PreparedStatement pstmt;
		ResultSet results;


		if(con == null)return null;

		pstmt = this.con.prepareStatement("SELECT * FROM Groups WHERE name=?");
		
		pstmt.setString(1, groupName);

		
		results = pstmt.executeQuery();
		
		while(results.next()){
			int id = results.getInt("id");
			String name = results.getString("name");
			String groupMaterial = results.getString("material");
			String level = results.getString("level");
			String class_size = results.getString("class_size");
			String max_class_size = results.getString("max_class_size");
			String day = results.getString("day");
			String time = results.getString("time");
			
			group = new Group(groupName, groupMaterial, level, day, time, class_size, max_class_size, id);
		}
		
	return group;
	}

	public void deleteGroup(JComboBox<String> cmbGroupNameListCombobox, int i, String groupName) {
		
		if(groupName == null || groupName == "" || groupName.isEmpty()){
			return;
		}else{
			 try 
			 {  
				PreparedStatement statement = con.prepareStatement("DELETE FROM Groups WHERE name = ?");
				statement.setString(1,groupName);
				statement.executeUpdate(); 
				
				JOptionPane.showMessageDialog(controllingFrame,
					    "Group Deleted",
					    "Deletion complete",
					    JOptionPane.INFORMATION_MESSAGE);	
			 }
			 catch(Exception e)
			 {
					JOptionPane.showMessageDialog(controllingFrame,
						    "Error deleting group",
						    "An error deleting this group has occurred. No information available",
						    JOptionPane.ERROR_MESSAGE);	
			 }
		}
		
	}
	
	///////////////////////////////////////////////////Methods for adding new customers from group panel //////////////////////////////////////
	public List<Customer>getCustomer(){
		return viewall_customers;
	}
	
	public List<Customer> getEmpty_customer() {
		return addnew_customers;
	}
	
	public void addCustomer(Customer customer){
		if(this.addnew_customers.size()==6){
			this.addnew_customers.add(0, customer);
			this.addnew_customers.remove(this.addnew_customers.get(this.getEmpty_customer().size()-1));
		}else{
			if(count >setAddCustomerRowNumber){
				this.addnew_customers.add(0, customer);
			}else{
				this.addnew_customers.add(0, customer);
				count++;	
			}
		}
	}
	
	public void addCustomerViewAllTable(Customer customer){
		if(this.viewall_customers.size()==setAddCustomerRowNumber){
			this.viewall_customers.add(0, customer);
			this.viewall_customers.remove(this.viewall_customers.get(this.getCustomer().size()-1));
		}else{
			if(count >setAddCustomerRowNumber){
				this.viewall_customers.add(0, customer);
			}else{
				this.viewall_customers.add(0, customer);
				count++;	
			}
		}
	}
	
	public void saveNewCustomer() throws SQLException{
		
		if(flag == 1)return;
		
		String checkSql = "select count(*) as count from customers where ID=?";
		PreparedStatement checkStmt = con.prepareStatement(checkSql);
		
		String insertSql = "insert into customers (id, firstName, lastName, month, material, level, age, listening, speaking, reading, participation, cooperation, interests, comments) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement insertStatement = con.prepareStatement(insertSql);
		
		String updateSql = "update customers set firstName=?, lastName=?, month=?, material=?, level=?, age=?, listening=?, speaking=?, reading=?, participation=?, cooperation=?, interests=?, comments=? where id=?";
		PreparedStatement updateStatement = con.prepareStatement(updateSql);
		
		for(Customer customer : addnew_customers){
			
			int t = customer.getId();
			if(t > 0){
				
				int id = customer.getId();

				String firstName = customer.getFirstname();
				
				String lastName = customer.getLastname();
				MonthCategory month = customer.getMonthCategory();
				String material = customer.getMaterial();
				String level = customer.getLevel();
				String age = customer.getAge();
				int listening = customer.getListening();
				int speaking = customer.getSpeaking();
				int reading = customer.getReading();
				int participation = customer.getParticipation();
				int cooperation = customer.getCooperation();
				String interests = customer.getInterests();
				String comments = customer.getComments();
				
				checkStmt.setInt(1, id);
				
				ResultSet checkResult = checkStmt.executeQuery();
				checkResult.next();
				
				int count = checkResult.getInt(1);
				
				
				if(count == 0){
					System.out.println("Inserting customer with ID " + id);
					
					int col = 1;
					
					insertStatement.setInt(col++, id);
					insertStatement.setString(col++, firstName);
					insertStatement.setString(col++, lastName);
					
					if(month == null){
						insertStatement.setString(col++, "");//Month is null - save empty space
					}else{
						insertStatement.setString(col++, month.name());//IF NULL PRODUCES AN ERROR AND DOESNT DAVE TO DB
					}
					insertStatement.setString(col++, material);
					insertStatement.setString(col++, level);
					insertStatement.setString(col++, age);
					insertStatement.setInt(col++, listening);
					insertStatement.setInt(col++, speaking);
					insertStatement.setInt(col++, reading);
					insertStatement.setInt(col++, participation);
					insertStatement.setInt(col++, cooperation);
					insertStatement.setString(col++, interests);
					insertStatement.setString(col++, comments);
					
					insertStatement.executeUpdate();

				}
				else{
					System.out.println("Updating customer with ID " + id);
					
					int col = 1;
					
					System.out.println(month.name());
					
					updateStatement.setString(col++, firstName);
					updateStatement.setString(col++, lastName);
					updateStatement.setString(col++, month.name());
					updateStatement.setString(col++, material);
					updateStatement.setString(col++, level);
					updateStatement.setString(col++, age);
					updateStatement.setInt(col++, listening);
					updateStatement.setInt(col++, speaking);
					updateStatement.setInt(col++, reading);
					updateStatement.setInt(col++, participation);
					updateStatement.setInt(col++, cooperation);
					updateStatement.setString(col++, interests);
					updateStatement.setString(col++, comments);
					updateStatement.setInt(col++, id);
					
					updateStatement.executeUpdate();
				}
			}
		}
		updateStatement.close();
		insertStatement.close();
		checkStmt.close();
	}
	
	public void removeCustomer(int index, int i){
		if(index <0){
			return;
		}else{
			if( i == 1){
				int remove_id = viewall_customers.get(index).getId();
				
				viewall_customers.remove(index);

				populateRemainingCustomerRows(viewall_customers, setViewAllRowNumber);
				
				delete(remove_id);
				
				try {
					this.save();
				} catch (SQLException e) {
					System.err.println("Unable to save database");
				}

			}
			if( i == 2){
				addnew_customers.remove(index);
				populateRemainingCustomerRows(addnew_customers, setNumberOfRows);			
			}
		}
	}
	
	public void populateRemainingCustomerRows(List<Customer> data, int j) {
       	for(int i = data.size()+1; i <=j; i++){
       		data.add(new Customer("", "", null, "", "", 0, 0,  0,  0,  0,  0,  "",  "", ""));
    	}
	}

	public void setAddNewCustomerRowNumber(int value) {
		setAddCustomerRowNumber = value;
	}
	
}
