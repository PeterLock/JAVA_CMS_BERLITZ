package material.gui;

import java.util.EventObject;

public class FormEvent extends EventObject {
	
	private static final long serialVersionUID = 1L;
	private String material_name;
	private String publisher_name;
	private String edition;
	private int num_levels;
	private int num_chapters;
	private String has_report;
	private String has_dvd;
	private String has_reader;
	private String has_test;
	private String test_information;
	private String material_description;
	private String material_comments;
	private int id;
	
	public FormEvent(Object source) {
		super(source);
	}
	public FormEvent(Object source, String material_name, String publisher_name, String edition,
			int num_levels, int num_chapters, String has_report, String has_dvd, String has_reader,
			String has_test, String test_information, String material_description, String material_comments,
			int id) {
		super(source);
		
	
		this.material_name = material_name;
		this.publisher_name = publisher_name;
		this.edition = edition;
		this.num_levels = num_levels;
		this.num_chapters = num_chapters;
		this.has_report = has_report;
		this.has_dvd = has_dvd;
		this.has_reader = has_reader;
		this.has_test = has_test;
		this.test_information = test_information;
		this.material_description = material_description;
		this.material_comments = material_comments;
		this.id = id;
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMaterial_name() {
		return material_name;
	}
	public void setMaterial_name(String material_name) {
		this.material_name = material_name;
	}
	public String getPublisher_name() {
		return publisher_name;
	}
	public void setPublisher_name(String publisher_name) {
		this.publisher_name = publisher_name;
	}
	public String getEdition() {
		return edition;
	}
	public void setEdition(String edition) {
		this.edition = edition;
	}
	public int getNum_levels() {
		return num_levels;
	}
	public void setNum_levels(int num_levels) {
		this.num_levels = num_levels;
	}
	public int getNum_chapters() {
		return num_chapters;
	}
	public void setNum_chapters(int num_chapters) {
		this.num_chapters = num_chapters;
	}
	public String getHas_report() {
		return has_report;
	}
	public void setHas_report(String has_report) {
		this.has_report = has_report;
	}
	public String getHas_dvd() {
		return has_dvd;
	}
	public void setHas_dvd(String has_dvd) {
		this.has_dvd = has_dvd;
	}
	public String getHas_reader() {
		return has_reader;
	}
	public void setHas_reader(String has_reader) {
		this.has_reader = has_reader;
	}
	public String getHas_test() {
		return has_test;
	}
	public void setHas_test(String has_test) {
		this.has_test = has_test;
	}
	public String getTest_information() {
		return test_information;
	}
	public void setTest_information(String test_information) {
		this.test_information = test_information;
	}
	public String getMaterial_description() {
		return material_description;
	}
	public void setMaterial_description(String material_description) {
		this.material_description = material_description;
	}
	public String getMaterial_comments() {
		return material_comments;
	}
	public void setMaterial_comments(String material_comments) {
		this.material_comments = material_comments;
	}


}
