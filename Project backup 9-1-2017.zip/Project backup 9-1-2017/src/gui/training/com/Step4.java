package gui.training.com;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import settings.UI_Settings;

public class Step4 extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel tipOneHeader;
	private JLabel tipTwoHeader;
	private JLabel previousStepTextButton = new JLabel("previous step");
	private JLabel nextStepTextButton = new JLabel("next step");
	private JLabel threeDots = new JLabel("...");
	private JLabel closeTips = new JLabel("close tips [x]");
	private int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;

	
	private JPanel rootpanel;
	private CreateTrainingSessionPanel sessionObject;
	
	public Step4(){
		
	}
	
	private void initialize(){
		addNextStepRow();
		initializeListeners();
	}
	
	public JPanel run(CreateTrainingSessionPanel sessionObject){
		
		this.sessionObject = sessionObject;
		
		rootpanel = new JPanel();
		rootpanel.setLayout(new BoxLayout(rootpanel, BoxLayout.Y_AXIS));
		rootpanel.setBackground(Color.GREEN);
		setPanelSize(rootpanel, new Dimension(new Dimension(screenWidth, 900)));
		
		
		initialize();
		
		return rootpanel;
		
	}
	
	private void initializeListeners() {
		
		nextStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		nextStepTextButton.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				JScrollPane scroller = sessionObject.getScroller();

				
				if(scroller != null){
					 scroller.getViewport().setViewPosition(new Point(0,0));
				 }
				
				 sessionObject.resetLocatorColors();
				 sessionObject.locator5.setBackground(CreateTrainingSessionPanel.LOCATOR_ACTIVE_COLOR);
				 CardLayout cl = (CardLayout)(sessionObject.cards.getLayout());
				 cl.show(sessionObject.cards, CreateTrainingSessionPanel.STEP5);
			}
		});
		
		
		previousStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		previousStepTextButton.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				JScrollPane scroller = sessionObject.getScroller();

				if(scroller != null){
					 scroller.getViewport().setViewPosition(new Point(0,0));
				 }
				
				 sessionObject.resetLocatorColors();
				 sessionObject.locator3.setBackground(CreateTrainingSessionPanel.LOCATOR_ACTIVE_COLOR);
				 CardLayout cl = (CardLayout)(sessionObject.cards.getLayout());
				 cl.show(sessionObject.cards, CreateTrainingSessionPanel.STEP3);
			}
			
		});
	}
	
	private void addNextStepRow() {
		
		nextStepTextButton.setFont(nextStepTextButton.getFont().deriveFont(12.0f));
		previousStepTextButton.setFont(previousStepTextButton.getFont().deriveFont(12.0f));

		nextStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());
		previousStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());


		JPanel container = new JPanel();
		container.setBackground(Color.WHITE);
		container.setLayout(new BoxLayout(container, BoxLayout.X_AXIS));
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(previousStepTextButton);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(nextStepTextButton);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		container.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		container.add(rightPanel);
		
		this.rootpanel.add(container);
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}

}
