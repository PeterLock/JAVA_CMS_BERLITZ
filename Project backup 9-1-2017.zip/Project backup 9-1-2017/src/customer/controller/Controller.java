package customer.controller;


import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import customer.gui.FormEvent;
import customer.model.Customer;
import customer.model.Database;
import customer.model.MonthCategory;

public class Controller {
	
	static Database db = new Database();
	
	public static List<Customer> getCustomer(int value){
		
		if(value == 1){
			return db.getCustomer();
		}else{
			return db.getEmpty_customer();
		}
		
	}
	
	public void removeCustomer(int index, int i){
		db.removeCustomer(index, i);
	}
	
	public void save() throws SQLException {
		db.save();
	}
	
	public void connect() throws Exception{
		db.connect();
	}
	
	public void load() throws SQLException{
		db.load();
	}
	
	public void close(){
		db.disconnect();
	}
	
	public void addCustomer(FormEvent ev){

		String firstname = ev.getFirstname();
		String lastname = ev.getLastname();
		int monthId = ev.getMonth();
		String material = ev.getMaterial();
		String level = ev.getLevel();
		int id = ev.getId();
		
		MonthCategory monthCategory = null;
		
		switch(monthId){
		
		case 1:
			monthCategory = MonthCategory.January;
			break;
		case 2:
			monthCategory = MonthCategory.February;
			break;
		case 3:
			monthCategory = MonthCategory.March;
			break;
		case 4:
			monthCategory = MonthCategory.April;
			break;
		case 5:
			monthCategory = MonthCategory.May;
			break;
		case 6:
			monthCategory = MonthCategory.June;
			break;
		case 7:
			monthCategory = MonthCategory.July;
			break;
		case 8:
			monthCategory = MonthCategory.August;
			break;
		case 9:
			monthCategory = MonthCategory.September;
			break;
		case 10:
			monthCategory = MonthCategory.October;
			break;
		case 11:
			monthCategory = MonthCategory.November;
			break;
		case 12:
			monthCategory = MonthCategory.December;
			break;
		default:
		
		}
		
		 int listen = ev.getListen();
		 int speak = ev.getSpeak();
		 int read = ev.getRead();
		 int par = ev.getParticipation();
		 int coop = ev.getCooperation();
		 String age = ev.getAge();
		 String interests = ev.getInterests();
		 String comments = ev.getComments();
		 
		
		Customer customer = new Customer(firstname, lastname, monthCategory, material,
			 level, id, listen, speak, read, par, coop, age, interests,
			 	comments);
		
		
		db.addCustomer(customer);
	}
	
	///////////////////////////////////////////////////////////////////////
	public void addEmptyCustomer(FormEvent ev){
			
	
			String firstname = ev.getFirstname();
			String lastname = ev.getLastname();
			int monthId = ev.getMonth();
			String material = ev.getMaterial();
			String level = ev.getLevel();
			int id = ev.getId();
			
			MonthCategory monthCategory = null;
			
			switch(monthId){
			
			case 1:
				monthCategory = MonthCategory.January;
				break;
			case 2:
				monthCategory = MonthCategory.February;
				break;
			case 3:
				monthCategory = MonthCategory.March;
				break;
			case 4:
				monthCategory = MonthCategory.April;
				break;
			case 5:
				monthCategory = MonthCategory.May;
				break;
			case 6:
				monthCategory = MonthCategory.June;
				break;
			case 7:
				monthCategory = MonthCategory.July;
				break;
			case 8:
				monthCategory = MonthCategory.August;
				break;
			case 9:
				monthCategory = MonthCategory.September;
				break;
			case 10:
				monthCategory = MonthCategory.October;
				break;
			case 11:
				monthCategory = MonthCategory.November;
				break;
			case 12:
				monthCategory = MonthCategory.December;
				break;
			default:
			
			}
			
			 int listen = ev.getListen();
			 int speak = ev.getSpeak();
			 int read = ev.getRead();
			 int par = ev.getParticipation();
			 int coop = ev.getCooperation();
			 String age = ev.getAge();
			 String interests = ev.getInterests();
			 String comments = ev.getComments();
			 
			
			Customer customer = new Customer(firstname, lastname, monthCategory, material,
				 level, id, listen, speak, read, par, coop, age, interests,
				 	comments);
			
			
			db.addCustomerViewAllTable(customer);
		}
	
	public void saveToFile(File file) throws IOException {
		db.saveToFile(file);
	}
	
	public void loadFromFile(File file) throws IOException {
		db.loadFromFile(file);
	}

	public String getDBname() {
		return db.getName();
	}

	public void search(String firstName, String lastName, String month, String material, String level) throws SQLException {
		db.search(firstName, lastName, month, material, level);
	}

	public void setRowNumber(int i) {
		db.setAddNewRowNumber(i);
	}

	public void clearViewAllTable() {
		db.clearViewAllTableData();
	}

	public void clearAddCustomerTable() {
		db.clearAddCustomerTableData();
	}

	public void setViewAllRowNumber(int tableRowNumber) {
		db.setViewAllRowNumber(tableRowNumber);
	}

	public void buildEmptyTable() {
		db.buildEmptyTable();
	}


}
