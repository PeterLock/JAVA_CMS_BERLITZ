package gui.training.com;




import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DragSourceDragEvent;
import java.awt.dnd.DragSourceMotionListener;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetContext;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.TransferHandler;


public class DragAndDrop extends JFrame {


	//Constants for laying out the GUI.//
    protected final static int CONTAINER_HEIGHT = 600,  CONTAINER_WIDTH = 250,  PANEL_INSETS = 5;
    
    private Dimension headerDimension = new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100);


	private int panelWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2;
	private int panelHeight = CONTAINER_HEIGHT/3;
	
	//setPanelSize(container, new Dimension(width/2, containerHeight/3));

	
    private final List<DragAndDropPanel> panels;
    private final mainPanel rootPanel;
    
    /**
     * <p></p>
     * <p></p>
     * <p></p>
     */
    //This represents the data that is transmitted in drag and drop.//
    //In our limited case with only 1 type of dropped item, it will be a panel object!//
    //Note DataFlavor can represent more than classes -- easily text, images, etc.//
    private static DataFlavor dragAndDropPanelDataFlavor = null;

    public DragAndDrop() throws Exception {

        rootPanel = new mainPanel(DragAndDrop.this);
        rootPanel.setLayout(new GridBagLayout());
        this.add(rootPanel);

        // Create a list to hold all the panels
        panels = new ArrayList<DragAndDropPanel>();
        
        DragAndDropPanel panel1 = new DragAndDropPanel();
        getRandomDragAndDropPanels().add(panel1);
        
        DragAndDropPanel panel2 = new DragAndDropPanel();
        getRandomDragAndDropPanels().add(panel2);
        
        DragAndDropPanel panel3 = new DragAndDropPanel();
        getRandomDragAndDropPanels().add(panel3);

        relayout();

    }

 
    //Removes all components from our root panel and re-adds them.//
    //////This is important for two things:///
    //////Adding a new panel (user clicks on button)///
    //////Re-ordering panels (user drags and drops a panel to acceptable drop target region)//
    protected void relayout() {

        // Create the constraints, and go ahead and set those
        // that don't change for components
        final GridBagConstraints gc = new GridBagConstraints();
        gc.gridwidth = GridBagConstraints.REMAINDER;
        gc.gridx = 0;
        gc.anchor = GridBagConstraints.NORTH;
        gc.weighty = 0.0;
        gc.fill = GridBagConstraints.NONE;

        int row = 0;

        // Clear out all previously added items
        rootPanel.removeAll();

        // Put a lot of room around panels so can drop easily!
        gc.insets = new Insets(PANEL_INSETS, PANEL_INSETS, PANEL_INSETS, PANEL_INSETS);
        
        // Add the panels, if any
        for (DragAndDropPanel p : getRandomDragAndDropPanels()) {
            gc.gridy = row++;
            rootPanel.add(p, gc);
        }

        // Add a vertical strut to push content to top.
        gc.weighty = 1.0;
        gc.weightx = 1.0;
        gc.fill = GridBagConstraints.BOTH;
        gc.gridy = row++;
        Component strut = Box.createVerticalStrut(1);
        rootPanel.add(strut, gc);

        this.validate();
        this.repaint();
    }

    //Returns (creating, if necessary) the DataFlavor representing RandomDragAndDropPanel//
    public static DataFlavor getDragAndDropPanelDataFlavor() throws Exception {
        if (dragAndDropPanelDataFlavor == null) {
            dragAndDropPanelDataFlavor = new DataFlavor(DataFlavor.javaJVMLocalObjectMimeType + ";findClass=DragAndDropPanel");
        }
        return dragAndDropPanelDataFlavor;
    }

    //Instantiate the demo.//
    public static void main(String args[]) throws Exception {
        DragAndDrop dragAndDrop = new DragAndDrop();
        dragAndDrop.setSize(new Dimension(CONTAINER_WIDTH, CONTAINER_HEIGHT));
        dragAndDrop.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dragAndDrop.setVisible(true);
    }


    //Returns the List of user-added panels//
    //Note that for drag and drop, these will be cleared, and the panels will be added back in the correct order!//
    protected List<DragAndDropPanel> getRandomDragAndDropPanels() {
        return panels;
    }
}

//This is the panel within the GUI that holds the button and RandomDragAndDropPanel's.//
//You can see that this has a DropTarget associated with it!//
class mainPanel extends JPanel {
	
    private final DragAndDrop dragAndDrop;
    mainPanel(DragAndDrop demo) {
        super();
        
        // Need to keep reference so can later communicate with drop listener
        this.dragAndDrop = demo;
        
        // Again, needs to negotiate with the drag-able object
        this.setTransferHandler(new DragAndDropTransferHandler());
        
        // Create the listener to do the work when dropping on this object!
        this.setDropTarget(new DropTarget(mainPanel.this, new DemoPanelDropTargetListener(mainPanel.this)));
    }

    public DragAndDrop getDragAndDropPanelsDemo() {
        return dragAndDrop;
    }
}

//Panel with random number. Can be dragged and dropped.//
class DragAndDropPanel extends JPanel implements Transferable {

    final static Random random = new Random();
    
    private static int counter = 0;

    public DragAndDropPanel() {

        // Add the listener which will export this panel for dragging
        this.addMouseListener(new DraggableMouseListener());
        
        // Add the handler, which negotiates between drop target and this 
        // draggable panel
        this.setTransferHandler(new DragAndDropTransferHandler());

        // Create a label with this panel's number
        counter++;
        JLabel valueLabel = new JLabel(String.valueOf(counter));
        valueLabel.setForeground(Color.WHITE);
        this.add(valueLabel);

        // Style it a bit to set apart from container
        this.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        this.setBackground(Color.PINK);
        

        // This won't take the entire width for easy drag and drop
        final Dimension d = new Dimension(DragAndDrop.CONTAINER_WIDTH - 2 * DragAndDrop.PANEL_INSETS, 30);
        this.setPreferredSize(d);
        this.setMinimumSize(d);
        
        
    }

    //One of three methods defined by the Transferable interface.//
    //If multiple DataFlavor's are supported, can choose what Object to return.//
    //In this case, we only support one: the actual JPanel.//
    //Note we could easily support more than one. For example, if supports text and drops to a JTextField, could return the label's text or any arbitrary text.//
    public Object getTransferData(DataFlavor flavor) {

        System.out.println("Step 7 of 7: Returning the data from the Transferable object. In this case, the actual panel is now transfered!");
        
        DataFlavor thisFlavor = null;

        try {
            thisFlavor = DragAndDrop.getDragAndDropPanelDataFlavor();
        } catch (Exception ex) {
            System.err.println("Problem lazy loading: " + ex.getMessage());
            ex.printStackTrace(System.err);
            return null;
        }

        // For now, assume wants this class... see loadDnD
        if (thisFlavor != null && flavor.equals(thisFlavor)) {
            return DragAndDropPanel.this;
        }

        return null;
    }


    //One of three methods defined by the Transferable interface.//
    //Returns supported DataFlavor. Again, we're only supporting this actual Object within the JVM.//
    //For more information, see the JavaDoc for DataFlavor.//
    public DataFlavor[] getTransferDataFlavors() {

        DataFlavor[] flavors = {null};
        
        System.out.println("Step 4 of 7: Querying for acceptable DataFlavors to determine what is available. Our example only supports our custom RandomDragAndDropPanel DataFlavor.");
        
        try {
            flavors[0] = DragAndDrop.getDragAndDropPanelDataFlavor();
        } catch (Exception ex) {
            System.err.println("Problem lazy loading: " + ex.getMessage());
            ex.printStackTrace(System.err);
            return null;
        }

        return flavors;
    }


    //One of three methods defined by the Transferable interface.//
    //Determines whether this object supports the DataFlavor. In this case, only one is supported: for this object itself.//
    public boolean isDataFlavorSupported(DataFlavor flavor) {

        System.out.println("Step 6 of 7: Verifying that DataFlavor is supported.  Our example only supports our custom RandomDragAndDropPanel DataFlavor.");
        
        DataFlavor[] flavors = {null};
        try {
            flavors[0] = DragAndDrop.getDragAndDropPanelDataFlavor();
        } catch (Exception ex) {
            System.err.println("Problem lazy loading: " + ex.getMessage());
            ex.printStackTrace(System.err);
            return false;
        }

        for (DataFlavor f : flavors) {
            if (f.equals(flavor)) {
                return true;
            }
        }

        return false;
    }
} // RandomDragAndDropPanelsDemo


//Listener that make source draggable.//
//Thanks, source modified from: http://www.zetcode.com/tutorials/javaswingtutorial/draganddrop///
class DraggableMouseListener extends MouseAdapter {

    @Override()
    public void mousePressed(MouseEvent e) {
        System.out.println("Step 1 of 7: Mouse pressed. Going to export our RandomDragAndDropPanel so that it is draggable.");
        
        JComponent c = (JComponent) e.getSource();
        TransferHandler handler = c.getTransferHandler();
        handler.exportAsDrag(c, e, TransferHandler.COPY);
    }
} // DraggableMouseListener


//Used by both the drag-able class and the target for negotiating data.//
//Note that this should be set for both the drag-able object and the drop target.//
class DragAndDropTransferHandler extends TransferHandler implements DragSourceMotionListener {

    public DragAndDropTransferHandler() {
        super();
    }


    //This creates the Transferable object. In our case, RandomDragAndDropPanel implements Transferable, so this requires only a type cast.//
    @Override()
    public Transferable createTransferable(JComponent c) {

        System.out.println("Step 3 of 7: Casting the RandomDragAndDropPanel as Transferable. The Transferable RandomDragAndDropPanel will be queried for acceptable DataFlavors as it enters drop targets, as well as eventually present the target with the Object it transfers.");
        
        // TaskInstancePanel implements Transferable
        if (c instanceof DragAndDropPanel) {
            Transferable tip = (DragAndDropPanel) c;
            return tip;
        }

        // Not found
        return null;
    }

    public void dragMouseMoved(DragSourceDragEvent dsde) {}


    //This is queried to see whether the component can be copied, moved, both or neither. We are only concerned with copying.//
    @Override()
    public int getSourceActions(JComponent c) {
        
        System.out.println("Step 2 of 7: Returning the acceptable TransferHandler action. Our RandomDragAndDropPanel accepts Copy only.");
        
        if (c instanceof DragAndDropPanel) {
            return TransferHandler.COPY;
        }
        
        return TransferHandler.NONE;
    }
} // DragAndDropTransferHandler



//Listens for drops and performs the updates.//
//The real magic behind the drop!//
class DemoPanelDropTargetListener implements DropTargetListener {

    private final mainPanel rootPanel;
    
 
    //Two cursors with which we are primarily interested while dragging://
    //////Cursor for drop-able condition//
    //////Cursor for non-drop-able condition//
    //After drop, we manually change the cursor back to default, though does this anyhow -- just to be complete.//
    private static final Cursor droppableCursor = Cursor.getPredefinedCursor(Cursor.HAND_CURSOR),
            notDroppableCursor = Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR);

    public DemoPanelDropTargetListener(mainPanel sheet) {
        this.rootPanel = sheet;
    }

    // Could easily find uses for these, like cursor changes, etc.
    public void dragEnter(DropTargetDragEvent dtde) {}
    public void dragOver(DropTargetDragEvent dtde) {
        if (!this.rootPanel.getCursor().equals(droppableCursor)) {
            this.rootPanel.setCursor(droppableCursor);
        }
    }
    public void dropActionChanged(DropTargetDragEvent dtde) {}
    public void dragExit(DropTargetEvent dte) {
        this.rootPanel.setCursor(notDroppableCursor);
    }


    //The user drops the item. Performs the drag and drop calculations and layout.//
    public void drop(DropTargetDropEvent dtde) {
        
        System.out.println("Step 5 of 7: The user dropped the panel. The drop(...) method will compare the drops location with other panels and reorder the panels accordingly.");
        
        // Done with cursors, dropping
        this.rootPanel.setCursor(Cursor.getDefaultCursor());
        
        // Just going to grab the expected DataFlavor to make sure
        // we know what is being dropped
        DataFlavor dragAndDropPanelFlavor = null;
        
        Object transferableObj = null;
        Transferable transferable = null;
        
        try {
            // Grab expected flavor
            dragAndDropPanelFlavor = DragAndDrop.getDragAndDropPanelDataFlavor();
            
            transferable = dtde.getTransferable();
            DropTargetContext c = dtde.getDropTargetContext();
            
            // What does the Transferable support
            if (transferable.isDataFlavorSupported(dragAndDropPanelFlavor)) {
                transferableObj = dtde.getTransferable().getTransferData(dragAndDropPanelFlavor);
            } 
            
        } catch (Exception ex) { /* nope, not the place */ }
        
        // If didn't find an item, bail
        if (transferableObj == null) {
            return;
        }
        
        // Cast it to the panel. By this point, we have verified it is 
        // a RandomDragAndDropPanel.
        DragAndDropPanel droppedPanel = (DragAndDropPanel)transferableObj;
        
        // Get the y offset from the top of the WorkFlowSheetPanel
        // for the drop option (the cursor on the drop)
        final int dropYLoc = dtde.getLocation().y;

        // We need to map the Y axis values of drop as well as other
        // RandomDragAndDropPanel so can sort by location.
        Map<Integer, DragAndDropPanel> yLocMapForPanels = new HashMap<Integer, DragAndDropPanel>();
        yLocMapForPanels.put(dropYLoc, droppedPanel);

        // Iterate through the existing demo panels. Going to find their locations.
        for (DragAndDropPanel nextPanel : rootPanel.getDragAndDropPanelsDemo().getRandomDragAndDropPanels()) {

            // Grab the y value
            int y = nextPanel.getY();

            // If the dropped panel, skip
            if (!nextPanel.equals(droppedPanel)) {
                yLocMapForPanels.put(y, nextPanel);
            }
        }

        // Grab the Y values and sort them
        List<Integer> sortableYValues = new ArrayList<Integer>();
        sortableYValues.addAll(yLocMapForPanels.keySet());
        Collections.sort(sortableYValues);

        // Put the panels in list in order of appearance
        List<DragAndDropPanel> orderedPanels = new ArrayList<DragAndDropPanel>();
        for (Integer i : sortableYValues) {
            orderedPanels.add(yLocMapForPanels.get(i));
        }
        
        // Grab the in-memory list and re-add panels in order.
        List<DragAndDropPanel> inMemoryPanelList = this.rootPanel.getDragAndDropPanelsDemo().getRandomDragAndDropPanels();
        inMemoryPanelList.clear();
        inMemoryPanelList.addAll(orderedPanels);
    
        // Request relayout contents, or else won't update GUI following drop.
        // Will add back in the order to which we just sorted
        this.rootPanel.getDragAndDropPanelsDemo().relayout();
    }
} // DemoPanelDropTargetListener