package gui.training.com;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import settings.UI_Settings;
import utilities.JTextFieldLimit;

public class Step1 extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	CreateTrainingSessionPanel sessionObject;
	
	private JPanel panel;
	private JPanel tipsContainer;
	private JPanel minimizeTips;
	private GridBagConstraints gc = new GridBagConstraints();
	private int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
	private String[] concepts = {"Time Management", "Planning For Time Management", "The Importance of Delegating Respondibility"};
	private JComboBox<String> cmbConcept1 = new JComboBox<String>(concepts);
	private JComboBox<String> cmbConcept2 = new JComboBox<String>(concepts);
	private JCheckBox chkOtherConcept = new JCheckBox("Add Other 1 to Database");
	
	private JTextArea txtArea_Important = new JTextArea(3,30);
	private JTextArea txtArea_Understood = new JTextArea(3,30);
	private JTextField txtConceptOther = new JTextField();
	
	private JLabel tipOneHeader;
	private JLabel tipTwoHeader;
	private JLabel nextStepTextButton = new JLabel(">>");
	private JLabel threeDots = new JLabel("...");
	private JLabel closeTips = new JLabel("close tips [x]");

	private JTextPane tipOneContent = new JTextPane();
    private JTextPane tipTwoContent = new JTextPane();
	
	@SuppressWarnings("rawtypes")
	private List comboboxes = new ArrayList<JComboBox>();
	private List textboxes = new ArrayList<JTextField>();
	
	private FormEventSBuilder ev;

	
	public Step1(FormEventSBuilder ev){
		
		this.ev = ev;
		intialize();

	}
	

	private void intialize() {
		initializeComboBoxes(cmbConcept1);
		initializeComboBoxes(cmbConcept2);
		initializeTextFields(txtConceptOther);
		initializeCheckBox(chkOtherConcept);
		initializeTextArea(txtArea_Important);
		initializeTextArea(txtArea_Understood);
		intializeTextPanes(tipOneContent);
		intializeTextPanes(tipTwoContent);
		initializeMinimizePanes();
		
		initializeListeners();
		
	}




	private void initializeListeners() {
		closeTips.setCursor(new Cursor(Cursor.HAND_CURSOR));
		closeTips.setForeground(UI_Settings.getComponentsFontColorLight());
		closeTips.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				tipsContainer.setVisible(false);
				minimizeTips.setVisible(true);
			}
		});
		
		minimizeTips.setCursor(new Cursor(Cursor.HAND_CURSOR));
		minimizeTips.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				minimizeTips.setVisible(false);
				tipsContainer.setVisible(true);
			}
		});
		nextStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		nextStepTextButton.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				JScrollPane scroller = sessionObject.getScroller();
				
				 String concept1 = cmbConcept1.getSelectedItem().toString();
				 String concept2 = cmbConcept2.getSelectedItem().toString();
				 String otherConcept = txtConceptOther.getText();
				 String conceptImportant = txtArea_Important.getText();
				 String conceptUnderstood = txtArea_Understood.getSelectedText();
				 
				 ev.setConcept1(concept1);
				 ev.setConcept2(concept2);
				 ev.setOtherConcept(otherConcept);
				 ev.setConceptImportant(conceptImportant);
				 ev.setConceptUnderstood(conceptUnderstood);
				 
				 System.out.println("In Step 1, name is: " + ev.getConcept1());

				 if(scroller != null){
					 scroller.getViewport().setViewPosition(new Point(0,0));
				 }
				
				 sessionObject.resetLocatorColors();
				 sessionObject.addFormEventDataToFields();
				 sessionObject.locator2.setBackground(CreateTrainingSessionPanel.LOCATOR_ACTIVE_COLOR);
				 CardLayout cl = (CardLayout)(sessionObject.cards.getLayout());
				 cl.show(sessionObject.cards, CreateTrainingSessionPanel.STEP2);
			}
		});
	}


	public JPanel run(CreateTrainingSessionPanel sessionObject){
		
		this.sessionObject = sessionObject;
		
		panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.setBackground(Color.WHITE);
		setPanelSize(panel, new Dimension(new Dimension(screenWidth, 800)));
		/////////////////////////////////////////////////////////////////////////////////

		addNextStepRow();
		addHeadingAndSubText();
		addComboBoxRow();
		addConceptKnowledgeBoxes();
		addTipContainers();
		addMinimizeTipsContainer();
		
		
		/////////////////////////////////////////////////////////////////////////////////
		return panel;
	}
	
	private void addNextStepRow() {
		nextStepTextButton.setFont(nextStepTextButton.getFont().deriveFont(12.0f));
		nextStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());


		JPanel container = new JPanel();
		container.setBackground(Color.WHITE);
		container.setLayout(new BoxLayout(container, BoxLayout.X_AXIS));
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(nextStepTextButton);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		container.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		container.add(rightPanel);
		
		panel.add(container);
	}


	private void addMinimizeTipsContainer() {
		threeDots.setForeground(UI_Settings.getComponentsFontColorLight());
		threeDots.setFont(threeDots.getFont().deriveFont(16.0f));
		panel.add(minimizeTips);
	}


	private void addTipContainers() {
		
		int containerHeight = 180;
		int tipOnecontainerHeight = 80;
		int tipTwocontainerHeight = 60;

		int count = 0;
		
		tipOneHeader = new JLabel("Tip 1:");
		tipOneHeader.setFont(tipOneHeader.getFont().deriveFont(14.0f));
		
		tipOneContent.setText("You can use the ABCD Learning Objectives Model to set a training objective "
				+ "that comprehensively addresses your learners needs. This helps to understand your Audience,"
				+ " define the Behavior needed at the end of the session, specify the Conditions under which "
				+ "the knowledge will be used, and Determine  the degree of knowledge needed.");
		
		tipTwoHeader = new JLabel("Tip 2:");
		tipTwoHeader.setFont(tipTwoHeader.getFont().deriveFont(14.0f));
		
		tipTwoContent.setText("You should only have one or two learning objectives for each class. If you have "
				+ "more, you are likely to have too much information to cover, and trainees may feel overwhelmed "
				+ "with information.");
		
		tipsContainer = new JPanel(new GridBagLayout());
		setPanelSize(tipsContainer, new Dimension(screenWidth, containerHeight));
		tipsContainer.setBackground(Color.WHITE);
		
		
		JPanel left = new JPanel(new GridBagLayout());
		setPanelSize(left, new Dimension(screenWidth/3*2, containerHeight));
		left.setBackground(Color.WHITE);
		
			JPanel containerOne = new JPanel(new GridBagLayout());
			setPanelSize(containerOne, new Dimension(screenWidth/3*2, tipOnecontainerHeight));
			containerOne.setBackground(new Color(242,242,242));
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(5,20,0,0);
			containerOne.add(tipOneHeader, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.insets = new Insets(0,20,0,0);
			containerOne.add(tipOneContent,gc);
			
			gc.gridx = 0;
			gc.gridy = count;
			gc.insets = new Insets(10,20,0,20);
			left.add(containerOne, gc);
			
			JPanel containerTwo = new JPanel(new GridBagLayout());
			setPanelSize(containerTwo, new Dimension(screenWidth/3*2, tipTwocontainerHeight));
			containerTwo.setBackground(new Color(242,242,242));
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(5,20,0,0);
			containerTwo.add(tipTwoHeader, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.insets = new Insets(0,20,0,0);
			containerTwo.add(tipTwoContent,gc);
			
			gc.gridx = 0;
			gc.gridy = ++count;
			gc.insets = new Insets(10,20,0,20);
			left.add(containerTwo, gc);
		
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,0,0,0);
		tipsContainer.add(left,gc);
		
		
		JPanel right = new JPanel(new GridBagLayout());
		setPanelSize(right, new Dimension(screenWidth/3, containerHeight));
		right.setBackground(Color.WHITE);
		
			JPanel hideTips = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20,5));
			setPanelSize(hideTips, new Dimension(screenWidth/3, 20));
			hideTips.setBackground(Color.WHITE);
			hideTips.add(closeTips);
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,0,0,0);
			right.add(hideTips,gc);
		
		gc.gridx = 1;
		tipsContainer.add(right, gc);
		
		tipsContainer.setAlignmentY(Component.LEFT_ALIGNMENT);
		panel.add(tipsContainer);
	}


	private void addConceptKnowledgeBoxes() {
		
		int containerHeight = 180;
		int count = 0;
		
		JPanel content = new JPanel(new GridBagLayout());
		setPanelSize(content, new Dimension(screenWidth, containerHeight));
		content.setBackground(Color.WHITE);
		
		JPanel left = new JPanel(new GridBagLayout());
		setPanelSize(left, new Dimension(screenWidth/3*2, containerHeight));
		left.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = count;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,20,0,100);
		left.add(new JLabel("Why are these concepts and skills important?"), gc);
		
		gc.gridx = 0;
		gc.gridy = ++count;
		left.add(txtArea_Important, gc);
		
		gc.gridx = 0;
		gc.gridy = ++count;
		left.add(new JLabel("How will you know that they have understood these correctly?"), gc);
		
		gc.gridx = 0;
		gc.gridy = ++count;
		left.add(txtArea_Understood, gc);

		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,0,0,0);
		content.add(left,gc);
		
		
		JPanel right = new JPanel(new GridBagLayout());
		setPanelSize(right, new Dimension(screenWidth/3, containerHeight));
		right.setBackground(Color.WHITE);
		
		gc.gridx = 1;
		content.add(right, gc);

		content.setAlignmentY(Component.LEFT_ALIGNMENT);
		panel.add(content);
	}


	private void addComboBoxRow() {
		
		int count = 0;
		
		JPanel content = new JPanel(new GridBagLayout());
		setPanelSize(content, new Dimension(screenWidth, 60));
		content.setBackground(Color.WHITE);
		
		gc.gridx = count;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,20,0,5);
		content.add(new JLabel("Concept 1:"),gc);
		
		gc.gridx = ++count;
		gc.insets = new Insets(0,10,0,10);
		gc.fill = GridBagConstraints.HORIZONTAL;
		content.add(cmbConcept1, gc);
		
		gc.gridx = ++count;
		gc.insets = new Insets(0,5,0,5);
		gc.fill = GridBagConstraints.NONE;
		content.add(new JLabel("Concept 2:"), gc);
		
		gc.gridx = ++count;
		gc.insets = new Insets(0,10,0,10);
		gc.fill = GridBagConstraints.HORIZONTAL;
		content.add(cmbConcept2, gc);
		
		gc.gridx = ++count;
		gc.insets = new Insets(0,5,0,10);
		gc.fill = GridBagConstraints.NONE;
		content.add(new JLabel("Other 1:"), gc);
		
		gc.gridx = ++count;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.insets = new Insets(0,-40,0,-10);
		content.add(txtConceptOther, gc);
		
		gc.gridx = ++count;
		gc.fill = GridBagConstraints.NONE;
		gc.insets = new Insets(0,20,0,5);
		content.add(chkOtherConcept, gc);
		
		content.setAlignmentY(Component.LEFT_ALIGNMENT);
		panel.add(content);
	}

	private void addHeadingAndSubText() {
		
		JPanel content = new JPanel(new GridBagLayout());
		setPanelSize(content, new Dimension(screenWidth, 100));
		content.setBackground(Color.WHITE);
		
		JLabel pageTitle = new JLabel("Step 1: Define Learning Objective");
		pageTitle.setFont(pageTitle.getFont().deriveFont(16.0f));
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(15,20,0,0);
		content.add(pageTitle, gc);
		
		
		JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
		setPanelSize(row1, new Dimension(screenWidth, 20));
		row1.setBackground(Color.WHITE);
		
		JTextPane row1Text = new JTextPane();
		row1Text.setFont(row1Text.getFont().deriveFont(11.0f));
		row1Text.setForeground(UI_Settings.getComponentsFontColorDark());
		row1Text.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(row1Text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0);
		
		row1Text.setParagraphAttributes(set, true);

		row1Text.setText("Your first step is to specify what you want your trainees to learn,"
				+ " and determine how you will measure this.");
		

		row1.add(row1Text);
		row1.setAlignmentY(Component.LEFT_ALIGNMENT);
		gc.gridx = 0;
		gc.gridy = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(0,0,0,0);
		content.add(row1, gc);
		
		//////////////////////////
		JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 40, 0));
		setPanelSize(row2, new Dimension(screenWidth, 20));
		row2.setBackground(Color.WHITE);
		
		JTextPane row2Text = new JTextPane();
		row2Text.setFont(row2Text.getFont().deriveFont(11.0f));
		row2Text.setForeground(UI_Settings.getComponentsFontColorDark());
		row2Text.setEditable(false);
		
		set = new SimpleAttributeSet(row2Text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0);
		
		row2Text.setParagraphAttributes(set, true);

		row2Text.setText("What are the most important concepts or skills that "
				+ "trainees need to understand by the end of the class?");
		

		row2.add(row2Text);
		gc.gridx = 0;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(0,20,0,0);
		content.add(row2,gc);
		content.setAlignmentY(Component.LEFT_ALIGNMENT);
		this.panel.add(content);
	}

	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
	
	@SuppressWarnings("unchecked")
	private void initializeComboBoxes(JComboBox<String> combobox) {
		
		combobox.setFont(UI_Settings.getComponentInputFontSize());
		combobox.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		combobox.setMinimumSize(combobox.getPreferredSize());
		
		this.comboboxes.add(combobox);		
	}
	
	@SuppressWarnings("unchecked")
	private void initializeTextFields(JTextField textfield) {
		textfield = new JTextField(20);
		textfield.setMinimumSize(textfield.getPreferredSize());
		textfield.setHorizontalAlignment(JTextField.CENTER);
		textboxes.add(textfield);
	}
	
	private void initializeCheckBox(JCheckBox checkbox) {
		checkbox.setFont(UI_Settings.getComponentsFontPlain());
		checkbox.setForeground(UI_Settings.getComponentsFontColorLight());
		checkbox.setSelected(true);
	}
	
	private void initializeTextArea(JTextArea textarea) {
		textarea.setEditable(true);
		textarea.setWrapStyleWord(true);
		textarea.setLineWrap(true);
		textarea.setDocument(new JTextFieldLimit(150));
		textarea.setBorder(UI_Settings.getBorderoutline());
		textarea.setPreferredSize(textarea.getPreferredSize());
	}
	
	private void intializeTextPanes(JTextPane textpane) {
		textpane.setFont(textpane.getFont().deriveFont(11.0f));
		textpane.setForeground(UI_Settings.getComponentsFontColorDark());
		textpane.setEditable(false);	
		textpane.setBackground(new Color(242,242,242));
		
		MutableAttributeSet set = new SimpleAttributeSet(textpane.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.3);
		
		textpane.setParagraphAttributes(set, true);
	}
	
	private void initializeMinimizePanes() {
		minimizeTips = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		setPanelSize(minimizeTips, new Dimension(screenWidth, 20));
		minimizeTips.setBackground(Color.WHITE);
		minimizeTips.add(threeDots);
		
		minimizeTips.setAlignmentY(Component.LEFT_ALIGNMENT);
		minimizeTips.setVisible(false);		
	}
}
