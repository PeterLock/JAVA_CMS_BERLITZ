package customer.model;

import java.io.Serializable;

public class Customer implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String firstname = "";
	private String lastname = "";
	private MonthCategory monthCategory;
	private String material = "";
	private String level = "";
	private int listening = 0;
	private int speaking = 0;
	private int reading = 0;
	private int participation = 0;
	private int cooperation = 0;
	private String age = "";
	private String comments = "";
	private String interests = "";
	private int id = 0;

	
	public Customer(String firstname, String lastname, MonthCategory monthCategory, String material,
			String level, Integer ID, int listen, int speak, int read, int par, int coop, String age, String interests,
			String comments){
		
		
		this.firstname = firstname;
		this.lastname = lastname;
		this.monthCategory = monthCategory;
		this.material = material;
		this.level = level;
		this.listening = listen;
		this.speaking = speak;
		this.reading = read;
		this.participation = par;
		this.cooperation = coop;
		this.age = age;
		this.interests = interests;
		this.comments = comments;
		this.id = ID;

	}
	
	public String getInterests() {
		return interests;
	}

	public void setInterests(String interests) {
		this.interests = interests;
	}
	
	
	
	public int getListening() {
		return listening;
	}

	public void setListening(int listening) {
		this.listening = listening;
	}

	public int getSpeaking() {
		return speaking;
	}

	public void setSpeaking(int speaking) {
		this.speaking = speaking;
	}

	public int getReading() {
		return reading;
	}

	public void setReading(int reading) {
		this.reading = reading;
	}

	public int getParticipation() {
		return participation;
	}

	public void setParticipation(int participation) {
		this.participation = participation;
	}

	public int getCooperation() {
		return cooperation;
	}

	public void setCooperation(int cooperation) {
		this.cooperation = cooperation;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public MonthCategory getMonthCategory() {
		return monthCategory;
	}
	public void setMonthCategory(MonthCategory monthCategory) {
		this.monthCategory = monthCategory;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	
	public String toString(){
		return id + ": " + firstname;
	}
}
