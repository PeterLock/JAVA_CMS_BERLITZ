package gui.training.com;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import settings.UI_Settings;
import utilities.JTextFieldLimit;

public class Step1 extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	CreateTrainingSessionPanel sessionObject;
	
	private JPanel rootpanel;
	private JPanel tipsContainer;
	private JPanel minimizeTips;
	private JPanel container;
	
	
	private JTextField txtTopic1 = new JTextField();
	private JTextField txtTopic2 = new JTextField();
	private JTextField txtTopic3 = new JTextField();
	
	private JTextField txtWhosGivingTraining = new JTextField();
	private JTextField txtWhatsTrainingTitle = new JTextField();
	
	private JLabel tipOneHeader;
	private JLabel tipTwoHeader;
	private JLabel nextStepTextButton = new JLabel("next step");
	private JLabel threeDots = new JLabel("...");
	private JLabel closeTips = new JLabel("close tips [x]");
	
	private JTextPane tipOneContent = new JTextPane();
    private JTextPane tipTwoContent = new JTextPane();
    private JTextPane whatAreTheTopicsText = new JTextPane();

    
    
    
	
	@SuppressWarnings("rawtypes")
	private List textboxes = new ArrayList<JTextField>();

	private GridBagConstraints gc = new GridBagConstraints();
	private int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;

	public Step1(){
		intialize();
	}
	

	private void intialize() {
		initializeTextFields(txtTopic1);
		initializeTextFields(txtTopic2);
		initializeTextFields(txtTopic3);
		initializeTextFields(txtWhosGivingTraining);
		initializeTextFields(txtWhatsTrainingTitle);

		
		intializeTextPanes(tipOneContent);
		intializeTextPanes(tipTwoContent);
		
		initializeMinimizePanes();
		initializeListeners();
	}


	private void initializeListeners() {
		closeTips.setCursor(new Cursor(Cursor.HAND_CURSOR));
		closeTips.setForeground(UI_Settings.getComponentsFontColorLight());
		closeTips.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				tipsContainer.setVisible(false);
				minimizeTips.setVisible(true);
			}
		});
		
		minimizeTips.setCursor(new Cursor(Cursor.HAND_CURSOR));
		minimizeTips.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				minimizeTips.setVisible(false);
				tipsContainer.setVisible(true);
			}
		});
		nextStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		nextStepTextButton.addMouseListener(new MouseAdapter(){
			@SuppressWarnings("static-access")
			public void mousePressed(MouseEvent e){
				
				JScrollPane scroller = sessionObject.getScroller();
				
				 
				if(scroller != null){
					 scroller.getViewport().setViewPosition(new Point(0,0));
				 }
				
				 sessionObject.resetLocatorColors();
				 sessionObject.locator2.setBackground(CreateTrainingSessionPanel.LOCATOR_ACTIVE_COLOR);
				 CardLayout cl = (CardLayout)(sessionObject.cards.getLayout());
				 cl.show(sessionObject.cards, CreateTrainingSessionPanel.STEP2);
			}
		});
	}


	public JPanel run(CreateTrainingSessionPanel sessionObject){
		
		this.sessionObject = sessionObject;
		
		rootpanel = new JPanel();
		rootpanel.setLayout(new BoxLayout(rootpanel, BoxLayout.Y_AXIS));
		rootpanel.setBackground(Color.WHITE);
		setPanelSize(rootpanel, new Dimension(new Dimension(screenWidth, 900)));

		addNextStepRow();
		addHeadingAndSubText();
		
		rootpanel.add(northSection());
		rootpanel.add(southSection());

		
		addTipContainers();
		addMinimizeTipsContainer();
		return rootpanel;
	}
	
	private Component northSection() {
		
		int containerHeight = 100;
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(screenWidth, containerHeight));
		container.setBackground(Color.WHITE);
		
			JPanel westPanel = new JPanel(new GridBagLayout());
			setPanelSize(westPanel, new Dimension(screenWidth/2, containerHeight));
			westPanel.setBackground(Color.WHITE);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,50,0,20);
				westPanel.add(new JLabel("Who is going to give the presentation?"), gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.insets = new Insets(0,-70,0,20);
				westPanel.add(txtWhosGivingTraining, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,50,0,20);
				westPanel.add(new JLabel("What is the title of the training session?"), gc);
				
				gc.gridx = 1;
				gc.gridy = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.insets = new Insets(0,-70,0,20);
				westPanel.add(txtWhatsTrainingTitle, gc);

			
			JPanel eastPanel = new JPanel(new GridBagLayout());
			setPanelSize(eastPanel, new Dimension(screenWidth/2, containerHeight));
			eastPanel.setBackground(Color.WHITE);
			
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(0,0,0,0);
			container.add(westPanel, gc);
				
			gc.gridx = 1;
			gc.insets = new Insets(0,0,0,0);
			container.add(eastPanel, gc);
			
		return container;
	}
	
	
	private Component southSection() {
		
		int containerHeight = 120;
		
		JPanel container = new JPanel();
		container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
		setPanelSize(container, new Dimension(screenWidth, containerHeight));
		container.setBackground(Color.WHITE);		
		
		JLabel title = new JLabel("What are the Topics?");
		title.setFont(title.getFont().deriveFont(14.0f));
		
		JPanel titleContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 50, 10));
		setPanelSize(titleContainer, new Dimension(screenWidth, 30));
		titleContainer.setBackground(Color.WHITE);
		titleContainer.add(title);
		
		whatAreTheTopicsText.setFont(whatAreTheTopicsText.getFont().deriveFont(11.0f));
		whatAreTheTopicsText.setForeground(UI_Settings.getComponentsFontColorDark());
		whatAreTheTopicsText.setEditable(false);	
		whatAreTheTopicsText.setBackground(Color.WHITE);
		
		MutableAttributeSet set = new SimpleAttributeSet(whatAreTheTopicsText.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.3);
		
		whatAreTheTopicsText.setParagraphAttributes(set, true);
		whatAreTheTopicsText.setText("What are the most important concepts or skills that trainees need to"
				+ " understand by the end of the class?");
		
		JPanel textContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 50, 10));
		setPanelSize(textContainer, new Dimension(screenWidth, 30));
		textContainer.setBackground(Color.WHITE);
		textContainer.add(whatAreTheTopicsText);
		
		
		container.add(titleContainer);
		container.add(textContainer);
		
		//Add the Topic entry fields//
		
		JPanel inputFields = new JPanel(new GridBagLayout());
		setPanelSize(inputFields, new Dimension(screenWidth, 50));
		inputFields.setBackground(Color.WHITE);
		
			int count = 0;
		
			gc.gridx = count;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,50,0,10);
			inputFields.add(new JLabel("Topic 1:"), gc);
			
			gc.gridx = ++count;
			gc.gridy = 0;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.insets = new Insets(0,-100,0,10);
			inputFields.add(txtTopic1, gc);
			
			gc.gridx = ++count;
			gc.gridy = 0;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.insets = new Insets(0,10,0,10);
			inputFields.add(new JLabel("Topic 2:"), gc);
			
			gc.gridx = ++count;
			gc.gridy = 0;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.insets = new Insets(0,-100,0,10);
			inputFields.add(txtTopic2, gc);

			gc.gridx = ++count;
			gc.gridy = 0;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.insets = new Insets(0,10,0,10);
			inputFields.add(new JLabel("Topic 3:"), gc);
			
			gc.gridx = ++count;
			gc.gridy = 0;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.insets = new Insets(0,-100,0,50);
			inputFields.add(txtTopic3, gc);
			

		container.add(inputFields);
		
		return container;
	}



	private void addNextStepRow() {
		nextStepTextButton.setFont(nextStepTextButton.getFont().deriveFont(12.0f));
		nextStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());


		JPanel container = new JPanel();
		container.setBackground(Color.WHITE);
		container.setLayout(new BoxLayout(container, BoxLayout.X_AXIS));
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(nextStepTextButton);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		container.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		container.add(rightPanel);
		
		rootpanel.add(container);
	}


	private void addMinimizeTipsContainer() {
		threeDots.setForeground(UI_Settings.getComponentsFontColorLight());
		threeDots.setFont(threeDots.getFont().deriveFont(16.0f));
		rootpanel.add(minimizeTips);
	}


	private void addTipContainers() {
		
		int containerHeight = 180;
		int tipOnecontainerHeight = 80;
		int tipTwocontainerHeight = 60;

		int count = 0;
		
		tipOneHeader = new JLabel("Tip 1:");
		tipOneHeader.setFont(tipOneHeader.getFont().deriveFont(14.0f));
		
		tipOneContent.setText("You can use the ABCD Learning Objectives Model to set a training objective "
				+ "that comprehensively addresses your learners needs. This helps to understand your Audience,"
				+ " define the Behavior needed at the end of the session, specify the Conditions under which "
				+ "the knowledge will be used, and Determine  the degree of knowledge needed.");
		
		tipTwoHeader = new JLabel("Tip 2:");
		tipTwoHeader.setFont(tipTwoHeader.getFont().deriveFont(14.0f));
		
		tipTwoContent.setText("You should only have one or two learning objectives for each class. If you have "
				+ "more, you are likely to have too much information to cover, and trainees may feel overwhelmed "
				+ "with information.");
		
		tipsContainer = new JPanel(new GridBagLayout());
		setPanelSize(tipsContainer, new Dimension(screenWidth, containerHeight));
		tipsContainer.setBackground(Color.WHITE);
		
		
		JPanel left = new JPanel(new GridBagLayout());
		setPanelSize(left, new Dimension(screenWidth/3*2, containerHeight));
		left.setBackground(Color.WHITE);
		
			JPanel containerOne = new JPanel(new GridBagLayout());
			setPanelSize(containerOne, new Dimension(screenWidth/3*2, tipOnecontainerHeight));
			containerOne.setBackground(new Color(242,242,242));
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(5,20,0,0);
			containerOne.add(tipOneHeader, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.insets = new Insets(0,20,0,0);
			containerOne.add(tipOneContent,gc);
			
			gc.gridx = 0;
			gc.gridy = count;
			gc.insets = new Insets(10,20,0,20);
			left.add(containerOne, gc);
			
			JPanel containerTwo = new JPanel(new GridBagLayout());
			setPanelSize(containerTwo, new Dimension(screenWidth/3*2, tipTwocontainerHeight));
			containerTwo.setBackground(new Color(242,242,242));
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(5,20,0,0);
			containerTwo.add(tipTwoHeader, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.insets = new Insets(0,20,0,0);
			containerTwo.add(tipTwoContent,gc);
			
			gc.gridx = 0;
			gc.gridy = ++count;
			gc.insets = new Insets(10,20,0,20);
			left.add(containerTwo, gc);
		
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,0,0,0);
		tipsContainer.add(left,gc);
		
		
		JPanel right = new JPanel(new GridBagLayout());
		setPanelSize(right, new Dimension(screenWidth/3, containerHeight));
		right.setBackground(Color.WHITE);
		
			JPanel hideTips = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15,5));
			setPanelSize(hideTips, new Dimension(screenWidth/3, 20));
			hideTips.setBackground(Color.WHITE);
			hideTips.add(closeTips);
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,0,0,0);
			right.add(hideTips,gc);
		
		gc.gridx = 1;
		tipsContainer.add(right, gc);
		
		tipsContainer.setAlignmentY(Component.LEFT_ALIGNMENT);
		rootpanel.add(tipsContainer);
	}



	private void addHeadingAndSubText() {
		
		JPanel content = new JPanel(new GridBagLayout());
		setPanelSize(content, new Dimension(screenWidth, 80));
		content.setBackground(Color.WHITE);
		
		JLabel pageTitle = new JLabel("Step 1: Define Learning Topic and Objective");
		pageTitle.setFont(pageTitle.getFont().deriveFont(16.0f));
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(15,20,0,0);
		content.add(pageTitle, gc);
		
		
		JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
		setPanelSize(row1, new Dimension(screenWidth, 20));
		row1.setBackground(Color.WHITE);
		
		JTextPane row1Text = new JTextPane();
		row1Text.setFont(row1Text.getFont().deriveFont(11.0f));
		row1Text.setForeground(UI_Settings.getComponentsFontColorDark());
		row1Text.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(row1Text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0);
		
		row1Text.setParagraphAttributes(set, true);

		row1Text.setText("Your first step is to specify what you want your trainees to learn.");
		

		row1.add(row1Text);
		row1.setAlignmentY(Component.LEFT_ALIGNMENT);
		gc.gridx = 0;
		gc.gridy = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(0,0,0,0);
		content.add(row1, gc);
		content.setAlignmentY(Component.LEFT_ALIGNMENT);
		this.rootpanel.add(content);
	}

	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
	
	@SuppressWarnings("unchecked")
	private void initializeTextFields(JTextField textfield) {
		textfield = new JTextField(40);
		textfield.setMinimumSize(textfield.getPreferredSize());
		textfield.setHorizontalAlignment(JTextField.CENTER);
		textboxes.add(textfield);
	}
	
	@SuppressWarnings("unused")
	private void initializeTextArea(JTextArea textarea) {
		textarea.setEditable(true);
		textarea.setWrapStyleWord(true);
		textarea.setLineWrap(true);
		textarea.setDocument(new JTextFieldLimit(150));
		textarea.setBorder(UI_Settings.getBorderoutline());
		textarea.setPreferredSize(textarea.getPreferredSize());
	}
	
	private void intializeTextPanes(JTextPane textpane) {
		textpane.setFont(textpane.getFont().deriveFont(11.0f));
		textpane.setForeground(UI_Settings.getComponentsFontColorDark());
		textpane.setEditable(false);	
		textpane.setBackground(new Color(242,242,242));
		
		MutableAttributeSet set = new SimpleAttributeSet(textpane.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.3);
		
		textpane.setParagraphAttributes(set, true);
	}
	
	private void initializeMinimizePanes() {
		minimizeTips = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		setPanelSize(minimizeTips, new Dimension(screenWidth, 20));
		minimizeTips.setBackground(Color.WHITE);
		minimizeTips.add(threeDots);
		
		minimizeTips.setAlignmentY(Component.LEFT_ALIGNMENT);
		minimizeTips.setVisible(false);		
	}
}
