package customer.gui;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import customer.model.Customer;

@SuppressWarnings("serial")
public class CustomerTableModel extends AbstractTableModel {
	
	private List<Customer>db;
	
	private String[] colNames = {"First Name", "Last Name", "Month Enrolled", "Material", "Level"};
	
	public CustomerTableModel(){
	}
	
	public void setData(List<Customer>db){
		this.db = db;

	}
	
	@Override
	public int getRowCount() {
		return db.size();
	}

	@Override
	public String getColumnName(int column) {
		return colNames[column];
	}

	@Override
	public int getColumnCount() {
		return 5;
	}

	@Override
	public Object getValueAt(int row, int col) {
		Customer customer = db.get(row);
		
		switch(col){
		case 0: 
			return customer.getFirstname();
		case 1: 
			return customer.getLastname();
		case 2:
			return customer.getMonthCategory();
		case 3: 
			return customer.getMaterial();
		case 4:
			return customer.getLevel();

		}
		return null;
	}
	
}
