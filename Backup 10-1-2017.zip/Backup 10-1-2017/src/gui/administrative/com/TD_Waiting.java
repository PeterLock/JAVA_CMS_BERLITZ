package gui.administrative.com;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_Waiting extends AbstractTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int AGE = 0;
	public final static int CUSTOMER_NAME = 1;
	public final static int PREFERRED_DAY1 = 2;
	public final static int RECOMMENDED_LEVEL = 3;
	public final static int WAITING_FROM = 4;
	public final static int WAITING_UNTIL = 5;
	
	
	public Object[][]values =
		{
				{new Integer(15), "Susan Miller", "Monday", "Timezones", "September 12th", "October 29th"},
				{"","","","","",""},
		};
	
	public final static String[] COLUMN_NAMES = {"Student Name", "Age", "Preferred Day 1", "Preferred Day 2", "Recommended Level", "Upper Level", "Waiting From"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	

	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}


	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList(16,16,16,16,16,16));

}
