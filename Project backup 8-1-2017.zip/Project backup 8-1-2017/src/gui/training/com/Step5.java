package gui.training.com;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import settings.UI_Settings;
import utilities.JTextFieldLimit;

public class Step5 extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JTextArea txtAreaFirstWe = new JTextArea(2, 20);
	private JTextArea txtAreaThenWe = new JTextArea(2, 20);
	private JTextArea txtAreaAndFinallyWe = new JTextArea(2, 20);
	private JTextArea txtAreaWhatIsTheNextStep = new JTextArea(2, 20);
	private JTextArea txtAreaWhenIsTheNextMeeting = new JTextArea(2, 20);
	private JTextArea txtAreaAdditionalNotes = new JTextArea(5, 40);


	
	
	private JLabel previousStepTextButton = new JLabel("previous step");
	private JLabel nextStepTextButton = new JLabel("next step");
	private int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;

	
	private JPanel rootpanel;
	private CreateTrainingSessionPanel sessionObject;
	private int containerHeight = 90;
	
	private JButton btnPreview = new JButton("Preview");
	private JButton btnPrint = new JButton("Print");
	private JButton btnSave = new JButton("Save");
;
	
	public Step5(){
		
	}
	
	private void initialize(){
		
		initializeTextArea(txtAreaFirstWe);
		initializeTextArea(txtAreaThenWe);
		initializeTextArea(txtAreaAndFinallyWe);
		initializeTextArea(txtAreaWhatIsTheNextStep);
		initializeTextArea(txtAreaWhenIsTheNextMeeting);
		initializeTextArea(txtAreaAdditionalNotes);
		initializeButtons(btnPreview);
		initializeButtons(btnPrint);
		initializeButtons(btnSave);


		
		initializeListeners();
	}
	


	public JPanel run(CreateTrainingSessionPanel sessionObject){
		
		this.sessionObject = sessionObject;

		
		rootpanel = new JPanel();
		rootpanel.setLayout(new BoxLayout(rootpanel, BoxLayout.Y_AXIS));
		rootpanel.setBackground(Color.WHITE);
		setPanelSize(rootpanel, new Dimension(new Dimension(screenWidth, 900)));
		
		
		initialize();
		
		
		addNextStepRow();
		addHeadingAndSubText();
		
		addFirstWePanel();
		addThenWePanel();
		addAndFinallyWePanel();
		
		addWhatIsTheNextStepPanel();
		addWhenWillTheNextMeetingBePanel();
		
		addAddionalNotesPanel();
		addButtonsPanel();

		
		return rootpanel;
		
	}
	

	private void addButtonsPanel() {
		GridBagConstraints gc = new GridBagConstraints();
		
		int containerHeight = 50;
		
		Dimension dimension = new Dimension(screenWidth, containerHeight);

		
		JPanel container = new JPanel(new GridBagLayout());
		container.setBackground(Color.WHITE);
		setPanelSize(container, dimension);
		
		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 2));
		buttonPanel.setBackground(Color.WHITE);
		
		buttonPanel.add(btnPreview);
		buttonPanel.add(btnPrint);
		buttonPanel.add(btnSave);

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,0,0,0);
		container.add(buttonPanel, gc);
		
		rootpanel.add(container);
		
	}

	private void addFirstWePanel() 
	{
		GridBagConstraints gc = new GridBagConstraints();
		
		Dimension dimension = new Dimension(screenWidth, containerHeight);
	
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, dimension);
		container.setBackground(Color.PINK);
		
			JPanel containerWest = new JPanel(new GridBagLayout());
			containerWest.setBackground(Color.WHITE);
			setPanelSize(containerWest, new Dimension((dimension.width/3)*2, dimension.height));
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,20,0,20);
				containerWest.add(new JLabel("First we .."), gc);
				
				
				gc.gridy = 1;
				gc.fill = GridBagConstraints.BOTH;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,20,10,20);
				containerWest.add(txtAreaFirstWe, gc);

			
			
			JPanel containerEast = new JPanel(new GridBagLayout());
			containerEast.setBackground(Color.WHITE);
			setPanelSize(containerEast, new Dimension(dimension.width/3, dimension.height));

			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,0,0);
			container.add(containerWest, gc);
		
			gc.gridx = 1;
			container.add(containerEast, gc);
			
		rootpanel.add(container);
		rootpanel.add(Box.createVerticalStrut(10));
	}



	private void addThenWePanel() {
		GridBagConstraints gc = new GridBagConstraints();
		
		Dimension dimension = new Dimension(screenWidth, containerHeight);
	
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, dimension);
		
			JPanel containerWest = new JPanel(new GridBagLayout());
			containerWest.setBackground(Color.WHITE);
			setPanelSize(containerWest, new Dimension((dimension.width/3)*2, dimension.height));
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,20,0,20);
				containerWest.add(new JLabel("Then we .."), gc);
				
				
				gc.gridy = 1;
				gc.fill = GridBagConstraints.BOTH;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,20,10,20);
				containerWest.add(txtAreaThenWe, gc);
			
			
			JPanel containerEast = new JPanel(new GridBagLayout());
			containerEast.setBackground(Color.WHITE);
			setPanelSize(containerEast, new Dimension(dimension.width/3, dimension.height));

			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,0,0);
			container.add(containerWest, gc);
		
			gc.gridx = 1;
			container.add(containerEast, gc);
			
		rootpanel.add(container);
		rootpanel.add(Box.createVerticalStrut(10));
		
	}
	
	private void addAndFinallyWePanel() {
		GridBagConstraints gc = new GridBagConstraints();
		
		Dimension dimension = new Dimension(screenWidth, containerHeight);
	
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, dimension);
		
			JPanel containerWest = new JPanel(new GridBagLayout());
			containerWest.setBackground(Color.WHITE);
			setPanelSize(containerWest, new Dimension((dimension.width/3)*2, dimension.height));
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,20,0,20);
			containerWest.add(new JLabel("And finally we .."), gc);
			
			
			gc.gridy = 1;
			gc.fill = GridBagConstraints.BOTH;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,20,10,20);
			containerWest.add(txtAreaAndFinallyWe, gc);
			
			JPanel containerEast = new JPanel(new GridBagLayout());
			containerEast.setBackground(Color.WHITE);
			setPanelSize(containerEast, new Dimension(dimension.width/3, dimension.height));

			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,0,0);
			container.add(containerWest, gc);
		
			gc.gridx = 1;
			container.add(containerEast, gc);
			
		rootpanel.add(container);
		rootpanel.add(Box.createVerticalStrut(10));		
	}

	private void addWhatIsTheNextStepPanel() {
		GridBagConstraints gc = new GridBagConstraints();
		
		int containerheights = 70;

		
		Dimension dimension = new Dimension(screenWidth, containerheights);
	
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, dimension);
		
			JPanel containerWest = new JPanel(new GridBagLayout());
			containerWest.setBackground(Color.WHITE);
			setPanelSize(containerWest, new Dimension(dimension.width/3, dimension.height));
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,20,0,20);
			containerWest.add(new JLabel("What is the next step?"), gc);
			
			
			gc.gridy = 1;
			gc.fill = GridBagConstraints.BOTH;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,20,10,0);
			containerWest.add(txtAreaWhatIsTheNextStep, gc);
			
			JPanel containerEast = new JPanel(new GridBagLayout());
			containerEast.setBackground(Color.WHITE);
			setPanelSize(containerEast, new Dimension((dimension.width/3*2), dimension.height));

			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.1;
			gc.weighty = 0.1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,0,0);
			container.add(containerWest, gc);
		
			gc.gridx = 1;			
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			container.add(containerEast, gc);
			
		rootpanel.add(container);
		rootpanel.add(Box.createVerticalStrut(10));				
	}
	
	private void addWhenWillTheNextMeetingBePanel() {
		GridBagConstraints gc = new GridBagConstraints();
		
		int containerheights = 70;
		
		Dimension dimension = new Dimension(screenWidth, containerheights);
	
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, dimension);
		
			JPanel containerWest = new JPanel(new GridBagLayout());
			containerWest.setBackground(Color.WHITE);
			setPanelSize(containerWest, new Dimension(dimension.width/3, dimension.height));
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,20,0,20);
			containerWest.add(new JLabel("When will the next meeting be?"), gc);
			
			
			gc.gridy = 1;
			gc.fill = GridBagConstraints.BOTH;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,20,10,0);
			containerWest.add(txtAreaWhenIsTheNextMeeting, gc);
			
			JPanel containerEast = new JPanel(new GridBagLayout());
			containerEast.setBackground(Color.WHITE);
			setPanelSize(containerEast, new Dimension((dimension.width/3*2), dimension.height));

			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.1;
			gc.weighty = 0.1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,0,0);
			container.add(containerWest, gc);
		
			gc.gridx = 1;			
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			container.add(containerEast, gc);
			
		rootpanel.add(container);
		rootpanel.add(Box.createVerticalStrut(10));			
	}
	
	
	private void addAddionalNotesPanel() {
		GridBagConstraints gc = new GridBagConstraints();
		
		int containerheights = 100;
		
		Dimension dimension = new Dimension(screenWidth, containerheights);
	
		JPanel container = new JPanel(new GridBagLayout());
		container.setBackground(Color.WHITE);
		setPanelSize(container, dimension);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,20,0,20);
			container.add(new JLabel("Additional notes:"), gc);
			
			
			gc.gridy = 1;
			gc.fill = GridBagConstraints.BOTH;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,20,0,20);
			container.add(txtAreaAdditionalNotes, gc);
			
			
		rootpanel.add(container);
		rootpanel.add(Box.createVerticalStrut(10));			
	}
	
	
	
	private void addHeadingAndSubText() {
		
		GridBagConstraints gc = new GridBagConstraints();
		
		JPanel content = new JPanel(new GridBagLayout());
		setPanelSize(content, new Dimension(screenWidth, 80));
		content.setBackground(Color.WHITE);
		
		JLabel pageTitle = new JLabel("Step 5: Conclusion");
		pageTitle.setFont(pageTitle.getFont().deriveFont(16.0f));
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(15,20,0,0);
		content.add(pageTitle, gc);
		
		
		JPanel row1 = new JPanel(new GridBagLayout());
		setPanelSize(row1, new Dimension(screenWidth, 40));
		row1.setBackground(Color.WHITE);
		
		JTextPane row1Text = new JTextPane();
		row1Text.setFont(row1Text.getFont().deriveFont(11.0f));
		row1Text.setForeground(UI_Settings.getComponentsFontColorDark());
		row1Text.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(row1Text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0);
		
		row1Text.setParagraphAttributes(set, true);

		row1Text.setText("Summarize the practical methods and key points outlined during your learning session. Also define "
				+ "the next step in the process including next meetings, deliverables and any extra notes that you may have.");
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,20,0,0);
		row1.add(row1Text, gc);
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(0,0,0,0);
		content.add(row1, gc);
		content.setAlignmentY(Component.LEFT_ALIGNMENT);
		this.rootpanel.add(content);
	}
	
	private void initializeListeners() {
		
		previousStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		previousStepTextButton.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				JScrollPane scroller = sessionObject.getScroller();

				if(scroller != null){
					 scroller.getViewport().setViewPosition(new Point(0,0));
				 }
				
				 sessionObject.resetLocatorColors();
				 sessionObject.locator4.setBackground(CreateTrainingSessionPanel.LOCATOR_ACTIVE_COLOR);
				 CardLayout cl = (CardLayout)(sessionObject.cards.getLayout());
				 cl.show(sessionObject.cards, CreateTrainingSessionPanel.STEP4);
			}
			
		});
	}
	
	private void addNextStepRow() {
		
		nextStepTextButton.setFont(nextStepTextButton.getFont().deriveFont(12.0f));
		previousStepTextButton.setFont(previousStepTextButton.getFont().deriveFont(12.0f));

		nextStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());
		previousStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());


		JPanel container = new JPanel();
		container.setBackground(Color.WHITE);
		container.setLayout(new BoxLayout(container, BoxLayout.X_AXIS));
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(previousStepTextButton);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		//rightPanel.add(nextStepTextButton);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		container.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		container.add(rightPanel);
		
		this.rootpanel.add(container);
	}
	
	@SuppressWarnings("unused")
	private void initializeTextArea(JTextArea textarea) {
		textarea.setEditable(true);
		textarea.setWrapStyleWord(true);
		textarea.setLineWrap(true);
		textarea.setDocument(new JTextFieldLimit(150));
		textarea.setBorder(UI_Settings.getBorderoutline());
		textarea.setPreferredSize(textarea.getPreferredSize());
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
	
	private void initializeButtons(JButton button) {
		button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		button.setPreferredSize(new Dimension(100,UI_Settings.getJbuttonSize().height));
		button.setMinimumSize(new Dimension(100,UI_Settings.getJbuttonSize().height));
		button.setFont(UI_Settings.getComponentInputFontSize());		
	}

}
