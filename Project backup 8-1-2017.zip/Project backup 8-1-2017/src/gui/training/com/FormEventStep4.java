package gui.training.com;

import java.util.EventObject;

public class FormEventStep4 extends EventObject {

	public FormEventStep4(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
