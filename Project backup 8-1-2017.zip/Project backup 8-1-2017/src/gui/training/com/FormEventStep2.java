package gui.training.com;

import java.util.ArrayList;
import java.util.EventObject;
import java.util.List;

public class FormEventStep2 extends EventObject {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String subTopic1Title;
	String subTopic1WhatDoEmployeesNeedToLearn;
	String subTopic1WhyImportant;
	List<String> subTopic1TrainingToolsArray = new ArrayList<String>();

	String subTopic2Title;
	String subTopic2WhatDoEmployeesNeedToLearn;
	String subTopic2WhyImportant;
	List<String> subTopic2TrainingToolsArray = new ArrayList<String>();



	public FormEventStep2(Object source, String subTopic1Title, String subTopic1WhatDoEmployeesNeedToLearn, String subTopic1WhyImportant, 
			List<String> subTopic1TrainingToolsArray, String subTopic2Title, String subTopic2WhatDoEmployeesNeedToLearn, String subTopic2WhyImportant, 
			List<String> subTopic2TrainingToolsArray) {
		super(source);
		
		this.subTopic1TrainingToolsArray.clear();
		this.subTopic2TrainingToolsArray.clear();
		
		
		this.subTopic1Title = subTopic1Title;
		this.subTopic1WhatDoEmployeesNeedToLearn = subTopic1WhatDoEmployeesNeedToLearn;
		this.subTopic1WhyImportant = subTopic1WhyImportant;
		this.subTopic1TrainingToolsArray = subTopic1TrainingToolsArray;
		
		this.subTopic2Title = subTopic2Title;
		this.subTopic2WhatDoEmployeesNeedToLearn = subTopic2WhatDoEmployeesNeedToLearn;
		this.subTopic2WhyImportant = subTopic2WhyImportant;
		this.subTopic2TrainingToolsArray = subTopic2TrainingToolsArray;
	}


	public String getSubTopic1Title() {
		return subTopic1Title;
	}



	public void setSubTopic1Title(String subTopic1Title) {
		this.subTopic1Title = subTopic1Title;
	}



	public String getSubTopic1WhatDoEmployeesNeedToLearn() {
		return subTopic1WhatDoEmployeesNeedToLearn;
	}



	public void setSubTopic1WhatDoEmployeesNeedToLearn(String subTopic1WhatDoEmployeesNeedToLearn) {
		this.subTopic1WhatDoEmployeesNeedToLearn = subTopic1WhatDoEmployeesNeedToLearn;
	}



	public String getSubTopic1WhyImportant() {
		return subTopic1WhyImportant;
	}



	public void setSubTopic1WhyImportant(String subTopic1WhyImportant) {
		this.subTopic1WhyImportant = subTopic1WhyImportant;
	}



	public List<String> getSubTopic1TrainingToolsArray() {
		return subTopic1TrainingToolsArray;
	}



	public void setSubTopic1TrainingToolsArray(List<String> subTopic1TrainingToolsArray) {
		this.subTopic1TrainingToolsArray = subTopic1TrainingToolsArray;
	}



	public String getSubTopic2Title() {
		return subTopic2Title;
	}



	public void setSubTopic2Title(String subTopic2Title) {
		this.subTopic2Title = subTopic2Title;
	}



	public String getSubTopic2WhatDoEmployeesNeedToLearn() {
		return subTopic2WhatDoEmployeesNeedToLearn;
	}



	public void setSubTopic2WhatDoEmployeesNeedToLearn(String subTopic2WhatDoEmployeesNeedToLearn) {
		this.subTopic2WhatDoEmployeesNeedToLearn = subTopic2WhatDoEmployeesNeedToLearn;
	}



	public String getSubTopic2WhyImportant() {
		return subTopic2WhyImportant;
	}



	public void setSubTopic2WhyImportant(String subTopic2WhyImportant) {
		this.subTopic2WhyImportant = subTopic2WhyImportant;
	}



	public List<String> getSubTopic2TrainingToolsArray() {
		return subTopic2TrainingToolsArray;
	}



	public void setSubTopic2TrainingToolsArray(List<String> subTopic2TrainingToolsArray) {
		this.subTopic2TrainingToolsArray = subTopic2TrainingToolsArray;
	}

}
