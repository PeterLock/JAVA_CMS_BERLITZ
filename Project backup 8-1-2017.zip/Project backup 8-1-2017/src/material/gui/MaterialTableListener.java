package material.gui;

public interface MaterialTableListener {
	public void rowDeleted(int row);
}
