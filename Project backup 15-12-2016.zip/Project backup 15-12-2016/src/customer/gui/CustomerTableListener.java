package customer.gui;

public interface CustomerTableListener {
	public void rowDeleted(int row);
}
