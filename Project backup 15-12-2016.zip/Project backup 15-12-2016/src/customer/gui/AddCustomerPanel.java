package customer.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import control.gui.FormListener;
import customer.controller.Controller;
import customer.model.Customer;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class AddCustomerPanel extends JPanel {
	
	
	private static final long serialVersionUID = 1L;
	private JTabbedPane pane = new JTabbedPane();
	JPasswordField passwordField;
    JFrame controllingFrame; 
    private Controller controller;
	private UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	private List<JCheckBox> checkboxes = new ArrayList<JCheckBox>();
	
    private TablePanel addnew_table_panel = new TablePanel();
    private TablePanel viewall_table_panel = new TablePanel();
    private JPanel threeDotsPanel;
    
    private JPanel container;
	private JPanel container_left;
	private JPanel container_right;
	
	private JComboBox<String> cmbMonths = new JComboBox<String>(UI_Settings.getMonths());
	private JComboBox<String> cmbLevel = new JComboBox<String>(UI_Settings.getLevels());
	private JComboBox<String> cmbMaterial = new JComboBox<String>(UI_Settings.getBooks());
	private JComboBox<String> cmbGroupNameListCombobox = new JComboBox<String>(UI_Settings.getGroups());
	
	
	private List<JComboBox> comboboxes = new ArrayList<JComboBox>();

    
    private FormListener formListener;
    
    
	public AddCustomerPanel(customer.controller.Controller controller){
		this.controller = controller;
	}
	
	public Component run(){
		
		JScrollPane scroller = intialize();
		
		return scroller;
	}

	private JScrollPane intialize() {
		
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel = new JPanel();
		
		initializeComboBoxes(cmbMaterial);
		initializeComboBoxes(cmbLevel);
		initializeComboBoxes(cmbMonths);
		initializeComboBoxes(cmbGroupNameListCombobox);
		
		/****************************Create the canvas**************************/
		
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(UI_Settings.getButtonPanelColor());
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		detailsPanel.setLayout(new GridBagLayout());
		
		//Create the GridBagConstraints object
		GridBagConstraints gc = new GridBagConstraints();
		
		
		threeDotsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 3));
		threeDotsPanel.setVisible(false);
		
		int tableWindowHeight = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height/3;
		int tableRowNumber = tableWindowHeight/UI_Settings.getTableRowHeight()+3;
		
		controller.setRowNumber(tableRowNumber);
		addnew_table_panel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		addnew_table_panel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		addnew_table_panel.setData(Controller.getCustomer(GET_ADDNEW_TABLE_CUSTOMER_LIST));
		
		
    	for(int i = 0; i < tableRowNumber; i++){
    		FormEvent ev = new FormEvent(this, "", "", 13, "", "", 0);
    		if(controller != null){
        		controller.addCustomer(ev);
    		}
    	}
    	
		addnew_table_panel.setCustomerTableListener(new CustomerTableListener() {
			
			@Override
			public void rowDeleted(int row) {
				controller.removeCustomer(row, 2);
			}
		});
		
		JLabel lblCloseWindow = new JLabel("close panel group [x]");
		lblCloseWindow.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
		JLabel lblCloseWindow2 = new JLabel("close panel group [x]");
		lblCloseWindow2.setForeground(Color.BLACK);
		lblCloseWindow2.setCursor(new Cursor(Cursor.HAND_CURSOR));

		
		@SuppressWarnings("unused")
		TextPrompt textPrompt;
		Border lightBorder = BorderFactory.createLineBorder(new Color(192,192,192));

		/***********************Initialize Fields******************************/
		Calendar c = Calendar.getInstance();
		JLabel lblDate = new JLabel(c.getTime().toString());
		
    	JCheckBox chkNewStudent;
    	JCheckBox chkReturningStudent;
    	
		chkReturningStudent = new JCheckBox("Returning Customer");
		chkReturningStudent.setFont(UI_Settings.getComponentsFontPlain());
		chkReturningStudent.setForeground(UI_Settings.getComponentsFontColorLight());
		chkReturningStudent.setSelected(false);
		
		chkNewStudent = new JCheckBox("New Customer");
		chkNewStudent.setFont(UI_Settings.getComponentsFontPlain());
		chkNewStudent.setForeground(UI_Settings.getComponentsFontColorLight());
		chkNewStudent.setSelected(true);
		
		JLabel labels[] = new JLabel[10];
		
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("...");
		labels[2] = new JLabel("save");
		labels[3] = new JLabel("clear table");
		labels[4] = new JLabel("delete");
		labels[5] = new JLabel("Administrator password");
		labels[6] = new JLabel("help");
		labels[7] = new JLabel("save customer");
		labels[8] = new JLabel("reset fields");
		labels[9] = new JLabel("show details");
		
		labels[1].setFont(labels[1].getFont().deriveFont(18.0f));
		labels[1].setVisible(true);
		labels[1].addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				addnew_table_panel.setVisible(true);
				threeDotsPanel.setVisible(false);
				container.setVisible(true);
				container_left.setVisible(true);
				container_right.setVisible(true);
			}
		});
		
		//Change reset fields color to light blue
		for(int i=0; i < 10; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

		}
		JTextField txtFirstName;
		JTextField txtLastName;
		
		JTextField txtAge;
		
		JTextField txtListen;
		JTextField txtSpeak;
		JTextField txtRead;
		JTextField txtParticipate;
		JTextField txtCooperate;
		
		JTextArea txtAreaComments;
		JTextArea txtAreaInterests;
		
		JButton btnSave;
		
		JCheckBox under_eight = new JCheckBox("4-8");
		JCheckBox eight_twelve = new JCheckBox("8-12");
		JCheckBox twelve_sixteen = new JCheckBox("12-16");
		JCheckBox sixteen_twentyfour = new JCheckBox("16-24");
		JCheckBox twentyfour_up = new JCheckBox("24 >");
		
		checkboxes.add(under_eight);
		checkboxes.add(eight_twelve);
		checkboxes.add(twelve_sixteen);
		checkboxes.add(sixteen_twentyfour);
		checkboxes.add(twentyfour_up);
		
		configure_checkboxes_age();

		
		
		List <JTextField> regular_textfields = new ArrayList<JTextField>();
		List<JTextField> assessment_textfields = new ArrayList<JTextField>();
		
		for(int i = 0; i < checkboxes.size(); i++){
			checkboxes.get(i).setFont(UI_Settings.getComponentsFontPlain());
			checkboxes.get(i).setForeground(UI_Settings.getComponentsFontColorLight());
			checkboxes.get(i).setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		}


		
		JPasswordField passwordField;
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
        

		
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage.setVisible(false);
		
		
		labels[9].addMouseListener(new MouseAdapter(){
			
			@SuppressWarnings("static-access")
			public void mousePressed(MouseEvent e){
				

				JTable table = addnew_table_panel.getTable();
				
				List<Customer> db;
				Customer customer;
				
				int selectedRow = table.convertRowIndexToModel(table.getSelectedRow());
				int selectedRowIndexInModel = table.convertRowIndexToModel(selectedRow);

				if(!(selectedRowIndexInModel == -1)){
					db = controller.getCustomer(GET_ADDNEW_TABLE_CUSTOMER_LIST);
					customer = db.get(selectedRowIndexInModel);
					
					ViewDetailsPanel viewDetails = new ViewDetailsPanel(customer);
					viewDetails.run();
				}
			}
		});
		
		txtAge = new JTextField(5);
		txtAge.setMinimumSize(txtAge.getPreferredSize());
		txtAge.setHorizontalAlignment(JTextField.CENTER);
		regular_textfields.add(txtAge);
		
		txtFirstName = new JTextField(10);
		txtLastName = new JTextField(10);
		
		regular_textfields.add(txtFirstName);
		regular_textfields.add(txtLastName);

		for(int i = 0; i < regular_textfields.size(); i++){
			
			regular_textfields.get(i).setMinimumSize(regular_textfields.get(i).getPreferredSize());
			regular_textfields.get(i).setForeground(UI_Settings.getComponentInputFontColor());

			
		}

		txtListen = new JTextField(28);
		txtSpeak = new JTextField(28);
		txtRead = new JTextField(28);
		txtParticipate = new JTextField(28);
		txtCooperate = new JTextField(28);
		
		assessment_textfields.add(txtCooperate); 
		assessment_textfields.add(txtParticipate); 
		assessment_textfields.add(txtRead); 
		assessment_textfields.add(txtSpeak); 
		assessment_textfields.add(txtListen); 
		
		
		addFocus(txtAge);
		addFocus(passwordField);
		
		for(int i = 0; i < assessment_textfields.size(); i++){
			assessment_textfields.get(i).setMinimumSize(assessment_textfields.get(i).getPreferredSize());
			assessment_textfields.get(i).setEditable(true);
			assessment_textfields.get(i).setHorizontalAlignment(JTextField.CENTER);
			textPrompt = new TextPrompt("0/5", assessment_textfields.get(i));
			addFocus(assessment_textfields.get(i));
			assessment_textfields.get(i).setForeground(UI_Settings.getComponentInputFontColor());
		}
		
		
		
		/********************************************************Text Areas*************************************************************/
		txtAreaComments = new JTextArea(3, 42);
		txtAreaComments.setEditable(true);
		txtAreaComments.setBorder(UI_Settings.getBorderoutline());
		txtAreaComments.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaComments.setWrapStyleWord(true);
		txtAreaComments.setLineWrap(true);
		txtAreaComments.setDocument(new JTextFieldLimit(150));
		txtAreaComments.setBorder(lightBorder);
		txtAreaComments.setPreferredSize(txtAreaComments.getPreferredSize());
		@SuppressWarnings("unused")
		TextPrompt prompt = new TextPrompt("<no comments added>", txtAreaComments);
		
		
		txtAreaInterests = new JTextArea(3, 42);
		txtAreaInterests.setEditable(true);
		txtAreaInterests.setBorder(UI_Settings.getBorderoutline());
		txtAreaInterests.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaInterests.setWrapStyleWord(true);
		txtAreaInterests.setLineWrap(true);
		txtAreaInterests.setDocument(new JTextFieldLimit(150));
		txtAreaInterests.setBorder(lightBorder);
		txtAreaInterests.setPreferredSize(txtAreaInterests.getPreferredSize());
		prompt = new TextPrompt("<no interests added>", txtAreaInterests);
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
			   int action = JOptionPane.showConfirmDialog(AddCustomerPanel.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
			   
		       if(action == JOptionPane.OK_OPTION){
		    	   
		    	   controller.setRowNumber(tableRowNumber);
		    	   controller.clearAddCustomerTable();
		    	   
		    	   //Reset the tables values//
			       	for(int i = 0; i < tableRowNumber; i++){
			    		FormEvent ev = new FormEvent(this, "", "", 13, "", "", 0);
			    		controller.addCustomer(ev);
			    		addnew_table_panel.refresh();
			    	}
		    		//////////////////////////
		    	   
		    	   failedMessage.setVisible(false);
		    	   
		    	   cmbMaterial.setSelectedIndex(0);
		    	   cmbMonths.setSelectedIndex(0);
		    	   cmbLevel.setSelectedIndex(0);
			   	   txtFirstName.setText("");
				   txtLastName.setText("");
				   
				   txtListen.setText("");
				   txtSpeak.setText("");
				   txtRead.setText("");
				   txtParticipate.setText("");
				   txtCooperate.setText("");
				   txtAreaComments.setText("");
				   txtAreaInterests.setText("");
				   
				   txtAge.setText("");
				   
		       }
			}
		});
	
		/****************************Create the canvas**************************/
		
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		
		/**********************************************************Card layout for the details panel********************************************************/
		//Contains the Add New Student and Existing Student CheckBoxes
		JPanel checkBoxesPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		checkBoxesPanel.setBackground(UI_Settings.getButtonPanelColor());
		checkBoxesPanel.add(chkNewStudent);
		checkBoxesPanel.add(chkReturningStudent);
		checkBoxesPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableButtonsPanelHeight()+10));
		checkBoxesPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableButtonsPanelHeight()+10));

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 10;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		
		detailsPanel.add(checkBoxesPanel, gc);
		/////////////////////////////////////////////////////Card 1 - New Customer//////////////////////////////////////////////
		
		gc.gridx = 0;
		gc.gridy = 2;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,10,13,10);
		detailsPanel.add(new JLabel("Customer Name:"), gc); //Customer name label
		
		//////////////////////////////////////////Begin Column 2 ///////////////////////////////////////////
		gc.gridx = 1;
		gc.gridy = 1;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(-7,12,7,-12);
		detailsPanel.add(new JLabel("First Name"), gc); //FirstName Label

		gc.gridx = 1;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-7,5,7,5);
		detailsPanel.add(txtFirstName, gc); //FirstName TextField
		
		//////////////////////////////////////////Begin Column 3 ///////////////////////////////////////////
		gc.gridx = 2;
		gc.gridy = 1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(-7,5,7,5);
		detailsPanel.add(new JLabel("Last Name"), gc); //Last Name Label

		gc.gridx = 2;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-7,5,7,5);
		detailsPanel.add(txtLastName, gc); //Last Name TextField
		//////////////////////////////////////////Begin Column 4///////////////////////////////////////////	
		gc.gridx = 3;
		gc.gridy = 2;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,5,13,5);
		detailsPanel.add(new JLabel("Month Started:"), gc); //Month started label
		//////////////////////////////////////////Begin Column 5///////////////////////////////////////////	

		gc.gridx = 4;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-8,5,8,5);
		detailsPanel.add(cmbMonths, gc); //Month started combo
		//////////////////////////////////////////Begin Column 6///////////////////////////////////////////		

		
		gc.gridx = 5;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,5,13,5);
		detailsPanel.add(new JLabel("Material:"), gc); //Material label
		//////////////////////////////////////////Begin Column 7///////////////////////////////////////////		

		gc.gridx = 7;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-12,5,12,5);
		detailsPanel.add(cmbMaterial, gc); //Materials Title ComboBox
		//////////////////////////////////////////Begin Column 8///////////////////////////////////////////	

		gc.gridx = 8;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,5,13,5);
		detailsPanel.add(new JLabel("Level:"), gc); //Level label
		//////////////////////////////////////////Begin Column 9///////////////////////////////////////////	
		gc.gridx = 9;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-11,5,11,5);
		detailsPanel.add(cmbLevel, gc); //Level combo
		//////////////////////////////////////////Set the GC for the save, search, and reset buttons///////////////////////////////////////////	
		gc.gridx = 0;
		gc.gridy = 6;
		gc.gridheight = 1;
		gc.gridwidth = 12;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,0,-5,0);
		/******************************************************Add the Buttons Panel************************************************/

		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);

		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(Color.WHITE);
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		/////////////////////////////////////////////////////////////////////////////////////
		JPanel clearTableButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 7));
		setPanelSize(clearTableButtonPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 20));
		clearTableButtonPanel.add(labels[3]);
		clearTableButtonPanel.setBackground(Color.WHITE);
		
		setPanelSize(threeDotsPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 20));
		threeDotsPanel.add(labels[1]);
		threeDotsPanel.setBackground(Color.WHITE);
		
		
		int container_height = 200;
		container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, container_height-10));
		container.setBackground(Color.WHITE);
		
		container_left = new JPanel(new GridBagLayout());
		container_left.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, container_height-20));
		container_left.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, container_height-20));
		container_left.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, container_height-20));
		container_left.setBorder(lightBorder);

		
		container_left.setBackground(Color.WHITE);
		lblCloseWindow.addMouseListener(new MouseAdapter(){
			
			public void mouseReleased(MouseEvent e){
				container.setVisible(false);
				threeDotsPanel.setVisible(true);
			}
			
		});
		Dimension dimension = new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getPopupHeaderHeight());
		JPanel header = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
		header.setBorder(new EmptyBorder(0,0,0,0));
		header.setBackground(new Color(191,210,236));
		setPanelSize(header, dimension);
		header.add(lblCloseWindow);
			
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		container_left.add(header, gc);
		
		JPanel container_left_body = new JPanel(new GridBagLayout());
		setPanelSize(container_left_body, new Dimension(dimension.width, container_height-50-UI_Settings.getPopupHeaderHeight()));
		container_left_body.setBackground(Color.WHITE);
		
			////////////////////////////CONTAINER LEFT BODY/////////////////////////
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.1;
			gc.weighty = 0.1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(5,20,0,20);
			container_left_body.add(new JLabel("Listening:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(5,10,0,20);
			container_left_body.add(txtListen, gc);
			
			gc.gridx = 0;
			gc.gridy = 2;
			gc.fill = GridBagConstraints.NONE;
			gc.insets = new Insets(2,20,0,20);
			container_left_body.add(new JLabel("Speaking:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 2;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(2,10,0,20);
			container_left_body.add(txtSpeak, gc);
		
			gc.gridx = 0;
			gc.gridy = 3;
			gc.fill = GridBagConstraints.NONE;
			gc.insets = new Insets(2,20,0,20);
			container_left_body.add(new JLabel("Reading:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 3;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(2,10,0,20);
			container_left_body.add(txtRead, gc);
			
			gc.gridx = 0;
			gc.gridy = 4;
			gc.fill = GridBagConstraints.NONE;
			gc.insets = new Insets(2,20,0,20);
			container_left_body.add(new JLabel("Participation:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 4;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(2,10,0,20);
			container_left_body.add(txtParticipate, gc);
			
			gc.gridx = 0;
			gc.gridy = 5;
			gc.fill = GridBagConstraints.NONE;
			gc.insets = new Insets(2,20,5,20);
			container_left_body.add(new JLabel("Cooperation:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(2,10,5,20);
			container_left_body.add(txtCooperate, gc);
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		container_left.add(container_left_body, gc);
		
		
		
		container_right = new JPanel(new GridBagLayout());
		setPanelSize(container_right, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, container_height-20));
		container_right.setBackground(Color.WHITE);
		container_right.setBorder(lightBorder);

		
		lblCloseWindow2.addMouseListener(new MouseAdapter(){
			
			public void mouseReleased(MouseEvent e){
				container.setVisible(false);
				threeDotsPanel.setVisible(true);
			}
			
		});
		
		JPanel header2 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
		header2.setBorder(new EmptyBorder(0,0,0,0));
		header2.setBackground(new Color(191,210,236));
		setPanelSize(header2, dimension);
		header2.add(lblCloseWindow2);
			
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		container_right.add(header2, gc);
		
		
		////////////////////////////CONTAINER RIGHT BODY/////////////////////////
		
		JPanel customerAgePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 30, 0));
		customerAgePanel.setBackground(Color.WHITE);
		customerAgePanel.add(new JLabel("Age:"));

		customerAgePanel.add(checkboxes.get(0));//age 4-8
		customerAgePanel.add(checkboxes.get(1));//age 8-12
		customerAgePanel.add(checkboxes.get(2));//age 12-16
		customerAgePanel.add(checkboxes.get(3));//age 16-24
		customerAgePanel.add(checkboxes.get(4));//age 24>
	
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 2;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,5,0,5);
		container_right.add(customerAgePanel, gc);
		
		
		JPanel container_right_body = new JPanel(new GridBagLayout());
		setPanelSize(container_right_body, new Dimension(dimension.width, container_height-50-UI_Settings.getPopupHeaderHeight()));
		container_right_body.setBackground(Color.WHITE);
		
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(-15,30,5,5);
			container_right_body.add(new JLabel("Interests:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(10,5,5,15);
			container_right_body.add(txtAreaInterests, gc);
			
			gc.gridx = 0;
			gc.gridy = 2;
			gc.gridheight = 1;
			gc.gridwidth = 2;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.CENTER;
			gc.insets = new Insets(-25,30,5,5);
			container_right_body.add(new JLabel("Comments:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 2;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(-5,5,5,15);
			container_right_body.add(txtAreaComments, gc);
			
			
		gc.gridx = 0;
		gc.gridy = 2;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		container_right.add(container_right_body, gc);

		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,5,0,0);
		container.add(container_left, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,10,0,10);
		container.add(container_right, gc);
		
		
		
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlSaveRow = new JPanel();
		pnlSaveRow.setBackground(Color.WHITE);
		pnlSaveRow.setLayout(new GridBagLayout());
		pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

			//Create the far left container for the group details information
			JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
			pnlSaveLeftPane.setBackground(Color.WHITE);
			pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
				
				JPanel panel3 = new JPanel(new GridBagLayout());
				panel3.setBackground(Color.WHITE);
				panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				
				
				JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row1.setBackground(Color.WHITE);
				row1.add(new JLabel("Table refreshed:"));
				row1.add(lblDate);
				
				JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row2.setBackground(Color.WHITE);
				row2.add(new JLabel("Connected to: " + controller.getDBname()));
				
				JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row3.setBackground(Color.WHITE);
				row3.add(new JLabel("Connection: Secure"));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(30,5,0,5);
			
				panel3.add(row1, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,5);
			
				panel3.add(row2, gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,45,5);
			
				panel3.add(row3, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,5);
			
				pnlSaveLeftPane.add(panel3, gc);
		
		pnlSaveRow.add(pnlSaveLeftPane, gc);
			
		//////////////////////////////////////////Main Column 2 ///////////////////////////////////////////
		//Create the second panel from the left (comments panel)

		JPanel pnlSaveRight = new JPanel(new GridBagLayout());
		pnlSaveRight.setBackground(Color.WHITE);
		pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));

		

		
			//Add the nested panels to the container panel (comments panel)
			
			JPanel pblButtons = new JPanel(new GridBagLayout());
			pblButtons.setBackground(Color.WHITE);
			pblButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pblButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pblButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			
			JPanel panel4 = new JPanel(new GridBagLayout());
			panel4.setBackground(Color.WHITE);
			panel4.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
			panel4.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
			panel4.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));

			btnSave = new JButton("Add New Customer");
			btnSave.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnSave.setPreferredSize(new Dimension(170,UI_Settings.getJbuttonSize().height));
			btnSave.setMinimumSize(new Dimension(170,UI_Settings.getJbuttonSize().height));
			btnSave.setFont(UI_Settings.getComponentInputFontSize());
			btnSave.addMouseListener(new MouseAdapter(){
				
				String firstName;
				String lastName;
				int month;
				String material;
				String level;
				int id;
				int listen;
				int speak;
				int read;
				int par;
				int coop;
				String ag;
				
				String interests;
				String comments;

				public void mousePressed(MouseEvent e) {
					firstName = txtFirstName.getText();
					lastName = txtLastName.getText();
					month = cmbMonths.getSelectedIndex();
					material = (String)cmbMaterial.getSelectedItem();
					level = (String)cmbLevel.getSelectedItem();
					interests = txtAreaInterests.getText();
					comments = txtAreaComments.getText();
					
					
					try{
						final int listentemp = Integer.parseInt(txtListen.getText());
						listen = listentemp;
						txtListen.setText(listen + "/5");
					} catch(NumberFormatException ec){
						txtListen.setText("0/5");
						listen = 0;
					}
					
					try{
						final int speaktemp = Integer.parseInt(txtSpeak.getText());
						speak = speaktemp;
						txtSpeak.setText(speak + "/5");
					} catch(NumberFormatException ec){
						txtSpeak.setText("0/5");
						speak = 0;
					}
					
					try{
						final int readtemp = Integer.parseInt(txtRead.getText());
						read = readtemp;
						txtRead.setText(read + "/5");
					} catch(NumberFormatException ec){
						txtRead.setText("0/5");
						read = 0;
					}
					
					try{
						final int partemp = Integer.parseInt(txtParticipate.getText());
						par = partemp;
						txtParticipate.setText(par + "/5");
					} catch(NumberFormatException ec){
						txtParticipate.setText("0/5");
						par = 0;
					}
					
					try{
						final int cooptemp = Integer.parseInt(txtCooperate.getText());
						coop = cooptemp;
						txtCooperate.setText(coop + "/5");
					} catch(NumberFormatException ec){
						txtCooperate.setText("0/5");
						coop = 0;
					}
					
					if(checkboxes.get(0).isSelected()){
						ag = "4-8";
					}
					
					if(checkboxes.get(1).isSelected()){
						ag = "8-12";
					}
					
					if(checkboxes.get(2).isSelected()){
						ag = "12-16";
					}
					
					if(checkboxes.get(3).isSelected()){
						ag = "16-24";
					}
					
					if(checkboxes.get(4).isSelected()){
						ag = "24 >";
					}
					
				}
				
				public void mouseReleased(MouseEvent e){
					int temp = idGenerator.getUniqueCustomerID();
					id=temp;
					
					FormEvent ev = new FormEvent(this, firstName, lastName, month, material, level, id, listen, speak, read, par, coop, ag, interests, comments);
					
					if(formListener == null){
						System.out.println("CustomerPane :: formListener==null");
					}
					
					ConfirmSavePane panel = new ConfirmSavePane(ev, formListener, addnew_table_panel, controller);
					panel.run();
					
					repaint();
					
					Calendar c = Calendar.getInstance();
					lblDate.setText(c.getTime().toString());
					
/*					if(checkValues()){
						
						SentryModule module = new SentryModule();
						
				           char[] input = passwordField.getPassword();
				            if (module.takeInput(input)) {
				            	
				                JOptionPane.showMessageDialog(controllingFrame,
				                    "Welcome administrator. The customer has been saved.");
								
								//resetComponents();
								
								FormEvent ev = new FormEvent(this, firstName, lastName, month, material, level, id);
				
								
								customerController.addCustomer(ev);
								
								tablePanel.refresh();
								
				                
				            } else {
				                JOptionPane.showMessageDialog(controllingFrame,
				                    "To save a customer please enter the correct password.",
				                    "Message",
				                    JOptionPane.ERROR_MESSAGE);
				            }
				            //Zero out the possible password, for security.
				            Arrays.fill(input, '0');
		
				            passwordField.selectAll();
						}*/
				}
				
				
				
				private void resetComponents() {
					failedMessage.setVisible(false);
				}
				
				
				
				private boolean checkValues() {
					if(firstName.isEmpty() && lastName.isEmpty() && material.isEmpty() && level.isEmpty()) {
						
						failedMessage.setVisible(true);
						
						txtFirstName.setBackground(UI_Settings.getComponentErrorColor());
						txtLastName.setBackground(UI_Settings.getComponentErrorColor());

						
						cmbMonths.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						cmbLevel.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						cmbMaterial.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
						
						//JOptionPane.showMessageDialog(CustomerPane.this, UI_Settings.getDlgSearchStudentFail(), "", JOptionPane.WARNING_MESSAGE);

						return false;
					}
					return true;
				}
			});
			
			labels[6].setCursor(UI_Settings.getJlabelCursor());
			labels[6].addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){
					
					JOptionPane.showMessageDialog(controllingFrame,
			                "The administrator password can be found with the \"Kids Coordinator\"\n"
			              + "or by contacting your \"Branch Manager\".");
					
				}
			});
			JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 3));
			adminPanel.setBackground(Color.WHITE);
			adminPanel.add(new JLabel("Administrator password:"));
			adminPanel.add(passwordField);
			adminPanel.add(labels[6]);
			adminPanel.add(btnSave);

			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTH;
			gc.insets = new Insets(15,0,0,0);
			
			panel4.add(adminPanel, gc);
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTH;
			gc.insets = new Insets(0,0,0,10);
			
			pblButtons.add(panel4, gc);
			
			//Add the comments panel	
			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,-5,0,0);
			
			pnlSaveRight.add(pblButtons, gc);
			
			//Add the nested panels to the container panel (information panel)
			pnlSaveRow.add(pnlSaveRight, gc);
	
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());

        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        addnew_table_panel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(addnew_table_panel);
        
        clearTableButtonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(clearTableButtonPanel);
        
        
        threeDotsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(threeDotsPanel);
        
        centerPanel.add(Box.createVerticalStrut(20));
        
        container.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(container);
        
        centerPanel.add(Box.createVerticalStrut(5));
        
        pnlSaveRow.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlSaveRow);
        
		/*********************************************************************************************************************************/
		/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 900));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 900));
		
			//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());		
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
		
		return scroller;
	}
	
	private void addFocus(JTextField jTextField) {
		jTextField.addFocusListener(new FocusListener() {
		      public void focusGained(FocusEvent e) {
		        jTextField.setText("");
		      }

		      public void focusLost(FocusEvent e) {
		    	  
		      }
		    });
	}


	public void setFormListener(FormListener listener){
		this.formListener = listener;
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
	
	private void configure_checkboxes_age() {
		
		ItemListener listener = new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				
				if(e.getStateChange() == ItemEvent.SELECTED){
					
					if(e.getItem() == checkboxes.get(0)){
						resetCheckBoxDays(0);
					}
					
					if(e.getItem() == checkboxes.get(1)){
						resetCheckBoxDays(1);
					}
					
					if(e.getItem() == checkboxes.get(2)){
						resetCheckBoxDays(2);
					}
					
					if(e.getItem() == checkboxes.get(3)){
						resetCheckBoxDays(3);
					}
					if(e.getItem() == checkboxes.get(4)){
						resetCheckBoxDays(4);
					}
				}
			}

			private void resetCheckBoxDays(int j) {
				
				for(int i = 0; i < checkboxes.size(); i++){
					if(j != i){
						checkboxes.get(i).setSelected(false);
					}
				}
				
			}
		};
		
		for(int i = 0; i < checkboxes.size(); i++){
			checkboxes.get(i).addItemListener(listener);
		}
	}


	public void refresh() {
		addnew_table_panel.refresh();
		viewall_table_panel.refresh();
	}



	public void resetPanels() {
		container.setVisible(true);
		container_left.setVisible(true);
		container_right.setVisible(true);
		threeDotsPanel.setVisible(false);
	}


	public void switchTabs() {
		pane.setSelectedIndex(1);
	}
	
	private void initializeComboBoxes(JComboBox<String> comboboxes) {
		
		comboboxes.setFont(UI_Settings.getComponentInputFontSize());
		comboboxes.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		comboboxes.setMinimumSize(comboboxes.getPreferredSize());
		
		this.comboboxes.add(comboboxes);		
	}
	
	private final static int GET_VIEWALL_TABLE_CUSTOMER_LIST = 1;
	private final static int GET_ADDNEW_TABLE_CUSTOMER_LIST = 2;

}
