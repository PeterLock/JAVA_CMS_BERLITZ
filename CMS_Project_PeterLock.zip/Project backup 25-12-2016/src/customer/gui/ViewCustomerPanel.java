package customer.gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import control.gui.FormListener;
import customer.controller.Controller;
import customer.model.Customer;
import settings.UI_Settings;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class ViewCustomerPanel extends JPanel {
	
	private static final long serialVersionUID = 1L;
	private JTabbedPane pane = new JTabbedPane();
	private JPasswordField passwordField;
    private JFrame controllingFrame; 
    private Controller controller;
	private UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	private List<JCheckBox> checkboxes = new ArrayList<JCheckBox>();
	
    private TablePanel addnew_table_panel = new TablePanel();
    private TablePanel viewall_table_panel = new TablePanel();
    private JPanel threeDotsPanel;
    
    private JPanel header;
    private JPanel container;
	private JPanel container_left;
	private JPanel container_right;
	private JPanel canvas;
	private JPanel detailsPanel;
	private JPanel centerPanel = new JPanel();
	
	private JComboBox<String> cmbMonths = new JComboBox<String>(UI_Settings.getMonths());
	private JComboBox<String> cmbLevel = new JComboBox<String>(UI_Settings.getLevels());
	private JComboBox<String> cmbMaterial = new JComboBox<String>(UI_Settings.getBooks());
	private JComboBox<String> cmbGroupNameListCombobox = new JComboBox<String>(UI_Settings.getGroups());
	
	
	private List<JComboBox> comboboxes = new ArrayList<JComboBox>();

    
    private FormListener formListener;
	
	public ViewCustomerPanel(customer.controller.Controller controller){
		this.controller = controller;
	}
	
	public Component run(){
		
		JScrollPane scroller = initialize();
		
		return scroller;
	}

	private JScrollPane initialize() {
		

		threeDotsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 3));
		threeDotsPanel.setVisible(false);
		
		int tableWindowHeight = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height/2;
		int tableRowNumber = tableWindowHeight/UI_Settings.getTableRowHeight();
		
		controller.setViewAllRowNumber(tableRowNumber);
		viewall_table_panel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		viewall_table_panel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		viewall_table_panel.setData(Controller.getCustomer(GET_VIEWALL_TABLE_CUSTOMER_LIST));
		viewall_table_panel.setCustomerTableListener(new CustomerTableListener() {
			
			@Override
			public void rowDeleted(int row) {
				controller.removeCustomer(row, 1);
			}
		});
		
    	for(int i = 0; i < tableRowNumber; i++){
    		//Add 7 empty rows to the table for its initial load//
    		FormEvent ev = new FormEvent(this, "", "", 13, "", "", 0);
    		
    		if(controller != null){
        		controller.addEmptyCustomer(ev);
    		}
    	}
	
		JButton btnSearch;
		JButton btnDeleteEvent;
		
    	JCheckBox chkNewStudent;
    	JCheckBox chkReturningStudent;
    	
		chkReturningStudent = new JCheckBox("All Customer");
		chkReturningStudent.setFont(UI_Settings.getComponentsFontPlain());
		chkReturningStudent.setForeground(UI_Settings.getComponentsFontColorLight());
		chkReturningStudent.setSelected(false);
		
		chkNewStudent = new JCheckBox("New Customer");
		chkNewStudent.setFont(UI_Settings.getComponentsFontPlain());
		chkNewStudent.setForeground(UI_Settings.getComponentsFontColorLight());
		chkNewStudent.setSelected(true);
		
		
		/**********************************Create CheckBoxes***********************************/
		chkNewStudent.setFont(UI_Settings.getComponentsFontPlain());
		chkNewStudent.setForeground(UI_Settings.getComponentsFontColorLight());
		chkNewStudent.setSelected(true);
		chkNewStudent.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e) {
				if(chkNewStudent.isSelected()==true){
				
					chkReturningStudent.setSelected(false);
					
				}
			}
		});
		
		chkReturningStudent.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				if(chkReturningStudent.isSelected()==true){
				
					chkNewStudent.setSelected(false);
					
				}				
			}
		});
		
		btnDeleteEvent = new JButton("Delete Customer");
		btnDeleteEvent.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnDeleteEvent.setFont(UI_Settings.getComponentInputFontSize());
		btnDeleteEvent.setPreferredSize(new Dimension(200,UI_Settings.getJbuttonSize().height));
		btnDeleteEvent.setMinimumSize(new Dimension(200,UI_Settings.getJbuttonSize().height));
		
		Calendar c = Calendar.getInstance();
		JLabel lblDate = new JLabel(c.getTime().toString());
		@SuppressWarnings("unused")
		TextPrompt textPrompt;
		/***********************Initialize Fields******************************/
		
		JLabel labels[] = new JLabel[9];
		
		labels[0] = new JLabel("clear table");
		labels[1] = new JLabel("show reports for this student");
		labels[2] = new JLabel("save");
		labels[3] = new JLabel("show customer details");
		labels[4] = new JLabel("delete");
		labels[5] = new JLabel("Administrator password");
		labels[6] = new JLabel("help");
		labels[7] = new JLabel("delete customer");
		labels[8] = new JLabel("reset fields");
		
		for(int i=0; i < 9; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		}
		
		//labels[3].setForeground(new Color(244,98,77));
		labels[3].setForeground(UI_Settings.getComponentsFontColorLight());
		
		JTextField txtFirstName;
		JTextField txtLastName;
		
		
		List <JTextField> regular_textfields = new ArrayList<JTextField>();
		
		JPasswordField passwordField;
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
        addFocus(passwordField);
        
		
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage.setVisible(false);

		
		txtFirstName = new JTextField(10);
		txtLastName = new JTextField(10);
		regular_textfields.add(txtFirstName);
		regular_textfields.add(txtLastName);

		for(int i = 0; i < regular_textfields.size(); i++){
			regular_textfields.get(i).setMinimumSize(regular_textfields.get(i).getPreferredSize());
		}
		
		
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(5, 5, 5, 5);
		CompoundBorder border = new CompoundBorder(line, empty);

		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/

		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
			   int action = JOptionPane.showConfirmDialog(ViewCustomerPanel.this, UI_Settings.getResetPrompt(), "", JOptionPane.OK_CANCEL_OPTION);
			   
		       if(action == JOptionPane.OK_OPTION){
		    	   controller.setRowNumber(tableRowNumber);
		    	   controller.clearViewAllTable();
			       for(int i = 0; i < tableRowNumber; i++){
			    		FormEvent ev = new FormEvent(this, "", "", 13, "", "", 0);
			    		controller.addEmptyCustomer(ev);
			    		viewall_table_panel.refresh();
		       	   }
		       }
			}
		});
		
		labels[3].addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				JTable table = viewall_table_panel.getTable();
				
				List<Customer> db;
				Customer customer;
				
				int selectedRow = table.convertRowIndexToModel(table.getSelectedRow());
				int selectedRowIndexInModel = table.convertRowIndexToModel(selectedRow);

				if(!(selectedRowIndexInModel == -1)){
					db = Controller.getCustomer(GET_VIEWALL_TABLE_CUSTOMER_LIST);
					customer = db.get(selectedRowIndexInModel);
					
					ViewDetailsPanel viewDetails = new ViewDetailsPanel(customer);
					viewDetails.run();
				}
				
			}
		});
		
		labels[8].addMouseListener(new MouseAdapter(){
			public void mouseReleased(MouseEvent e){
				txtFirstName.setText("");
				txtLastName.setText("");
				cmbMonths.setSelectedIndex(0);
				cmbMaterial.setSelectedIndex(0);
				cmbLevel.setSelectedIndex(0);
			}
		});
		
		/*****************************************************************************************************************************/

		initializeComboBoxes(cmbMaterial);
		initializeComboBoxes(cmbLevel);
		initializeComboBoxes(cmbMonths);
		initializeComboBoxes(cmbGroupNameListCombobox);
		
		
		btnSearch = new JButton("Search");
		btnSearch.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnSearch.setPreferredSize(UI_Settings.getJbuttonSize());
		btnSearch.setFont(UI_Settings.getComponentInputFontSize());
		
		btnSearch.addMouseListener(new MouseAdapter(){
			
			String firstName;
			String lastName;
			String month;
			String material;
			String level;

			public void mousePressed(MouseEvent e) {
				
				Calendar c = Calendar.getInstance();
				lblDate.setText(c.getTime().toString());
				
				firstName = txtFirstName.getText();
				lastName = txtLastName.getText();
				month = cmbMonths.getSelectedItem().toString();
				material = cmbMaterial.getSelectedItem().toString();
				level = cmbLevel.getSelectedItem().toString();
				
				try {
					controller.search(firstName, lastName, month, material, level);
					viewall_table_panel.refresh();
				} catch (SQLException e1) {
					System.err.print(e1);
				}
				
			}
			
			public void mouseReleased(MouseEvent e){
				
				
				
			}
			
			private boolean checkValues() {
				
				if(firstName.isEmpty() && lastName.isEmpty() && material.isEmpty() && level.isEmpty()) {
					
					failedMessage.setVisible(true);
					
					txtFirstName.setBackground(UI_Settings.getComponentErrorColor());
					txtLastName.setBackground(UI_Settings.getComponentErrorColor());
					
		
					cmbMonths.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
					
					cmbGroupNameListCombobox.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
					cmbLevel.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
					cmbMaterial.getEditor().getEditorComponent().setBackground(UI_Settings.getComponentErrorColor());
					
					//JOptionPane.showMessageDialog(CustomerPane.this, UI_Settings.getDlgSearchStudentFail(), "", JOptionPane.WARNING_MESSAGE);

					return false;
				}
				return true;
			}
		});
		/**********************Create the messages panel***********************/
		GridBagConstraints gc = new GridBagConstraints();

		JPanel heading = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		JLabel lblHeading = new JLabel("Viewing records from the database");
		heading.setBackground(Color.WHITE);
		lblHeading.setFont(lblHeading.getFont().deriveFont(16.0f));
		heading.add(lblHeading);
		
		JPanel headingMessage = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		headingMessage.setBackground(Color.WHITE);
		JLabel lblHeadingMessage = new JLabel("Viewing records from the database is simple. Select from any of the options "
				+ "below and hit search. If you want to delete or edit any of the records found you will need to enter the "
				+ "administrative password.");
		
		headingMessage.add(lblHeadingMessage);
		
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(UI_Settings.getButtonPanelColor());
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 90));
		detailsPanel.setLayout(new GridBagLayout());
		/****************************Create the header**************************/
		header = new JPanel(new GridBagLayout());
		setPanelSize(header, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 160));
		header.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		header.add(heading,gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(-10,0,0,0);
		header.add(headingMessage, gc);
	
		gc.gridy = 2;
		gc.insets = new Insets(0,0,0,0);
		header.add(detailsPanel, gc);
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) );
		/**********************************************************Card layout for the details panel********************************************************/
		//Contains the Add New Student and Existing Student CheckBoxes
		JPanel checkBoxesPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		checkBoxesPanel.setBackground(UI_Settings.getButtonPanelColor());
		checkBoxesPanel.add(chkNewStudent);
		checkBoxesPanel.add(chkReturningStudent);
		checkBoxesPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableButtonsPanelHeight()+10));
		checkBoxesPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableButtonsPanelHeight()+10));

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 10;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,10,0);
		
		detailsPanel.add(checkBoxesPanel, gc);
		/////////////////////////////////////////////////////Card 1 - New Customer//////////////////////////////////////////////
		
		gc.gridx = 0;
		gc.gridy = 2;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,10,13,10);
		detailsPanel.add(new JLabel("Customer Name:"), gc); //Customer name label
		
		//////////////////////////////////////////Begin Column 2 ///////////////////////////////////////////
		gc.gridx = 1;
		gc.gridy = 1;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(-7,12,7,-12);
		detailsPanel.add(new JLabel("First Name"), gc); //FirstName Label

		gc.gridx = 1;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-7,5,7,5);
		detailsPanel.add(txtFirstName, gc); //FirstName TextField
		
		//////////////////////////////////////////Begin Column 3 ///////////////////////////////////////////
		gc.gridx = 2;
		gc.gridy = 1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(-7,5,7,5);
		detailsPanel.add(new JLabel("Last Name"), gc); //Last Name Label

		gc.gridx = 2;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-7,5,7,5);
		detailsPanel.add(txtLastName, gc); //Last Name TextField
		//////////////////////////////////////////Begin Column 4///////////////////////////////////////////	
		gc.gridx = 3;
		gc.gridy = 2;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,5,13,5);
		detailsPanel.add(new JLabel("Month Started:"), gc); //Month started label
		//////////////////////////////////////////Begin Column 5///////////////////////////////////////////	

		gc.gridx = 4;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(-8,5,8,5);
		detailsPanel.add(cmbMonths, gc); //Month started combo
		//////////////////////////////////////////Begin Column 6///////////////////////////////////////////		

		
		gc.gridx = 5;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,5,13,5);
		detailsPanel.add(new JLabel("Material:"), gc); //Material label
		//////////////////////////////////////////Begin Column 7///////////////////////////////////////////		

		gc.gridx = 7;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-8,5,12,5);
		detailsPanel.add(cmbMaterial, gc); //Materials Title ComboBox
		//////////////////////////////////////////Begin Column 8///////////////////////////////////////////	

		gc.gridx = 8;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-13,5,13,5);
		detailsPanel.add(new JLabel("Level:"), gc); //Level label
		//////////////////////////////////////////Begin Column 9///////////////////////////////////////////	
		gc.gridx = 9;
		gc.gridy = 2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(-11,5,11,5);
		detailsPanel.add(cmbLevel, gc); //Level combo
		//////////////////////////////////////////Set the GC for the save, search, and reset buttons///////////////////////////////////////////	
		gc.gridx = 0;
		gc.gridy = 6;
		gc.gridheight = 1;
		gc.gridwidth = 12;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,0,-5,0);
		/******************************************************Add the Buttons Panel************************************************/
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(labels[3]);
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 2));
		rightPanel.setBackground(Color.WHITE);
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[8]);
		rightPanel.add(btnSearch);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);

		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlInformation = new JPanel();
		pnlInformation.setBackground(Color.WHITE);
		pnlInformation.setLayout(new GridBagLayout());
		pnlInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlSaveRow = new JPanel();
		pnlSaveRow.setBackground(Color.WHITE);
		pnlSaveRow.setLayout(new GridBagLayout());
		pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

			//Create the far left container for the group details information
			JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
			pnlSaveLeftPane.setBackground(Color.WHITE);
			pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel panel3 = new JPanel(new GridBagLayout());
				panel3.setBackground(Color.WHITE);
				panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				
				
				JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row1.setBackground(Color.WHITE);
				row1.add(new JLabel("Table updated:"));
				row1.add(lblDate);
				
				JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row2.setBackground(Color.WHITE);
				row2.add(new JLabel("Connected to: " + controller.getDBname()));
				
				JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row3.setBackground(Color.WHITE);
				row3.add(new JLabel("Connection: Secure"));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(30,5,0,5);
			
				panel3.add(row1, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,5);
			
				panel3.add(row2, gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,45,5);
			
				panel3.add(row3, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,5);
			
				pnlSaveLeftPane.add(panel3, gc);
		
		pnlSaveRow.add(pnlSaveLeftPane, gc);
			
		//////////////////////////////////////////Main Column 2 ///////////////////////////////////////////
		//Create the second panel from the left (comments panel)

		JPanel pnlSaveRight = new JPanel(new GridBagLayout());
		pnlSaveRight.setBackground(Color.WHITE);
		pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));

		

		
			//Add the nested panels to the container panel (comments panel)
			
			JPanel pblButtons = new JPanel(new GridBagLayout());
			pblButtons.setBackground(Color.WHITE);
			pblButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
			pblButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
			pblButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
			
			JPanel panel4 = new JPanel(new GridBagLayout());
			//panel4.setBackground(new Color(246,246,246));
			panel4.setBackground(Color.WHITE);

			//panel4.setBorder(border);
			panel4.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
			panel4.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
			panel4.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));

			btnDeleteEvent = new JButton("Delete");
			btnDeleteEvent.setCursor(new Cursor(Cursor.HAND_CURSOR));
			btnDeleteEvent.setPreferredSize(new Dimension(170,UI_Settings.getJbuttonSize().height));
			btnDeleteEvent.setMinimumSize(new Dimension(170,UI_Settings.getJbuttonSize().height));
			btnDeleteEvent.setFont(UI_Settings.getComponentInputFontSize());
			btnDeleteEvent.addMouseListener(new MouseAdapter(){
				
				public void mouseReleased(MouseEvent e){
					
					int row = viewall_table_panel.getSelectedRow();
					
					viewall_table_panel.deleteRow(row);
				}
				
				
			});
			
			labels[6].setCursor(UI_Settings.getJlabelCursor());
			labels[6].addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){
					
					JOptionPane.showMessageDialog(controllingFrame,
			                "The administrator password can be found with the \"Kids Coordinator\"\n"
			              + "or by contacting your \"Branch Manager\".");
					
				}
			});
			
			JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
			adminPanel.setBackground(Color.WHITE);
			adminPanel.add(new JLabel("Administrator password:"));
			adminPanel.add(passwordField);
			adminPanel.add(labels[6]);
			adminPanel.add(btnDeleteEvent);

			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTH;
			gc.insets = new Insets(15,-5,0,-5);
			
			panel4.add(adminPanel, gc);
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHEAST;
			gc.insets = new Insets(0,0,0,15);
			pblButtons.add(labels[0], gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHEAST;
			gc.insets = new Insets(-10,0,0,10);
			
			pblButtons.add(panel4, gc);
			
			//Add the comments panel	
			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,-5,0,0);
			
			pnlSaveRight.add(pblButtons, gc);
			
			//Add the nested panels to the container panel (information panel)
			pnlSaveRow.add(pnlSaveRight, gc);
		
		//Add the nested panels to the container panel (information panel)
		pnlInformation.add(pnlSaveRow, gc);
		
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());

        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        viewall_table_panel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(viewall_table_panel);

        centerPanel.add(Box.createVerticalStrut(10));
        
        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlInformation);
        
		/*********************************************************************************************************************************/
		/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 850));
		
			//Add the details section and table sections to the canvas.
		canvas.add(header, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scroller.setBorder(BorderFactory.createEmptyBorder());		
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return scroller;
		
	}
	
	private void addFocus(JTextField jTextField) {
		jTextField.addFocusListener(new FocusListener() {
		      public void focusGained(FocusEvent e) {
		        jTextField.setText("");
		      }

		      public void focusLost(FocusEvent e) {
		    	  
		      }
		    });
	}


	public void setFormListener(FormListener listener){
		this.formListener = listener;
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
	
	private void configure_checkboxes_age() {
		
		ItemListener listener = new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				
				if(e.getStateChange() == ItemEvent.SELECTED){
					
					if(e.getItem() == checkboxes.get(0)){
						resetCheckBoxDays(0);
					}
					
					if(e.getItem() == checkboxes.get(1)){
						resetCheckBoxDays(1);
					}
					
					if(e.getItem() == checkboxes.get(2)){
						resetCheckBoxDays(2);
					}
					
					if(e.getItem() == checkboxes.get(3)){
						resetCheckBoxDays(3);
					}
					if(e.getItem() == checkboxes.get(4)){
						resetCheckBoxDays(4);
					}
				}
			}

			private void resetCheckBoxDays(int j) {
				
				for(int i = 0; i < checkboxes.size(); i++){
					if(j != i){
						checkboxes.get(i).setSelected(false);
					}
				}
				
			}
		};
		
		for(int i = 0; i < checkboxes.size(); i++){
			checkboxes.get(i).addItemListener(listener);
		}
	}


	public void refresh() {
		addnew_table_panel.refresh();
		viewall_table_panel.refresh();
	}



	public void resetPanels() {
		container.setVisible(true);
		container_left.setVisible(true);
		container_right.setVisible(true);
		threeDotsPanel.setVisible(false);
	}


	public void switchTabs() {
		pane.setSelectedIndex(1);
	}
	
	private void initializeComboBoxes(JComboBox<String> comboboxes) {
		
		comboboxes.setFont(UI_Settings.getComponentInputFontSize());
		comboboxes.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		comboboxes.setMinimumSize(comboboxes.getPreferredSize());
		
		this.comboboxes.add(comboboxes);		
	}
	
	private final static int GET_VIEWALL_TABLE_CUSTOMER_LIST = 1;
	private final static int GET_ADDNEW_TABLE_CUSTOMER_LIST = 2;

}
