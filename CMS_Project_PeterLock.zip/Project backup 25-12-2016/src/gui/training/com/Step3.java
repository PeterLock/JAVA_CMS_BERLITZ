package gui.training.com;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.border.Border;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import settings.UI_Settings;

public class Step3 extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private Dimension headerDimension = new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100);
	
	CreateTrainingSessionPanel sessionObject;
	private int height = 600;
	private int width = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
	
	private JPanel panel;
	private JPanel container;
	private JPanel containerLeft;
	private JPanel containerRight;
	private IntroductionPanel introductionPanel = new IntroductionPanel(width, height);
	private MainSessionPanel mainsessionPanel = new MainSessionPanel(width, height);
	
	private GridBagConstraints gc = new GridBagConstraints();
	

	
	private JLabel nextStepTextButton = new JLabel("Next Step");
	private JLabel previousStepTextButton = new JLabel("Previous Step");

	public Step3(){
		
		intialize();

	}
	

	private void intialize() {
		
		initializeListeners();
		
	}
	
	public JPanel run(CreateTrainingSessionPanel sessionObject){
		
		this.sessionObject = sessionObject;
		
		panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.setBackground(Color.WHITE);
		setPanelSize(panel, new Dimension(new Dimension(width, 800)));
		/////////////////////////////////////////////////////////////////////////////////

		addHeadingAndSubText();
		addMaterialBody();
		
		addNextStepRow();
		
		/////////////////////////////////////////////////////////////////////////////////
		return panel;
	}

	private void addMaterialBody() {
		
		//Add the main container//
		container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(headerDimension.width, height));
		container.setBackground(Color.WHITE);
		
		//Add the left section of the main container//
		containerLeft = new JPanel(new GridBagLayout());
		setPanelSize(containerLeft, new Dimension(headerDimension.width/3+150, height));
		containerLeft.setBackground(Color.WHITE);
		
		//Add the right section of the main container//
		containerRight = new JPanel(new GridBagLayout());
		setPanelSize(containerRight, new Dimension(headerDimension.width/3-150, height));
		containerRight.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(5,40,5,20);
		containerLeft.add(introductionPanel.run(), gc);
		
		gc.gridx = 1;
		gc.insets = new Insets(5,0,5,5);
		containerLeft.add(mainsessionPanel.run(), gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,0,0,0);
		container.add(containerLeft, gc);
		
		gc.gridx = 1;
		container.add(containerRight, gc);
		
		this.panel.add(container, gc);
	}


	private JPanel getMainSessionPanel() {
		
		JPanel container = new JPanel();
		container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
		setPanelSize(container, new Dimension(width/2, height));
		container.setBackground(Color.PINK);

		
		return container;
	}


	private JPanel getIntroductionPanel() {
		return container;
	}


	private void initializeListeners() {
		
		nextStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		nextStepTextButton.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				JScrollPane scroller = sessionObject.getScroller();
				
				 if(scroller != null){
					 scroller.getViewport().setViewPosition(new Point(0,0));
				 }
				
				 sessionObject.resetLocatorColors();
				 sessionObject.locator4.setBackground(CreateTrainingSessionPanel.LOCATOR_ACTIVE_COLOR);
				 CardLayout cl = (CardLayout)(sessionObject.cards.getLayout());
				 cl.show(sessionObject.cards, CreateTrainingSessionPanel.STEP4);
			}
		});
		
		previousStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		previousStepTextButton.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				
				JScrollPane scroller = sessionObject.getScroller();
				
				 if(scroller != null){
					 scroller.getViewport().setViewPosition(new Point(0,0));
				 }
				
				 sessionObject.resetLocatorColors();
				 sessionObject.locator2.setBackground(CreateTrainingSessionPanel.LOCATOR_ACTIVE_COLOR);
				 CardLayout cl = (CardLayout)(sessionObject.cards.getLayout());
				 cl.show(sessionObject.cards, CreateTrainingSessionPanel.STEP2);
			}
		});
	}



	private void addNextStepRow() {
		nextStepTextButton.setFont(nextStepTextButton.getFont().deriveFont(14.0f));
		previousStepTextButton.setFont(previousStepTextButton.getFont().deriveFont(14.0f));


		JPanel container = new JPanel();
		container.setBackground(Color.WHITE);
		container.setLayout(new BoxLayout(container, BoxLayout.X_AXIS));
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(previousStepTextButton);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(nextStepTextButton);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		container.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		container.add(rightPanel);
		
		panel.add(Box.createVerticalStrut(10));
		panel.add(container);
	}



	private void addHeadingAndSubText() {
		
		JPanel pageHeader = new JPanel();
		pageHeader.setLayout(new BoxLayout(pageHeader, BoxLayout.Y_AXIS));
		pageHeader.setBackground(Color.WHITE);
		setPanelSize(pageHeader, headerDimension);
		/////////////////////////////////////////////////////////////////////////////////
		
		JLabel pageTitle = new JLabel("Step 3: Organize Material");
		pageTitle.setFont(pageTitle.getFont().deriveFont(16.0f));
		
		/////////////////////////////////////////////////////////////////////////////////
		JPanel pageTitlePanel = new JPanel();
		pageTitlePanel.setBackground(UI_Settings.getButtonPanelColor());
		pageTitlePanel.setLayout(new BoxLayout(pageTitlePanel, BoxLayout.X_AXIS));
		pageTitlePanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		pageTitlePanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		pageTitlePanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(pageTitle);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));

		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		pageTitlePanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pageTitlePanel.add(rightPanel);
		/////////////////////////////////////////////////////////////////////////////////
		JPanel pageHeaderTextPanel = new JPanel(new GridBagLayout());
		setPanelSize(pageHeaderTextPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 70));
		pageHeaderTextPanel.setBackground(Color.WHITE);

		JTextPane pageHeaderTextRow1 = new JTextPane();
		pageHeaderTextRow1.setFont(pageHeaderTextRow1.getFont().deriveFont(11.0f));
		pageHeaderTextRow1.setForeground(UI_Settings.getComponentsFontColorDark());
		pageHeaderTextRow1.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(pageHeaderTextRow1.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.5);
		
		pageHeaderTextRow1.setParagraphAttributes(set, true);
		
		pageHeaderTextRow1.setText("Once you have a general idea of what you need to cover, "
				+ "draft a lesson outline. List all of the points that you need to cover, "
				+ "in the order in which you'll cover them.");
		
		JTextPane pageHeaderTextRow2 = new JTextPane();
		pageHeaderTextRow2.setFont(pageHeaderTextRow2.getFont().deriveFont(11.0f));
		pageHeaderTextRow2.setForeground(UI_Settings.getComponentsFontColorDark());
		pageHeaderTextRow2.setEditable(false);
		
		set = new SimpleAttributeSet(pageHeaderTextRow2.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.5);
		
		pageHeaderTextRow2.setParagraphAttributes(set, true);
		pageHeaderTextRow2.setText("Use the 5 E Learning Cycle to link information to trainees "
				+ "existing skills and knowledge. This will help them put it into a personal context, "
				+ "which, in turn, will help them retain it better.");
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,20,0,20);
		pageHeaderTextPanel.add(pageHeaderTextRow1,gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(-10,45,10,0);
		pageHeaderTextPanel.add(pageHeaderTextRow2,gc);
		/////////////////////////////////////////////////////////////////////////////////
		pageHeader.add(Box.createVerticalStrut(16));

		pageTitlePanel.setAlignmentY(Component.LEFT_ALIGNMENT);
		pageHeader.add(pageTitlePanel);
		
		pageHeaderTextPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
		pageHeader.add(pageHeaderTextPanel);
		
		this.panel.add(pageHeader);
	}
	

	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
}
