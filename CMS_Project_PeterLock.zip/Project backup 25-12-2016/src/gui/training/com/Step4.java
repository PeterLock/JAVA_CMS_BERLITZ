package gui.training.com;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagLayout;

import javax.swing.JPanel;

public class Step4 extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
	
	public Step4(){
		
	}
	
	public JPanel run(){
		
		JPanel panel = new JPanel(new GridBagLayout());
		panel.setBackground(Color.PINK);
		setPanelSize(panel, new Dimension(new Dimension(screenWidth, 500)));
		
		return panel;
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}

}
