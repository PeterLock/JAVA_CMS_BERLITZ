package gui.training.com;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.Border;

import settings.UI_Settings;
import utilities.JTextFieldLimit;

public class MainSessionPanel extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private GridBagConstraints gc = new GridBagConstraints();
	private int width;
	private int height;
	private JPanel container;
	private JPanel header;
	private JPanel mainSection;
	private JLabel headerLabel;
	
	private String containerFontType = "Courier";
	private int headerHeight = 50;
	
	private JTextArea txtAreaSessionOne;
	private JTextArea txtAreaSessionTwo;
	
	List <JLabel> labels = new ArrayList<JLabel>();
	
	private Border border = BorderFactory.createLineBorder(new Color(180,180,180));
	
	private Color fontcolor = new Color(102,102,102);
	
	public MainSessionPanel(int width, int height){
		
		this.width = width/2;
		this.height = height;
		
		initialize();
		
	}

	private void initialize() {
		
		headerLabel = new JLabel("Main session");

		
		txtAreaSessionOne = new JTextArea(8, 20);
		txtAreaSessionOne.setEditable(true);
		txtAreaSessionOne.setBorder(UI_Settings.getBorderoutline());
		txtAreaSessionOne.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaSessionOne.setWrapStyleWord(true);
		txtAreaSessionOne.setLineWrap(true);
		txtAreaSessionOne.setDocument(new JTextFieldLimit(80));
		txtAreaSessionOne.setBorder(border);
		txtAreaSessionOne.setPreferredSize(txtAreaSessionOne.getPreferredSize());
		
		txtAreaSessionTwo = new JTextArea(6, 20);
		txtAreaSessionTwo.setEditable(true);
		txtAreaSessionTwo.setBorder(UI_Settings.getBorderoutline());
		txtAreaSessionTwo.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaSessionTwo.setWrapStyleWord(true);
		txtAreaSessionTwo.setLineWrap(true);
		txtAreaSessionTwo.setDocument(new JTextFieldLimit(80));
		txtAreaSessionTwo.setBorder(border);
		txtAreaSessionTwo.setPreferredSize(txtAreaSessionTwo.getPreferredSize());
	}

	public JPanel run(){
		
		JPanel container = setUpMainContainer();
		
		return container;
	}
	
	private JPanel setUpMainContainer() {
		
		int count = 0;
		int offset = 0;
		
		//String containerFontType = headerLabel.getFont().getFontName();
		
		container = new JPanel();
		container.setLayout(new GridBagLayout());
		setPanelSize(container, new Dimension(width, height));
		container.setBackground(Color.WHITE);
		
		//Add the header//
		header = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 18));
		setPanelSize(header, new Dimension(width, headerHeight));
		header.setBackground(new Color(25,120,174));
		headerLabel.setFont(new Font(containerFontType, Font.BOLD, (int)12.0f));
		
		headerLabel.setForeground(Color.WHITE);
		header.add(headerLabel);
		
		gc.gridx = 0;
		gc.gridy = count;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.insets = new Insets(0,0,2,0);
		container.add(header, gc);
		
		offset = headerHeight+headerHeight/2;
		
		//Add the body of this container - this holds the session briefing, session notes 1, and session notes 2//
		mainSection = new JPanel();
		mainSection.setLayout(new GridBagLayout());
		mainSection.setBackground(Color.PINK);
		setPanelSize(mainSection, new Dimension(width, this.height-offset+3));
		mainSection.setBorder(border);
		
		
		gc.gridy = ++count;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.fill = GridBagConstraints.NONE;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.insets = new Insets(0,0,7,0);
		container.add(mainSection, gc);
		
		return container;
	}

	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
}
